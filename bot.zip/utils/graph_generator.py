"""
Graph Generator for VPS Metrics
Generates matplotlib graphs for CPU, RAM, Disk, I/O, and Network usage
"""

import matplotlib
matplotlib.use('Agg') # Use non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import io
import logging
from typing import Optional

from utils.database import db

logger = logging.getLogger(__name__)

class MetricsGraphGenerator:
 """
 Generates graphs for VPS metrics
 """
 
 def __init__(self):
 self.fig_size = (12, 8)
 self.dpi = 100
 
 async def generate_metrics_graph(self, container_name: str, hours: int = 24) -> Optional[io.BytesIO]:
 """
 Generate a comprehensive metrics graph for a VPS
 
 Args:
 container_name: Container name
 hours: Number of hours of history to display
 
 Returns:
 BytesIO object containing the PNG image, or None if failed
 """
 try:
 # Get metrics history
 metrics = db.get_metrics_history(container_name, hours)
 
 if not metrics:
 logger.warning(f\"No metrics found for {container_name}\")
 return None
 
 # Extract data
 timestamps = [m['recorded_at'] for m in metrics]
 cpu_data = [m['cpu_percent'] or 0 for m in metrics]
 ram_data = [m['ram_mb'] or 0 for m in metrics]
 disk_data = [m['disk_mb'] / 1024 or 0 for m in metrics] # Convert to GB
 io_read_data = [m['disk_io_read_mb'] or 0 for m in metrics]
 io_write_data = [m['disk_io_write_mb'] or 0 for m in metrics]
 net_rx_data = [m['network_rx_mb'] or 0 for m in metrics]
 net_tx_data = [m['network_tx_mb'] or 0 for m in metrics]
 
 # Create figure with subplots
 fig, axes = plt.subplots(5, 1, figsize=self.fig_size, dpi=self.dpi)
 fig.suptitle(f'VPS Metrics - {container_name}\\nLast {hours} hours', fontsize=16, fontweight='bold')
 
 # 1. CPU Usage
 axes[0].plot(timestamps, cpu_data, color='#3498db', linewidth=2)
 axes[0].fill_between(timestamps, cpu_data, alpha=0.3, color='#3498db')
 axes[0].axhline(y=80, color='orange', linestyle='--', label='Warning (80%)')
 axes[0].axhline(y=95, color='red', linestyle='--', label='Critical (95%)')
 axes[0].set_ylabel('CPU (%)', fontweight='bold')
 axes[0].set_title('CPU Usage', fontweight='bold')
 axes[0].legend(loc='upper right')
 axes[0].grid(True, alpha=0.3)
 axes[0].set_ylim(0, 100)
 
 # 2. RAM Usage
 axes[1].plot(timestamps, ram_data, color='#2ecc71', linewidth=2)
 axes[1].fill_between(timestamps, ram_data, alpha=0.3, color='#2ecc71')
 axes[1].set_ylabel('RAM (MB)', fontweight='bold')
 axes[1].set_title('RAM Usage', fontweight='bold')
 axes[1].grid(True, alpha=0.3)
 
 # 3. Disk Usage
 axes[2].plot(timestamps, disk_data, color='#9b59b6', linewidth=2)
 axes[2].fill_between(timestamps, disk_data, alpha=0.3, color='#9b59b6')
 axes[2].set_ylabel('Disk (GB)', fontweight='bold')
 axes[2].set_title('Disk Usage', fontweight='bold')
 axes[2].grid(True, alpha=0.3)
 
 # 4. Disk I/O
 axes[3].plot(timestamps, io_read_data, color='#e74c3c', linewidth=2, label='Read')
 axes[3].plot(timestamps, io_write_data, color='#e67e22', linewidth=2, label='Write')
 axes[3].fill_between(timestamps, io_read_data, alpha=0.2, color='#e74c3c')
 axes[3].fill_between(timestamps, io_write_data, alpha=0.2, color='#e67e22')
 axes[3].axhline(y=100, color='orange', linestyle='--', label='Warning (100 MB/s)')
 axes[3].set_ylabel('I/O (MB/s)', fontweight='bold')
 axes[3].set_title('Disk I/O Activity', fontweight='bold')
 axes[3].legend(loc='upper right')
 axes[3].grid(True, alpha=0.3)
 
 # 5. Network Activity
 axes[4].plot(timestamps, net_rx_data, color='#1abc9c', linewidth=2, label='RX (Download)')
 axes[4].plot(timestamps, net_tx_data, color='#16a085', linewidth=2, label='TX (Upload)')
 axes[4].fill_between(timestamps, net_rx_data, alpha=0.2, color='#1abc9c')
 axes[4].fill_between(timestamps, net_tx_data, alpha=0.2, color='#16a085')
 axes[4].axhline(y=500, color='orange', linestyle='--', label='Warning (500 MB/s)')
 axes[4].set_ylabel('Network (MB/s)', fontweight='bold')
 axes[4].set_title('Network Activity', fontweight='bold')
 axes[4].set_xlabel('Time', fontweight='bold')
 axes[4].legend(loc='upper right')
 axes[4].grid(True, alpha=0.3)
 
 # Format x-axis for all subplots
 for ax in axes:
 ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
 ax.xaxis.set_major_locator(mdates.HourLocator(interval=2))
 plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
 
 # Adjust layout
 plt.tight_layout()
 
 # Save to BytesIO
 buf = io.BytesIO()
 plt.savefig(buf, format='png', bbox_inches='tight')
 buf.seek(0)
 plt.close(fig)
 
 return buf
 
 except Exception as e:
 logger.error(f\"Failed to generate metrics graph: {e}\")
 return None
 
 async def create_monitoring_embed(self) -> discord.Embed:
 """Create the monitoring embed with all VPS metrics"""
 
 # Get all VPS with their latest metrics
 all_vps = db.get_all_vps()
 latest_metrics = db.get_all_latest_metrics()
 
 # Create a map of container_name -> metrics
 metrics_map = {m['container_name']: m for m in latest_metrics}
 
 # Separate LXC and KVM
 lxc_vps = [v for v in all_vps if v.get('vps_type') == 'lxc' and v.get('is_active') and not v.get('is_suspended')]
 kvm_vps = [v for v in all_vps if v.get('vps_type') == 'kvm' and v.get('is_active') and not v.get('is_suspended')]
 
 # Create embed
 embed = discord.Embed(
 title=\"VPS Monitoring Dashboard\",
 description=f\"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\",
 color=discord.Color.blue()
 )
 
 # LXC Section
 if lxc_vps:
 lxc_text = \"\"
 
 for vps in lxc_vps[:15]: # Limit to 15 to avoid embed size limits
 container_name = vps['container_name']
 user_id = vps['user_id']
 
 # Get metrics
 metrics = metrics_map.get(container_name)
 
 if metrics:
 cpu = metrics.get('cpu_percent', 0)
 ram = metrics.get('ram_mb', 0)
 disk = metrics.get('disk_mb', 0) / 1024 # Convert to GB
 io_read = metrics.get('disk_io_read_mb', 0)
 io_write = metrics.get('disk_io_write_mb', 0)
 net_rx = metrics.get('network_rx_mb', 0)
 net_tx = metrics.get('network_tx_mb', 0)
 
 lxc_text += f\"**{container_name}** | <@{user_id}> ({user_id})\\n\"
 lxc_text += f\"CPU: {cpu:.1f}% | RAM: {ram:.0f}MB | Disk: {disk:.1f}GB\\n\"
 lxc_text += f\"I/O: R:{io_read:.1f}MB W:{io_write:.1f}MB | Net: RX:{net_rx:.1f}MB TX:{net_tx:.1f}MB\\n\\n\"
 else:
 lxc_text += f\"**{container_name}** | <@{user_id}> ({user_id})\\n\"
 lxc_text += f\"No metrics available\\n\\n\"
 
 if len(lxc_vps) > 15:
 lxc_text += f\"... and {len(lxc_vps) - 15} more LXC containers\\n\"
 
 embed.add_field(
 name=\"LXC Containers\",
 value=lxc_text if lxc_text else \"No active LXC containers\",
 inline=False
 )
 
 # Separator
 if lxc_vps and kvm_vps:
 embed.add_field(
 name=\"\\u200b\",
 value=\"\" * 50,
 inline=False
 )
 
 # KVM Section
 if kvm_vps:
 kvm_text = \"\"
 
 for vps in kvm_vps[:15]: # Limit to 15
 container_name = vps['container_name']
 user_id = vps['user_id']
 
 # Get metrics
 metrics = metrics_map.get(container_name)
 
 if metrics:
 cpu = metrics.get('cpu_percent', 0)
 ram = metrics.get('ram_mb', 0)
 disk = metrics.get('disk_mb', 0) / 1024 # Convert to GB
 io_read = metrics.get('disk_io_read_mb', 0)
 io_write = metrics.get('disk_io_write_mb', 0)
 net_rx = metrics.get('network_rx_mb', 0)
 net_tx = metrics.get('network_tx_mb', 0)
 
 kvm_text += f\"**{container_name}** | <@{user_id}> ({user_id})\\n\"
 kvm_text += f\"CPU: {cpu:.1f}% | RAM: {ram:.0f}MB | Disk: {disk:.1f}GB\\n\"
 kvm_text += f\"I/O: R:{io_read:.1f}MB W:{io_write:.1f}MB | Net: RX:{net_rx:.1f}MB TX:{net_tx:.1f}MB\\n\\n\"
 else:
 kvm_text += f\"**{container_name}** | <@{user_id}> ({user_id})\\n\"
 kvm_text += f\"No metrics available\\n\\n\"
 
 if len(kvm_vps) > 15:
 kvm_text += f\"... and {len(kvm_vps) - 15} more KVM containers\\n\"
 
 embed.add_field(
 name=\"KVM Containers\",
 value=kvm_text if kvm_text else \"No active KVM containers\",
 inline=False
 )
 
 # Summary
 total_vps = len(lxc_vps) + len(kvm_vps)
 embed.set_footer(text=f\"Total Active VPS: {total_vps} | LXC: {len(lxc_vps)} | KVM: {len(kvm_vps)}\")
 
 return embed
 
 def stop(self):
 \"\"\"Stop the monitoring task\"\"\"
 if self.update_monitoring.is_running():
 self.update_monitoring.cancel()
 logger.info(\"VPS Monitoring task stopped\")
