import discord
from discord.ext import commands

class TutoEarnCredits(commands.Cog):
 def __init__(self, bot):
 self.bot = bot

 @commands.hybrid_command(name="tuto-earn-credits", description="Learn how to earn credits easily.")
 async def earn_credits(self, ctx):
 embed = discord.Embed(
 title="How to easily earn credits",
 description=(
 "1. Invite friends or promote via platforms like YouTube, TikTok, Twitter, etc., with your Discord server link.\n\n"
 "2. Server boosting is currently the fastest way to earn credits; you can get 200 credits per boost.\n\n"
 ),
 color=0xE5E6EB
 )
 await ctx.send(embed=embed)

async def setup(bot):
 await bot.add_cog(TutoEarnCredits(bot))