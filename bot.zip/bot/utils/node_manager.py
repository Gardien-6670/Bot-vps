import os
import re
import aiohttp
import asyncio
import logging
from utils.database import db

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class NodeConnectionError(Exception):
 """Custom exception for node connection or timeout errors."""
 pass

def get_nodes():
 """
 Reads node configurations from environment variables and supports non-sequential numbering.
 Finds all NODE_X_URL variables and loads the corresponding configuration for each number X.
 """
 nodes = {}
 node_numbers = set()
 
 # First, find all defined node numbers by looking for NODE_X_URL variables
 for env_var in os.environ:
 match = re.match(r'NODE_(\d+)_URL', env_var)
 if match:
 node_numbers.add(int(match.group(1)))

 # Now, iterate through the found node numbers and load their config
 for i in sorted(list(node_numbers)):
 url = os.getenv(f'NODE_{i}_URL')
 # This check is technically redundant now but good for safety
 if not url:
 continue

 api_key = os.getenv(f'NODE_{i}_API_KEY', os.getenv('API_KEY'))
 ip = os.getenv(f'NODE_{i}_IP')
 domain = os.getenv(f'NODE_{i}_DOMAIN')
 max_lxc_str = os.getenv(f'NODE_{i}_MAX_LXC', '0')
 max_kvm_str = os.getenv(f'NODE_{i}_MAX_KVM', '0')
 premium_str = os.getenv(f'NODE_{i}_PREMIUM', 'false')

 try:
 max_lxc = int(max_lxc_str)
 max_kvm = int(max_kvm_str)
 except ValueError:
 logging.warning(f"Invalid MAX_LXC or MAX_KVM value for NODE_{i}. Using 0.")
 max_lxc = 0
 max_kvm = 0

 is_premium = premium_str.lower() in ['true', '1', 'yes']

 node_type = 'lxc' if max_lxc > 0 else 'kvm'

 nodes[f'node{i}'] = {
 "url": url,
 "api_key": api_key,
 "ip": ip,
 "domain": domain,
 "max_lxc": max_lxc,
 "max_kvm": max_kvm,
 "premium": is_premium,
 "type": node_type,
 }

 # Fallback to single API_URL if no NODE_n_URL is defined
 if not nodes:
 api_url = os.getenv('API_URL')
 if api_url:
 nodes['node1'] = {
 "url": api_url,
 "api_key": os.getenv('API_KEY'),
 "ip": os.getenv('NODE_IP'),
 "domain": os.getenv('NODE_DOMAIN'),
 "max_lxc": int(os.getenv('MAX_LXC', '50')),
 "max_kvm": int(os.getenv('MAX_KVM', '10')),
 "premium": False,
 "type": "lxc",
 }
 logging.info("Using single API_URL as node1.")

 logging.info(f"Loaded {len(nodes)} nodes from environment variables.")
 return nodes

NODES = get_nodes()

async def get_node_stats(node_name, node_info):
 """Fetches stats for a single node."""
 headers = {"X-API-KEY": node_info.get("api_key") or ""}
 lxc_count = 0 # Initialize to 0
 kvm_count = 0 # Initialize to 0
 
 try:
 async with aiohttp.ClientSession() as session:
 # Get LXC stats
 async with session.get(f"{node_info['url']}/lxc/stats", headers=headers, timeout=5) as resp:
 if resp.status == 200:
 data = await resp.json()
 lxc_count = data.get('total_containers', 0) # Use total_containers
 else:
 logging.warning(f"Failed to get LXC stats from {node_name} ({node_info['url']}): Status {resp.status}")
 
 # Get KVM stats
 async with session.get(f"{node_info['url']}/kvm/stats", headers=headers, timeout=5) as resp:
 if resp.status == 200:
 data = await resp.json()
 kvm_count = data.get('total_vms', 0) # Use total_vms
 else:
 logging.warning(f"Failed to get KVM stats from {node_name} ({node_info['url']}): Status {resp.status}")

 except (aiohttp.ClientError, asyncio.TimeoutError) as e:
 logging.error(f"Could not connect to node {node_name} ({node_info['url']}) to get stats: {e}")

 return {
 "lxc_current": lxc_count, # Now represents total count
 "kvm_current": kvm_count, # Now represents total count
 "lxc_max": node_info["max_lxc"],
 "kvm_max": node_info["max_kvm"]
 }

async def find_best_node(vps_type: str):
 """
 Finds the best node to create a new VPS on, based on capacity.
 """
 if not NODES:
 logging.error("No nodes configured. Cannot find a node for VPS creation.")
 return None, None

 best_node = None
 min_load = float('inf')

 tasks = [get_node_stats(name, info) for name, info in NODES.items()]
 results = await asyncio.gather(*tasks)

 node_names = list(NODES.keys())

 for i, stats in enumerate(results):
 node_name = node_names[i]
 
 if vps_type == 'lxc':
 current = stats['lxc_current']
 max_cap = stats['lxc_max']
 elif vps_type == 'kvm':
 current = stats['kvm_current']
 max_cap = stats['kvm_max']
 else:
 continue

 if current >= max_cap:
 logging.warning(f"Node {node_name} is at full capacity for {vps_type.upper()}s ({current}/{max_cap}).")
 continue

 # Calculate load as a percentage of capacity
 load = (current / max_cap) if max_cap > 0 else float('inf')

 if load < min_load:
 min_load = load
 best_node = node_name
 
 if best_node:
 logging.info(f"Selected node '{best_node}' for new {vps_type.upper()} VPS.")
 return best_node, NODES[best_node]
 
 logging.error(f"No available node found for a new {vps_type.upper()} VPS.")
 return None, None

def get_node_for_vps(container_name: str):
 """
 Gets the node info dictionary for a given container name.
 """
 vps_info = db.get_vps_by_container_name(container_name)
 if not vps_info:
 logging.error(f"Could not find VPS {container_name} in database to determine its node.")
 return None

 node_name = vps_info.get('node')
 if not node_name:
 if 'node1' in NODES:
 logging.warning(f"VPS {container_name} has no node assigned. Defaulting to 'node1'.")
 return NODES['node1']
 elif NODES:
 first_node_name = list(NODES.keys())[0]
 logging.warning(f"VPS {container_name} has no node assigned and 'node1' is not configured. Defaulting to first node '{first_node_name}'.")
 return NODES[first_node_name]
 else:
 logging.error("No nodes configured, cannot determine node for existing VPS.")
 return None

 node_info = NODES.get(node_name)
 if not node_info:
 logging.error(f"Node '{node_name}' for VPS {container_name} is not configured in environment variables.")
 return None

 return node_info

async def api_request(method: str, endpoint: str, node_url: str, api_key: str, data: dict | None = None, timeout_seconds: int = 300):
 """
 Sends an API request to a specific node.
 """
 headers = {
 "X-API-KEY": api_key or "",
 "Content-Type": "application/json"
 }
 # Ensure the node_url doesn't have a trailing slash and the endpoint has a leading one
 url = f"{node_url.rstrip('/')}/{endpoint.lstrip('/')}"
 timeout = aiohttp.ClientTimeout(total=timeout_seconds)

 logging.info(f"Attempting API request: {method} {url}")

 try:
 async with aiohttp.ClientSession(timeout=timeout) as session:
 async with session.request(method, url, headers=headers, json=data) as response:
 if 'application/json' in response.content_type:
 json_response = await response.json()
 if response.status >= 400:
 logging.error(f"API Error: {method} {url} returned status {response.status}.")
 logging.error(f"Response Body: {json_response}")
 logging.error("Please check your NODE_X_URL and NODE_X_API_KEY environment variables.")
 return json_response
 else:
 response_text = await response.text()
 if response.status >= 400:
 logging.error(f"API Error: {method} {url} returned status {response.status}.")
 logging.error(f"Response Body: {response_text}")
 logging.error("Please check your NODE_X_URL and NODE_X_API_KEY environment variables.")
 return None
 else:
 return {"status": response.status, "text": response_text}

 except aiohttp.ClientConnectorError as e:
 logging.error(f"API Connection Error: Failed to connect to {url}. Please ensure the NODE_X_URL is correct and the node is accessible.")
 logging.error(f"Details: {e}")
 raise NodeConnectionError(f"Failed to connect to node {url}: {e}") from e
 except asyncio.TimeoutError:
 logging.error(f"API Timeout Error: Request to {url} timed out after {timeout_seconds} seconds.")
 raise NodeConnectionError(f"Node API request timed out for {url}")
 except Exception as e:
 logging.error(f"An unexpected error occurred during the API request to {url}: {e}")
 raise NodeConnectionError(f"Unexpected error during API request to {url}: {e}") from e
