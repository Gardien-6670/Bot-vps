"""
Main surveillance module that regroups all surveillance systems.
This file provides a unified interface for all VPS surveillance tasks.
"""

from .dedi import SurveillanceDedi
from .kvm import SurveillanceKVM
from .lxc_mining import SurveillanceLXC
from .lxc_protection import AntiDDoSMonitorLXC
from .ui_views import UnsuspendView, ConfirmUnsuspendView
from .rate_limiter import PerMinuteRateLimiter

__all__ = [
    'SurveillanceDedi',
    'SurveillanceKVM',
    'SurveillanceLXC',
    'AntiDDoSMonitorLXC',
    'UnsuspendView',
    'ConfirmUnsuspendView',
    'PerMinuteRateLimiter',
]
