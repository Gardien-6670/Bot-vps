import os
import random
import string
import asyncio
import aiohttp
from datetime import datetime, timedelta
from flask import Flask, render_template_string, redirect, request, url_for, jsonify
from dotenv import load_dotenv
import logging
from linkvertise import LinkvertiseClient
import pytz

# Load environment variables
load_dotenv()

from .database import db

app = Flask(__name__)

linkvertise_client = LinkvertiseClient()

def generate_random_token(length=30):
    """Generates a random alphanumeric string of specified length."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for i in range(length))

def is_valid_token(token: str) -> bool:
    """
    Vérifie si un token est valide.
    Accepte les tokens de 30 à 32 caractères pour rétrocompatibilité.
    """
    if not token:
        return False
    token_len = len(token)
    if token_len < 30 or token_len > 32:
        return False
    # Vérifie que le token contient uniquement des caractères alphanumériques
    return token.isalnum()


# Configure Flask logging
app.logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
app.logger.addHandler(handler)

CUTY_IO_API_TOKEN = os.getenv("CUTY_IO_API_TOKEN")
FLASK_BIND_HOST = os.getenv("FLASK_HOST", "0.0.0.0")
FLASK_PORT = 6028
# SSL Configuration (optionnel)
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"
SSL_CERT = os.getenv("SSL_CERT_PATH", "/etc/letsencrypt/live/api-veridian.duckdns.org/fullchain.pem")
SSL_KEY = os.getenv("SSL_KEY_PATH", "/etc/letsencrypt/live/api-veridian.duckdns.org/privkey.pem")

CODE_PAGE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Code</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #2c2f33; color: #ffffff; text-align: center; padding: 50px; margin: 0; }
        .container { background-color: #23272a; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); max-width: 600px; }
        h1 { color: #5cb85c; margin-bottom: 20px; }
        .subtitle { font-size: 0.95em; color: #99aab5; margin-bottom: 30px; }
        .code-label { font-size: 0.95em; color: #b0b5b8; margin-bottom: 15px; }
        .code-display { font-size: 3em; font-weight: bold; color: #7289da; padding: 20px; border: 2px dashed #7289da; border-radius: 5px; display: inline-block; user-select: all; margin: 20px 0; letter-spacing: 10px; }
        .button-container { display: flex; justify-content: center; gap: 15px; margin-top: 30px; }
        .btn { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; transition: background-color 0.3s; }
        .btn-primary { background-color: #7289da; color: white; }
        .btn-primary:hover { background-color: #5b6eae; }
        .btn-secondary { background-color: #404040; color: white; }
        .btn-secondary:hover { background-color: #505050; }
        .info-text { font-size: 0.9em; color: #b0b5b8; margin-top: 25px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ad Watched Successfully!</h1>
        <p class="subtitle">Your code from the ad provider:</p>
        
        <p class="code-label">Enter this code on the previous page:</p>
        <div class="code-display" id="codeDisplay">{{ code }}</div>
        
        <div class="button-container">
            <button class="btn btn-primary" onclick="copyCode()">Copy Code</button>
            <button class="btn btn-secondary" onclick="goBack()">Return to Home</button>
        </div>
        
        <p class="info-text">You can now watch another ad or enter this code on the home page.</p>
    </div>

            <script>
                const codeDisplay = document.getElementById('codeDisplay');
                
                function copyCode() {
                    navigator.clipboard.writeText('{{ code }}').then(() => {
                        alert('Code copied!');
                    });
                }
                
                function goBack() {
                    window.location.href = `/watch-ads/{{ user_id }}/{{ token }}`;
                }
            </script></body>
</html>
"""

CHOICE_PAGE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch Ads & Earn VPS Points</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #2c2f33; color: #ffffff; text-align: center; padding: 50px; margin: 0; }
        .container { background-color: #23272a; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); max-width: 700px; }
        h1 { color: #7289da; margin-bottom: 30px; }
        .subtitle { font-size: 0.95em; color: #99aab5; margin-bottom: 30px; }
        .section { margin: 30px 0; }
        .button-container { display: flex; justify-content: center; gap: 20px; margin: 30px 0; flex-wrap: wrap; }
        .method-button { background-color: #7289da; color: white; padding: 15px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1em; transition: background-color 0.3s; }
        .method-button:hover:not(:disabled) { background-color: #5b6eae; }
        .method-button:disabled { background-color: #555; color: #aaa; cursor: not-allowed; }
        .disabled-tooltip { position: relative; display: inline-block; }
        .disabled-tooltip .tooltip-text { visibility: hidden; width: 220px; background-color: #333; color: #fff; text-align: center; border-radius: 6px; padding: 5px 0; position: absolute; z-index: 1; bottom: 125%; left: 50%; margin-left: -110px; opacity: 0; transition: opacity 0.3s; font-size: 0.9em; }
        .disabled-tooltip:hover .tooltip-text { visibility: visible; opacity: 1; }
        .code-input-group { margin: 30px 0; padding: 20px 0; border-top: 1px solid #404040; }
        .code-input-label { font-size: 0.95em; color: #b0b5b8; margin-bottom: 15px; }
        #code-input { padding: 12px; font-size: 1.2em; width: 200px; text-align: center; border-radius: 5px; border: 1px solid #ccc; text-transform: uppercase; }
        .submit-button { background-color: #5cb85c; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; margin-top: 10px; }
        .submit-button:hover { background-color: #4cae4c; }
        .submit-button:disabled { background-color: #555; cursor: not-allowed; }
        .error-text { color: #d9534f; font-size: 0.9em; margin-top: 5px; }
        .success-text { color: #5cb85c; font-size: 0.9em; margin-top: 5px; }
        .info-text { font-size: 0.95em; color: #b0b5b8; margin: 10px 0; }
        .expire-text { font-size: 0.9em; color: #99aab5; margin-top: 30px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Watch Ads & Earn VPS Points</h1>
        <p class="subtitle">Choose an ad method below to start earning. You can earn 1 VPS Point per method daily.</p>
        
        <div class="section">
            <p class="info-text">We recommend using an ad-blocker. This will not affect your earnings.</p>
            <div class="button-container">
                {% if cuty_disabled %}
                <div class="disabled-tooltip">
                    <button class="method-button" disabled>Cuty</button>
                    <span class="tooltip-text">You have already earned a VPS point with Cuty today.</span>
                </div>
                {% else %}
                <button class="method-button" onclick="selectMethod('cuty')">Cuty (1 VPS Point)</button>
                {% endif %}

                {% if linkvertise_disabled %}
                <div class="disabled-tooltip">
                    <button class="method-button" disabled>Linkvertise</button>
                    <span class="tooltip-text">{{ linkvertise_tooltip }}</span>
                </div>
                {% else %}
                <button class="method-button" onclick="selectMethod('linkvertise')">Linkvertise (1 VPS Point)</button>
                {% endif %}
            </div>
        </div>

        {% if code and code != '------' %}
        <div class="code-input-group">
            <p class="code-input-label">Enter your code from the last ad:</p>
            <input type="text" id="code-input" placeholder="5-character code" maxlength="5">
            <button class="submit-button" onclick="submitCode()">Submit Code</button>
            <div id="code-error" class="error-text"></div>
        </div>
        {% endif %}

        <p class="expire-text">Linkvertise links never expire. Other methods expire in 4 hours.</p>
    </div>

    <script>
        function selectMethod(method) {
            const buttons = document.querySelectorAll('.method-button');
            buttons.forEach(btn => btn.disabled = true);
            
            fetch('/select-ad-method/{{ user_id }}/{{ token }}', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ method: method })
            })
            .then(response => {
                if (!response.ok) throw new Error('HTTP error! status: ' + response.status);
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect_url;
                } else {
                    alert('Error: ' + data.message);
                    buttons.forEach(btn => btn.disabled = false);
                }
            })
            .catch(error => {
                alert('Error: ' + error.message);
                buttons.forEach(btn => btn.disabled = false);
            });
        }

        function submitCode() {
            const codeInput = document.getElementById('code-input');
            const codeError = document.getElementById('code-error');
            
            if (!codeInput) return;
            
            const enteredCode = codeInput.value.trim().toUpperCase();
            if (enteredCode.length !== 5) {
                codeError.innerText = 'Please enter a valid 5-character code.';
                return;
            }

            codeInput.disabled = true;
            codeError.innerText = 'Validating...';
            codeError.className = '';

            fetch('/submit-code/{{ user_id }}/{{ token }}', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: enteredCode }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    codeError.innerText = data.message;
                    codeError.className = 'success-text';
                    codeInput.value = '';
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    codeError.innerText = data.message;
                    codeError.className = 'error-text';
                    codeInput.disabled = false;
                }
            })
            .catch(error => {
                codeError.innerText = 'An error occurred. Please try again.';
                codeError.className = 'error-text';
                codeInput.disabled = false;
            });
        }
    </script>
</body>
</html>
"""

REWARD_PAGE_HTML_EXPIRED = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ad Link Expired</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #2c2f33; color: #ffffff; text-align: center; padding: 50px; margin: 0; }
        .container { background-color: #23272a; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); max-width: 600px; }
        h1 { color: #d9534f; }
        p { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Link Expired or Invalid!</h1>
        <p>This ad link has expired, has already been used, or is invalid.</p>
        <p>Please go back to Discord and use the <strong>/watch-ads</strong> command to get a new link.</p>
    </div>
</body>
</html>
"""


def ensure_aware(dt):
    """Convert naive datetime to UTC-aware datetime."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=pytz.utc)
    return dt

def normalize_ad_info(ad_info):
    """Normalize ad_info datetime fields to be timezone-aware."""
    if ad_info:
        ad_info['ad_code_expiration'] = ensure_aware(ad_info.get('ad_code_expiration'))
    return ad_info

def get_linkvertise_limit_reason(user_id: int) -> tuple[str | None, timedelta | None]:
    """Checks for Linkvertise limits and returns the reason and remaining time if applicable."""
    # Check daily limit (5 times)
    daily_watches = db.get_linkvertise_daily_watches(user_id)
    today_utc = datetime.now(pytz.utc).date()
    today_watches = [watch for watch in daily_watches if watch.astimezone(pytz.utc).date() == today_utc]
    
    if len(today_watches) >= 5:
        app.logger.info(f"User {user_id} reached daily limit for Linkvertise.")
        return "daily_limit", None
        
    return None, None

def is_watch_limit_reached(user_id, method):
    if method == 'linkvertise':
        reason, _ = get_linkvertise_limit_reason(user_id)
        return reason is not None
    else:  # 'cuty'
        last_watch_date = db.get_last_watch_date(user_id, method)
        if last_watch_date:
            last_watch_date = ensure_aware(last_watch_date)
            if (datetime.now(pytz.utc) - last_watch_date).days < 1:
                return True
    return False

@app.route('/watch-ads/<int:user_id>/<string:token>')
async def watch_ads_page(user_id, token):
    if not is_valid_token(token):
        app.logger.warning(f"Invalid token for user {user_id}: {token} (length: {len(token)})")
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)

    ad_info = normalize_ad_info(db.get_ad_code_info(user_id))
    
    if not ad_info or ad_info.get('token') != token:
        app.logger.warning(f"No valid ad session found for user {user_id} with token {token}")
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)
    
    # No expiration check for linkvertise - it stays active until code is submitted
    # Only check expiration if it's NOT a linkvertise session
    if ad_info.get('current_ad_method') != 'linkvertise' and datetime.now(pytz.utc) > ad_info['ad_code_expiration']:
        db.clear_ad_code(user_id)
        app.logger.info(f"Ad session expired for user {user_id} with token {token}")
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)

    # If method already selected and code generated, show the page with code visible
    code = '------'
    if ad_info.get('current_ad_method') and ad_info.get('current_ad_method') != 'direct' and ad_info.get('current_ad_code'):
        code = ad_info['current_ad_code']
    
    # Otherwise, show choice page with empty code
    cuty_disabled = is_watch_limit_reached(user_id, 'cuty')
    linkvertise_reason, linkvertise_remaining = get_linkvertise_limit_reason(user_id)
    linkvertise_disabled = linkvertise_reason is not None

    tooltip_message = ""
    if linkvertise_reason == 'cooldown':
        minutes = int(linkvertise_remaining.total_seconds() / 60) + 1
        tooltip_message = f"You are on cooldown. Please wait {minutes} more minutes."
    elif linkvertise_reason == 'daily_limit':
        tooltip_message = "You have reached the daily limit for Linkvertise (5 times)."
    else:
        tooltip_message = "You have already earned credits with Linkvertise today."


    return render_template_string(CHOICE_PAGE_HTML, user_id=user_id, token=token, code=code, cuty_disabled=cuty_disabled, linkvertise_disabled=linkvertise_disabled, linkvertise_tooltip=tooltip_message)

@app.route('/select-ad-method/<int:user_id>/<string:token>', methods=['POST'])
async def select_ad_method(user_id, token):
    data = request.get_json()
    method = data.get('method')

    if method not in ['cuty', 'linkvertise']:
        return jsonify({'status': 'failed', 'message': 'Invalid method'}), 400

    if not is_valid_token(token):
        return jsonify({'status': 'failed', 'message': 'Invalid token'}), 400

    ad_info = normalize_ad_info(db.get_ad_code_info(user_id))
    if not ad_info or ad_info.get('token') != token:
        return jsonify({'status': 'failed', 'message': 'Session not found'}), 400
    
    # Check expiration only if NOT linkvertise (linkvertise has no time limit)
    if ad_info.get('current_ad_method') != 'linkvertise' and datetime.now(pytz.utc) > ad_info['ad_code_expiration']:
        return jsonify({'status': 'failed', 'message': 'Session expired'}), 400

    if method == 'linkvertise':
        reason, remaining = get_linkvertise_limit_reason(user_id)
        if reason == 'cooldown':
            minutes = int(remaining.total_seconds() / 60) + 1
            return jsonify({'status': 'failed', 'message': f'You are on cooldown. Please wait {minutes} more minutes.'}), 400
        elif reason == 'daily_limit':
            return jsonify({'status': 'failed', 'message': 'You have reached the daily limit for Linkvertise (5 times).'}), 400
    elif is_watch_limit_reached(user_id, method):
        return jsonify({'status': 'failed', 'message': f'You have already used {method} today'}), 400

    # Generate the shortlink URL (which will handle code generation on return)
    final_redirect_url = url_for('ad_reward_page', user_id=user_id, token=token, code='PENDING', _external=True)
    
    if method == 'cuty':
        if not CUTY_IO_API_TOKEN:
            return jsonify({'status': 'failed', 'message': 'Cuty.io not configured'}), 500

        cuty_io_api_url = "https://api.cuty.io/full"
        headers = {'Content-Type': 'application/json'}
        payload = {'token': CUTY_IO_API_TOKEN, 'url': final_redirect_url}

        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(cuty_io_api_url, headers=headers, json=payload) as resp:
                    if resp.status in [200, 201]:
                        data_resp = await resp.json()
                        # Store method before redirecting
                        expiration = datetime.now(pytz.utc) + timedelta(hours=4)
                        db.store_ad_code(user_id, None, expiration, token, method, ad_info.get('message_id'), ad_info.get('channel_id'))
                        return jsonify({'status': 'success', 'redirect_url': data_resp['data']['short_url']})
                    else:
                        error_text = await resp.text()
                        app.logger.error(f"Cuty.io API error for user {user_id}: {resp.status} - {error_text}")
                        return jsonify({'status': 'failed', 'message': 'Cuty.io error'}), 500
            except Exception as e:
                app.logger.error(f"Failed to connect to Cuty.io API: {e}")
                return jsonify({'status': 'failed', 'message': 'Cuty.io connection error'}), 500
    
    elif method == 'linkvertise':
        try:
            link = linkvertise_client.linkvertise(1429607, final_redirect_url)
            # Store method before redirecting
            expiration = datetime.now(pytz.utc) + timedelta(days=365)
            db.store_ad_code(user_id, None, expiration, token, method, ad_info.get('message_id'), ad_info.get('channel_id'))
            return jsonify({'status': 'success', 'redirect_url': link})
        except Exception as e:
            app.logger.error(f"Failed to create Linkvertise link for user {user_id}: {e}")
            return jsonify({'status': 'failed', 'message': 'Linkvertise error'}), 500

@app.route('/generate-link/<int:user_id>/<string:token>/<string:method>')
async def generate_link(user_id, token, method):
    if method not in ['cuty', 'linkvertise']:
        return "Invalid method specified", 400

    if not is_valid_token(token):
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)

    ad_info = normalize_ad_info(db.get_ad_code_info(user_id))
    if not ad_info or ad_info.get('token') != token:
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)
    
    # Check expiration only if NOT linkvertise
    if ad_info.get('current_ad_method') != 'linkvertise' and datetime.now(pytz.utc) > ad_info['ad_code_expiration']:
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)

    if is_watch_limit_reached(user_id, method):
        return f"You have already used the {method.capitalize()} method today."

    code = ad_info.get('current_ad_code')
    if not code or ad_info.get('current_ad_method') != method:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
        db.update_ad_session(user_id, token, code, method)

    final_redirect_url = url_for('ad_reward_page', user_id=user_id, code=code, token=token, _external=True)

    if method == 'cuty':
        if not CUTY_IO_API_TOKEN:
            return "Cuty.io API token not configured.", 500

        cuty_io_api_url = "https://api.cuty.io/full"
        headers = {'Content-Type': 'application/json'}
        payload = {'token': CUTY_IO_API_TOKEN, 'url': final_redirect_url}

        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(cuty_io_api_url, headers=headers, json=payload) as resp:
                    if resp.status in [200, 201]:
                        data = await resp.json()
                        return redirect(data['data']['short_url'])
                    else:
                        error_text = await resp.text()
                        app.logger.error(f"Cuty.io API error for user {user_id}: {resp.status} - {error_text}")
                        return f"Error from Cuty.io API: {resp.status}", 500
            except Exception as e:
                app.logger.error(f"Failed to connect to Cuty.io API: {e}")
                return "Failed to connect to Cuty.io API", 500
    
    elif method == 'linkvertise':
        try:
            link = linkvertise_client.linkvertise(1429607, final_redirect_url)
            return redirect(link)
        except Exception as e:
            app.logger.error(f"Failed to create Linkvertise link for user {user_id}: {e}")
            return "Failed to create Linkvertise link", 500

@app.route('/ad-reward-page/<int:user_id>/<string:code>/<string:token>')
async def ad_reward_page(user_id, code, token):
    if not is_valid_token(token):
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)
        
    ad_info = normalize_ad_info(db.get_ad_code_info(user_id))

    if not ad_info or ad_info.get('token') != token:
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)
    
    # Check expiration only if NOT linkvertise
    if ad_info.get('current_ad_method') != 'linkvertise' and datetime.now(pytz.utc) > ad_info['ad_code_expiration']:
        return render_template_string(REWARD_PAGE_HTML_EXPIRED)

    # If code is PENDING (user just returned from Cuty/Linkvertise), generate the actual code
    if code == 'PENDING':
        if not ad_info.get('current_ad_method'):
            return render_template_string(REWARD_PAGE_HTML_EXPIRED)
        
        # Generate the code now
        actual_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
        db.update_ad_session(user_id, token, actual_code, ad_info['current_ad_method'])
        code = actual_code
    
    # Display the code page with button to return to home
    return render_template_string(CODE_PAGE_HTML, user_id=user_id, code=code, token=token)

@app.route('/submit-code/<int:user_id>/<string:token>', methods=['POST'])
async def submit_code(user_id, token):
    data = request.get_json()
    entered_code = data.get('code')

    if not entered_code:
        return jsonify({'status': 'failed', 'message': 'No code provided.'}), 400
    
    if not is_valid_token(token):
        return jsonify({'status': 'failed', 'message': 'Invalid token.', 'bruteforce_lock': True}), 400
        
    ad_info = normalize_ad_info(db.get_ad_code_info(user_id))

    if not ad_info or ad_info.get('token') != token or not ad_info.get('current_ad_code'):
        return jsonify({'status': 'failed', 'message': 'No active ad session found. Please start over.', 'bruteforce_lock': True})

    # Check expiration only if NOT linkvertise
    if ad_info.get('current_ad_method') != 'linkvertise' and datetime.now(pytz.utc) > ad_info['ad_code_expiration']:
        db.clear_ad_code(user_id)
        return jsonify({'status': 'failed', 'message': 'Your session has expired. Please start over.', 'bruteforce_lock': True})

    # Check if user is brute force locked
    brute_force_lock = ensure_aware(db.get_brute_force_lock(user_id))
    if brute_force_lock and datetime.now(pytz.utc) < brute_force_lock:
        return jsonify({'status': 'failed', 'message': 'Too many failed attempts. Please try again later.', 'bruteforce_lock': True})
    elif brute_force_lock and datetime.now(pytz.utc) >= brute_force_lock:
        db.clear_brute_force_lock(user_id)

    attempts = db.get_ad_code_attempts(user_id)
    if attempts >= 3:
        lock_until = datetime.now(pytz.utc) + timedelta(hours=1)
        db.set_brute_force_lock(user_id, lock_until)
        return jsonify({'status': 'failed', 'message': 'Too many failed attempts. Please try again in 1 hour.', 'bruteforce_lock': True})

    stored_code = ad_info['current_ad_code']
    method = ad_info.get('current_ad_method')

    if entered_code.upper() == stored_code:
        # Method was selected via Cuty/Linkvertise, award credits now
        method = ad_info.get('current_ad_method')
        
        if not method or method not in ['cuty', 'linkvertise']:
            return jsonify({'status': 'failed', 'message': 'Invalid method. Please start over.', 'bruteforce_lock': True})
        
        # Check daily limit before granting credits
        if is_watch_limit_reached(user_id, method):
            return jsonify({'status': 'failed', 'message': f'You have already earned rewards with {method} today. Please try again tomorrow.', 'bruteforce_lock': True})
        
        conn = None
        cursor = None
        try:
            conn, cursor = db.start_transaction()
            
            # Linkvertise gives VPS points, Cuty gives credits
            if method == 'linkvertise' or method == 'cuty':
                db.add_vps_points(user_id, 1, cursor=cursor, conn=conn)
                db.update_ad_credits_earned(user_id, 1, cursor=cursor, conn=conn)
                success_message = 'You have successfully earned 1 VPS Point!'
            else:
                 # Fallback for cuty if logic gets separated again
                db.add_credits(user_id, 2, cursor=cursor, conn=conn)
                db.update_ad_credits_earned(user_id, 2, cursor=cursor, conn=conn)
                success_message = 'You have successfully earned 2 credits!'
            
            db.set_last_watch_date(user_id, method, cursor=cursor, conn=conn)
            db.add_ad_watch_log(user_id, cursor=cursor, conn=conn) # Log ad watch for ad-supported tiers
            db.update_ad_session(user_id, token, None, None, cursor=cursor, conn=conn)
            db.clear_ad_code_attempts(user_id, cursor=cursor, conn=conn)
            db.commit_transaction(conn, cursor)
            return jsonify({'status': 'success', 'message': success_message})
        except Exception as e:
            if conn and cursor:
                db.rollback_transaction(conn, cursor)
            app.logger.error(f"Error processing ad code for user {user_id}: {e}")
            return jsonify({'status': 'failed', 'message': 'An unexpected error occurred.'}), 500
        
    else:
        new_attempts = db.increment_ad_code_attempts(user_id)
        if new_attempts >= 3:
            lock_until = datetime.now(pytz.utc) + timedelta(hours=1)
            db.set_brute_force_lock(user_id, lock_until)
            return jsonify({'status': 'failed', 'message': 'Invalid code. Too many failed attempts. Please try again in 1 hour.', 'bruteforce_lock': True})
        else:
            remaining = 3 - new_attempts
            return jsonify({'status': 'failed', 'message': f'Invalid code. You have {remaining} attempt(s) remaining.'})

@app.route('/invalidate-ad-link/<int:user_id>', methods=['POST'])
async def invalidate_ad_link(user_id):
    """Kept for backwards compatibility or other uses, but new flow clears code on success/failure."""
    app.logger.info(f"Invalidating ad link for user_id: {user_id}")
    db.clear_ad_code(user_id)
    return {"message": "Ad link invalidated successfully"}, 200

def run_flask_app():
    ssl_context = (SSL_CERT, SSL_KEY) if SSL_ENABLED else None
    app.run(host=FLASK_BIND_HOST, port=FLASK_PORT, debug=True, use_reloader=False, ssl_context=ssl_context)
def run_flask_app():
    ssl_context = (SSL_CERT, SSL_KEY) if SSL_ENABLED else None
    app.run(host=FLASK_BIND_HOST, port=FLASK_PORT, debug=True, use_reloader=False, ssl_context=ssl_context)