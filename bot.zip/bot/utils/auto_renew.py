from utils.database import db
from datetime import datetime, timedelta
import asyncio
import logging
import discord
from utils import node_manager
from discord.ext import tasks
from bot.commands.plans import LXC_AD_TIERS # Import tier definitions

async def auto_renew_suspended_vps(bot: discord.Client):
    """
    Automatically renews suspended VPS if the user has enough credits or vps points.
    """
    all_vps = db.get_all_vps()
    suspended_vps = [vps for vps in all_vps if vps['is_suspended'] and (vps.get('suspension_reason') == 'suspended_for_non_payment' or vps.get('is_suspended') == 1)]
    now = datetime.now()

    for vps in suspended_vps:
        user_id = vps['user_id']
        vps_id = vps['id']
        container_name = vps['container_name']

        is_free_tier = (vps.get('plan_tier') and vps['plan_tier'] != '') or \
            (vps.get('invite_plan_tier') and vps['invite_plan_tier'] != '')

        renewed = False
        renewal_dm_info = None  # (is_free, cost_str, new_due_date)

        if is_free_tier:
            # FREE TIER (suspended): Use VPS points with dynamic cost
            plan_tier = vps.get('plan_tier')
            cost_vps_points = 1  # Default cost
            if plan_tier and plan_tier in LXC_AD_TIERS:
                cost_vps_points = LXC_AD_TIERS[plan_tier].get('ads_required', 1)

            user_vps_points = db.get_vps_points(user_id)
            if user_vps_points >= cost_vps_points:
                new_due_date = now + timedelta(days=1)
                
                # ✅ Utiliser une transaction pour les 3 opérations
                conn, cursor = db.start_transaction()
                try:
                    db.consume_vps_points(user_id, cost_vps_points, cursor=cursor, conn=conn)
                    db.set_vps_due_date(vps_id, new_due_date, cursor=cursor, conn=conn)
                    db.unsuspend_vps(container_name, cursor=cursor, conn=conn)
                    db.commit_transaction(conn, cursor)
                    logging.info(f"Suspended FREE VPS {container_name} for user {user_id} has been automatically renewed for 1 day using {cost_vps_points} vps points.")
                    renewed = True
                    renewal_dm_info = (True, f"{cost_vps_points} VPS points", new_due_date)
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Failed to renew suspended FREE VPS {container_name}: {e}")
                    raise
        else:
            # PAID TIER (suspended): Use credits
            cost_credits = vps['cost_credits']
            balance = db.get_balance(user_id)
            if balance >= cost_credits:
                new_due_date = now + timedelta(days=30)
                
                # ✅ Utiliser une transaction pour les 3 opérations
                conn, cursor = db.start_transaction()
                try:
                    db.add_credits(user_id, -cost_credits, cursor=cursor, conn=conn)  # Use add_credits for consistency
                    db.set_vps_due_date(vps_id, new_due_date, cursor=cursor, conn=conn)
                    db.unsuspend_vps(container_name, cursor=cursor, conn=conn)
                    db.commit_transaction(conn, cursor)
                    logging.info(f"Suspended PAID VPS {container_name} for user {user_id} has been automatically renewed for 30 days using {cost_credits} credits.")
                    renewed = True
                    renewal_dm_info = (False, f"{cost_credits} credits", new_due_date)
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Failed to renew suspended PAID VPS {container_name}: {e}")
                    raise

        if renewed:
            # Skip dedicated servers - they don't use node API
            if vps.get('is_dedicated'):
                logging.info(f"VPS {container_name} (dedicated) renewed but not restarted via API.")
                continue

            # Start container via API
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                logging.error(f"Could not determine node for VPS {container_name}. Cannot start.")
                continue

            node_url, api_key = node_info['url'], node_info['api_key']
            vps_type = vps.get('vps_type', 'lxc')
            endpoint = f"/lxc/container/{container_name}/start" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/start"

            try:
                result = await node_manager.api_request('POST', endpoint, node_url, api_key)
                if result and result.get("status") == "success":
                    logging.info(f"VPS {container_name} for user {user_id} has been started after renewal.")
                else:
                    logging.error(f"Failed to start container {container_name} via API")
            except Exception as e:
                logging.error(f"Error starting VPS {container_name}: {e}")

        # Send DM to user confirming renewal
        if renewal_dm_info:
            is_free, cost_str, new_due_date = renewal_dm_info
            try:
                user = await bot.fetch_user(user_id)
                embed = discord.Embed(
                    title="VPS Renewed Successfully",
                    description=f"Your VPS `{container_name}` has been automatically renewed and is now active again.",
                    color=discord.Color.green()
                )
                embed.add_field(name="Cost", value=cost_str, inline=True)
                embed.add_field(name="New expiry date", value=new_due_date.strftime("%Y-%m-%d %H:%M"), inline=True)
                await user.send(embed=embed)
            except discord.Forbidden:
                logging.warning(f"Cannot send renewal DM to user {user_id}.")
            except discord.NotFound:
                logging.warning(f"User {user_id} not found for renewal DM.")

async def check_vps_payments_at_exact_time(bot: discord.Client):
    """
    Check VPS payments and renew/suspend at the exact due date/time.
    This runs every minute to ensure precise timing.
    """
    all_vps = db.get_all_vps()
    now = datetime.now()

    for vps in all_vps:
        # This task only handles active (not suspended) VPS
        if vps.get('is_suspended'):
            continue

        if isinstance(vps['due_date'], str):
            due_date = datetime.fromisoformat(vps['due_date'])
        else:
            due_date = vps['due_date']

        # Check if VPS is due within the next minute (to catch exact time)
        # This ensures we process renewals at the exact due time
        time_until_due = (due_date - now).total_seconds()

        # If not yet due or already processed (more than 1 minute past), skip
        if time_until_due > 60 or time_until_due < -60:
            continue

        # VPS is due now (within ±1 minute window)
        user_id = vps['user_id']
        vps_id = vps['id']
        container_name = vps['container_name']

        user = None
        try:
            user = await bot.fetch_user(user_id)
        except discord.NotFound:
            logging.warning(f"User {user_id} not found, cannot send DM.")

        # Differentiate between free and paid tiers
        is_free_tier = (vps.get('plan_tier') and vps['plan_tier'] != '') or \
            (vps.get('invite_plan_tier') and vps['invite_plan_tier'] != '')

        if is_free_tier:
            # --- Free Tier Renewal Logic with Dynamic Cost ---
            plan_tier = vps.get('plan_tier')
            cost_vps_points = 1  # Default cost
            if plan_tier and plan_tier in LXC_AD_TIERS:
                cost_vps_points = LXC_AD_TIERS[plan_tier].get('ads_required', 1)

            renewal_days = 1
            user_vps_points = db.get_vps_points(user_id)

            if user_vps_points >= cost_vps_points:
                new_due_date = due_date + timedelta(days=renewal_days)
                
                # ✅ Utiliser une transaction pour les 2 opérations
                conn, cursor = db.start_transaction()
                try:
                    db.consume_vps_points(user_id, cost_vps_points, cursor=cursor, conn=conn)
                    db.set_vps_due_date(vps_id, new_due_date, cursor=cursor, conn=conn)
                    db.commit_transaction(conn, cursor)
                    logging.info(f"Active FREE VPS {container_name} for user {user_id} renewed for {renewal_days} day using {cost_vps_points} VPS points at exact due time.")
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Failed to renew active FREE VPS {container_name}: {e}")
                    raise
                if user:
                    try:
                        embed = discord.Embed(
                            title="VPS Renewed Successfully",
                            description=f"Your free VPS `{container_name}` has been automatically renewed for 1 day using **{cost_vps_points} VPS point(s)**.",
                            color=discord.Color.green()
                        )
                        embed.add_field(name="New expiry date", value=new_due_date.strftime("%Y-%m-%d %H:%M"), inline=True)
                        embed.add_field(name="Remaining VPS Points", value=str(db.get_vps_points(user_id)), inline=True)
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send free VPS renewal DM to user {user_id}.")
            else:
                # Not enough points, suspend
                # ✅ Arrêter via API D'ABORD, puis marquer suspendu en DB
                node_info = node_manager.get_node_for_vps(container_name)
                if node_info:
                    node_url, api_key = node_info['url'], node_info['api_key']
                    vps_type = vps.get('vps_type', 'lxc')
                    endpoint = f"/lxc/container/{container_name}/stop" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/stop"
                    
                    try:
                        result = await node_manager.api_request('POST', endpoint, node_url, api_key, data={"force": True})
                        
                        # ✅ Seulement si l'arrêt a réussi
                        if result and (result.get("status") == "success" or result.get("result") is not False):
                            db.suspend_vps(vps_id, reason='suspended_for_non_payment')
                            logging.info(f"Active FREE VPS {container_name} for user {user_id} stopped and suspended due to insufficient VPS points ({user_vps_points}/{cost_vps_points}).")
                        else:
                            logging.error(f"Failed to stop VPS {container_name}, not marking as suspended in DB")
                    except Exception as e:
                        logging.error(f"Error stopping VPS {container_name}: {e}, not marking as suspended in DB")
                else:
                    # Pas de node info, marquer quand même suspendu (VPS orphelin?)
                    db.suspend_vps(vps_id, reason='suspended_for_non_payment')
                    logging.warning(f"No node info for {container_name}, marked as suspended in DB only")

                if user:
                    embed = discord.Embed(
                        title="Free VPS Suspended",
                        description=f"Your free VPS `{container_name}` has been suspended because you do not have enough VPS Points to cover the daily renewal cost ({cost_vps_points} point/day).",
                        color=discord.Color.orange()
                    )
                    embed.add_field(name="Action Required", value="Please earn more VPS Points to reactivate your VPS. It will be automatically reactivated once you have sufficient points.")
                    try:
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send free VPS suspension DM to user {user_id}.")

        else:  # Paid Tier
            # --- Paid Tier Renewal Logic ---
            cost_credits = vps['cost_credits']
            user_balance = db.get_balance(user_id)
            renewal_days = 30

            if user_balance >= cost_credits:
                new_due_date = due_date + timedelta(days=renewal_days)
                db.add_credits(user_id, -cost_credits)  # Use add_credits for consistency
                db.set_vps_due_date(vps_id, new_due_date)
                logging.info(f"Active PAID VPS {container_name} for user {user_id} has been renewed for {renewal_days} days at exact due time.")
                if user:
                    try:
                        embed = discord.Embed(
                            title="Automatic VPS Renewal",
                            description=f"Your VPS `{container_name}` has been automatically renewed for one more month. {cost_credits} credits have been deducted from your balance.",
                            color=discord.Color.green()
                        )
                        embed.add_field(name="New expiry date", value=new_due_date.strftime("%Y-%m-%d %H:%M"), inline=True)
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send paid renewal DM to user {user_id}.")
            else:
                # Not enough credits, suspend
                db.suspend_vps(vps_id, reason='suspended_for_non_payment')
                logging.info(f"Active PAID VPS {container_name} for user {user_id} is overdue and has been suspended.")

                # Stop container via API
                node_info = node_manager.get_node_for_vps(container_name)
                if node_info:
                    node_url, api_key = node_info['url'], node_info['api_key']
                    vps_type = vps.get('vps_type', 'lxc')
                    endpoint = f"/lxc/container/{container_name}/stop" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/stop"
                    await node_manager.api_request('POST', endpoint, node_url, api_key, data={"force": True})

                if user:
                    delete_timestamp = int((now + timedelta(days=2)).timestamp())
                    embed = discord.Embed(
                        title="VPS Payment Overdue",
                        description=f"Your VPS `{container_name}` has been suspended due to non-payment. You do not have enough credits ({user_balance}) to renew it for {cost_credits} credits.",
                        color=discord.Color.orange()
                    )
                    embed.add_field(
                        name="Deletion Date",
                        value=f"Your VPS will be permanently deleted <t:{delete_timestamp}:R> if not renewed.",
                        inline=False
                    )
                    try:
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send overdue DM to user {user_id}.")

async def start_vps_renewal_tasks(bot: discord.Client):
    """
    Starts the background tasks for VPS renewal.
    """
    @tasks.loop(minutes=2)
    async def auto_renewal_loop():
        try:
            await auto_renew_suspended_vps(bot)
        except Exception as e:
            logging.error(f"An error occurred in the auto-renewal task: {e}")

    @auto_renewal_loop.before_loop
    async def before_auto_renewal():
        await bot.wait_until_ready()
        logging.info("Auto-renewal task ready")

    @tasks.loop(minutes=1)
    async def check_vps_payments_exact_time_loop():
        """
        Check VPS payments every minute for exact timing.
        This ensures renewals happen at the precise due date/time.
        """
        try:
            await check_vps_payments_at_exact_time(bot)
        except Exception as e:
            logging.error(f"An error occurred in the exact-time payment check task: {e}")

    @check_vps_payments_exact_time_loop.before_loop
    async def before_check_payments_exact():
        await bot.wait_until_ready()
        logging.info("VPS exact-time payment check task ready (runs every minute)")

    auto_renewal_loop.start()
    check_vps_payments_exact_time_loop.start()
