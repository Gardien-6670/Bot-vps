import mysql.connector
from mysql.connector import errorcode
import logging
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
from typing import Any, cast, Dict, List
import sqlite3
from threading import Lock
import threading
import subprocess
import pytz
import json

load_dotenv()

# 
# SYSTÈME DE MIGRATION AUTOMATIQUE DE LA BASE DE DONNÉES
# 

# Définition complète du schéma de la base de données
DATABASE_SCHEMA = {
 'vps': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('user_id', 'BIGINT NOT NULL'),
 ('username', 'VARCHAR(255)'),
 ('container_name', 'VARCHAR(255) UNIQUE'),
 ('vmid', 'INT DEFAULT NULL'),
 ('node', 'VARCHAR(100) NOT NULL'),
 ('vps_type', 'VARCHAR(50) NOT NULL'),
 ('plan_id', 'VARCHAR(100)'),
 ('hostname', 'VARCHAR(255)'),
 ('cpu', 'INT DEFAULT 1'),
 ('ram', 'FLOAT DEFAULT 0.5'),
 ('disk', 'FLOAT DEFAULT 5.0'),
 ('cpu_limit', 'INT DEFAULT NULL'),
 ('memory_limit', 'INT DEFAULT 512'),
 ('disk_limit', 'INT DEFAULT 10'),
 ('cost_credits', 'INT DEFAULT 0'),
 ('due_date', 'DATETIME'),
 ('ssh_link', 'TEXT'),
 ('ssh_port', 'INT'),
 ('ssh_password', 'VARCHAR(255)'),
 ('ip_address', 'VARCHAR(45)'),
 ('payment_type', 'VARCHAR(50)'),
 ('cost_per_day', 'FLOAT DEFAULT 0'),
 ('vm_username', 'VARCHAR(255) DEFAULT "root"'),
 ('vm_password', 'VARCHAR(255) DEFAULT NULL'),
 ('is_active', 'BOOLEAN DEFAULT TRUE'),
 ('is_suspended', 'BOOLEAN DEFAULT FALSE'),
 ('suspicion_count', 'INT DEFAULT 0'),
 ('suspension_reason', 'VARCHAR(255) DEFAULT NULL'),
 ('suspended_at', 'DATETIME DEFAULT NULL'),
 ('threat_score', 'INT DEFAULT 0'),
 ('status', 'VARCHAR(50) DEFAULT "active"'),
 ('is_dedicated', 'BOOLEAN DEFAULT FALSE'),
 ('attributed_to_user_id', 'BIGINT DEFAULT NULL'),
 ('attribution_end_date', 'DATETIME DEFAULT NULL'),
 ('surveillance_user', 'VARCHAR(255)'),
 ('surveillance_password', 'VARCHAR(255)'),
 ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('updated_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_user_id', 'user_id'),
 ('idx_container_name', 'container_name'),
 ('idx_node', 'node'),
 ('idx_vmid', 'vmid'),
 ]
 },
 'vps_command_logs': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('vps_id', 'INT NOT NULL'),
 ('command', 'TEXT NOT NULL'),
 ('executed_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('is_suspicious', 'BOOLEAN DEFAULT FALSE'),
 ('analyzed_by_ai', 'BOOLEAN DEFAULT FALSE'),
 ],
 'indexes': [
 ('idx_vps_id', 'vps_id'),
 ]
 },
 'users': {
 'columns': [
 ('user_id', 'BIGINT PRIMARY KEY'),
 ('balance', 'INT DEFAULT 0'),
 ('pending_balance', 'INT DEFAULT 0'),
 ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('updated_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
 ],
 'indexes': []
 },
 'ad_rewards': {
 'columns': [
 ('user_id', 'BIGINT PRIMARY KEY'),
 ('current_ad_code', 'VARCHAR(255)'),
 ('ad_code_expiration', 'DATETIME'),
 ('token', 'VARCHAR(255)'),
 ('current_ad_method', 'VARCHAR(255)'),
 ('message_id', 'BIGINT'),
 ('channel_id', 'BIGINT'),
 ('ad_code_attempts', 'INT DEFAULT 0'),
 ('total_ad_credits', 'INT DEFAULT 0'),
 ('last_cuty_watch_date', 'DATETIME'),
 ('last_linkvertise_watch_date', 'DATETIME'),
 ('linkvertise_daily_watches', 'TEXT'),
 ('brute_force_lock_until', 'DATETIME'),
 ('remind_me', 'BOOLEAN DEFAULT FALSE'),
 ('next_reminder_time', 'DATETIME'),
 ],
 'indexes': []
 },
 'transactions': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('track_id', 'VARCHAR(255) UNIQUE NOT NULL'),
 ('user_id', 'BIGINT NOT NULL'),
 ('credits', 'INT NOT NULL'),
 ('expiration_time', 'DATETIME NOT NULL'),
 ('guild_id', 'BIGINT'),
 ('status', 'VARCHAR(50) DEFAULT "pending"'),
 ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_track_id', 'track_id'),
 ('idx_user_id', 'user_id'),
 ('idx_status', 'status'),
 ]
 },
 'port_forwards': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('external_port', 'INT NOT NULL'),
 ('internal_port', 'INT NOT NULL'),
 ('protocol', 'VARCHAR(10) NOT NULL'),
 ('device_name', 'VARCHAR(255) UNIQUE NOT NULL'),
 ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_container_name', 'container_name'),
 ('idx_external_port', 'external_port'),
 ]
 },
 'dedicated_orders': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('user_id', 'BIGINT NOT NULL'),
 ('plan_name', 'VARCHAR(255) NOT NULL'),
 ('specs', 'JSON'),
 ('price_eur', 'DECIMAL(10, 2) NOT NULL'),
 ('track_id', 'VARCHAR(255) UNIQUE'),
 ('status', 'VARCHAR(50) DEFAULT "pending_payment"'),
 ('container_name', 'VARCHAR(255)'),
 ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('paid_at', 'TIMESTAMP NULL'),
 ('provisioned_at', 'TIMESTAMP NULL'),
 ],
 'indexes': [
 ('idx_user_id', 'user_id'),
 ('idx_track_id', 'track_id'),
 ('idx_status', 'status'),
 ]
 },
 'invited_members': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('member_id', 'BIGINT NOT NULL'),
 ('inviter_id', 'BIGINT NOT NULL'),
 ('joined_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('left_at', 'TIMESTAMP NULL'),
 ('invite_code', 'VARCHAR(255)'),
 ('reward_given', 'BOOLEAN DEFAULT FALSE'),
 ('month_id', 'INT DEFAULT NULL'),
 ],
 'indexes': [
 ('idx_member_id', 'member_id'),
 ('idx_inviter', 'inviter_id'),
 ('idx_month', 'month_id'),
 ]
 },
 'plan_panel_messages': {
 'columns': [
 ('panel_type', 'VARCHAR(50) PRIMARY KEY'),
 ('channel_id', 'BIGINT NOT NULL'),
 ('message_id', 'BIGINT NOT NULL'),
 ],
 'indexes': []
 },
 'security_threats': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('threat_score', 'INT NOT NULL'),
 ('severity', 'VARCHAR(20) NOT NULL'),
 ('threat_data', 'TEXT'),
 ('resolved', 'BOOLEAN DEFAULT FALSE'),
 ('detected_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('resolved_at', 'TIMESTAMP NULL'),
 ],
 'indexes': [
 ('idx_container_name', 'container_name'),
 ('idx_severity', 'severity'),
 ('idx_detected_at', 'detected_at'),
 ]
 },
 'file_scan_results': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('file_hash', 'VARCHAR(64) UNIQUE NOT NULL'),
 ('filepath', 'TEXT'),
 ('threat_level', 'INT DEFAULT 0'),
 ('detection_ratio', 'VARCHAR(20)'),
 ('vt_positives', 'INT'),
 ('vt_total', 'INT'),
 ('suspicious', 'BOOLEAN DEFAULT FALSE'),
 ('official', 'BOOLEAN DEFAULT FALSE'),
 ('quarantined', 'BOOLEAN DEFAULT FALSE'),
 ('ai_decision', 'JSON'),
 ('first_seen', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('last_seen', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_file_hash', 'file_hash'),
 ('idx_threat_level', 'threat_level'),
 ]
 },
 'quarantine_log': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('original_path', 'TEXT NOT NULL'),
 ('quarantine_path', 'TEXT NOT NULL'),
 ('file_hash', 'VARCHAR(64)'),
 ('threat_level', 'INT'),
 ('quarantined_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ('restored', 'BOOLEAN DEFAULT FALSE'),
 ('restored_at', 'TIMESTAMP NULL'),
 ],
 'indexes': [
 ('idx_container_name', 'container_name'),
 ('idx_file_hash', 'file_hash'),
 ]
 },
 'network_stats': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('bytes_sent', 'BIGINT DEFAULT 0'),
 ('bytes_received', 'BIGINT DEFAULT 0'),
 ('recorded_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_container_name', 'container_name'),
 ('idx_recorded_at', 'recorded_at'),
 ]
 },
 'resource_abuse_log': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('abuse_type', 'VARCHAR(50) NOT NULL'),
 ('abuse_value', 'TEXT'),
 ('detected_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_container_name', 'container_name'),
 ('idx_abuse_type', 'abuse_type'),
 ]
 },
 'virustotal_daily_stats': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('record_date', 'DATE NOT NULL'),
 ('key_hash', 'VARCHAR(64) NOT NULL'),
 ('request_count', 'INT DEFAULT 0'),
 ],
 'indexes': [
 ('idx_date_key', 'record_date, key_hash'),
 ]
 },
 'metrics_history': {
 'columns': [
 ('id', 'INT AUTO_INCREMENT PRIMARY KEY'),
 ('container_name', 'VARCHAR(255) NOT NULL'),
 ('vps_type', 'VARCHAR(50) NOT NULL'),
 ('cpu_percent', 'FLOAT DEFAULT 0'),
 ('ram_mb', 'FLOAT DEFAULT 0'),
 ('disk_mb', 'FLOAT DEFAULT 0'),
 ('disk_io_read_mb', 'FLOAT DEFAULT 0'),
 ('disk_io_write_mb', 'FLOAT DEFAULT 0'),
 ('network_rx_mb', 'FLOAT DEFAULT 0'),
 ('network_tx_mb', 'FLOAT DEFAULT 0'),
 ('recorded_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
 ],
 'indexes': [
 ('idx_container', 'container_name'),
 ('idx_recorded_at', 'recorded_at'),
 ('idx_container_time', 'container_name, recorded_at'),
 ]
 },
}

class Database:
    def __init__(self, local_db_file='database.db'):
        self.db_config = {
            'host': os.getenv('MYSQL_HOST'),
            'user': os.getenv('MYSQL_USER'),
            'password': os.getenv('MYSQL_PASSWORD'),
            'database': os.getenv('MYSQL_DATABASE'),
            'port': os.getenv('MYSQL_PORT', 3306)
        }
        self.local_db_file = local_db_file
        self.db_lock = Lock()

        if not all([self.db_config['host'], self.db_config['user'], self.db_config['password'], self.db_config['database']]):
            raise ValueError("Missing MySQL environment variables in .env file. Please set MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, and MYSQL_DATABASE.")

        conn = self.get_db_connection()
        if conn:
            logging.info("Database connection successful.")
            conn.close()
            # Automatically create missing tables on init
            self.create_missing_tables()
            # Run comprehensive database migration
            try:
                self._verify_and_migrate_database()
            except Exception as migration_error:
                logging.error(f"[WARNING] Database migration failed: {migration_error}")
                logging.warning("[WARNING] Some features may not work correctly")
        else:
            logging.error("Database connection failed on initialization.")

    def get_db_connection(self):
        try:
            conn = mysql.connector.connect(**self.db_config)
            return conn
        except mysql.connector.Error as err:
            logging.error(f"MySQL Connection Error: {err}")
            return None

    def _execute_query(self, query: str, params=(), cursor=None, conn=None) -> None:
        """Execute a query without returning results (INSERT, UPDATE, DELETE)"""
        if cursor and conn:
            query = query.replace('?', '%s')
            try:
                cursor.execute(query, params)
            except mysql.connector.Error as err:
                logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                raise
        else:
            with self.db_lock:
                conn = self.get_db_connection()
                if not conn:
                    raise ConnectionError("Failed to obtain MySQL connection for write operation.")

                query = query.replace('?', '%s')
                cursor = conn.cursor(dictionary=True)
                try:
                    cursor.execute(query, params)
                    conn.commit()
                except mysql.connector.Error as err:
                    logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                    raise
                finally:
                    cursor.close()
                    conn.close()

    def _fetch_one(self, query: str, params=(), cursor=None, conn=None) -> dict[str, Any] | None:
        """Execute a query and return one row"""
        if cursor and conn:
            query = query.replace('?', '%s')
            try:
                cursor.execute(query, params)
                result = cursor.fetchone()
                return cast(dict[str, Any] | None, result)
            except mysql.connector.Error as err:
                logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                raise
        else:
            with self.db_lock:
                conn = self.get_db_connection()
                if not conn:
                    raise ConnectionError("Failed to obtain MySQL connection for read operation.")

                query = query.replace('?', '%s')
                cursor = conn.cursor(dictionary=True)
                try:
                    cursor.execute(query, params)
                    result = cursor.fetchone()
                    return cast(dict[str, Any] | None, result)
                except mysql.connector.Error as err:
                    logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                    raise
                finally:
                    cursor.close()
                    conn.close()

    def _fetch_all(self, query: str, params=(), cursor=None, conn=None) -> list[dict[str, Any]]:
        """Execute a query and return all rows"""
        if cursor and conn:
            query = query.replace('?', '%s')
            try:
                cursor.execute(query, params)
                results = cursor.fetchall()
                return cast(list[dict[str, Any]], results)
            except mysql.connector.Error as err:
                logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                raise
        else:
            with self.db_lock:
                conn = self.get_db_connection()
                if not conn:
                    raise ConnectionError("Failed to obtain MySQL connection for read operation.")

                query = query.replace('?', '%s')
                cursor = conn.cursor(dictionary=True)
                try:
                    cursor.execute(query, params)
                    results = cursor.fetchall()
                    return cast(list[dict[str, Any]], results)
                except mysql.connector.Error as err:
                    logging.error(f"MySQL Query Error: {err} on query: {query} with params: {params}")
                    raise
                finally:
                    cursor.close()
                    conn.close()

    def start_transaction(self):
        conn = self.get_db_connection()
        if not conn:
            raise Exception("Failed to get database connection for transaction.")
        cursor = conn.cursor(dictionary=True)
        return conn, cursor

    def commit_transaction(self, conn, cursor):
        try:
            conn.commit()
            logging.debug("Transaction committed.")
        except Exception as e:
            logging.error(f"Error committing transaction: {e}")
            raise
        finally:
            cursor.close()
            conn.close()

    def rollback_transaction(self, conn, cursor):
        try:
            conn.rollback()
            logging.warning("Transaction rolled back.")
        except Exception as e:
            logging.error(f"Error rolling back transaction: {e}")
            raise
        finally:
            cursor.close()
            conn.close()

    def _table_exists(self, table_name: str) -> bool:
        db_name = self.db_config['database']
        query = """SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s"""
        result = self._fetch_one(query, (db_name, table_name))
        return result['COUNT(*)'] > 0 if result else False

    def _verify_schema_integrity(self):
        required_tables = {
            "dedicated_orders": [],
            "paid_plans_message": [],
            "transactions": [],
            "giveaways": [],
            "giveaway_participants": [],
            "virustotal_daily_stats": [],
            "tos_message": [],
            "plan_panel_messages": [],
            "feature_flags": [],
            "ad_rewards": [
                "token", "linkvertise_daily_watches", "ads_watched_total",
                "terms_reminder_count", "terms_last_reminder_date"
            ],
            "vps": [
                "threat_score", "cpu_limit", "plan_tier", "ads_available",
                "ads_watched_today", "suspension_reason", "suspended_at",
                "invite_plan_tier", "last_scan_time"
            ],
            "vps_command_logs": [],
            "invited_members": ["month_id", "invite_plan_eligible"],
            "invited_members_monthly": [],
            "invite_plan_renewal_info": [],
            "users": [
                "vps_points", "public_ip", "is_ip_verified", "ip_warning_sent_at",
                "ip_warning_count", "ip_token", "ip_token_expires_at", "vps_suspension_date"
            ],
            "guild_invites": []
        }

        missing = []
        for table, columns in required_tables.items():
            if not self._table_exists(table):
                missing.append(f"table:{table}")
                continue
            for column in columns:
                if not self._column_exists(table, column):
                    missing.append(f"column:{table}.{column}")

        if missing:
            logging.warning(f"[WARNING] Schema inconsistencies detected: {', '.join(missing)}")
        else:
            logging.info("[OK] All required tables and columns are present.")

    def create_missing_tables(self):
        """Creates tables if they don't exist."""
        print(" [DATABASE] Starting create_missing_tables()...")
        logging.info(" Starting create_missing_tables()...")
        try:
                # ========================================================================
                # TABLES CRITIQUES - CRÉÉES EN PREMIER POUR ÉVITER LES ERREURS
                # ========================================================================

                # Table pour les commandes de serveurs dédiés
                dedicated_orders_table_sql = """
                CREATE TABLE IF NOT EXISTS dedicated_orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                plan_name VARCHAR(255) NOT NULL,
                specs JSON,
                price_eur DECIMAL(10, 2) NOT NULL,
                track_id VARCHAR(255) UNIQUE,
                status VARCHAR(50) DEFAULT 'pending_payment',
                container_name VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                paid_at TIMESTAMP NULL,
                provisioned_at TIMESTAMP NULL
                );
                """
                self._execute_query(dedicated_orders_table_sql)
                print(" [DATABASE] Table dedicated_orders créée")
                logging.info(" Table dedicated_orders créée")

                # Table pour les commandes de renouvellement de VPS dedies
                dedicated_renewal_orders_table_sql = """
                CREATE TABLE IF NOT EXISTS dedicated_renewal_orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                container_name VARCHAR(255) NOT NULL,
                months INT NOT NULL,
                price_eur DECIMAL(10, 2) NOT NULL,
                track_id VARCHAR(255) UNIQUE NOT NULL,
                expiration_time DATETIME NOT NULL,
                status VARCHAR(50) DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME NULL
                );
                """
                self._execute_query(dedicated_renewal_orders_table_sql)

                # Add indexes separately for MySQL 9 compatibility
                # Add indexes separately with existence check
                renewal_indexes = [
                ('idx_track_id', 'track_id'),
                ('idx_status', 'status'),
                ('idx_user_id', 'user_id'),
                ('idx_container_name', 'container_name')
                ]
                for index_name, column_name in renewal_indexes:
                    try:
                        if not self._index_exists('dedicated_renewal_orders', index_name):
                            self._execute_query(f"ALTER TABLE dedicated_renewal_orders ADD INDEX {index_name} ({column_name})")
                        logging.debug(f"Index {index_name} created on dedicated_renewal_orders")
                    except Exception as e:
                        logging.debug(f"Index creation skipped or failed: {e}")

                print(" [DATABASE] Table dedicated_renewal_orders creee")
                logging.info(" Table dedicated_renewal_orders creee")

                # Table pour les logs de transactions (credits et points VPS)
                transaction_logs_table_sql = """
                CREATE TABLE IF NOT EXISTS transaction_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                transaction_type VARCHAR(50) NOT NULL,
                amount INT NOT NULL,
                balance_before INT NOT NULL,
                balance_after INT NOT NULL,
                reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """
                self._execute_query(transaction_logs_table_sql)

                # Add indexes separately with existence check
                transaction_logs_indexes = [
                ('idx_user_id', 'user_id'),
                ('idx_transaction_type', 'transaction_type'),
                ('idx_created_at', 'created_at')
                ]
                for index_name, column_name in transaction_logs_indexes:
                    try:
                        if not self._index_exists('transaction_logs', index_name):
                            self._execute_query(f"ALTER TABLE transaction_logs ADD INDEX {index_name} ({column_name})")
                        logging.debug(f"Index {index_name} created on transaction_logs")
                    except Exception as e:
                        logging.debug(f"Index creation skipped or failed: {e}")

                print(" [DATABASE] Table transaction_logs creee")
                logging.info(" Table transaction_logs creee")

                # Table pour les messages de plans payants
                paid_plans_message_table_sql = """
                CREATE TABLE IF NOT EXISTS paid_plans_message (
                id INT AUTO_INCREMENT PRIMARY KEY,
                message_id BIGINT NOT NULL,
                channel_id BIGINT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                """
                self._execute_query(paid_plans_message_table_sql)
                logging.info(" Table paid_plans_message créée")

                # Table pour les transactions
                transactions_table_sql = """
                CREATE TABLE IF NOT EXISTS transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                credits INT NOT NULL,
                status VARCHAR(50) DEFAULT 'pending',
                payment_method VARCHAR(50),
                transaction_id VARCHAR(255) UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP NULL,
                INDEX idx_user_id (user_id),
                INDEX idx_status (status),
                INDEX idx_transaction_id (transaction_id)
                );
                """
                self._execute_query(transactions_table_sql)
                logging.info(" Table transactions créée")

                # Table pour les giveaways
                giveaways_table_sql = """
                CREATE TABLE IF NOT EXISTS giveaways (
                id INT AUTO_INCREMENT PRIMARY KEY,
                guild_id BIGINT NOT NULL,
                channel_id BIGINT NOT NULL,
                message_id BIGINT,
                prize VARCHAR(255) NOT NULL,
                winner_count INT DEFAULT 1,
                end_time DATETIME NOT NULL,
                status VARCHAR(50) DEFAULT 'running',
                prize_distributed TINYINT(1) DEFAULT 0,
                created_by BIGINT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                participants TEXT,
                INDEX idx_status (status),
                INDEX idx_end_time (end_time)
                );
                """
                self._execute_query(giveaways_table_sql)
                logging.info(" Table giveaways créée")

                # Table pour les participants aux giveaways
                giveaway_participants_table_sql = """
                CREATE TABLE IF NOT EXISTS giveaway_participants (
                id INT AUTO_INCREMENT PRIMARY KEY,
                giveaway_id INT NOT NULL,
                user_id BIGINT NOT NULL,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_participant (giveaway_id, user_id),
                INDEX idx_giveaway_id (giveaway_id),
                INDEX idx_user_id (user_id)
                );
                """
                self._execute_query(giveaway_participants_table_sql)
                logging.info(" Table giveaway_participants créée")

                # Table pour les statistiques VirusTotal
                virustotal_daily_stats_table_sql = """
                CREATE TABLE IF NOT EXISTS virustotal_daily_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                key_hash VARCHAR(64) NOT NULL,
                record_date DATE NOT NULL,
                request_count INT DEFAULT 0,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_key_date (key_hash, record_date),
                INDEX idx_record_date (record_date)
                );
                """
                self._execute_query(virustotal_daily_stats_table_sql)
                logging.info(" Table virustotal_daily_stats créée")

                # Table pour les messages TOS
                tos_message_table_sql = """
                CREATE TABLE IF NOT EXISTS tos_message (
                id INT AUTO_INCREMENT PRIMARY KEY,
                message_id BIGINT NOT NULL,
                channel_id BIGINT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                );
                """
                self._execute_query(tos_message_table_sql)
                logging.info(" Table tos_message créée")

                # Table pour l'historique des métriques
                metrics_history_table_sql = """
                CREATE TABLE IF NOT EXISTS metrics_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                container_name VARCHAR(255) NOT NULL,
                vps_type VARCHAR(50) NOT NULL,
                cpu_percent FLOAT DEFAULT 0,
                ram_mb FLOAT DEFAULT 0,
                disk_mb FLOAT DEFAULT 0,
                disk_io_read_mb FLOAT DEFAULT 0,
                disk_io_write_mb FLOAT DEFAULT 0,
                network_rx_mb FLOAT DEFAULT 0,
                network_tx_mb FLOAT DEFAULT 0,
                recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_container (container_name),
                INDEX idx_recorded_at (recorded_at),
                INDEX idx_container_time (container_name, recorded_at)
                );
                """
                self._execute_query(metrics_history_table_sql)
                logging.info(" Table metrics_history créée")

                # ========================================================================
                # TABLES EXISTANTES
                # ========================================================================

                plan_panels_table_sql = """
                CREATE TABLE IF NOT EXISTS plan_panel_messages (
                panel_type VARCHAR(50) PRIMARY KEY,
                channel_id BIGINT NOT NULL,
                message_id BIGINT NOT NULL
                );
                """
                self._execute_query(plan_panels_table_sql)

                ad_rewards_table_sql = """
                CREATE TABLE IF NOT EXISTS ad_rewards (
                user_id BIGINT PRIMARY KEY,
                current_ad_code VARCHAR(255),
                ad_code_expiration DATETIME,
                token VARCHAR(255),
                current_ad_method VARCHAR(255),
                message_id BIGINT,
                channel_id BIGINT,
                ad_code_attempts INT DEFAULT 0,
                total_ad_credits INT DEFAULT 0,
                last_cuty_watch_date DATETIME,
                last_linkvertise_watch_date DATETIME,
                linkvertise_daily_watches TEXT,
                brute_force_lock_until DATETIME,
                remind_me BOOLEAN DEFAULT FALSE,
                next_reminder_time DATETIME
                );
                """
                self._execute_query(ad_rewards_table_sql)

                # Check and alter 'token' column in 'ad_rewards' table
                try:
                    token_column_type = self._get_column_type('ad_rewards', 'token')
                    if token_column_type and 'varchar(255)' not in token_column_type.lower():
                        logging.info(f"Altering 'ad_rewards.token' from {token_column_type} to VARCHAR(255).")
                        self._execute_query("ALTER TABLE ad_rewards MODIFY COLUMN token VARCHAR(255)")
                        logging.info("'ad_rewards.token' column altered successfully to VARCHAR(255).")
                    elif not token_column_type:
                        logging.warning("'ad_rewards.token' column not found, skipping alter. It might be created later or be part of another migration.")
                    else:
                        logging.info(f"'ad_rewards.token' column is already VARCHAR(255) or sufficient ({token_column_type}).")
                except Exception as e:
                    logging.error(f"Failed to check/alter 'ad_rewards.token' column: {e}")

                # Check and alter 'linkvertise_daily_watches' column in 'ad_rewards' table
                try:
                    linkvertise_column_type = self._get_column_type('ad_rewards', 'linkvertise_daily_watches')
                    if linkvertise_column_type and 'text' not in linkvertise_column_type.lower():
                        logging.info(f"Altering 'ad_rewards.linkvertise_daily_watches' from {linkvertise_column_type} to TEXT.")
                        self._execute_query("ALTER TABLE ad_rewards MODIFY COLUMN linkvertise_daily_watches TEXT")
                        logging.info("'ad_rewards.linkvertise_daily_watches' column altered successfully to TEXT.")
                    elif not linkvertise_column_type:
                        logging.warning("'ad_rewards.linkvertise_daily_watches' column not found, skipping alter. It might be created later or be part of another migration.")
                    else:
                        logging.info(f"'advertise.linkvertise_daily_watches' column is already TEXT or sufficient ({linkvertise_column_type}).")
                except Exception as e:
                    logging.error(f"Failed to check/alter 'ad_rewards.linkvertise_daily_watches' column: {e}")

                # Créer la table vps si elle n'existe pas
                vps_table_sql = """
                CREATE TABLE IF NOT EXISTS vps (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                vmid INT UNIQUE NOT NULL,
                node VARCHAR(100) NOT NULL,
                vps_type VARCHAR(50) NOT NULL,
                plan_id VARCHAR(100),
                hostname VARCHAR(255),
                cpu_limit INT DEFAULT 1,
                memory_limit INT DEFAULT 512,
                disk_limit INT DEFAULT 10,
                payment_type VARCHAR(50),
                cost_per_day FLOAT DEFAULT 0,
                vm_username VARCHAR(255) DEFAULT 'root',
                vm_password VARCHAR(255) DEFAULT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                suspension_reason VARCHAR(255) DEFAULT NULL,
                suspended_at DATETIME DEFAULT NULL,
                threat_score INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id),
                INDEX idx_vmid (vmid),
                INDEX idx_node (node)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
                try:
                    self._execute_query(vps_table_sql)
                    logging.info(" Table vps créée ou déjà existante")
                except Exception as vps_error:
                    logging.error(f"Échec de la création de la table vps: {vps_error}")

                # Créer la table vps_command_logs sans FOREIGN KEY d'abord
                # (car l'utilisateur peut ne pas avoir la permission REFERENCES)
                vps_command_logs_table_sql = """
                CREATE TABLE IF NOT EXISTS vps_command_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                vps_id INT NOT NULL,
                command TEXT NOT NULL,
                executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_suspicious BOOLEAN DEFAULT FALSE,
                analyzed_by_ai BOOLEAN DEFAULT FALSE,
                INDEX idx_vps_id (vps_id)
                );
                """
                try:
                    self._execute_query(vps_command_logs_table_sql)
                    logging.info(" Table vps_command_logs créée (sans FOREIGN KEY)")
                    
                    # Essayer d'ajouter la FOREIGN KEY si l'utilisateur a les permissions
                    try:
                        # Vérifier si la contrainte existe déjà
                        check_fk_query = """
                        SELECT CONSTRAINT_NAME 
                        FROM information_schema.TABLE_CONSTRAINTS 
                        WHERE TABLE_SCHEMA = %s 
                        AND TABLE_NAME = 'vps_command_logs' 
                        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
                        """
                        existing_fk = self._fetch_one(check_fk_query, (self.db_config['database'],))

                        if not existing_fk:
                            add_fk_sql = """
                            ALTER TABLE vps_command_logs 
                            ADD CONSTRAINT fk_vps_command_logs_vps_id 
                            FOREIGN KEY (vps_id) REFERENCES vps(id) ON DELETE CASCADE
                            """
                            self._execute_query(add_fk_sql)
                            logging.info(" FOREIGN KEY ajoutée à vps_command_logs")
                        else:
                            logging.info(" FOREIGN KEY existe déjà sur vps_command_logs")
                    except Exception as fk_error:
                        # Si l'ajout de FOREIGN KEY échoue, ce n'est pas grave
                        # La table fonctionne quand même, juste sans contrainte d'intégrité référentielle
                        logging.warning(f"Impossible d'ajouter FOREIGN KEY à vps_command_logs: {fk_error}")
                        logging.info("[WARNING] Table vps_command_logs créée sans FOREIGN KEY (permissions insuffisantes)")
                        logging.info("[WARNING] L'intégrité référentielle devra être gérée au niveau applicatif")
                except Exception as table_error:
                    logging.error(f"Échec de la création de vps_command_logs: {table_error}")
                    # Ne pas lever l'exception, continuer avec les autres tables

                # Créer la table invited_members si elle n'existe pas
                invited_members_table_sql = """
                CREATE TABLE IF NOT EXISTS invited_members (
                id INT AUTO_INCREMENT PRIMARY KEY,
                inviter_id BIGINT NOT NULL,
                invited_id BIGINT NOT NULL,
                invited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                month_id INT DEFAULT NULL,
                INDEX idx_inviter (inviter_id),
                INDEX idx_invited (invited_id),
                INDEX idx_month (month_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
                try:
                    self._execute_query(invited_members_table_sql)
                    logging.info(" Table invited_members créée ou déjà existante")
                except Exception as invited_error:
                    logging.error(f"Échec de la création de invited_members: {invited_error}")

                # Créer la table feature_flags si elle n'existe pas (KVM/LXC/maintenance)
                feature_flags_table_sql = """
                    CREATE TABLE IF NOT EXISTS feature_flags (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    flag_name VARCHAR(100) UNIQUE NOT NULL,
                    is_enabled BOOLEAN DEFAULT TRUE,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_flag_name (flag_name)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                    """
                try:
                    self._execute_query(feature_flags_table_sql)
                    logging.info(" Table feature_flags créée ou déjà existante")

                    # Flags par défaut (insérés si absents)
                    default_flags = [
                    ('kvm_plans_enabled', True, 'Enable/disable KVM VPS plans'),
                    ('lxc_plans_enabled', True, 'Enable/disable LXC VPS plans'),
                    ('maintenance_mode', False, 'Enable/disable maintenance mode'),
                    ]

                    for flag_name, is_enabled, description in default_flags:
                        try:
                            self._execute_query(
                                "INSERT IGNORE INTO feature_flags (flag_name, is_enabled, description) VALUES (?, ?, ?)",
                                (flag_name, 1 if is_enabled else 0, description)
                            )
                        except Exception as flag_error:
                            logging.warning(f"Impossible d'insérer le flag {flag_name}: {flag_error}")

                    logging.info(" Feature flags par défaut initialisés")
                except Exception as feature_error:
                    logging.error(f"Échec de la création de feature_flags: {feature_error}")

                # Créer la table guild_invites si elle n'existe pas
                guild_invites_table_sql = """
                CREATE TABLE IF NOT EXISTS guild_invites (
                guild_id BIGINT NOT NULL,
                invite_code VARCHAR(255) NOT NULL,
                inviter_id BIGINT NULL,
                uses INT DEFAULT 0,
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, invite_code),
                INDEX idx_inviter_id (inviter_id),
                INDEX idx_last_updated (last_updated)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
                try:
                    self._execute_query(guild_invites_table_sql)
                    logging.info(" Table guild_invites créée ou déjà existante")
                except Exception as guild_invites_error:
                    logging.error(f"Échec de la création de guild_invites: {guild_invites_error}")

                # Add threat_score to vps table if not exists
                if not self._column_exists('vps', 'threat_score'):
                    self._execute_query("ALTER TABLE vps ADD COLUMN threat_score INT DEFAULT 0")

                # Add cpu_limit to vps table if not exists
                if not self._column_exists('vps', 'cpu_limit'):
                    self._execute_query("ALTER TABLE vps ADD COLUMN cpu_limit INT DEFAULT NULL")

                # Add plan_tier to vps table if not exists
                if not self._column_exists('vps', 'plan_tier'):
                    self._execute_query("ALTER TABLE vps ADD COLUMN plan_tier VARCHAR(50) DEFAULT NULL")

                # Add ads_available to vps table if not exists
                if not self._column_exists('vps', 'ads_available'):
                    self._execute_query("ALTER TABLE vps ADD COLUMN ads_available INT DEFAULT 0")

                # Add ads_watched_today to vps table if not exists
                if not self._column_exists('vps', 'ads_watched_today'):
                    self._execute_query("ALTER TABLE vps ADD COLUMN ads_watched_today INT DEFAULT 0")

                # Add ads_watched_total to ad_rewards table if not exists
                if not self._column_exists('ad_rewards', 'ads_watched_total'):
                    self._execute_query("ALTER TABLE ad_rewards ADD COLUMN ads_watched_total INT DEFAULT 0")

                # Add terms_reminder_count to ad_rewards table if not exists
                if not self._column_exists('ad_rewards', 'terms_reminder_count'):
                    self._execute_query("ALTER TABLE ad_rewards ADD COLUMN terms_reminder_count INT DEFAULT 0")

                # Add terms_last_reminder_date to ad_rewards table if not exists
                if not self._column_exists('ad_rewards', 'terms_last_reminder_date'):
                    self._execute_query("ALTER TABLE ad_rewards ADD COLUMN terms_last_reminder_date DATETIME DEFAULT NULL")

                # Add legacy compatibility column last_ad_watch_date if missing
                if not self._column_exists('ad_rewards', 'last_ad_watch_date'):
                    self._execute_query("ALTER TABLE ad_rewards ADD COLUMN last_ad_watch_date DATETIME DEFAULT NULL")
            
                # Add month_id to invited_members table if not exists
                if not self._column_exists('invited_members', 'month_id'):
                    self._execute_query("ALTER TABLE invited_members ADD COLUMN month_id INT DEFAULT NULL")
            
                # Add invite_plan_eligible to invited_members table if not exists
                if not self._column_exists('invited_members', 'invite_plan_eligible'):
                    self._execute_query("ALTER TABLE invited_members ADD COLUMN invite_plan_eligible BOOLEAN DEFAULT TRUE")

                # Add invited_members_monthly table
                invited_members_monthly_table_sql = """
                CREATE TABLE IF NOT EXISTS invited_members_monthly (
                id INT AUTO_INCREMENT PRIMARY KEY,
                month_id INT NOT NULL,
                inviter_id BIGINT NOT NULL,
                invited_member_id BIGINT NOT NULL,
                joined_at DATETIME NOT NULL,
                left_at DATETIME NULL,
                invite_code VARCHAR(255) NULL,
                invite_plan_eligible BOOLEAN DEFAULT TRUE,
                UNIQUE(month_id, invited_member_id)
                );
                """
                self._execute_query(invited_members_monthly_table_sql)

                # Add invite_plan_renewal_info table
                invite_plan_renewal_info_table_sql = """
                CREATE TABLE IF NOT EXISTS invite_plan_renewal_info (
                vps_id INT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                invite_plan_tier VARCHAR(50) NOT NULL,
                required_invites INT NOT NULL,
                renewal_month_id INT NOT NULL,
                last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """
                try:
                    self._execute_query(invite_plan_renewal_info_table_sql)
                    logging.info(" Table invite_plan_renewal_info créée ou déjà existante")
                    
                    # Essayer d'ajouter la FOREIGN KEY si possible
                    try:
                        # Vérifier si la contrainte existe déjà
                        check_fk_query = """
                        SELECT CONSTRAINT_NAME 
                        FROM information_schema.TABLE_CONSTRAINTS 
                        WHERE TABLE_SCHEMA = %s 
                        AND TABLE_NAME = 'invite_plan_renewal_info' 
                        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
                        """
                        existing_fk = self._fetch_one(check_fk_query, (self.db_config['database'],))

                        if not existing_fk:
                            add_fk_sql = """
                            ALTER TABLE invite_plan_renewal_info 
                            ADD CONSTRAINT fk_invite_plan_renewal_vps_id 
                            FOREIGN KEY (vps_id) REFERENCES vps(id) ON DELETE CASCADE
                            """
                            self._execute_query(add_fk_sql)
                            logging.info(" FOREIGN KEY ajoutée à invite_plan_renewal_info")
                    except Exception as fk_error:
                        logging.warning(f"Impossible d'ajouter FOREIGN KEY à invite_plan_renewal_info: {fk_error}")
                except Exception as table_error:
                    logging.error(f"Échec de la création de invite_plan_renewal_info: {table_error}")

                # Créer la table users si elle n'existe pas
                users_table_sql = """
                CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                credits DECIMAL(10, 2) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
                try:
                    self._execute_query(users_table_sql)
                    print(" [DATABASE] Table users créée ou déjà existante")
                    logging.info(" Table users créée ou déjà existante")
                except Exception as users_error:
                    logging.error(f"Échec de la création de la table users: {users_error}")

                # Add vps_points to users table if not exists
                try:
                    if not self._column_exists('users', 'vps_points'):
                        self._execute_query("ALTER TABLE users ADD COLUMN vps_points INT DEFAULT 0")
                    logging.info(" Colonne 'vps_points' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne vps_points: {e}")

                # Add suspension_reason to vps table if not exists
                try:
                    if not self._column_exists('vps', 'suspension_reason'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN suspension_reason VARCHAR(255) DEFAULT NULL")
                    logging.info(" Colonne 'suspension_reason' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne suspension_reason: {e}")

                # Add suspended_at to vps table if not exists
                try:
                    if not self._column_exists('vps', 'suspended_at'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN suspended_at DATETIME DEFAULT NULL")
                    logging.info(" Colonne 'suspended_at' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne suspended_at: {e}")

                # Add invite_plan_tier to vps table if not exists
                try:
                    if not self._column_exists('vps', 'invite_plan_tier'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN invite_plan_tier VARCHAR(50) DEFAULT NULL")
                    logging.info(" Colonne 'invite_plan_tier' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne invite_plan_tier: {e}")

                # Add last_scan_time to vps table if not exists
                try:
                    if not self._column_exists('vps', 'last_scan_time'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN last_scan_time DATETIME DEFAULT NULL")
                    logging.info(" Colonne 'last_scan_time' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne last_scan_time: {e}")

                # Add columns for IP verification to users table
                try:
                    if not self._column_exists('users', 'public_ip'):
                        self._execute_query("ALTER TABLE users ADD COLUMN public_ip VARCHAR(255) DEFAULT NULL")
                    logging.info(" Colonne 'public_ip' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne public_ip: {e}")
                
                try:
                    if not self._column_exists('users', 'is_ip_verified'):
                        self._execute_query("ALTER TABLE users ADD COLUMN is_ip_verified BOOLEAN DEFAULT FALSE")
                    logging.info(" Colonne 'is_ip_verified' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne is_ip_verified: {e}")

                # Add ip_warning_sent_at to users table if not exists
                try:
                    if not self._column_exists('users', 'ip_warning_sent_at'):
                        self._execute_query("ALTER TABLE users ADD COLUMN ip_warning_sent_at DATETIME DEFAULT NULL")
                    logging.info(" Colonne 'ip_warning_sent_at' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne ip_warning_sent_at: {e}")
                
                # Add ip_warning_count
                try:
                    if not self._column_exists('users', 'ip_warning_count'):
                        self._execute_query("ALTER TABLE users ADD COLUMN ip_warning_count INT DEFAULT 0")
                    logging.info(" Colonne 'ip_warning_count' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne ip_warning_count: {e}")
                
                # Add vps_suspension_date
                try:
                    if not self._column_exists('users', 'vps_suspension_date'):
                        self._execute_query("ALTER TABLE users ADD COLUMN vps_suspension_date DATETIME DEFAULT NULL")
                    logging.info(" Colonne 'vps_suspension_date' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne vps_suspension_date: {e}")

                # Add ip_token
                try:
                    if not self._column_exists('users', 'ip_token'):
                        self._execute_query("ALTER TABLE users ADD COLUMN ip_token VARCHAR(255) DEFAULT NULL")
                    logging.info(" Colonne 'ip_token' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne ip_token: {e}")

                # Add ip_token_expires_at
                try:
                    if not self._column_exists('users', 'ip_token_expires_at'):
                        self._execute_query("ALTER TABLE users ADD COLUMN ip_token_expires_at DATETIME DEFAULT NULL")
                    logging.info(" Colonne 'ip_token_expires_at' ajoutée à la table users")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne ip_token_expires_at: {e}")

                ip_verification_tokens_table_sql = """
                CREATE TABLE IF NOT EXISTS ip_verification_tokens (
                user_id BIGINT PRIMARY KEY,
                token VARCHAR(255) NOT NULL,
                expires_at DATETIME NOT NULL
                );
                """
                self._execute_query(ip_verification_tokens_table_sql)

                # ========================================================================
                # COLONNES MANQUANTES DANS LA TABLE VPS
                # ========================================================================
            
                # Colonne status
                try:
                    if not self._column_exists('vps', 'status'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN status VARCHAR(50) DEFAULT 'active'")
                    print(" [DATABASE] Colonne 'status' ajoutée à la table vps")
                    logging.info(" Colonne 'status' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne status: {e}")

                # Colonne is_dedicated
                try:
                    if not self._column_exists('vps', 'is_dedicated'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN is_dedicated TINYINT(1) DEFAULT 0")
                    print(" [DATABASE] Colonne 'is_dedicated' ajoutée à la table vps")
                    logging.info(" Colonne 'is_dedicated' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne is_dedicated: {e}")

                # Colonne attributed_to_user_id
                try:
                    if not self._column_exists('vps', 'attributed_to_user_id'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN attributed_to_user_id BIGINT DEFAULT NULL")
                    print(" [DATABASE] Colonne 'attributed_to_user_id' ajoutée à la table vps")
                    logging.info(" Colonne 'attributed_to_user_id' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne attributed_to_user_id: {e}")

                # Colonne attribution_end_date
                try:
                    if not self._column_exists('vps', 'attribution_end_date'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN attribution_end_date TIMESTAMP NULL")
                    print(" [DATABASE] Colonne 'attribution_end_date' ajoutée à la table vps")
                    logging.info(" Colonne 'attribution_end_date' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne attribution_end_date: {e}")

                # Colonne container_name
                try:
                    if not self._column_exists('vps', 'container_name'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN container_name VARCHAR(255) DEFAULT NULL")
                    print(" [DATABASE] Colonne 'container_name' ajoutée à la table vps")
                    logging.info(" Colonne 'container_name' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne container_name: {e}")

                # Colonne due_date
                try:
                    if not self._column_exists('vps', 'due_date'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN due_date TIMESTAMP NULL")
                    print(" [DATABASE] Colonne 'due_date' ajoutée à la table vps")
                    logging.info(" Colonne 'due_date' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne due_date: {e}")

                # Colonne cost_credits
                try:
                    if not self._column_exists('vps', 'cost_credits'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN cost_credits INT DEFAULT 0")
                    print(" [DATABASE] Colonne 'cost_credits' ajoutée à la table vps")
                    logging.info(" Colonne 'cost_credits' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne cost_credits: {e}")

                # Colonne is_suspended
                try:
                    if not self._column_exists('vps', 'is_suspended'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN is_suspended TINYINT(1) DEFAULT 0")
                    print(" [DATABASE] Colonne 'is_suspended' ajoutée à la table vps")
                    logging.info(" Colonne 'is_suspended' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne is_suspended: {e}")

                # Colonne ssh_port
                try:
                    if not self._column_exists('vps', 'ssh_port'):
                        self._execute_query("ALTER TABLE vps ADD COLUMN ssh_port INT DEFAULT NULL")
                    print(" [DATABASE] Colonne 'ssh_port' ajoutée à la table vps")
                    logging.info(" Colonne 'ssh_port' ajoutée à la table vps")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne ssh_port: {e}")

                # ========================================================================
                # COLONNES MANQUANTES DANS LA TABLE INVITED_MEMBERS
                # ========================================================================
            
                # Colonne member_id
                try:
                    if not self._column_exists('invited_members', 'member_id'):
                        self._execute_query("ALTER TABLE invited_members ADD COLUMN member_id BIGINT NOT NULL AFTER id")
                    print(" [DATABASE] Colonne 'member_id' ajoutée à la table invited_members")
                    logging.info(" Colonne 'member_id' ajoutée à la table invited_members")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne member_id: {e}")

                # Colonne joined_at
                try:
                    if not self._column_exists('invited_members', 'joined_at'):
                        self._execute_query("ALTER TABLE invited_members ADD COLUMN joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
                    print(" [DATABASE] Colonne 'joined_at' ajoutée à la table invited_members")
                    logging.info(" Colonne 'joined_at' ajoutée à la table invited_members")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne joined_at: {e}")

                # Colonne left_at
                try:
                    if not self._column_exists('invited_members', 'left_at'):
                        self._execute_query("ALTER TABLE invited_members ADD COLUMN left_at TIMESTAMP NULL")
                    print(" [DATABASE] Colonne 'left_at' ajoutée à la table invited_members")
                    logging.info(" Colonne 'left_at' ajoutée à la table invited_members")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne left_at: {e}")

                # Colonne reward_given
                try:
                    if not self._column_exists('invited_members', 'reward_given'):
                        self._execute_query("ALTER TABLE invited_members ADD COLUMN reward_given TINYINT(1) DEFAULT 0")
                    print(" [DATABASE] Colonne 'reward_given' ajoutée à la table invited_members")
                    logging.info(" Colonne 'reward_given' ajoutée à la table invited_members")
                except Exception as e:
                    logging.warning(f"Impossible d'ajouter la colonne reward_given: {e}")

                # ========================================================================
                # INDEX POUR AMÉLIORER LES PERFORMANCES
                # ========================================================================
                try:
                    # Vérifier et créer les index pour vps
                    if not self._index_exists('vps', 'idx_vps_status'):
                        self._execute_query("CREATE INDEX idx_vps_status ON vps(status)")
                        logging.info(" Index idx_vps_status créé")
                    
                    if not self._index_exists('vps', 'idx_vps_is_suspended'):
                        self._execute_query("CREATE INDEX idx_vps_is_suspended ON vps(is_suspended)")
                        logging.info(" Index idx_vps_is_suspended créé")
                    
                    if not self._index_exists('vps', 'idx_vps_is_dedicated'):
                        self._execute_query("CREATE INDEX idx_vps_is_dedicated ON vps(is_dedicated)")
                        logging.info(" Index idx_vps_is_dedicated créé")
                    
                    # Vérifier et créer les index pour invited_members
                    if not self._index_exists('invited_members', 'idx_invited_members_member_id'):
                        self._execute_query("CREATE INDEX idx_invited_members_member_id ON invited_members(member_id)")
                        logging.info(" Index idx_invited_members_member_id créé")
                    
                    if not self._index_exists('invited_members', 'idx_invited_members_reward_given'):
                        self._execute_query("CREATE INDEX idx_invited_members_reward_given ON invited_members(reward_given)")
                        logging.info(" Index idx_invited_members_reward_given créé")
                    
                    logging.info(" Index créés pour améliorer les performances")
                except Exception as idx_error:
                    # Les index peuvent déjà exister, ce n'est pas grave
                    logging.warning(f"Certains index existent déjà ou n'ont pas pu être créés: {idx_error}")

                logging.info("Successfully checked and created missing tables if they did not exist.")
                self._verify_schema_integrity()
                print("[OK] [DATABASE] Successfully checked and created missing tables!")
                return "Database tables checked/created successfully."
        except Exception as e:
            logging.error(f"Failed to create missing tables: {e}")
            print(f"[ERROR] [DATABASE] Failed to create missing tables: {e}")
            import traceback
            traceback.print_exc()
            return f"Error creating tables: {e}"

    def _get_column_type(self, table_name: str, column_name: str) -> str | None:
        """Get the column type (e.g., 'varchar(255)') for a specific column in a table."""
        db_name = self.db_config['database']
        query = """SELECT COLUMN_TYPE
        FROM information_schema.COLUMNS
        WHERE table_schema = %s AND table_name = %s AND column_name = %s"""
        result = self._fetch_one(query, (db_name, table_name, column_name))
        return result['COLUMN_TYPE'] if result else None

    def _column_exists(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table."""
        db_name = self.db_config['database']
        query = """SELECT COUNT(*)
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s AND column_name = %s"""
        result = self._fetch_one(query, (db_name, table_name, column_name))
        return result['COUNT(*)'] > 0 if result else False

    def _index_exists(self, table_name: str, index_name: str) -> bool:
        """Check if an index exists on a table."""
        db_name = self.db_config['database']
        query = """SELECT COUNT(*)
        FROM information_schema.statistics
        WHERE table_schema = %s AND table_name = %s AND index_name = %s"""
        result = self._fetch_one(query, (db_name, table_name, index_name))
        return result['COUNT(*)'] > 0 if result else False

    def add_giveaway(self, message_id: int, channel_id: int, guild_id: int, end_time: datetime, winners_count: int, prize: int):
        self._execute_query(
        "INSERT INTO giveaways (message_id, channel_id, guild_id, end_time, winners_count, prize, participants) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (message_id, channel_id, guild_id, end_time, winners_count, prize, '[]')
        )

    def get_giveaway(self, message_id: int) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM giveaways WHERE message_id = ?", (message_id,))

    def get_all_running_giveaways(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM giveaways WHERE status = 'running' AND prize_distributed = 0")

    def update_giveaway_participants(self, message_id: int, participants: str):
        self._execute_query("UPDATE giveaways SET participants = ? WHERE message_id = ?", (participants, message_id))

    def end_giveaway(self, message_id: int, winners: str):
        self._execute_query("UPDATE giveaways SET status = 'ended', winners = ?, prize_distributed = 1 WHERE message_id = ?", (winners, message_id))

    def get_giveaway_participants(self, message_id: int) -> list[int]:
        import json
        result = self._fetch_one("SELECT participants FROM giveaways WHERE message_id = ?", (message_id,))
        if result and result.get('participants'):
            return json.loads(result['participants'])
        return []

    def add_participant(self, message_id: int, user_id: int):
        import json
        participants = self.get_giveaway_participants(message_id)
        if user_id not in participants:
            participants.append(user_id)
        self.update_giveaway_participants(message_id, json.dumps(participants))

    def remove_participant(self, message_id: int, user_id: int):
        import json
        participants = self.get_giveaway_participants(message_id)
        if user_id in participants:
            participants.remove(user_id)
        self.update_giveaway_participants(message_id, json.dumps(participants))

        # ===== GUILD INVITES FUNCTIONS =====
        
    def save_guild_invite(self, guild_id: int, invite_code: str, inviter_id: int | None, uses: int):
        self._execute_query(
        '''INSERT INTO guild_invites (guild_id, invite_code, inviter_id, uses, last_updated) 
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE inviter_id=VALUES(inviter_id), uses=VALUES(uses), last_updated=VALUES(last_updated)''',
        (guild_id, invite_code, inviter_id, uses, datetime.now())
        )
        
    def get_guild_invites(self, guild_id: int) -> list[dict[str, Any]]:
        return self._fetch_all(
        "SELECT * FROM guild_invites WHERE guild_id = ?",
        (guild_id,)
        )
        
    def get_invite_by_code(self, guild_id: int, invite_code: str) -> dict[str, Any] | None:
        return self._fetch_one(
        "SELECT * FROM guild_invites WHERE guild_id = ? AND invite_code = ?",
        (guild_id, invite_code)
        )
        
    def update_invite_uses(self, guild_id: int, invite_code: str, new_uses: int):
        self._execute_query(
        "UPDATE guild_invites SET uses = ?, last_updated = ? WHERE guild_id = ? AND invite_code = ?",
        (new_uses, datetime.now(), guild_id, invite_code)
        )
        
    def delete_guild_invite(self, guild_id: int, invite_code: str):
        self._execute_query(
        "DELETE FROM guild_invites WHERE guild_id = ? AND invite_code = ?",
        (guild_id, invite_code)
        )
        logging.info(f"Deleted invite {invite_code} from guild {guild_id}")
        
    def clear_guild_invites(self, guild_id: int):
        self._execute_query(
        "DELETE FROM guild_invites WHERE guild_id = ?",
        (guild_id,)
        )
        logging.info(f"Cleared all invites for guild {guild_id}")

        # ===== VPS FUNCTIONS =====

    def suspend_vps(self, container_name: str, reason: str | None = None):
        self._execute_query("UPDATE vps SET is_suspended = 1, suspension_reason = ?, suspended_at = NOW() WHERE container_name = ?", (reason, container_name,))
        logging.info(f"VPS {container_name} has been suspended. Reason: {reason}")

    def is_vps_suspended(self, container_name: str) -> bool:
        result = self._fetch_one("SELECT is_suspended FROM vps WHERE container_name = ?", (container_name,))
        if result and 'is_suspended' in result:
            return bool(result['is_suspended'])
        return False

    def increment_suspicion_count(self, container_name: str) -> int:
        self._execute_query("UPDATE vps SET suspicion_count = suspicion_count + 1 WHERE container_name = ?", (container_name,))
        result = self._fetch_one("SELECT suspicion_count FROM vps WHERE container_name = ?", (container_name,))
        if result and 'suspicion_count' in result:
            return int(result['suspicion_count'])
        return 0

    def reset_suspicion_count(self, container_name: str):
        self._execute_query("UPDATE vps SET suspicion_count = 0 WHERE container_name = ?", (container_name,))

    def add_vps(self, user_id: int, username: str, container_name: str, cpu: int, ram: float, disk: float, cost_credits: int, ssh_link: str | None = None, ssh_port: int | None = None, ssh_password: str | None = None, vps_type: str = 'lxc', ip_address: str | None = None, node: str | None = None, is_dedicated: bool = False, attributed_to_user_id: int | None = None, attribution_end_date: datetime | None = None, surveillance_user: str | None = None, surveillance_password: str | None = None, due_date: datetime | None = None, plan_tier: str | None = None, invite_plan_tier: str | None = None, cursor=None, conn=None):
        if node is None:
            node = 'node1' # Default to node1 if not specified
        
        # Use provided due_date if available, otherwise calculate default
        if due_date is None:
            if plan_tier is not None and plan_tier != '' or invite_plan_tier is not None and invite_plan_tier != '': # If it's a free tier VPS (ad-supported or invite-based)
                due_date = datetime.now() + timedelta(days=1) # All free tiers (ads or invite) now get 1 day initially
            else: # For paid plans or if plan_tier/invite_plan_tier is not specified
                due_date = datetime.now() + timedelta(days=30)
        self._execute_query(
        "INSERT INTO vps (user_id, username, container_name, vmid, cpu, ram, disk, cost_credits, due_date, ssh_link, ssh_port, ssh_password, vps_type, ip_address, node, is_dedicated, attributed_to_user_id, attribution_end_date, surveillance_user, surveillance_password, plan_tier, invite_plan_tier) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (user_id, username, container_name, None, cpu, ram, disk, cost_credits, due_date, ssh_link, ssh_port, ssh_password, vps_type, ip_address, node, is_dedicated, attributed_to_user_id, attribution_end_date, surveillance_user, surveillance_password, plan_tier, invite_plan_tier), cursor=cursor, conn=conn
        )
        logging.info(f"VPS ({vps_type}, dedicated: {is_dedicated}) added on node {node} for user {user_id} with container {container_name}, IP {ip_address}, SSH port {ssh_port}. Plan tier: {plan_tier}. Invite plan tier: {invite_plan_tier}. Attributed to: {attributed_to_user_id} until {attribution_end_date}")

    def get_user_vps(self, user_id: int) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM vps WHERE user_id = ?", (user_id,))

    def get_user_active_vps(self, user_id: int) -> list[dict[str, Any]]:
        """Get all active (not suspended) VPS instances for a specific user."""
        return self._fetch_all("SELECT * FROM vps WHERE user_id = ? AND is_suspended = 0", (user_id,))

    def get_all_vps(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM vps")

    def get_vps_by_id(self, vps_id: int, cursor=None, conn=None) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM vps WHERE id = ?", (vps_id,), cursor=cursor, conn=conn)

    def get_vps_by_container_name(self, container_name: str) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM vps WHERE container_name = ?", (container_name,))

    def get_vps_by_ip_and_port(self, ip_address: str, ssh_port: int) -> dict[str, Any] | None:
        """Checks if a VPS with the given IP address and SSH port already exists."""
        return self._fetch_one("SELECT id FROM vps WHERE ip_address = ? AND ssh_port = ?", (ip_address, ssh_port))

    def update_vps_due_date(self, vps_id: int):
        new_due_date = datetime.now() + timedelta(days=30)
        self._execute_query("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id))
        logging.info(f"VPS {vps_id} renewed. New due date: {new_due_date}")

    def extend_vps_due_date(self, vps_id: int, months: int, cursor=None, conn=None):
        vps = self.get_vps_by_id(vps_id, cursor=cursor, conn=conn)
        if vps:
            current_due_date = vps['due_date']
        new_due_date = current_due_date + timedelta(days=30 * months)
        self._execute_query("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), cursor=cursor, conn=conn)
        logging.info(f"VPS {vps_id} renewed for {months} months. New due date: {new_due_date}")

    def update_vps_status(self, vps_id: int, status: str):
        self._execute_query("UPDATE vps SET status = ? WHERE id = ?", (status, vps_id))
        logging.info(f"VPS {vps_id} status updated to {status}")

    def delete_vps(self, vps_id: int) -> str | None:
        vps_info = self.get_vps_by_id(vps_id)
        if vps_info:
            self._execute_query("DELETE FROM vps WHERE id = ?", (vps_id,))
        logging.info(f"VPS {vps_id} ({vps_info['container_name']}) deleted from database.")
        return str(vps_info['container_name'])
        return None

    def delete_vps_by_container_name(self, container_name: str) -> str | None:
        vps_info = self.get_vps_by_container_name(container_name)
        if vps_info:
            self._execute_query("DELETE FROM vps WHERE container_name = ?", (container_name,))
        logging.info(f"VPS ({container_name}) deleted from database.")
        return str(vps_info['container_name'])
        return None

    def update_vps_ssh_link(self, container_name: str, ssh_link: str | None):
        self._execute_query("UPDATE vps SET ssh_link = ? WHERE container_name = ?", (ssh_link, container_name))
        logging.info(f"VPS {container_name} SSH link updated.")

    def update_vps_ip(self, container_name: str, ip_address: str):
        self._execute_query("UPDATE vps SET ip_address = ? WHERE container_name = ?", (ip_address, container_name))
        logging.info(f"VPS {container_name} IP address updated to {ip_address}.")

    def update_vps_threat_score(self, vps_id: int, score: int):
        self._execute_query("UPDATE vps SET threat_score = ? WHERE id = ?", (score, vps_id))
        logging.info(f"VPS {vps_id} threat score updated to {score}.")

    def update_vps_cpu_limit(self, vps_id: int, limit: int | None):
        self._execute_query("UPDATE vps SET cpu_limit = ? WHERE id = ?", (limit, vps_id))
        logging.info(f"VPS {vps_id} CPU limit updated to {limit}.")

    def update_vps_ssh_credentials(self, container_name: str, ssh_port: int, ssh_password: str):
        self._execute_query("UPDATE vps SET ssh_port = ?, ssh_password = ? WHERE container_name = ?", (ssh_port, ssh_password, container_name))
        logging.info(f"VPS {container_name} SSH credentials updated (port: {ssh_port}).")

    def update_vps_surveillance_credentials(self, container_name: str, user: str, password: str):
        self._execute_query("UPDATE vps SET surveillance_user = ?, surveillance_password = ? WHERE container_name = ?", (user, password, container_name))
        logging.info(f"VPS {container_name} surveillance credentials updated for user {user}.")

    def get_all_ssh_ports(self) -> list[int]:
        result = self._fetch_all("SELECT ssh_port FROM vps WHERE ssh_port IS NOT NULL")
        ports = []
        for row in result:
            if 'ssh_port' in row and row['ssh_port'] is not None:
                ports.append(int(row['ssh_port']))
        return ports

    def unsuspend_vps(self, container_name: str):
        self._execute_query("UPDATE vps SET is_suspended = 0, suspension_reason = NULL WHERE container_name = ?", (container_name,))
        logging.info(f"VPS {container_name} has been unsuspended.")

    def update_unassigned_vps_nodes(self, default_node_name: str):
        """Updates VPS entries with no node assigned to a default node name."""
        self._execute_query("UPDATE vps SET node = ? WHERE node IS NULL", (default_node_name,))
        logging.info(f"Updated unassigned VPS nodes to '{default_node_name}'.")

    def get_expiring_vps(self, days_ahead: int = 3) -> list[dict[str, Any]]:
        """Get VPS that will expire within the specified number of days"""
        future_date = datetime.now() + timedelta(days=days_ahead)
        return self._fetch_all(
        "SELECT * FROM vps WHERE due_date <= ? AND due_date > NOW() AND status = 'active'",
        (future_date,)
        )

    def get_expired_vps(self) -> list[dict[str, Any]]:
        """Get all expired VPS"""
        return self._fetch_all(
        "SELECT * FROM vps WHERE due_date < NOW() AND status = 'active'"
        )

    def get_all_users_with_vps(self) -> list[dict[str, Any]]:
        """Get all unique users who have VPS"""
        return self._fetch_all(
        "SELECT DISTINCT user_id FROM vps"
        )

    def get_dedicated_unattributed_vps(self) -> list[dict[str, Any]]:
        """Returns a list of dedicated servers that are not currently attributed to any user."""
        return self._fetch_all("SELECT * FROM vps WHERE is_dedicated = 1 AND attributed_to_user_id IS NULL")

    def get_dedicated_vps_by_user(self, user_id: int) -> list[dict[str, Any]]:
        """Returns a list of dedicated servers attributed to a specific user."""
        return self._fetch_all("SELECT * FROM vps WHERE is_dedicated = 1 AND attributed_to_user_id = ?", (user_id,))

    def get_all_dedicated_vps(self) -> list[dict[str, Any]]:
        """Returns a list of all dedicated servers, attributed or not."""
        return self._fetch_all("SELECT * FROM vps WHERE is_dedicated = 1")

    def update_dedicated_vps_attribution(self, container_name: str, user_id: int | None, attribution_end_date: datetime | None):
        """Updates the attribution status and end date for a dedicated VPS."""
        self._execute_query(
        "UPDATE vps SET attributed_to_user_id = ?, attribution_end_date = ? WHERE container_name = ? AND is_dedicated = 1",
        (user_id, attribution_end_date, container_name)
        )
        if user_id:
            logging.info(f"Dedicated VPS {container_name} attributed to user {user_id} until {attribution_end_date}.")
        else:
            logging.info(f"Dedicated VPS {container_name} un-attributed.")

    def get_expiring_dedicated_vps_attributions(self, days_ahead: int = 2) -> list[dict[str, Any]]:
        """Gets dedicated VPS attributions that are expiring within the specified number of days."""
        now = datetime.now()
        expiration_threshold = now + timedelta(days=days_ahead)
        return self._fetch_all(
        "SELECT * FROM vps WHERE is_dedicated = 1 AND attributed_to_user_id IS NOT NULL AND attribution_end_date IS NOT NULL AND attribution_end_date <= ? AND attribution_end_date > ?",
        (expiration_threshold, now)
        )

    def get_expired_dedicated_vps_attributions(self) -> list[dict[str, Any]]:
        """Gets dedicated VPS attributions that have already expired."""
        now = datetime.now()
        return self._fetch_all(
        "SELECT * FROM vps WHERE is_dedicated = 1 AND attributed_to_user_id IS NOT NULL AND attribution_end_date IS NOT NULL AND attribution_end_date <= ?",
        (now,)
        )

        # ===== USER FUNCTIONS =====

    def get_balance(self, user_id: int, cursor=None, conn=None) -> int:
        result = self._fetch_one("SELECT balance FROM users WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        if result and 'balance' in result:
            return int(result['balance'])
        return 0

    def get_pending_balance(self, user_id: int, cursor=None, conn=None) -> int:
        result = self._fetch_one("SELECT pending_balance FROM users WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        if result and 'pending_balance' in result:
            return int(result['pending_balance'])
        return 0

    def add_credits(self, user_id: int, amount: int, reason: str = None, cursor=None, conn=None):
        # Get balance before
        balance_before = self.get_balance(user_id)
        
        self._execute_query("INSERT INTO users (user_id, balance, pending_balance) VALUES (?, 0, 0) ON DUPLICATE KEY UPDATE user_id=user_id", (user_id,), cursor=cursor, conn=conn)
        self._execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id), cursor=cursor, conn=conn)
        
        # Get balance after
        balance_after = balance_before + amount
        
        # Log transaction
        transaction_type = "credit_add" if amount > 0 else "credit_remove"
        self._log_transaction(user_id, transaction_type, abs(amount), balance_before, balance_after, reason, cursor=cursor, conn=conn)
        
        logging.info(f"User {user_id} had {amount} credits added. Reason: {reason}")

    def add_pending_credits(self, user_id: int, amount: int):
        self._execute_query("INSERT INTO users (user_id, balance, pending_balance) VALUES (?, 0, 0) ON DUPLICATE KEY UPDATE user_id=user_id", (user_id,))
        self._execute_query("UPDATE users SET pending_balance = pending_balance + ? WHERE user_id = ?", (amount, user_id))
        logging.info(f"User {user_id} received {amount} pending credits.")

    def remove_pending_credits(self, user_id: int, amount: int):
        current_pending = self.get_pending_balance(user_id)
        new_pending = max(0, current_pending - amount)
        self._execute_query("UPDATE users SET pending_balance = ? WHERE user_id = ?", (new_pending, user_id))
        logging.info(f"User {user_id} had {amount} pending credits removed. New pending balance: {new_pending}.")

    def remove_all_pending_credits(self, user_id: int):
        self._execute_query("UPDATE users SET pending_balance = 0 WHERE user_id = ?", (user_id,))
        logging.info(f"User {user_id} all pending credits removed.")

    def move_pending_to_balance(self, user_id: int, amount: int):
        current_pending = self.get_pending_balance(user_id)
        actual_amount_to_move = min(amount, current_pending)
        self._execute_query("UPDATE users SET balance = balance + ?, pending_balance = pending_balance - ? WHERE user_id = ?", (actual_amount_to_move, actual_amount_to_move, user_id))
        logging.info(f"User {user_id} moved {actual_amount_to_move} pending credits to balance. Remaining pending: {current_pending - actual_amount_to_move}.")
        
    def set_balance(self, user_id: int, amount: int):
        self._execute_query("INSERT INTO users (user_id) VALUES (?) ON DUPLICATE KEY UPDATE user_id=user_id", (user_id,))
        self._execute_query("UPDATE users SET balance = ? WHERE user_id = ?", (amount, user_id))
        logging.info(f"User {user_id}'s balance set to {amount}.")

    def remove_credits(self, user_id: int, amount: int, reason: str = None, cursor=None, conn=None):
        # Get balance before
        balance_before = self.get_balance(user_id)
        
        self._execute_query("INSERT INTO users (user_id, balance, pending_balance) VALUES (?, 0, 0) ON DUPLICATE KEY UPDATE user_id=user_id", (user_id,), cursor=cursor, conn=conn)
        self._execute_query("UPDATE users SET balance = balance - ? WHERE user_id = ?", (amount, user_id), cursor=cursor, conn=conn)
        
        # Get balance after
        balance_after = balance_before - amount
        
        # Log transaction
        self._log_transaction(user_id, "credit_remove", amount, balance_before, balance_after, reason, cursor=cursor, conn=conn)
        
        logging.info(f"User {user_id} had {amount} credits removed. Reason: {reason}")

        # ===== TRANSACTION FUNCTIONS =====

    def add_transaction(self, track_id: str, user_id: int, credits: int, expiration_time, guild_id: int | None = None):
        # Convertir expiration_time en datetime si nécessaire
        if isinstance(expiration_time, (int, float)):
            # Si c'est un timestamp Unix, le convertir en datetime
            expiration_time = datetime.fromtimestamp(expiration_time)
        elif isinstance(expiration_time, str):
            # Si c'est une chaîne, essayer de la parser
            try:
                expiration_time = datetime.fromisoformat(expiration_time)
            except ValueError:
                try:
                    expiration_time = datetime.fromtimestamp(float(expiration_time))
                except ValueError:
                    raise ValueError(f"Invalid expiration_time format: {expiration_time}")
        elif not isinstance(expiration_time, datetime):
            raise ValueError(f"expiration_time must be datetime, timestamp, or ISO string, got {type(expiration_time)}")
        
        # Formater en string pour MySQL
        expiration_time_str = expiration_time.strftime('%Y-%m-%d %H:%M:%S')
        
        self._execute_query(
        "INSERT INTO transactions (track_id, user_id, credits, expiration_time, guild_id) VALUES (?, ?, ?, ?, ?)",
        (track_id, user_id, credits, expiration_time_str, guild_id)
        )

    def get_pending_transactions(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM transactions WHERE status = 'pending'")

    def get_transaction(self, track_id: str, cursor=None, conn=None) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM transactions WHERE track_id = ?", (track_id,), cursor=cursor, conn=conn)

        # ===== DEDICATED SERVER ORDER FUNCTIONS =====
        # CREATE TABLE dedicated_orders (
        # id INT AUTO_INCREMENT PRIMARY KEY,
        # user_id BIGINT NOT NULL,
        # plan_name VARCHAR(255) NOT NULL,
        # specs JSON,
        # price_eur DECIMAL(10, 2) NOT NULL,
        # track_id VARCHAR(255) UNIQUE,
        # status VARCHAR(50) DEFAULT 'pending_payment',
        # container_name VARCHAR(255),
        # created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        # paid_at TIMESTAMP NULL,
        # provisioned_at TIMESTAMP NULL
        # );

    def add_dedicated_order(self, user_id: int, plan_name: str, specs: dict, price_eur: float, track_id: str) -> int:
        """Adds a new dedicated server order to the database."""
        specs_json = json.dumps(specs)
        self._execute_query(
        "INSERT INTO dedicated_orders (user_id, plan_name, specs, price_eur, track_id) VALUES (?, ?, ?, ?, ?)",
        (user_id, plan_name, specs_json, price_eur, track_id)
        )
        result = self._fetch_one("SELECT LAST_INSERT_ID() as id")
        logging.info(f"Dedicated order created for user {user_id} with track_id {track_id}.")
        return result['id'] if result else -1

    def get_dedicated_order(self, order_id: int, cursor=None, conn=None) -> dict[str, Any] | None:
        """Gets a dedicated server order by its internal ID."""
        order = self._fetch_one("SELECT * FROM dedicated_orders WHERE id = ?", (order_id,), cursor=cursor, conn=conn)
        if order and isinstance(order.get('specs'), str):
            order['specs'] = json.loads(order['specs'])
        return order

    def get_dedicated_order_by_track_id(self, track_id: str, cursor=None, conn=None) -> dict[str, Any] | None:
        """Gets a dedicated server order by its OxaPay track_id."""
        order = self._fetch_one("SELECT * FROM dedicated_orders WHERE track_id = ?", (track_id,), cursor=cursor, conn=conn)
        if order and isinstance(order.get('specs'), str):
            order['specs'] = json.loads(order['specs'])
        return order

    def get_pending_dedicated_orders(self) -> list[dict[str, Any]]:
        """Gets all dedicated server orders that are pending payment."""
        return self._fetch_all("SELECT * FROM dedicated_orders WHERE status = 'pending_payment'")

    def get_pending_dedicated_renewal_orders(self) -> list[dict[str, Any]]:
        """Gets all dedicated VPS renewal orders that are pending payment."""
        return self._fetch_all("SELECT * FROM dedicated_renewal_orders WHERE status = 'pending'")

    def update_dedicated_order_status(self, order_id: int, status: str, container_name: str | None = None, cursor=None, conn=None):
        """Updates the status of a dedicated server order."""
        if status == 'paid':
            self._execute_query("UPDATE dedicated_orders SET status = 'paid', paid_at = ? WHERE id = ?", (datetime.now(), order_id), cursor=cursor, conn=conn)
        elif status == 'provisioned':
            self._execute_query("UPDATE dedicated_orders SET status = 'provisioned', container_name = ?, provisioned_at = ? WHERE id = ?", (container_name, datetime.now(), order_id), cursor=cursor, conn=conn)
        else:
            self._execute_query("UPDATE dedicated_orders SET status = ? WHERE id = ?", (status, order_id), cursor=cursor, conn=conn)
        logging.info(f"Dedicated order {order_id} status updated to {status}.")

    def add_dedicated_renewal_order(self, user_id: int, container_name: str, months: int, price_eur: float, track_id: str, expiration_time: datetime) -> int:
        """Adds a new dedicated VPS renewal order to the database."""
        self._execute_query(
        "INSERT INTO dedicated_renewal_orders (user_id, container_name, months, price_eur, track_id, expiration_time, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')",
        (user_id, container_name, months, price_eur, track_id, expiration_time)
        )
        result = self._fetch_one("SELECT LAST_INSERT_ID() as id")
        logging.info(f"Dedicated renewal order created for user {user_id}, VPS {container_name}, {months} months, track_id {track_id}.")
        return result['id'] if result else -1

    def get_dedicated_renewal_order_by_track_id(self, track_id: str, cursor=None, conn=None) -> dict[str, Any] | None:
        """Gets a dedicated renewal order by its OxaPay track_id."""
        return self._fetch_one("SELECT * FROM dedicated_renewal_orders WHERE track_id = ?", (track_id,), cursor=cursor, conn=conn)

    def update_dedicated_renewal_order_status(self, order_id: int, status: str, cursor=None, conn=None):
        """Updates the status of a dedicated renewal order."""
        if status == 'completed':
            self._execute_query("UPDATE dedicated_renewal_orders SET status = 'completed', completed_at = ? WHERE id = ?", (datetime.now(), order_id), cursor=cursor, conn=conn)
        else:
            self._execute_query("UPDATE dedicated_renewal_orders SET status = ? WHERE id = ?", (status, order_id), cursor=cursor, conn=conn)
        logging.info(f"Dedicated renewal order {order_id} status updated to {status}.")

    def extend_vps_expiry_by_months(self, container_name: str, months: int, cursor=None, conn=None):
        """Extends the expiry date of a VPS by a specified number of months."""
        vps = self.get_vps_by_container_name(container_name)
        if not vps:
            logging.error(f"VPS {container_name} not found for expiry extension.")
            return False

        current_due_date = vps.get('due_date')
        if current_due_date:
            # Ensure timezone awareness
            if isinstance(current_due_date, str):
                current_due_date = datetime.fromisoformat(current_due_date)
            if current_due_date.tzinfo is None:
                current_due_date = pytz.utc.localize(current_due_date)

            # If already expired, start from now
            now_utc = datetime.now(pytz.utc)
            if current_due_date < now_utc:
                new_due_date = now_utc + timedelta(days=30 * months)
            else:
                new_due_date = current_due_date + timedelta(days=30 * months)
        else:
            # No due date set, start from now
            new_due_date = datetime.now(pytz.utc) + timedelta(days=30 * months)

        self._execute_query(
            "UPDATE vps SET due_date = ? WHERE container_name = ?",
            (new_due_date, container_name),
            cursor=cursor, conn=conn
        )
        logging.info(f"Extended VPS {container_name} expiry by {months} months. New due date: {new_due_date}.")
        return True

        # ===============================================
        # TRANSACTION LOGS FUNCTIONS
        # ===============================================

    def _log_transaction(self, user_id: int, transaction_type: str, amount: int, balance_before: int, balance_after: int, reason: str = None, cursor=None, conn=None):
        """Log a transaction (credit or VPS point) to transaction_logs table."""
        self._execute_query(
        "INSERT INTO transaction_logs (user_id, transaction_type, amount, balance_before, balance_after, reason) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, transaction_type, amount, balance_before, balance_after, reason),
        cursor=cursor, conn=conn
        )
        logging.debug(f"Transaction logged: user={user_id}, type={transaction_type}, amount={amount}, reason={reason}")

    def get_transaction_logs(self, user_id: int = None, transaction_type: str = None, min_amount: int = None, max_amount: int = None, start_date: datetime = None, end_date: datetime = None, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        """Get transaction logs with advanced filters."""
        query = "SELECT * FROM transaction_logs WHERE 1=1"
        params = []
        
        if user_id:
            query += " AND user_id = ?"
        params.append(user_id)
        
        if transaction_type:
            query += " AND transaction_type = ?"
        params.append(transaction_type)
        
        if min_amount is not None:
            query += " AND amount >= ?"
        params.append(min_amount)
        
        if max_amount is not None:
            query += " AND amount <= ?"
        params.append(max_amount)
        
        if start_date:
            query += " AND created_at >= ?"
        params.append(start_date)
        
        if end_date:
            query += " AND created_at <= ?"
        params.append(end_date)
        
        query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        return self._fetch_all(query, tuple(params))

    def get_transaction_logs_count(self, user_id: int = None, transaction_type: str = None, min_amount: int = None, max_amount: int = None, start_date: datetime = None, end_date: datetime = None) -> int:
        """Get total count of transaction logs with filters."""
        query = "SELECT COUNT(*) as count FROM transaction_logs WHERE 1=1"
        params = []
        
        if user_id:
            query += " AND user_id = ?"
        params.append(user_id)
        
        if transaction_type:
            query += " AND transaction_type = ?"
        params.append(transaction_type)
        
        if min_amount is not None:
            query += " AND amount >= ?"
        params.append(min_amount)
        
        if max_amount is not None:
            query += " AND amount <= ?"
        params.append(max_amount)
        
        if start_date:
            query += " AND created_at >= ?"
        params.append(start_date)
        
        if end_date:
            query += " AND created_at <= ?"
        params.append(end_date)
        
        result = self._fetch_one(query, tuple(params))
        return result['count'] if result else 0

    def get_transaction_statistics(self, user_id: int = None, start_date: datetime = None, end_date: datetime = None) -> dict[str, Any]:
        """Get statistics about transactions."""
        query = """
        SELECT 
        transaction_type,
        COUNT(*) as count,
        SUM(amount) as total_amount,
        AVG(amount) as avg_amount,
        MIN(amount) as min_amount,
        MAX(amount) as max_amount
        FROM transaction_logs
        WHERE 1=1
        """
        params = []
        
        if user_id:
            query += " AND user_id = ?"
        params.append(user_id)
        
        if start_date:
            query += " AND created_at >= ?"
        params.append(start_date)
        
        if end_date:
            query += " AND created_at <= ?"
        params.append(end_date)
        
        query += " GROUP BY transaction_type"
        
        results = self._fetch_all(query, tuple(params))
        
        # Format results
        stats = {
        'by_type': {},
        'total_transactions': 0,
        'total_credits_added': 0,
        'total_credits_removed': 0,
        'total_points_added': 0,
        'total_points_removed': 0
        }
        
        for row in results:
            trans_type = row['transaction_type']
            stats['by_type'][trans_type] = {
                'count': row['count'],
                'total': row['total_amount'],
                'average': float(row['avg_amount']) if row['avg_amount'] else 0,
                'min': row['min_amount'],
                'max': row['max_amount']
            }
            stats['total_transactions'] += row['count']

            if trans_type == 'credit_add':
                stats['total_credits_added'] = row['total_amount']
            elif trans_type == 'credit_remove':
                stats['total_credits_removed'] = row['total_amount']
            elif trans_type == 'point_add':
                stats['total_points_added'] = row['total_amount']
            elif trans_type == 'point_remove':
                stats['total_points_removed'] = row['total_amount']

        return stats

    def archive_old_transaction_logs(self, days_old: int = 365) -> int:
        """Archive transaction logs older than specified days."""
        cutoff_date = datetime.now() - timedelta(days=days_old)
        
        # First, get count of logs to archive
        count_result = self._fetch_one(
        "SELECT COUNT(*) as count FROM transaction_logs WHERE created_at < ?",
        (cutoff_date,)
        )
        count = count_result['count'] if count_result else 0
        
        if count > 0:
            # Create archive table if it doesn't exist
            self._execute_query("""
            CREATE TABLE IF NOT EXISTS transaction_logs_archive (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT NOT NULL,
            transaction_type VARCHAR(50) NOT NULL,
            amount INT NOT NULL,
            balance_before INT NOT NULL,
            balance_after INT NOT NULL,
            reason TEXT,
            created_at TIMESTAMP,
            archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Copy to archive
            self._execute_query("""
            INSERT INTO transaction_logs_archive 
            (user_id, transaction_type, amount, balance_before, balance_after, reason, created_at)
            SELECT user_id, transaction_type, amount, balance_before, balance_after, reason, created_at
            FROM transaction_logs
            WHERE created_at < ?
            """, (cutoff_date,))

            # Delete from main table
            self._execute_query(
                "DELETE FROM transaction_logs WHERE created_at < ?",
                (cutoff_date,)
            )

            logging.info(f"Archived {count} transaction logs older than {days_old} days")

        return count

        # ===============================================

    def mark_transaction_as_processing(self, track_id: str):
        self._execute_query("UPDATE transactions SET status = 'processing' WHERE track_id = ?", (track_id,))

    def mark_transaction_as_pending(self, track_id: str):
        self._execute_query("UPDATE transactions SET status = 'pending' WHERE track_id = ?", (track_id,))

    def mark_transaction_as_completed(self, track_id: str, cursor=None, conn=None):
        self._execute_query("UPDATE transactions SET status = 'completed' WHERE track_id = ?", (track_id,), cursor=cursor, conn=conn)
        
    def mark_transaction_as_expired(self, track_id: str):
        self._execute_query("UPDATE transactions SET status = 'expired' WHERE track_id = ?", (track_id,))

    def has_completed_credit_transaction(self, user_id: int) -> bool:
        """Checks if a user has at least one completed credit purchase transaction."""
        result = self._fetch_one("SELECT COUNT(*) as count FROM transactions WHERE user_id = ? AND status = 'completed'", (user_id,))
        return result['count'] > 0 if result else False

        # ===== PORT FORWARDING FUNCTIONS =====

    def add_port_forward_entry(self, container_name: str, external_port: int, internal_port: int, protocol: str, device_name: str):
        self._execute_query(
        "INSERT INTO port_forwards (container_name, external_port, internal_port, protocol, device_name) VALUES (?, ?, ?, ?, ?)",
        (container_name, external_port, internal_port, protocol, device_name)
        )
        logging.info(f"Port forward {external_port}:{internal_port}/{protocol} added for {container_name}.")

    def remove_port_forward_entry(self, device_name: str):
        self._execute_query("DELETE FROM port_forwards WHERE device_name = ?", (device_name,))
        logging.info(f"Port forward device {device_name} removed from database.")

    def get_port_forward_by_external_port(self, external_port: int, protocol: str) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM port_forwards WHERE external_port = ? AND protocol = ?", (external_port, protocol))

    def get_port_forwards_for_container(self, container_name: str) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM port_forwards WHERE container_name = ?", (container_name,))

    def get_all_port_forwards(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM port_forwards")

    def get_stats_channel_id(self, key: str) -> int | None:
        result = self._fetch_one("SELECT channel_id FROM channel_stats WHERE channel_key = ?", (key,))
        if result and 'channel_id' in result and result['channel_id'] is not None:
            return int(result['channel_id'])
        return None

    def set_stats_channel_id(self, key: str, channel_id: int):
        self._execute_query(
        "INSERT INTO channel_stats (channel_key, channel_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE channel_id=VALUES(channel_id)",
        (key, channel_id)
        )

    def delete_stats_channel(self, key: str):
        self._execute_query("DELETE FROM channel_stats WHERE channel_key = ?", (key,))

    def add_invited_member(self, member_id: int, inviter_id: int, joined_at, invite_code: str | None = None, invite_plan_eligible: bool = True):
        month_id = self.get_current_month_id()
        self._execute_query(
        "INSERT IGNORE INTO invited_members (member_id, inviter_id, joined_at, invite_code, month_id, invite_plan_eligible) VALUES (?, ?, ?, ?, ?, ?)",
        (member_id, inviter_id, joined_at, invite_code, month_id, invite_plan_eligible)
        )
        self._execute_query(
        "INSERT IGNORE INTO invited_members_monthly (month_id, inviter_id, invited_member_id, joined_at, invite_code, invite_plan_eligible) VALUES (?, ?, ?, ?, ?, ?)",
        (month_id, inviter_id, member_id, joined_at, invite_code, invite_plan_eligible)
        )
        logging.info(f"Member {member_id} invited by {inviter_id} (code: {invite_code}) recorded for month {month_id}.")

    def update_member_leave_time(self, member_id: int, left_at):
        self._execute_query(
        "UPDATE invited_members SET left_at = ? WHERE member_id = ?",
        (left_at, member_id)
        )
        logging.info(f"Member {member_id} leave time updated to {left_at}.")

    def get_invited_member(self, member_id: int) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM invited_members WHERE member_id = ?", (member_id,))

    def get_members_invited_by(self, inviter_id: int) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM invited_members WHERE inviter_id = ?", (inviter_id,))

    def get_inviter_leaderboard_data(self) -> list[dict[str, Any]]:
        return self._fetch_all(
        '''
        SELECT
        inviter_id,
        SUM(CASE WHEN left_at IS NULL THEN 1 ELSE 0 END) as valid_invites_count,
        SUM(CASE WHEN left_at IS NOT NULL THEN 1 ELSE 0 END) as left_invites_count
        FROM invited_members
        GROUP BY inviter_id
        ORDER BY valid_invites_count DESC
        '''
        )

    def get_total_valid_invite_count(self, user_id: int) -> int:
        """Gets the total number of valid invites (users who haven't left) for a user."""
        result = self._fetch_one(
        "SELECT COUNT(*) as count FROM invited_members WHERE inviter_id = ? AND left_at IS NULL",
        (user_id,)
        )
        return result['count'] if result else 0

    def get_valid_invite_count(self, user_id: int, month_id: int | None = None) -> int:
        """Gets the number of valid invites (users who haven't left) for a user for a specific month or current month."""
        if month_id is None:
            month_id = self.get_current_month_id()
        result = self._fetch_one(
        "SELECT COUNT(*) as count FROM invited_members_monthly WHERE inviter_id = ? AND left_at IS NULL AND month_id = ?",
        (user_id, month_id)
        )
        return result['count'] if result else 0

    def get_invited_members_for_month(self, inviter_id: int, month_id: int) -> list[dict[str, Any]]:
        """Returns all invited members by an inviter for a given month."""
        return self._fetch_all(
        "SELECT * FROM invited_members_monthly WHERE inviter_id = ? AND month_id = ?",
        (inviter_id, month_id)
        )
        
    def get_invited_member_in_month(self, inviter_id: int, invited_member_id: int, month_id: int) -> dict[str, Any] | None:
        """Checks if an invited member is present for a given inviter in a specific month."""
        return self._fetch_one(
        "SELECT * FROM invited_members_monthly WHERE inviter_id = ? AND invited_member_id = ? AND month_id = ?",
        (inviter_id, invited_member_id, month_id)
        )

    def add_invite_plan_renewal_info(self, vps_id: int, user_id: int, invite_plan_tier: str, required_invites: int, renewal_month_id: int):
        """Adds renewal information for an invite-based VPS."""
        self._execute_query(
        "INSERT INTO invite_plan_renewal_info (vps_id, user_id, invite_plan_tier, required_invites, renewal_month_id) VALUES (?, ?, ?, ?, ?)",
        (vps_id, user_id, invite_plan_tier, required_invites, renewal_month_id)
        )
        logging.info(f"Invite plan renewal info added for VPS {vps_id} for month {renewal_month_id}.")

    def get_invite_plan_renewal_info(self, vps_id: int) -> dict[str, Any] | None:
        """Retrieves renewal information for an invite-based VPS."""
        return self._fetch_one(
        "SELECT * FROM invite_plan_renewal_info WHERE vps_id = ?",
        (vps_id,)
        )

    def update_invite_plan_renewal_info(self, vps_id: int, required_invites: int, renewal_month_id: int):
        """Updates renewal information for an invite-based VPS."""
        self._execute_query(
        "UPDATE invite_plan_renewal_info SET required_invites = ?, renewal_month_id = ?, last_checked = ? WHERE vps_id = ?",
        (required_invites, renewal_month_id, datetime.now(), vps_id)
        )
        logging.info(f"Invite plan renewal info updated for VPS {vps_id} for month {renewal_month_id}.")

    def get_invited_members_for_month(self, inviter_id: int, month_id: int) -> list[dict[str, Any]]:
        """Returns all invited members by an inviter for a given month."""
        return self._fetch_all(
        "SELECT * FROM invited_members_monthly WHERE inviter_id = ? AND month_id = ?",
        (inviter_id, month_id)
        )
        
    def get_invited_member_in_month(self, inviter_id: int, invited_member_id: int, month_id: int) -> dict[str, Any] | None:
        """Checks if an invited member is present for a given inviter in a specific month."""
        return self._fetch_one(
        "SELECT * FROM invited_members_monthly WHERE inviter_id = ? AND invited_member_id = ? AND month_id = ?",
        (inviter_id, invited_member_id, month_id)
        )

    def add_invite_plan_renewal_info(self, vps_id: int, user_id: int, invite_plan_tier: str, required_invites: int, renewal_month_id: int):
        """Adds renewal information for an invite-based VPS."""
        self._execute_query(
        "INSERT INTO invite_plan_renewal_info (vps_id, user_id, invite_plan_tier, required_invites, renewal_month_id) VALUES (?, ?, ?, ?, ?)",
        (vps_id, user_id, invite_plan_tier, required_invites, renewal_month_id)
        )
        logging.info(f"Invite plan renewal info added for VPS {vps_id} for month {renewal_month_id}.")

    def get_invite_plan_renewal_info(self, vps_id: int) -> dict[str, Any] | None:
        """Retrieves renewal information for an invite-based VPS."""
        return self._fetch_one(
        "SELECT * FROM invite_plan_renewal_info WHERE vps_id = ?",
        (vps_id,)
        )

    def update_invite_plan_renewal_info(self, vps_id: int, required_invites: int, renewal_month_id: int):
        """Updates renewal information for an invite-based VPS."""
        self._execute_query(
        "UPDATE invite_plan_renewal_info SET required_invites = ?, renewal_month_id = ?, last_checked = ? WHERE vps_id = ?",
        (required_invites, renewal_month_id, datetime.now(), vps_id)
        )
        logging.info(f"Invite plan renewal info updated for VPS {vps_id} for month {renewal_month_id}.")

    def mark_invite_reward_given(self, member_id: int):
        self._execute_query("UPDATE invited_members SET reward_given = 1 WHERE member_id = ?", (member_id,))
        logging.info(f"Reward marked as given for member {member_id}.")

    def get_unrewarded_members(self, joined_before: datetime) -> list[dict[str, Any]]:
        return self._fetch_all(
        "SELECT member_id, inviter_id FROM invited_members WHERE joined_at <= ? AND left_at IS NULL AND reward_given = 0",
        (joined_before.isoformat(),)
        )

    def get_last_giveaway_transaction_count(self) -> int:
        result = self._fetch_one("SELECT last_transaction_count FROM giveaway_stats WHERE id = 1")
        if result and 'last_transaction_count' in result:
            return int(result['last_transaction_count'])
        return 0

    def update_last_giveaway_transaction_count(self, count: int):
        self._execute_query("INSERT INTO giveaway_stats (id, last_transaction_count) VALUES (1, ?) ON DUPLICATE KEY UPDATE last_transaction_count=VALUES(last_transaction_count)", (count,))

    def get_current_month_id(self) -> int:
        """Returns an integer representing the current month (YYYYMM)."""
        return datetime.now().year * 100 + datetime.now().month

    def save_tos_message_id(self, message_id: int, channel_id: int):
        self._execute_query("INSERT INTO tos_message (id, message_id, channel_id) VALUES (1, ?, ?) ON DUPLICATE KEY UPDATE message_id=VALUES(message_id), channel_id=VALUES(channel_id)", (message_id, channel_id))

    def get_tos_message_id(self) -> tuple[int | None, int | None]:
        result = self._fetch_one("SELECT message_id, channel_id FROM tos_message WHERE id = 1")
        if result and 'message_id' in result and 'channel_id' in result:
            return (int(result['message_id']), int(result['channel_id']))
        return (None, None)

    def add_suspicion_log(self, container_name: str, process_list: str):
        self._execute_query("INSERT INTO suspicion_logs (container_name, process_list) VALUES (?, ?)", (container_name, process_list))

    def get_suspicion_logs(self, container_name: str, limit: int = 3) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT process_list FROM suspicion_logs WHERE container_name = ? ORDER BY detected_at DESC LIMIT ?", (container_name, limit))

    def clear_suspicion_logs(self, container_name: str):
        self._execute_query("DELETE FROM suspicion_logs WHERE container_name = ?", (container_name,))

    def create_paypal_transaction(self, user_id: int, channel_id: int, paypal_username: str) -> int | None:
        self._execute_query("INSERT INTO paypal_transactions (user_id, channel_id, paypal_username) VALUES (?, ?, ?)", (user_id, channel_id, paypal_username))
        result = self._fetch_one("SELECT LAST_INSERT_ID() as id")
        if result and 'id' in result:
            return int(result['id'])
        return None

    def get_paypal_transaction_by_channel(self, channel_id: int) -> dict[str, Any] | None:
        return self._fetch_one("SELECT * FROM paypal_transactions WHERE channel_id = ?", (channel_id,))

    def approve_paypal_transaction(self, transaction_id: int, credits: int, admin_id: int, cursor=None, conn=None):
        # First, check the current status of the transaction
        transaction = self._fetch_one("SELECT status FROM paypal_transactions WHERE id = ?", (transaction_id,), cursor=cursor, conn=conn)
        if transaction and transaction['status'] == 'pending':
            self._execute_query("UPDATE paypal_transactions SET status = 'approved', credits = ?, processed_by = ?, processed_at = ? WHERE id = ?", (credits, admin_id, datetime.now(), transaction_id), cursor=cursor, conn=conn)
            logging.info(f"PayPal transaction {transaction_id} approved by {admin_id} for {credits} credits.")
        else:
            logging.warning(f"Attempted to approve PayPal transaction {transaction_id} but its status was not pending (current status: {transaction['status'] if transaction else 'not found'}).")
            raise ValueError("Transaction is not in a pending state or not found.")

    def decline_paypal_transaction(self, transaction_id: int, admin_id: int):
        self._execute_query("UPDATE paypal_transactions SET status = 'declined', processed_by = ?, processed_at = ? WHERE id = ?", (admin_id, datetime.now(), transaction_id))

    def get_paypal_transactions_this_month(self) -> int:
        now = datetime.now()
        first_day_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        result = self._fetch_one("SELECT COUNT(*) as count FROM paypal_transactions WHERE status = 'approved' AND processed_at >= ?", (first_day_of_month,))
        if result and 'count' in result:
            return int(result['count'])
        return 0

    def get_linkvertise_daily_watches(self, user_id: int, cursor=None, conn=None) -> list[datetime]:
        result = self._fetch_one("SELECT linkvertise_daily_watches FROM ad_rewards WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        if result and result.get('linkvertise_daily_watches'):
            try:
                timestamps_str = json.loads(result['linkvertise_daily_watches'])
                # Ensure all are timezone-aware
                return [pytz.utc.localize(datetime.fromisoformat(ts.replace('Z', '+00:00'))) if isinstance(ts, str) and ts.endswith('Z') else datetime.fromisoformat(ts) for ts in timestamps_str]
            except (json.JSONDecodeError, TypeError):
                return []
        return []

    def add_linkvertise_watch(self, user_id: int, watch_time: datetime, cursor=None, conn=None):
        current_watches = self.get_linkvertise_daily_watches(user_id, cursor=cursor, conn=conn)
        
        today = watch_time.astimezone(pytz.utc).date()
        recent_watches = [watch for watch in current_watches if watch.astimezone(pytz.utc).date() == today]
        
        recent_watches.append(watch_time)
        
        timestamps_str = json.dumps([watch.isoformat() for watch in recent_watches])
        
        self._execute_query(
            "INSERT INTO ad_rewards (user_id, linkvertise_daily_watches) VALUES (?, ?) ON DUPLICATE KEY UPDATE linkvertise_daily_watches = ?",
            (user_id, timestamps_str, timestamps_str),
            cursor=cursor, conn=conn
        )
        logging.info(f"User {user_id} added a linkvertise watch time. Total today: {len(recent_watches)}")

        # ===== AD REWARDS FUNCTIONS =====

    def get_ad_credits_earned(self, user_id: int) -> int:
        result = self._fetch_one("SELECT total_ad_credits FROM ad_rewards WHERE user_id = ?", (user_id,))
        if result and 'total_ad_credits' in result:
            return int(result['total_ad_credits'])
        return 0

    def update_ad_credits_earned(self, user_id: int, amount: int, cursor=None, conn=None):
        self._execute_query("INSERT INTO ad_rewards (user_id, total_ad_credits) VALUES (?, ?) ON DUPLICATE KEY UPDATE total_ad_credits = total_ad_credits + ?", (user_id, amount, amount), cursor=cursor, conn=conn)
        logging.info(f"User {user_id} earned {amount} credits from ads.")

    def set_last_watch_date(self, user_id: int, method: str, cursor=None, conn=None):
        if method not in ['cuty', 'linkvertise']:
            raise ValueError("Invalid ad method specified.")
        
        now_utc = datetime.now(pytz.utc)
        
        if method == 'linkvertise':
            self.add_linkvertise_watch(user_id, now_utc, cursor=cursor, conn=conn)

        column_name = f"last_{method}_watch_date"
        
        self._execute_query(f"INSERT INTO ad_rewards (user_id, {column_name}) VALUES (?, ?) ON DUPLICATE KEY UPDATE {column_name} = ?", (user_id, now_utc, now_utc), cursor=cursor, conn=conn)
        logging.info(f"User {user_id} last {method} watch date updated.")

    def get_last_watch_date(self, user_id: int, method: str) -> datetime | None:
        if method not in ['cuty', 'linkvertise']:
            raise ValueError("Invalid ad method specified.")
        
        column_name = f"last_{method}_watch_date"
        
        # For backward compatibility with 'cuty'
        if method == 'cuty':
            # Check new column first, then old column
            try:
                result = self._fetch_one(f"SELECT {column_name}, last_ad_watch_date FROM ad_rewards WHERE user_id = ?", (user_id,))
            except mysql.connector.Error as e:
                # This can happen if last_ad_watch_date doesn't exist.
                if e.errno == 1054:  # "Unknown column"
                    result = self._fetch_one(f"SELECT {column_name} FROM ad_rewards WHERE user_id = ?", (user_id,))
                else:
                    raise e

            if result:
                if result.get(column_name):
                    return pytz.utc.localize(result[column_name]) if result[column_name] else None
                if result.get('last_ad_watch_date'):
                    # Data migration
                    last_date = pytz.utc.localize(result['last_ad_watch_date']) if result['last_ad_watch_date'] else None
                    if last_date:
                        self._execute_query("UPDATE ad_rewards SET last_cuty_watch_date = ?, last_ad_watch_date = NULL WHERE user_id = ?", (last_date, user_id))
                        logging.info(f"Migrated last_ad_watch_date to last_cuty_watch_date for user {user_id}")
                    return last_date
        else:  # For linkvertise
            result = self._fetch_one(f"SELECT {column_name} FROM ad_rewards WHERE user_id = ?", (user_id,))
            if result and result.get(column_name):
                return pytz.utc.localize(result[column_name])

        return None

    def store_ad_code(self, user_id: int, code: str, expiration: datetime, token: str, method: str, message_id: int | None = None, channel_id: int | None = None):
        self._execute_query(
        "INSERT INTO ad_rewards (user_id, current_ad_code, ad_code_expiration, token, current_ad_method, message_id, channel_id, ad_code_attempts) VALUES (?, ?, ?, ?, ?, ?, ?, 0) ON DUPLICATE KEY UPDATE current_ad_code = ?, ad_code_expiration = ?, token = ?, current_ad_method = ?, message_id = ?, channel_id = ?, ad_code_attempts = 0",
        (user_id, code, expiration, token, method, message_id, channel_id, code, expiration, token, method, message_id, channel_id)
        )
        logging.info(f"User {user_id} stored ad code {code} with token {token} for method {method} expiring at {expiration}. Message ID: {message_id}, Channel ID: {channel_id}.")

    def update_ad_session(self, user_id: int, token: str, code: str, method: str, cursor=None, conn=None):
        self._execute_query(
        "UPDATE ad_rewards SET current_ad_code = ?, current_ad_method = ? WHERE user_id = ? AND token = ?",
        (code, method, user_id, token),
        cursor=cursor,
        conn=conn
        )
        logging.info(f"Updated ad session for user {user_id} with new code and method {method}.")

    def get_ad_code_info(self, user_id: int) -> dict[str, Any] | None:
        return self._fetch_one("SELECT current_ad_code, ad_code_expiration, token, message_id, channel_id, current_ad_method FROM ad_rewards WHERE user_id = ?", (user_id,))

    def get_ad_code_attempts(self, user_id: int) -> int:
        result = self._fetch_one("SELECT ad_code_attempts FROM ad_rewards WHERE user_id = ?", (user_id,))
        return result['ad_code_attempts'] if result else 0

    def increment_ad_code_attempts(self, user_id: int) -> int:
        self._execute_query("UPDATE ad_rewards SET ad_code_attempts = ad_code_attempts + 1 WHERE user_id = ?", (user_id,))
        return self.get_ad_code_attempts(user_id)

    def store_ad_message_info(self, user_id: int, message_id: int, channel_id: int):
        self._execute_query("INSERT INTO ad_rewards (user_id, message_id, channel_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE message_id = ?, channel_id = ?", (user_id, message_id, channel_id, message_id, channel_id))
        logging.info(f"User {user_id} stored ad message info. Message ID: {message_id}, Channel ID: {channel_id}.")

    def clear_ad_code(self, user_id: int, cursor=None, conn=None):
        self._execute_query("UPDATE ad_rewards SET current_ad_code = NULL, ad_code_expiration = NULL, token = NULL, message_id = NULL, channel_id = NULL WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        logging.info(f"User {user_id} ad code, token, and message info cleared.")

    def clear_ad_code_attempts(self, user_id: int, cursor=None, conn=None):
        self._execute_query("UPDATE ad_rewards SET ad_code_attempts = 0 WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        logging.info(f"User {user_id} ad code attempts cleared.")

    def clear_ad_session(self, user_id: int, cursor=None, conn=None):
        """
        Clears an ad session for a user, resetting relevant fields.
        """
        self._execute_query(
        "UPDATE ad_rewards SET current_ad_code = NULL, ad_code_expiration = NULL, current_ad_method = NULL, token = NULL, ad_code_attempts = 0 WHERE user_id = ?",
        (user_id,), cursor=cursor, conn=conn
        )
        logging.info(f"Cleared ad session for user {user_id}")

    def get_brute_force_lock(self, user_id: int) -> datetime | None:
        result = self._fetch_one("SELECT brute_force_lock_until FROM ad_rewards WHERE user_id = ?", (user_id,))
        if result and result['brute_force_lock_until']:
            return result['brute_force_lock_until']
        return None

    def set_brute_force_lock(self, user_id: int, lock_until: datetime):
        self._execute_query("UPDATE ad_rewards SET brute_force_lock_until = ? WHERE user_id = ?", (lock_until, user_id,))
        logging.info(f"User {user_id} brute force locked until {lock_until}.")

    def clear_brute_force_lock(self, user_id: int):
        self._execute_query("UPDATE ad_rewards SET brute_force_lock_until = NULL WHERE user_id = ?", (user_id,))
        logging.info(f"User {user_id} brute force lock cleared.")

    def set_ad_reminder(self, user_id: int, enable: bool, next_reminder_time: datetime | None = None):
        if enable:
            self._execute_query("INSERT INTO ad_rewards (user_id, remind_me, next_reminder_time) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE remind_me = ?, next_reminder_time = ?", (user_id, 1, next_reminder_time, 1, next_reminder_time))
            logging.info(f"User {user_id} ad reminder enabled for {next_reminder_time}.")
        else:
            self._execute_query("INSERT INTO ad_rewards (user_id, remind_me) VALUES (?, ?) ON DUPLICATE KEY UPDATE remind_me = ?, next_reminder_time = NULL", (user_id, 0, 0))
            logging.info(f"User {user_id} ad reminder disabled.")

    def get_users_for_ad_reminder(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT user_id, next_reminder_time FROM ad_rewards WHERE remind_me = 1 AND next_reminder_time <= ?", (datetime.now(pytz.utc),))

    def save_paid_plans_message_id(self, message_id: int, channel_id: int):
        self._execute_query("INSERT INTO paid_plans_message (id, message_id, channel_id) VALUES (1, ?, ?) ON DUPLICATE KEY UPDATE message_id=VALUES(message_id), channel_id=VALUES(channel_id)", (message_id, channel_id))
        logging.info(f"Paid plans message ID {message_id} saved for channel {channel_id}.")

        # Helper function to retrieve paid plans message ID and channel ID
    def get_paid_plans_message_id(self) -> tuple[int | None, int | None]:
        result = self._fetch_one("SELECT message_id, channel_id FROM paid_plans_message WHERE id = 1")
        if result and 'message_id' in result and 'channel_id' in result:
            return (int(result['message_id']), int(result['channel_id']))
        return (None, None)

        # ===== PLAN PANEL MESSAGES FUNCTIONS =====
        # CREATE TABLE plan_panel_messages (
        # panel_type VARCHAR(50) PRIMARY KEY,
        # channel_id BIGINT NOT NULL,
        # message_id BIGINT NOT NULL
        # );

    def save_plan_panel_message(self, panel_type: str, channel_id: int, message_id: int):
        """Saves or updates the message ID for a plan panel."""
        self._execute_query(
        "INSERT INTO plan_panel_messages (panel_type, channel_id, message_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE channel_id=VALUES(channel_id), message_id=VALUES(message_id)",
        (panel_type, channel_id, message_id)
        )
        logging.info(f"Saved message ID {message_id} for plan panel '{panel_type}'.")

    def get_plan_panel_message(self, panel_type: str) -> tuple[int, int] | None:
        """Retrieves the channel ID and message ID for a plan panel."""
        result = self._fetch_one("SELECT channel_id, message_id FROM plan_panel_messages WHERE panel_type = ?", (panel_type,))
        if result and 'channel_id' in result and 'message_id' in result:
            return (int(result['channel_id']), int(result['message_id']))
        return None

        # ==========================================

    def is_feature_enabled(self, flag_name: str) -> bool:
        result = self._fetch_one("SELECT is_enabled FROM feature_flags WHERE flag_name = ?", (flag_name,))
        if result is None:
            return True # Default to enabled if not in DB
        return bool(result['is_enabled'])

    def set_feature_enabled(self, flag_name: str, is_enabled: bool):
        self._execute_query(
        "INSERT INTO feature_flags (flag_name, is_enabled) VALUES (?, ?) ON DUPLICATE KEY UPDATE is_enabled = ?",
        (flag_name, 1 if is_enabled else 0, 1 if is_enabled else 0)
        )
        logging.info(f"Feature flag '{flag_name}' set to {is_enabled}.")

    def reset_negative_pending_balances(self):
        self._execute_query("UPDATE users SET pending_balance = 0 WHERE pending_balance < 0")
        logging.info("All negative pending balances have been reset to 0.")
        
        # ===== VIRUSTOTAL DAILY STATS FUNCTIONS =====

    def get_virustotal_daily_requests(self, date_str: str, api_key_hash: str) -> int:
        """Get the VirusTotal API request count for a specific date and API key."""
        result = self._fetch_one(
        "SELECT request_count FROM virustotal_daily_stats WHERE record_date = ? AND key_hash = ?",
        (date_str, api_key_hash)
        )
        return result['request_count'] if result else 0

    def increment_virustotal_daily_requests(self, date_str: str, api_key_hash: str):
        """Increment the VirusTotal API request count for a specific date and API key."""
        self._execute_query(
        "INSERT INTO virustotal_daily_stats (record_date, key_hash, request_count) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE request_count = request_count + 1",
        (date_str, api_key_hash)
        )
        logging.debug(f"Incremented VirusTotal daily requests for {api_key_hash} on {date_str}")
        
        # ===== FILE SCAN RESULTS FUNCTIONS =====

    def get_file_scan_result(self, file_hash: str) -> dict[str, Any] | None:
        """Get cached scan result for a file hash"""
        result = self._fetch_one(
        "SELECT * FROM file_scan_results WHERE file_hash = ?",
        (file_hash,)
        )
        if result:
            # Update last_seen
            self._execute_query(
                "UPDATE file_scan_results SET last_seen = ? WHERE file_hash = ?",
                (datetime.now(), file_hash)
            )
        return result

    def save_file_scan_result(self, file_hash: str, scan_data: dict):
        """Save or update file scan result"""
        self._execute_query(
        '''INSERT INTO file_scan_results 
        (file_hash, filepath, threat_level, detection_ratio, vt_positives, vt_total, 
        suspicious, official, quarantined, ai_decision)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        filepath=VALUES(filepath),
        threat_level=VALUES(threat_level),
        detection_ratio=VALUES(detection_ratio),
        vt_positives=VALUES(vt_positives),
        vt_total=VALUES(vt_total),
        suspicious=VALUES(suspicious),
        official=VALUES(official),
        quarantined=VALUES(quarantined),
        ai_decision=VALUES(ai_decision),
        last_seen=CURRENT_TIMESTAMP''',
        (
        file_hash,
        scan_data.get('filepath'),
        scan_data.get('threat_level', 0),
        scan_data.get('detection_ratio'),
        scan_data.get('vt_positives'),
        scan_data.get('vt_total'),
        1 if scan_data.get('suspicious') else 0,
        1 if scan_data.get('official') else 0,
        1 if scan_data.get('quarantined') else 0,
        json.dumps(scan_data.get('ai_decision')) if scan_data.get('ai_decision') else None
        )
        )
        logging.info(f"Saved scan result for hash {file_hash}: threat level {scan_data.get('threat_level', 0)}%")

    def get_suspicious_files(self, min_threat_level: int = 50) -> list[dict[str, Any]]:
        """Get all suspicious files above a certain threat level"""
        return self._fetch_all(
        "SELECT * FROM file_scan_results WHERE threat_level >= ? ORDER BY threat_level DESC",
        (min_threat_level,)
        )

    def get_quarantined_files(self, container_name: str | None = None) -> list[dict[str, Any]]:
        """Get quarantined files, optionally filtered by container"""
        if container_name:
            return self._fetch_all(
        "SELECT * FROM quarantine_log WHERE container_name = ? AND restored = 0 ORDER BY quarantined_at DESC",
        (container_name,)
        )
        return self._fetch_all(
        "SELECT * FROM quarantine_log WHERE restored = 0 ORDER BY quarantined_at DESC"
        )

    def cleanup_old_scan_results(self, days: int = 30):
        """Clean up scan results older than specified days"""
        cutoff_date = datetime.now() - timedelta(days=days)
        self._execute_query(
        "DELETE FROM file_scan_results WHERE last_seen < ? AND threat_level < 50",
        (cutoff_date,)
        )
        logging.info(f"Cleaned up scan results older than {days} days")

        # ===== SECURITY THREATS FUNCTIONS =====

    def log_security_threat(self, container_name: str, threat_score: int, threat_data: str):
        """Log a security threat"""
        severity = 'CRITICAL' if threat_score >= 80 else 'HIGH' if threat_score >= 50 else 'MEDIUM'
        
        self._execute_query(
        '''INSERT INTO security_threats (container_name, threat_score, severity, threat_data)
        VALUES (?, ?, ?, ?)''',
        (container_name, threat_score, severity, threat_data)
        )
        logging.warning(f"Security threat logged for {container_name}: {severity} (score: {threat_score})")

    def get_security_threats(self, container_name: str | None = None, resolved: bool = False, hours: int = 24) -> list[dict[str, Any]]:
        """Get security threats, optionally filtered by container and time."""
        cutoff_date = datetime.now() - timedelta(hours=hours)
        if container_name:
            return self._fetch_all(
        "SELECT * FROM security_threats WHERE container_name = ? AND resolved = ? AND detected_at >= ? ORDER BY detected_at DESC",
        (container_name, 1 if resolved else 0, cutoff_date)
        )
        return self._fetch_all(
        "SELECT * FROM security_threats WHERE resolved = ? AND detected_at >= ? ORDER BY detected_at DESC",
        (1 if resolved else 0, cutoff_date)
        )

    def resolve_security_threat(self, threat_id: int):
        """Mark a security threat as resolved"""
        self._execute_query(
        "UPDATE security_threats SET resolved = 1, resolved_at = ? WHERE id = ?",
        (datetime.now(), threat_id)
        )
        logging.info(f"Security threat {threat_id} marked as resolved")

    def get_threat_statistics(self, days: int = 30) -> dict[str, Any]:
        """Get threat statistics for the specified period"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        total = self._fetch_one(
        "SELECT COUNT(*) as count FROM security_threats WHERE detected_at >= ?",
        (cutoff_date,)
        )
        
        by_severity = self._fetch_all(
        "SELECT severity, COUNT(*) as count FROM security_threats WHERE detected_at >= ? GROUP BY severity",
        (cutoff_date,)
        )
        
        by_container = self._fetch_all(
        """SELECT container_name, COUNT(*) as count, AVG(threat_score) as avg_score
        FROM security_threats
        WHERE detected_at >= ?
        GROUP BY container_name
        ORDER BY count DESC
        LIMIT 10""",
        (cutoff_date,)
        )
        
        return {
        'total_threats': total['count'] if total else 0,
        'by_severity': {row['severity']: row['count'] for row in by_severity},
        'top_containers': by_container
        }

        # ===== QUARANTINE FUNCTIONS =====

    def log_quarantine(self, container_name: str, original_path: str, quarantine_path: str, file_hash: str | None = None, threat_level: int | None = None):
        """Log a quarantined file"""
        self._execute_query(
        '''INSERT INTO quarantine_log (container_name, original_path, quarantine_path, file_hash, threat_level)
        VALUES (?, ?, ?, ?, ?)''',
        (container_name, original_path, quarantine_path, file_hash, threat_level)
        )
        logging.info(f"Quarantined: {original_path} -> {quarantine_path}")

    def restore_quarantined_file(self, quarantine_id: int):
        """Mark a quarantined file as restored"""
        self._execute_query(
        "UPDATE quarantine_log SET restored = 1, restored_at = ? WHERE id = ?",
        (datetime.now(), quarantine_id)
        )
        logging.info(f"Quarantine entry {quarantine_id} marked as restored")

        # ===== NETWORK STATISTICS FUNCTIONS =====

    def save_network_stats(self, container_name: str, stats: dict):
        """Save network statistics for a container"""
        self._execute_query(
        '''INSERT INTO network_stats (container_name, bytes_sent, bytes_received)
        VALUES (?, ?, ?)''',
        (
        container_name,
        stats.get('bytes_sent', 0),
        stats.get('bytes_received', 0)
        )
        )

    def get_network_stats(self, container_name: str) -> dict[str, Any] | None:
        """Get the most recent network statistics"""
        return self._fetch_one(
        "SELECT * FROM network_stats WHERE container_name = ? ORDER BY recorded_at DESC LIMIT 1",
        (container_name,)
        )

    def cleanup_old_network_stats(self, days: int = 7):
        """Clean up old network statistics"""
        cutoff_date = datetime.now() - timedelta(days=days)
        self._execute_query(
        "DELETE FROM network_stats WHERE recorded_at < ?",
        (cutoff_date,)
        )
        logging.info(f"Cleaned up network stats older than {days} days")

        # ===== RESOURCE ABUSE FUNCTIONS =====

    def log_resource_abuse(self, container_name: str, abuse_type: str, abuse_value: str):
        """Log resource abuse incident"""
        self._execute_query(
        "INSERT INTO resource_abuse_log (container_name, abuse_type, abuse_value) VALUES (?, ?, ?)",
        (container_name, abuse_type, abuse_value)
        )
        logging.warning(f"Resource abuse logged: {container_name} - {abuse_type}: {abuse_value}")

    def get_resource_abuse_history(self, container_name: str, days: int = 7) -> list[dict[str, Any]]:
        """Get resource abuse history for a container"""
        cutoff_date = datetime.now() - timedelta(days=days)
        return self._fetch_all(
        "SELECT * FROM resource_abuse_log WHERE container_name = ? AND detected_at >= ? ORDER BY detected_at DESC",
        (container_name, cutoff_date)
        )

    def get_containers_with_abuse(self, days: int = 7) -> list[dict[str, Any]]:
        """Get containers with resource abuse in the specified period"""
        cutoff_date = datetime.now() - timedelta(days=days)
        return self._fetch_all(
        """SELECT container_name, abuse_type, COUNT(*) as count
        FROM resource_abuse_log
        WHERE detected_at >= ?
        GROUP BY container_name, abuse_type
        ORDER BY count DESC""",
        (cutoff_date,)
        )

    def add_vps_command_log(self, vps_id: int, command: str):
        self._execute_query("INSERT INTO vps_command_logs (vps_id, command) VALUES (?, ?)", (vps_id, command))

    def get_unanalyzed_command_logs(self) -> list[dict[str, Any]]:
        return self._fetch_all("SELECT * FROM vps_command_logs WHERE analyzed_by_ai = FALSE")

        # ===== AD-TIER VPS FUNCTIONS =====

    def get_all_ad_tier_vps(self) -> list[dict[str, Any]]:
        """Get all VPS instances with ad-supported tier."""
        return self._fetch_all("SELECT * FROM vps WHERE plan_tier IS NOT NULL AND plan_tier != ''")

    def get_all_paid_vps(self) -> list[dict[str, Any]]:
        """Get all VPS that are paid with credits (not ad-tier or invite-tier)."""
        return self._fetch_all("SELECT * FROM vps WHERE (plan_tier IS NULL OR plan_tier = '') AND (invite_plan_tier IS NULL OR invite_plan_tier = '')")

    def get_suspended_paid_vps_for_deletion(self, days: int) -> list[dict[str, Any]]:
        """Get paid VPS suspended for more than X days."""
        cutoff_date = datetime.now() - timedelta(days=days)
        return self._fetch_all(
        "SELECT * FROM vps WHERE (plan_tier IS NULL OR plan_tier = '') AND (invite_plan_tier IS NULL OR invite_plan_tier = '') AND is_suspended = 1 AND suspended_at <= ?",
        (cutoff_date,)
        )

    def get_suspended_ad_tier_vps_for_deletion(self, days: int = 7) -> list[dict[str, Any]]:
        """Get ad-tier VPS suspended for more than X days."""
        cutoff_date = datetime.now() - timedelta(days=days)
        return self._fetch_all(
        "SELECT * FROM vps WHERE plan_tier IS NOT NULL AND status = 'suspended' AND suspended_at <= ?",
        (cutoff_date,)
        )

    def get_total_ads_watched(self) -> int:
        """Get total number of ads watched by all users."""
        result = self._fetch_one("SELECT COALESCE(SUM(ads_watched_total), 0) as total FROM ad_rewards")
        return result['total'] if result else 0

    def get_ad_watch_log(self, user_id: int) -> list[datetime]:
        """Get list of ad watch timestamps for a user in the last 24 hours."""
        result = self._fetch_one("SELECT linkvertise_daily_watches FROM ad_rewards WHERE user_id = ?", (user_id,))
        if result and result.get('linkvertise_daily_watches'):
            try:
                timestamps_str = json.loads(result['linkvertise_daily_watches'])
                return [datetime.fromisoformat(ts) for ts in timestamps_str]
            except (json.JSONDecodeError, ValueError):
                return []
        return []

    def extend_vps_due_date_by_days(self, vps_id: int, days: int, cursor=None, conn=None):
        """Extend VPS due date by X days. If due_date is in the past, renewal starts from now."""
        vps = self.get_vps_by_id(vps_id, cursor=cursor, conn=conn)
        if vps:
            current_due_date = vps['due_date']
            if isinstance(current_due_date, str):
                current_due_date = datetime.fromisoformat(current_due_date.replace('Z', '+00:00'))
            now = datetime.now()
            # If expired, start from now; otherwise add days to current due date
            base_date = now if (not current_due_date or current_due_date < now) else current_due_date
            new_due_date = base_date + timedelta(days=days)
            self._execute_query("UPDATE vps SET due_date = ?, status = 'active' WHERE id = ?", (new_due_date, vps_id), cursor=cursor, conn=conn)
            logging.info(f"VPS {vps_id} due date extended by {days} days. New due date: {new_due_date}")

    def set_vps_due_date(self, vps_id: int, new_due_date: datetime, cursor=None, conn=None):
        """Sets the due date for a VPS to a specific date."""
        self._execute_query("UPDATE vps SET due_date = ? WHERE id = ?", (new_due_date, vps_id), cursor=cursor, conn=conn)
        logging.info(f"VPS {vps_id} due date set to: {new_due_date}")

    def update_vps_plan_tier(self, vps_id: int, plan_tier: str, cursor=None, conn=None):
        """Update the plan tier of a VPS."""
        self._execute_query("UPDATE vps SET plan_tier = ? WHERE id = ?", (plan_tier, vps_id), cursor=cursor, conn=conn)
        logging.info(f"VPS {vps_id} plan tier updated to {plan_tier}")

    def update_vps_last_scan(self, vps_id: int, last_scan_time: datetime, cursor=None, conn=None):
        """Updates the last_scan_time for a VPS."""
        self._execute_query("UPDATE vps SET last_scan_time = ? WHERE id = ?", (last_scan_time, vps_id), cursor=cursor, conn=conn)
        logging.info(f"VPS {vps_id} last scan time updated to {last_scan_time}.")

    def get_user_ad_tier_vps_count(self, user_id: int) -> int:
        """Count how many ad-tier VPS instances a user has."""
        result = self._fetch_one("SELECT COUNT(*) as count FROM vps WHERE user_id = ? AND plan_tier IS NOT NULL AND plan_tier != ''", (user_id,))
        return result['count'] if result else 0

    def get_user_invite_vps(self, user_id: int) -> dict[str, Any] | None:
        """Get a user's invite-based VPS."""
        return self._fetch_one("SELECT * FROM vps WHERE user_id = ? AND invite_plan_tier IS NOT NULL AND invite_plan_tier != ''", (user_id,))

    def get_all_invite_vps(self) -> list[dict[str, Any]]:
        """Get all VPS instances with invite-based tier."""
        return self._fetch_all("SELECT * FROM vps WHERE invite_plan_tier IS NOT NULL AND invite_plan_tier != ''")

    def get_user_ad_tier_vps_by_tier(self, user_id: int, plan_tier: str) -> list[dict[str, Any]]:
        """Get all ad-tier VPS instances for a user by specific tier."""
        return self._fetch_all("SELECT * FROM vps WHERE user_id = ? AND plan_tier = ?", (user_id, plan_tier))

    def increment_ads_watched_for_user(self, user_id: int, cursor=None, conn=None):
        """Increment total ads watched for a user."""
        self._execute_query(
        "UPDATE ad_rewards SET ads_watched_total = ads_watched_total + 1 WHERE user_id = ?",
        (user_id,), cursor=cursor, conn=conn
        )
        logging.info(f"User {user_id} ads_watched_total incremented")

    def update_vps_ads_watched_today(self, vps_id: int, count: int, cursor=None, conn=None):
        """Update the ads watched today count for a VPS."""
        self._execute_query("UPDATE vps SET ads_watched_today = ? WHERE id = ?", (count, vps_id), cursor=cursor, conn=conn)
        logging.info(f"VPS {vps_id} ads_watched_today updated to {count}")

    def add_ad_watch_log(self, user_id: int, watch_time: datetime = None, cursor=None, conn=None):
        """Add an ad watch log entry for a user (alias for add_linkvertise_watch)."""
        if watch_time is None:
            watch_time = datetime.now(pytz.utc)
        return self.add_linkvertise_watch(user_id, watch_time, cursor=cursor, conn=conn)

    def consume_ads(self, user_id: int, ads_count: int, cursor=None, conn=None):
        """Consume/increment ads watched for a user (for ad-tier VPS renewal)."""
        self._execute_query(
        "UPDATE ad_rewards SET ads_watched_total = ads_watched_total + ? WHERE user_id = ?",
        (ads_count, user_id), cursor=cursor, conn=conn
        )
        logging.info(f"User {user_id} consumed {ads_count} ads for VPS renewal")

    def increment_terms_reminder_count(self, user_id: int, cursor=None, conn=None):
        """Increment the terms reminder count for a user."""
        self._execute_query(
        "UPDATE ad_rewards SET terms_reminder_count = terms_reminder_count + 1, terms_last_reminder_date = ? WHERE user_id = ?",
        (datetime.now(), user_id), cursor=cursor, conn=conn
        )
        logging.info(f"User {user_id} terms reminder count incremented")

    def reset_terms_reminder_count(self, user_id: int, cursor=None, conn=None):
        """Reset the terms reminder count for a user (after they accept terms)."""
        self._execute_query(
        "UPDATE ad_rewards SET terms_reminder_count = 0, terms_last_reminder_date = NULL WHERE user_id = ?",
        (user_id,), cursor=cursor, conn=conn
        )
        logging.info(f"User {user_id} terms reminder count reset")

    def get_terms_reminder_info(self, user_id: int) -> dict[str, Any] | None:
        """Get terms reminder info for a user."""
        return self._fetch_one(
        "SELECT terms_reminder_count, terms_last_reminder_date FROM ad_rewards WHERE user_id = ?",
        (user_id,)
        )

    def add_vps_points(self, user_id: int, points: int, reason: str = None, cursor=None, conn=None):
        """Add VPS points to a user (for linkvertise ads)."""
        # Get points before
        points_before = self.get_vps_points(user_id, cursor=cursor, conn=conn)
        
        self._execute_query(
        "INSERT INTO users (user_id, vps_points) VALUES (?, ?) ON DUPLICATE KEY UPDATE vps_points = vps_points + ?",
        (user_id, points, points), cursor=cursor, conn=conn
        )
        
        # Get points after
        points_after = points_before + points
        
        # Log transaction
        transaction_type = "point_add" if points > 0 else "point_remove"
        self._log_transaction(user_id, transaction_type, abs(points), points_before, points_after, reason, cursor=cursor, conn=conn)
        
        logging.info(f"User {user_id} earned {points} VPS points. Reason: {reason}")

    def get_vps_points(self, user_id: int, cursor=None, conn=None) -> int:
        """Get total VPS points for a user."""
        result = self._fetch_one("SELECT vps_points FROM users WHERE user_id = ?", (user_id,), cursor=cursor, conn=conn)
        if result and result.get('vps_points') is not None:
            return result['vps_points']
        
        # If user doesn't exist in users table, create entry with 0 points
        try:
            self._execute_query(
                "INSERT INTO users (user_id, vps_points) VALUES (?, 0) ON DUPLICATE KEY UPDATE vps_points = vps_points",
                (user_id,), cursor=cursor, conn=conn
            )
        except Exception as e:
            logging.debug(f"Could not ensure user entry: {e}")

        return 0

    def consume_vps_points(self, user_id: int, points: int, cursor=None, conn=None) -> bool:
        """Consume/deduct VPS points for VPS renewal. Returns True if successful."""
        current_points = self.get_vps_points(user_id, cursor=cursor, conn=conn)
        if current_points < points:
            logging.warning(f"User {user_id} does not have enough points. Has {current_points}, needs {points}")
            return False

        try:
            self._execute_query(
                "UPDATE users SET vps_points = vps_points - ? WHERE user_id = ?",
                (points, user_id), cursor=cursor, conn=conn
            )
            logging.info(f"User {user_id} consumed {points} VPS points. Remaining: {current_points - points}")
            return True
        except Exception as e:
            logging.error(f"Error consuming VPS points for user {user_id}: {e}")
            return False

    def mark_commands_as_analyzed(self, log_ids: list[int], suspicious_log_ids: list[int]):
        if not log_ids:
            return
        
        # Mark all as analyzed
        query_placeholder = ','.join(['%s'] * len(log_ids))
        self._execute_query(f"UPDATE vps_command_logs SET analyzed_by_ai = TRUE WHERE id IN ({query_placeholder})", tuple(log_ids))
        
        # Mark suspicious ones
        if suspicious_log_ids:
            suspicious_query_placeholder = ','.join(['%s'] * len(suspicious_log_ids))
        self._execute_query(f"UPDATE vps_command_logs SET is_suspicious = TRUE WHERE id IN ({suspicious_query_placeholder})", tuple(suspicious_log_ids))

    def update_user_ip_status(self, user_id: int, is_verified: bool | None = None, ip_warning_sent_at: datetime | None = None, ip_warning_count: int | None = None, vps_suspension_date: datetime | None = None, public_ip: str | None = None):
        """
        Updates the IP verification status for a user, including verification status, warning timestamps, count,
        suspension date, and public IP address.
        """
        # Ensure user exists
        self._execute_query("INSERT INTO users (user_id) VALUES (?) ON DUPLICATE KEY UPDATE user_id=user_id", (user_id,))

        set_clauses: list[str] = []
        params: list[Any] = []

        if is_verified is not None:
            set_clauses.append("is_ip_verified = ?")
            params.append(1 if is_verified else 0)

        if ip_warning_sent_at is not None:
            set_clauses.append("ip_warning_sent_at = ?")
            params.append(ip_warning_sent_at)

        if ip_warning_count is not None:
            set_clauses.append("ip_warning_count = ?")
            params.append(ip_warning_count)

        if vps_suspension_date is not None:
            set_clauses.append("vps_suspension_date = ?")
            params.append(vps_suspension_date)

        if public_ip is not None:
            set_clauses.append("public_ip = ?")
            params.append(public_ip)

        if not set_clauses:
            logging.debug(f"No IP status fields to update for user {user_id}")
            return

        params.append(user_id)
        sql = f"UPDATE users SET {', '.join(set_clauses)} WHERE user_id = ?"
        self._execute_query(sql, params)

        if is_verified:
            self.clear_ip_verification_state(user_id)
        logging.info(f"Updated IP status for user {user_id}. Changes: {set_clauses}")

    def get_user_ip_status(self, user_id: int) -> dict[str, Any]:
        """
        Retrieves the full IP verification status for a user.
        Returns a dictionary with 'is_ip_verified', 'ip_warning_sent_at', 'ip_warning_count',
        'vps_suspension_date', 'public_ip'.
        """
        default_status = {
        'is_ip_verified': False,
        'ip_warning_sent_at': None,
        'ip_warning_count': 0,
        'vps_suspension_date': None,
        'public_ip': None
        }

        # Check if the user exists
        user_exists_result = self._fetch_one("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        if not user_exists_result:
            # If user does not exist, return default status
            return default_status

        # Safely check for column existence before querying them
        columns_to_fetch = ['is_ip_verified', 'ip_warning_sent_at', 'ip_warning_count', 'vps_suspension_date', 'public_ip']
        existing_columns = []
        for col in columns_to_fetch:
            if self._column_exists('users', col):
                existing_columns.append(col)
            else:
                logging.warning(f"Column 'users.{col}' does not exist. Defaulting its value for user {user_id}.")

        if not existing_columns:
            return default_status  # No relevant columns found, return default.

        select_query_columns = ", ".join(existing_columns)
        result = self._fetch_one(f"SELECT {select_query_columns} FROM users WHERE user_id = ?", (user_id,))

        if result:
            status = default_status.copy()
            if 'is_ip_verified' in result:
                status['is_ip_verified'] = bool(result['is_ip_verified'])
            if 'ip_warning_sent_at' in result and result['ip_warning_sent_at']:
                status['ip_warning_sent_at'] = pytz.utc.localize(result['ip_warning_sent_at'])
            if 'ip_warning_count' in result:
                status['ip_warning_count'] = result['ip_warning_count']
            if 'vps_suspension_date' in result and result['vps_suspension_date']:
                status['vps_suspension_date'] = pytz.utc.localize(result['vps_suspension_date'])
            if 'public_ip' in result:
                status['public_ip'] = result['public_ip']
            return status

        return default_status  # Should not be reached if user_exists_result was true, but for safety

    def clear_ip_verification_state(self, user_id: int):
        """
        Clears all IP verification warning and suspension related timestamps and counters
        for a given user. This is typically called when a user successfully verifies their IP.
        """
        set_clauses = []
        if self._column_exists('users', 'ip_warning_sent_at'):
            set_clauses.append("ip_warning_sent_at = NULL")
        if self._column_exists('users', 'ip_warning_count'):
            set_clauses.append("ip_warning_count = 0")
        if self._column_exists('users', 'vps_suspension_date'):
            set_clauses.append("vps_suspension_date = NULL")
        
        if set_clauses:
            sql = f"UPDATE users SET {', '.join(set_clauses)} WHERE user_id = ?"
            self._execute_query(sql, (user_id,))
            logging.info(f"Cleared IP verification states for user {user_id}. Cleared: {set_clauses}")
        else:
            logging.warning(f"No IP warning or suspension columns found to clear for user {user_id}.")

    def delete_user_vps_entry(self, vps_id: int):
        """Deletes a VPS entry from the database by its ID."""
        self._execute_query("DELETE FROM vps WHERE id = ?", (vps_id,))
        logging.info(f"VPS entry with ID {vps_id} deleted from database.")

        # ===== IP VERIFICATION FUNCTIONS =====

    def is_ip_already_used(self, ip_address: str, user_id_to_exclude: int) -> bool:
        """Checks if an IP address is already in use by another user."""
        if not self._column_exists('users', 'public_ip'):
            return False
        result = self._fetch_one("SELECT COUNT(*) as count FROM users WHERE public_ip = ? AND user_id != ?", (ip_address, user_id_to_exclude))
        return result['count'] > 0 if result else False

    def set_ip_verification_token(self, user_id: int, token: str, expiration: datetime):
        """Stores or updates an IP verification token for a user."""
        self._execute_query(
        "INSERT INTO ip_verification_tokens (user_id, token, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token=VALUES(token), expires_at=VALUES(expires_at)",
        (user_id, token, expiration)
        )

    def get_ip_verification_token(self, user_id: int) -> dict[str, Any] | None:
        """Retrieves the current IP verification token for a user."""
        return self._fetch_one("SELECT token, expires_at FROM ip_verification_tokens WHERE user_id = ?", (user_id,))

    def clear_ip_verification_token(self, user_id: int):
        """Deletes an IP verification token for a user after it has been used."""
        self._execute_query("DELETE FROM ip_verification_tokens WHERE user_id = ?", (user_id,))

    def update_user_ip_and_verify(self, user_id: int, ip_address: str):
        """Sets the user's public IP and marks them as verified."""
        # Now uses the comprehensive update_user_ip_status method
        self.update_user_ip_status(user_id, is_verified=True, public_ip=ip_address)
        logging.info(f"User {user_id} verified IP to {ip_address} and all warning states cleared.")

    def get_user_by_ip(self, ip_address: str) -> dict | None:
        """Récupère un utilisateur par son adresse IP publique (anti-double compte)."""
        result = self._fetch_one(
        "SELECT user_id, public_ip, is_ip_verified FROM users WHERE public_ip = ? AND is_ip_verified = TRUE",
        (ip_address,)
        )
        return result

    def reset_user_ip_verification(self, user_id: int):
        """Resets a user's IP verification status, forcing them to re-verify."""
        self._execute_query(
        "UPDATE users SET is_ip_verified = FALSE, public_ip = NULL WHERE user_id = ?",
        (user_id,)
        )

    def get_ip_warning_sent_at(self, user_id: int) -> datetime | None:
        """Retrieves the timestamp when an IP verification warning was sent to a user."""
        result = self._fetch_one("SELECT ip_warning_sent_at FROM users WHERE user_id = ?", (user_id,))
        if result and result['ip_warning_sent_at']:
            return pytz.utc.localize(result['ip_warning_sent_at'])
        return None

    def set_ip_warning_sent_at(self, user_id: int, timestamp: datetime):
        """Sets the timestamp when an IP verification warning was sent to a user."""
        self._execute_query("UPDATE users SET ip_warning_sent_at = ? WHERE user_id = ?", (timestamp, user_id))

    def clear_ip_warning_sent_at(self, user_id: int):
        """Clears the timestamp when an IP verification warning was sent to a user."""
        # This function now delegates to the more comprehensive clear_ip_verification_state
        self.clear_ip_verification_state(user_id)
        logging.info(f"Legacy clear_ip_warning_sent_at called, delegated to clear_ip_verification_state for user {user_id}.")

        # 
        # MÉTHODES DE MIGRATION AUTOMATIQUE DE LA BASE DE DONNÉES
        # 

    def _verify_and_migrate_database(self):
        """
        Vérifie et migre automatiquement toutes les tables et colonnes nécessaires
        Version optimisée : vérifie uniquement les colonnes critiques pour éviter les blocages
        """
        logging.info(" Vérification rapide du schéma de la base de données...")
        
        # Colonnes critiques à vérifier (table, colonne, définition)
        critical_columns = [
        ('vps', 'username', 'VARCHAR(255)'),
        ('vps', 'status', 'VARCHAR(50) DEFAULT "active"'),
        ('vps', 'is_suspended', 'BOOLEAN DEFAULT FALSE'),
        ('vps', 'suspicion_count', 'INT DEFAULT 0'),
        ]
        
        columns_added = 0
        errors = []
        
        for table_name, column_name, column_def in critical_columns:
            try:
                if not self._column_exists(table_name, column_name):
                    logging.info(f" Ajout de la colonne '{column_name}' à la table '{table_name}'...")
                    self._add_column(table_name, column_name, column_def)
                    columns_added += 1
            except Exception as e:
                error_msg = f"Erreur lors de l'ajout de '{table_name}.{column_name}': {e}"
                logging.error(error_msg)
                errors.append(error_msg)
        
        # Vérifier et modifier vmid pour qu'il soit nullable
        try:
            # Vérifier si vmid existe et n'est pas nullable
            query = """
            SELECT IS_NULLABLE
            FROM information_schema.columns
            WHERE table_schema = %s AND table_name = 'vps' AND column_name = 'vmid'
            """
            result = self._fetch_one(query, (self.db_config['database'],))
            if result and result['IS_NULLABLE'] == 'NO':
                logging.info(" Modification de la colonne 'vmid' pour la rendre nullable...")
                self._execute_query("ALTER TABLE vps MODIFY COLUMN vmid INT DEFAULT NULL")
                logging.info(" Colonne 'vmid' modifiée avec succès")
                columns_added += 1
        except Exception as e:
            error_msg = f"Erreur lors de la modification de vmid: {e}"
            logging.error(error_msg)
            errors.append(error_msg)
        
        # Résumé
        logging.info("="*80)
        logging.info("[OK] Vérification rapide du schéma terminée")
        if columns_added > 0:
            logging.info(f" {columns_added} colonne(s) ajoutée(s)/modifiée(s)")
        if errors:
            logging.warning(f" [WARNING] {len(errors)} erreur(s) rencontrée(s)")
            for error in errors:
                logging.warning(f" - {error}")
        logging.info("="*80)

    def _table_exists(self, table_name: str) -> bool:
        """Vérifie si une table existe"""
        try:
            query = """
            SELECT COUNT(*) as count
            FROM information_schema.tables
            WHERE table_schema = %s AND table_name = %s
            """
            result = self._fetch_one(query, (self.db_config['database'], table_name))
            return result['count'] > 0 if result else False
        except Exception as e:
            logging.error(f"Erreur lors de la vérification de l'existence de la table '{table_name}': {e}")
            return False

    def _create_table(self, table_name: str, schema: Dict):
        """Crée une table avec toutes ses colonnes et indexes"""
        columns_sql = []
        
        for column_name, column_def in schema['columns']:
            columns_sql.append(f"{column_name} {column_def}")

        # Ajouter les indexes dans la définition de la table
        for index_name, index_columns in schema.get('indexes', []):
            if 'PRIMARY KEY' not in index_columns.upper():
                columns_sql.append(f"INDEX {index_name} ({index_columns})")
        
        create_sql = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
        {', '.join(columns_sql)}
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """
        
        self._execute_query(create_sql)
        logging.info(f" Table '{table_name}' créée avec succès")

    def _add_column(self, table_name: str, column_name: str, column_def: str):
        """Ajoute une colonne à une table existante"""
        # Nettoyer la définition de colonne (enlever PRIMARY KEY, etc.)
        clean_def = column_def.replace('PRIMARY KEY', '').replace('AUTO_INCREMENT', '').strip()
        
        alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {clean_def}"
        
        try:
            self._execute_query(alter_sql)
            logging.info(f" Colonne '{column_name}' ajoutée à '{table_name}'")
        except Exception as e:
            logging.error(f"Erreur lors de l'ajout de la colonne '{column_name}' à '{table_name}': {e}")
            raise

    def _index_exists(self, table_name: str, index_name: str) -> bool:
        """Vérifie si un index existe"""
        try:
            query = """
            SELECT COUNT(*) as count
            FROM information_schema.statistics
            WHERE table_schema = %s AND table_name = %s AND index_name = %s
            """
            result = self._fetch_one(query, (self.db_config['database'], table_name, index_name))
            return result['count'] > 0 if result else False
        except Exception as e:
            logging.error(f"Erreur lors de la vérification de l'index '{index_name}' sur '{table_name}': {e}")
            return False

    def _add_index(self, table_name: str, index_name: str, index_columns: str):
        """Ajoute un index à une table"""
        alter_sql = f"ALTER TABLE {table_name} ADD INDEX {index_name} ({index_columns})"

        try:
            self._execute_query(alter_sql)
            logging.info(f" Index '{index_name}' ajouté à '{table_name}'")
        except Exception as e:
            logging.error(f"Erreur lors de l'ajout de l'index '{index_name}' à '{table_name}': {e}")
            raise

        #
        # METRICS HISTORY FUNCTIONS
        #

    def save_metrics(self, container_name: str, vps_type: str, metrics: dict):
        """
        Save VPS metrics to history
        
        Args:
        container_name: Container name
        vps_type: 'lxc' or 'kvm'
        metrics: Dict with cpu_percent, ram_mb, disk_mb, disk_io_read_mb, 
        disk_io_write_mb, network_rx_mb, network_tx_mb
        """
        query = """
        INSERT INTO metrics_history 
        (container_name, vps_type, cpu_percent, ram_mb, disk_mb, 
        disk_io_read_mb, disk_io_write_mb, network_rx_mb, network_tx_mb)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        self._execute_query(query, (
        container_name,
        vps_type,
        metrics.get('cpu_percent', 0),
        metrics.get('ram_mb', 0),
        metrics.get('disk_mb', 0),
        metrics.get('disk_io_read_mb', 0),
        metrics.get('disk_io_write_mb', 0),
        metrics.get('network_rx_mb', 0),
        metrics.get('network_tx_mb', 0)
        ))

    def get_metrics_history(self, container_name: str, hours: int = 24) -> list[dict[str, Any]]:
        """
        Get metrics history for a container
        
        Args:
        container_name: Container name
        hours: Number of hours to look back
        
        Returns:
        List of metrics records
        """
        query = """
        SELECT * FROM metrics_history
        WHERE container_name = ?
        AND recorded_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)
        ORDER BY recorded_at ASC
        """
        
        return self._fetch_all(query, (container_name, hours))

    def get_latest_metrics(self, container_name: str) -> dict[str, Any] | None:
        """
        Get the latest metrics for a container
        
        Args:
        container_name: Container name
        
        Returns:
        Latest metrics record or None
        """
        query = """
        SELECT * FROM metrics_history
        WHERE container_name = ?
        ORDER BY recorded_at DESC
        LIMIT 1
        """
        
        return self._fetch_one(query, (container_name,))

    def get_all_latest_metrics(self) -> list[dict[str, Any]]:
        """
        Get latest metrics for all containers
        
        Returns:
        List of latest metrics for each container
        """
        query = """
        SELECT m1.* FROM metrics_history m1
        INNER JOIN (
        SELECT container_name, MAX(recorded_at) as max_time
        FROM metrics_history
        GROUP BY container_name
        ) m2 ON m1.container_name = m2.container_name 
        AND m1.recorded_at = m2.max_time
        ORDER BY m1.vps_type, m1.container_name
        """
        
        return self._fetch_all(query)

    def detect_abuse(self, container_name: str, hours: int = 1) -> dict:
        """
        Detect resource abuse based on metrics history
        
        Args:
        container_name: Container name
        hours: Number of hours to analyze
        
        Returns:
        Dict with abuse detection results
        """
        metrics = self.get_metrics_history(container_name, hours)
        
        if not metrics:
            return {'abuse_detected': False, 'abuse_types': []}
        
        abuse_types = []
        
        # CPU abuse: > 80% for sustained period
        cpu_values = [m['cpu_percent'] for m in metrics if m['cpu_percent'] is not None]
        if cpu_values:
            avg_cpu = sum(cpu_values) / len(cpu_values)
        if avg_cpu > 80 and len([c for c in cpu_values if c > 80]) / len(cpu_values) > 0.8:
            abuse_types.append({
        'type': 'cpu_abuse',
        'severity': 'high' if avg_cpu > 95 else 'medium',
        'value': f'{avg_cpu:.1f}%',
        'threshold': '80%'
        })
        
        # RAM abuse: > 90% sustained
        ram_values = [m['ram_mb'] for m in metrics if m['ram_mb'] is not None]
        if ram_values and metrics[0].get('ram_mb'):
            # Get RAM limit from VPS info
            vps = self.get_vps_by_container_name(container_name)
            if vps and vps.get('memory_limit'):
                ram_limit = vps['memory_limit']
                ram_percents = [(r / ram_limit * 100) for r in ram_values]
                avg_ram = sum(ram_percents) / len(ram_percents)
                if avg_ram > 90:
                    abuse_types.append({
                        'type': 'ram_abuse',
                        'severity': 'medium',
                        'value': f'{avg_ram:.1f}%',
                        'threshold': '90%'
                    })
        
        # Disk I/O abuse: > 100 MB/s sustained
        io_read_values = [m['disk_io_read_mb'] for m in metrics if m['disk_io_read_mb'] is not None]
        io_write_values = [m['disk_io_write_mb'] for m in metrics if m['disk_io_write_mb'] is not None]
        
        if io_read_values or io_write_values:
            total_io = sum(io_read_values) + sum(io_write_values)
            avg_io = total_io / len(metrics) if metrics else 0
            if avg_io > 100:  # 100 MB/s
                abuse_types.append({
                    'type': 'disk_io_abuse',
                    'severity': 'high' if avg_io > 500 else 'medium',
                    'value': f'{avg_io:.1f} MB/s',
                    'threshold': '100 MB/s'
                })
        
        # Network abuse: > 500 MB/s sustained
        net_rx_values = [m['network_rx_mb'] for m in metrics if m['network_rx_mb'] is not None]
        net_tx_values = [m['network_tx_mb'] for m in metrics if m['network_tx_mb'] is not None]
        
        if net_rx_values or net_tx_values:
            total_net = sum(net_rx_values) + sum(net_tx_values)
            avg_net = total_net / len(metrics) if metrics else 0
            if avg_net > 500:  # 500 MB/s
                abuse_types.append({
                    'type': 'network_abuse',
                    'severity': 'critical' if avg_net > 1000 else 'high',
                    'value': f'{avg_net:.1f} MB/s',
                    'threshold': '500 MB/s'
                })

        return {
            'abuse_detected': len(abuse_types) > 0,
            'abuse_types': abuse_types,
            'metrics_analyzed': len(metrics)
        }

    def cleanup_old_metrics(self, days: int = 7):
        """
        Clean up metrics older than specified days
        
        Args:
        days: Number of days to keep
        """
        query = """
        DELETE FROM metrics_history
        WHERE recorded_at < DATE_SUB(NOW(), INTERVAL ? DAY)
        """
        
        self._execute_query(query, (days,))
        logging.info(f"Cleaned up metrics older than {days} days")

    def log_resource_abuse(self, container_name: str, abuse_type: str, abuse_value: str):
        """
        Log a resource abuse incident
        
        Args:
        container_name: Container name
        abuse_type: Type of abuse (cpu_abuse, ram_abuse, disk_io_abuse, network_abuse)
        abuse_value: Value that triggered the abuse detection
        """
        query = """
        INSERT INTO resource_abuse_log
        (container_name, abuse_type, abuse_value)
        VALUES (?, ?, ?)
        """
        
        self._execute_query(query, (container_name, abuse_type, abuse_value))
        logging.warning(f"Resource abuse logged: {container_name} - {abuse_type} - {abuse_value}")

# Create database instance
db = Database()
