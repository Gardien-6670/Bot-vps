"""
Wrapper de base de données pour le Bot
======================================

Ce module utilise bot/shared/database pour toutes les opérations DB.
Le bot est le seul point d'accès à la base de données.
"""

import sys
import os

# Ajouter le chemin du bot pour importer shared
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Importer depuis bot/shared
from shared.database_wrapper import db

# Exporter pour compatibilité
__all__ = ['db']

__version__ = '2.0.0'
