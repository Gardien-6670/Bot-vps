"""
Système de monitoring des remboursements VPS
============================================

Ce module permet de suivre et analyser les remboursements effectués.
"""

import logging
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Dict, List, Tuple
import json

logger = logging.getLogger(__name__)


class RefundMonitor:
    """Moniteur pour suivre les remboursements VPS"""
    
    def __init__(self, db):
        self.db = db
        self.refund_log = []
        
    def log_refund(self, user_id: int, refund_type: str, amount: int, reason: str, vps_info: dict):
        """
        Enregistre un remboursement
        
        Args:
            user_id: ID de l'utilisateur
            refund_type: 'credits' ou 'points'
            amount: Montant remboursé
            reason: Raison du remboursement
            vps_info: Informations sur le VPS
        """
        refund_entry = {
            'timestamp': datetime.now().isoformat(),
            'user_id': user_id,
            'refund_type': refund_type,
            'amount': amount,
            'reason': reason,
            'vps_type': 'ad' if vps_info.get('plan_tier') or vps_info.get('invite_plan_tier') else 'paid',
            'vps_name': vps_info.get('container_name', 'unknown'),
            'plan_tier': vps_info.get('plan_tier'),
            'invite_plan_tier': vps_info.get('invite_plan_tier'),
            'cost_credits': vps_info.get('cost_credits', 0)
        }
        
        self.refund_log.append(refund_entry)
        
        logger.info(
            f"Refund logged: user={user_id}, type={refund_type}, "
            f"amount={amount}, reason={reason}, vps={vps_info.get('container_name')}"
        )
        
    def get_refund_stats(self, days: int = 30) -> Dict:
        """
        Obtient les statistiques de remboursement
        
        Args:
            days: Nombre de jours à analyser
            
        Returns:
            Dictionnaire avec les statistiques
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        
        recent_refunds = [
            r for r in self.refund_log 
            if datetime.fromisoformat(r['timestamp']) > cutoff_date
        ]
        
        stats = {
            'total_refunds': len(recent_refunds),
            'credits_refunded': sum(r['amount'] for r in recent_refunds if r['refund_type'] == 'credits'),
            'points_refunded': sum(r['amount'] for r in recent_refunds if r['refund_type'] == 'points'),
            'by_reason': defaultdict(int),
            'by_vps_type': defaultdict(int),
            'by_user': defaultdict(lambda: {'credits': 0, 'points': 0}),
        }
        
        for refund in recent_refunds:
            stats['by_reason'][refund['reason']] += 1
            stats['by_vps_type'][refund['vps_type']] += 1
            
            user_id = refund['user_id']
            if refund['refund_type'] == 'credits':
                stats['by_user'][user_id]['credits'] += refund['amount']
            else:
                stats['by_user'][user_id]['points'] += refund['amount']
                
        return stats
        
    def get_refund_report(self, days: int = 30) -> str:
        """
        Génère un rapport de remboursement formaté
        
        Args:
            days: Nombre de jours à analyser
            
        Returns:
            Rapport formaté en texte
        """
        stats = self.get_refund_stats(days)
        
        report = f"""
╔══════════════════════════════════════════════════════════════╗
║         RAPPORT DE REMBOURSEMENTS - {days} DERNIERS JOURS         ║
╚══════════════════════════════════════════════════════════════╝

📊 STATISTIQUES GLOBALES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total remboursements : {stats['total_refunds']}
Crédits remboursés   : {stats['credits_refunded']}
Points VPS remboursés: {stats['points_refunded']}

📈 PAR RAISON
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        
        for reason, count in sorted(stats['by_reason'].items(), key=lambda x: x[1], reverse=True):
            report += f"  • {reason:30s} : {count:3d}\n"
            
        report += f"""
🏷️  PAR TYPE DE VPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        
        for vps_type, count in sorted(stats['by_vps_type'].items(), key=lambda x: x[1], reverse=True):
            report += f"  • VPS {vps_type:10s} : {count:3d}\n"
            
        report += f"""
👥 TOP 10 UTILISATEURS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        
        top_users = sorted(
            stats['by_user'].items(), 
            key=lambda x: x[1]['credits'] + x[1]['points'], 
            reverse=True
        )[:10]
        
        for user_id, amounts in top_users:
            if amounts['credits'] > 0 and amounts['points'] > 0:
                report += f"  • User {user_id:15d} : {amounts['credits']:4d} credits + {amounts['points']:2d} points\n"
            elif amounts['credits'] > 0:
                report += f"  • User {user_id:15d} : {amounts['credits']:4d} credits\n"
            else:
                report += f"  • User {user_id:15d} : {amounts['points']:2d} points\n"
                
        report += "\n" + "═" * 64 + "\n"
        
        return report
        
    def check_anomalies(self, threshold_credits: int = 5000, threshold_points: int = 10) -> List[Dict]:
        """
        Détecte les anomalies dans les remboursements
        
        Args:
            threshold_credits: Seuil de crédits pour détecter une anomalie
            threshold_points: Seuil de points pour détecter une anomalie
            
        Returns:
            Liste des anomalies détectées
        """
        stats = self.get_refund_stats(days=7)  # 7 derniers jours
        anomalies = []
        
        for user_id, amounts in stats['by_user'].items():
            if amounts['credits'] > threshold_credits:
                anomalies.append({
                    'type': 'high_credits',
                    'user_id': user_id,
                    'amount': amounts['credits'],
                    'message': f"User {user_id} a reçu {amounts['credits']} crédits en 7 jours"
                })
                
            if amounts['points'] > threshold_points:
                anomalies.append({
                    'type': 'high_points',
                    'user_id': user_id,
                    'amount': amounts['points'],
                    'message': f"User {user_id} a reçu {amounts['points']} points VPS en 7 jours"
                })
                
        return anomalies
        
    def export_to_json(self, filepath: str, days: int = 30):
        """
        Exporte les statistiques en JSON
        
        Args:
            filepath: Chemin du fichier de sortie
            days: Nombre de jours à exporter
        """
        stats = self.get_refund_stats(days)
        
        # Convertir defaultdict en dict normal pour JSON
        export_data = {
            'generated_at': datetime.now().isoformat(),
            'period_days': days,
            'total_refunds': stats['total_refunds'],
            'credits_refunded': stats['credits_refunded'],
            'points_refunded': stats['points_refunded'],
            'by_reason': dict(stats['by_reason']),
            'by_vps_type': dict(stats['by_vps_type']),
            'by_user': {str(k): v for k, v in stats['by_user'].items()}
        }
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2)
            
        logger.info(f"Refund stats exported to {filepath}")


# Instance globale du moniteur
_refund_monitor = None


def get_refund_monitor(db):
    """Obtient l'instance du moniteur de remboursements"""
    global _refund_monitor
    if _refund_monitor is None:
        _refund_monitor = RefundMonitor(db)
    return _refund_monitor


def log_refund(db, user_id: int, refund_type: str, amount: int, reason: str, vps_info: dict):
    """
    Fonction helper pour enregistrer un remboursement
    
    Args:
        db: Instance de la base de données
        user_id: ID de l'utilisateur
        refund_type: 'credits' ou 'points'
        amount: Montant remboursé
        reason: Raison du remboursement
        vps_info: Informations sur le VPS
    """
    monitor = get_refund_monitor(db)
    monitor.log_refund(user_id, refund_type, amount, reason, vps_info)
