"""
Module de scan VirusTotal
Gestion des clés API, rate limiting, et scanning de fichiers
"""

import os
import asyncio
import aiohttp
import hashlib
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Any
from collections import deque

logger = logging.getLogger(__name__)

class PerMinuteRateLimiter:
    """Thread-safe rate limiter with semaphore"""
    def __init__(self, requests_per_minute: int):
        self.max_requests = requests_per_minute
        self.time_window = 60
        self.request_timestamps = []
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            while True:
                now = time.time()
                self.request_timestamps = [
                    ts for ts in self.request_timestamps
                    if now - ts < self.time_window
                ]

                if len(self.request_timestamps) < self.max_requests:
                    self.request_timestamps.append(now)
                    break
                else:
                    oldest_request_time = self.request_timestamps[0]
                    time_to_wait = self.time_window - (now - oldest_request_time)
                    logger.info(f"[VT] Rate limit reached. Waiting for {time_to_wait:.2f} seconds.")
                    await asyncio.sleep(time_to_wait + 0.1)

class VirusTotalScanner:
    """
    Scanner VirusTotal avec gestion multi-clés et rate limiting
    """

    def __init__(self, db_instance=None):
        """
        Initialise le scanner VirusTotal

        Args:
            db_instance: Instance de la base de données pour le tracking des requêtes
        """
        self.db = db_instance
        self.api_key_data: List[Dict[str, Any]] = []
        self.vt_key_index = 0
        self.vt_semaphore = asyncio.Semaphore(3)  # Limite les requêtes concurrentes

        self._initialize_api_keys()

    @staticmethod
    def _get_key_hash(api_key: str) -> str:
        """Génère un hash SHA256 de la clé API pour le stockage en base"""
        return hashlib.sha256(api_key.encode()).hexdigest()

    def _initialize_api_keys(self):
        """Initialise les clés API VirusTotal depuis les variables d'environnement"""
        vt_keys_from_env = []

        # Clé primaire
        primary_key = os.getenv('VIRUSTOTAL_API_KEY')
        if primary_key:
            vt_keys_from_env.append(primary_key)
            logger.info("[VT] Clé VirusTotal primaire chargée")

        # Clés additionnelles (VIRUSTOTAL_API_KEY_1, VIRUSTOTAL_API_KEY_2, etc.)
        for i in range(1, 11):
            additional_key = os.getenv(f'VIRUSTOTAL_API_KEY_{i}')
            if additional_key:
                vt_keys_from_env.append(additional_key)
                logger.info(f"[VT] Clé VirusTotal additionnelle {i} chargée")

        if not vt_keys_from_env:
            logger.warning("[VT] Aucune clé VIRUSTOTAL_API_KEY trouvée dans .env. Le scan VirusTotal sera désactivé.")
            return

        logger.info(f"[VT] {len(vt_keys_from_env)} clé(s) VirusTotal initialisée(s)")

        # Préparer les données de clés avec rate limiting
        today_date = datetime.now().date()
        today_str = today_date.strftime('%Y-%m-%d')

        for vt_key in vt_keys_from_env:
            try:
                key_hash_full = self._get_key_hash(vt_key)

                # Obtenir le compteur de requêtes quotidiennes depuis la DB
                daily_count = 0
                if self.db:
                    try:
                        daily_count = self.db.get_virustotal_daily_requests(today_str, key_hash_full)
                    except Exception as e:
                        logger.warning(f"[VT] Impossible de récupérer le compteur de requêtes: {e}")

                self.api_key_data.append({
                    'key': vt_key,
                    'key_hash': key_hash_full,
                    'per_minute_limiter': PerMinuteRateLimiter(4),  # 4 requêtes/minute
                    'daily_request_count': daily_count,
                    'last_reset_date': today_date,
                    'consecutive_errors': 0
                })

                key_hash_short = key_hash_full[:8]
                logger.info(f"[VT] Clé {key_hash_short}... chargée. Requêtes quotidiennes: {daily_count}/500")

            except Exception as e:
                logger.error(f"[VT] Échec de l'initialisation de la clé: {e}")

        # Résumé du load balancing
        if self.api_key_data:
            total_requests = sum(k['daily_request_count'] for k in self.api_key_data)
            avg_requests = total_requests / len(self.api_key_data)
            logger.info(
                f"[VT] Load balancing: {len(self.api_key_data)} clé(s) disponible(s). "
                f"Total requêtes aujourd'hui: {total_requests}, Moyenne par clé: {avg_requests:.1f}/500"
            )

    async def _get_next_api_key_data(self) -> Optional[Dict[str, Any]]:
        """
        Obtient la prochaine clé API disponible avec load balancing

        Returns:
            Dictionnaire avec les données de la clé ou None si aucune clé disponible
        """
        if not self.api_key_data:
            return None

        # Vérifier et réinitialiser les compteurs quotidiens si nécessaire
        today_date = datetime.now().date()
        today_str = today_date.strftime('%Y-%m-%d')

        for key_data in self.api_key_data:
            if key_data['last_reset_date'] != today_date:
                # Nouveau jour, réinitialiser le compteur
                key_hash_full = key_data.get('key_hash', self._get_key_hash(key_data['key']))

                daily_count = 0
                if self.db:
                    try:
                        daily_count = self.db.get_virustotal_daily_requests(today_str, key_hash_full)
                    except Exception:
                        pass

                key_data['daily_request_count'] = daily_count
                key_data['last_reset_date'] = today_date
                key_data['consecutive_errors'] = 0
                logger.info(f"[VT] Compteur réinitialisé pour la clé {key_hash_full[:8]}...: {daily_count}/500")

        # Trouver les clés disponibles (< 500 requêtes/jour et < 5 erreurs consécutives)
        available_keys = [
            k for k in self.api_key_data
            if k['daily_request_count'] < 500 and k['consecutive_errors'] < 5
        ]

        if not available_keys:
            logger.error("[VT] Toutes les clés API VirusTotal sont épuisées ou ont trop d'erreurs")
            return None

        # Sélectionner la clé avec le moins de requêtes (load balancing)
        selected_key = min(available_keys, key=lambda k: k['daily_request_count'])

        # Mettre à jour l'index pour le round-robin
        try:
            self.vt_key_index = self.api_key_data.index(selected_key)
        except ValueError:
            self.vt_key_index = 0

        key_hash_short = selected_key.get('key_hash', self._get_key_hash(selected_key['key']))[:8]
        logger.debug(
            f"[VT] Clé sélectionnée: {key_hash_short}... (requêtes: {selected_key['daily_request_count']}/500). "
            f"Clés disponibles: {len(available_keys)}/{len(self.api_key_data)}"
        )

        return selected_key
 
    async def scan_file_hash(
        self,
        file_hash: str,
        container_name: str = None,
        filepath: str = None
    ) -> Optional[Dict]:
        """
        Scan un fichier par son hash sur VirusTotal

        Args:
            file_hash: Hash SHA256 du fichier
            container_name: Nom du conteneur (optionnel, pour les logs)
            filepath: Chemin du fichier (optionnel, pour les logs)

        Returns:
            Dictionnaire avec les résultats du scan ou None si échec
        """
        if not self.api_key_data:
            logger.warning("[VT] Aucune clé API VirusTotal disponible")
            return None

        logger.info(f"[VT] Scan du fichier: {filepath or 'unknown'} (hash: {file_hash[:16]}...)")

        key_data = await self._get_next_api_key_data()

        if not key_data or not key_data.get('per_minute_limiter'):
            logger.warning(f"[VT] Aucune clé API disponible pour {file_hash}")
            return None

        virustotal_api_key = key_data['key']
        per_minute_limiter = key_data['per_minute_limiter']

        try:
            # Attendre le rate limiter
            await per_minute_limiter.acquire()

            # Requête à l'API VirusTotal
            url = f"https://www.virustotal.com/api/v3/files/{file_hash}"
            headers = {"x-apikey": virustotal_api_key}

            async with self.vt_semaphore:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as response:
                        # Incrémenter le compteur après une requête réussie
                        if response.status in [200, 404]:
                            key_data['daily_request_count'] += 1

                        if self.db:
                            try:
                                key_hash_full = key_data.get('key_hash', self._get_key_hash(virustotal_api_key))
                                self.db.increment_virustotal_daily_requests(
                                    datetime.now().strftime('%Y-%m-%d'),
                                    key_hash_full
                                )
                            except Exception as e:
                                logger.warning(f"[VT] Échec de l'incrémentation du compteur DB: {e}")

                        logger.debug(f"[VT] Statut de réponse: {response.status} pour {filepath or file_hash}")

                        if response.status == 200:
                            data = await response.json()

                            if not data or 'data' not in data:
                                logger.error(f"[VT] Réponse VirusTotal invalide pour {file_hash}")
                                key_data['consecutive_errors'] += 1
                                return None

                            attributes = data['data'].get('attributes', {})
                            stats = attributes.get('last_analysis_stats', {})

                            positives = stats.get('malicious', 0)
                            total = sum(stats.values())

                            # Calculer le score de sécurité: 100 = sûr, 0 = très dangereux
                            malicious_percentage = int((positives / total) * 100) if total > 0 else 0
                            security_score = 100 - malicious_percentage

                            # Réinitialiser les erreurs consécutives en cas de succès
                            key_data['consecutive_errors'] = 0

                            logger.info(
                                f"[VT] Résultat du scan pour {filepath or file_hash}: {positives}/{total} détections "
                                f"(malveillant: {malicious_percentage}%, score de sécurité: {security_score}/100)"
                            )

                            return {
                                'positives': positives,
                                'total': total,
                                'detection_ratio': f"{positives}/{total}",
                                'threat_level': security_score,
                                'malicious_percentage': malicious_percentage,
                                'scan_date': datetime.now().isoformat(),
                                'file_hash': file_hash
                            }

                        elif response.status == 404:
                            logger.info(f"[VT] Fichier non trouvé dans la base VirusTotal: {file_hash}")
                            key_data['consecutive_errors'] = 0
                            return {
                                'positives': 0,
                                'total': 0,
                                'detection_ratio': '0/0',
                                'threat_level': 50,
                                'malicious_percentage': 0,
                                'scan_date': datetime.now().isoformat(),
                                'file_hash': file_hash,
                                'not_found': True
                            }

                        elif response.status == 429:
                            logger.warning(f"[VT] Rate limit atteint pour la clé (quotidien: {key_data['daily_request_count']})")
                            key_data['consecutive_errors'] += 1
                            return None

                        elif response.status == 401:
                            logger.error(f"[VT] Clé API invalide ou expirée")
                            key_data['consecutive_errors'] += 10
                            return None

                        else:
                            logger.warning(f"[VT] L'API a retourné le statut {response.status} pour {file_hash}")
                            key_data['consecutive_errors'] += 1
                            return None

        except asyncio.TimeoutError:
            logger.error(f"[VT] Timeout du scan pour {file_hash}")
            key_data['consecutive_errors'] += 1
            return None

        except aiohttp.ClientError as e:
            logger.error(f"[VT] Erreur de connexion pour {file_hash}: {e}")
            key_data['consecutive_errors'] += 1
            return None

        except Exception as e:
            logger.error(f"[VT] Erreur du scan pour {file_hash}: {e}")
            key_data['consecutive_errors'] += 1
            return None

    async def upload_file(
        self,
        file_content: bytes,
        filename: str = None
    ) -> Optional[Dict]:
        """
        Upload un fichier vers VirusTotal pour analyse

        Args:
            file_content: Contenu du fichier en bytes
            filename: Nom du fichier (optionnel)

        Returns:
            Dictionnaire avec l'ID d'analyse ou None si échec
        """
        if not self.api_key_data:
            logger.warning("[VT] Aucune clé API VirusTotal disponible pour l'upload")
            return None
 
        # Limite de taille: 32 MB pour l'API gratuite
        if len(file_content) > 32 * 1024 * 1024:
            logger.warning(f"[VT] Fichier trop volumineux pour l'upload: {len(file_content)} bytes")
            return None

        key_data = await self._get_next_api_key_data()

        if not key_data:
            logger.warning("[VT] Aucune clé API disponible pour l'upload")
            return None

        virustotal_api_key = key_data['key']
        per_minute_limiter = key_data['per_minute_limiter']
 
        try:
            await per_minute_limiter.acquire()

            url = "https://www.virustotal.com/api/v3/files"
            headers = {"x-apikey": virustotal_api_key}

            data = aiohttp.FormData()
            data.add_field('file', file_content, filename=filename or 'file')

            async with self.vt_semaphore:
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, headers=headers, data=data, timeout=aiohttp.ClientTimeout(total=60)) as response:
                        if response.status in [200, 201]:
                            key_data['daily_request_count'] += 1

                        if self.db:
                            try:
                                key_hash_full = key_data.get('key_hash', self._get_key_hash(virustotal_api_key))
                                self.db.increment_virustotal_daily_requests(
                                    datetime.now().strftime('%Y-%m-%d'),
                                    key_hash_full
                                )
                            except Exception as e:
                                logger.warning(f"[VT] Échec de l'incrémentation du compteur DB: {e}")

                        if response.status in [200, 201]:
                            result = await response.json()
                            analysis_id = result.get('data', {}).get('id')

                            key_data['consecutive_errors'] = 0

                            logger.info(f"[VT] Fichier uploadé avec succès. ID d'analyse: {analysis_id}")

                            return {
                                'analysis_id': analysis_id,
                                'upload_date': datetime.now().isoformat(),
                                'status': 'queued'
                            }

                        elif response.status == 429:
                            logger.warning(f"[VT] Rate limit atteint lors de l'upload")
                            key_data['consecutive_errors'] += 1
                            return None

                        else:
                            logger.warning(f"[VT] Upload échoué avec le statut {response.status}")
                            key_data['consecutive_errors'] += 1
                            return None

        except asyncio.TimeoutError:
            logger.error(f"[VT] Timeout lors de l'upload")
            key_data['consecutive_errors'] += 1
            return None

        except Exception as e:
            logger.error(f"[VT] Erreur lors de l'upload: {e}")
            key_data['consecutive_errors'] += 1
            return None

    def get_stats(self) -> Dict:
        """
        Obtient les statistiques d'utilisation des clés API

        Returns:
            Dictionnaire avec les statistiques
        """
        if not self.api_key_data:
            return {
                'total_keys': 0,
                'available_keys': 0,
                'total_requests_today': 0,
                'keys_details': []
            }

        available_keys = [
            k for k in self.api_key_data
            if k['daily_request_count'] < 500 and k['consecutive_errors'] < 5
        ]

        total_requests = sum(k['daily_request_count'] for k in self.api_key_data)

        keys_details = []
        for k in self.api_key_data:
            key_hash_short = k['key_hash'][:8]
            keys_details.append({
                'key_hash': key_hash_short,
                'daily_requests': k['daily_request_count'],
                'consecutive_errors': k['consecutive_errors'],
                'available': k['daily_request_count'] < 500 and k['consecutive_errors'] < 5
            })

        return {
            'total_keys': len(self.api_key_data),
            'available_keys': len(available_keys),
            'total_requests_today': total_requests,
            'average_requests_per_key': total_requests / len(self.api_key_data) if self.api_key_data else 0,
            'keys_details': keys_details
        }

    def is_available(self) -> bool:
        """
        Vérifie si le scanner VirusTotal est disponible

        Returns:
            True si au moins une clé API est disponible
        """
        if not self.api_key_data:
            return False

        available_keys = [
            k for k in self.api_key_data
            if k['daily_request_count'] < 500 and k['consecutive_errors'] < 5
        ]

        return len(available_keys) > 0

# Instance globale (singleton)
_scanner_instance = None

def get_virustotal_scanner(db_instance=None) -> VirusTotalScanner:
    """
    Obtient l'instance globale du scanner VirusTotal (singleton)

    Args:
        db_instance: Instance de la base de données

    Returns:
        Instance du scanner VirusTotal
    """
    global _scanner_instance

    if _scanner_instance is None:
        _scanner_instance = VirusTotalScanner(db_instance)

    return _scanner_instance
