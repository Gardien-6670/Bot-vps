import discord
from discord.ext import commands
import logging
import os

# Configuration des seuils pour les notifications
IMPORTANT_CREDIT_THRESHOLD = 1000  # Crédits
IMPORTANT_POINT_THRESHOLD = 100    # Points VPS
ADMIN_NOTIFICATION_CHANNEL_ID = int(os.getenv('ADMIN_NOTIFICATION_CHANNEL_ID', '0'))

async def notify_important_transaction(bot: commands.Bot, user_id: int, transaction_type: str, amount: int, balance_after: int, reason: str = None):
    """Send notification for important transactions."""
    
    # Check if transaction is important
    is_important = False
    
    if transaction_type in ['credit_add', 'credit_remove'] and amount >= IMPORTANT_CREDIT_THRESHOLD:
        is_important = True
    elif transaction_type in ['point_add', 'point_remove'] and amount >= IMPORTANT_POINT_THRESHOLD:
        is_important = True
    
    if not is_important or ADMIN_NOTIFICATION_CHANNEL_ID == 0:
        return
    
    # Get notification channel
    try:
        channel = bot.get_channel(ADMIN_NOTIFICATION_CHANNEL_ID)
        if not channel:
            channel = await bot.fetch_channel(ADMIN_NOTIFICATION_CHANNEL_ID)
        
        if not channel:
            logging.warning(f"Admin notification channel {ADMIN_NOTIFICATION_CHANNEL_ID} not found")
            return
        
        # Get user info
        try:
            user = await bot.fetch_user(user_id)
            user_display = f"{user.mention} ({user.name}#{user.discriminator})"
        except:
            user_display = f"User ID: {user_id}"
        
        # Format transaction info
        type_emoji = {
            'credit_add': '💰',
            'credit_remove': '💸',
            'point_add': '⭐',
            'point_remove': '🔻'
        }.get(transaction_type, '📝')
        
        type_display = {
            'credit_add': 'Credits Added',
            'credit_remove': 'Credits Removed',
            'point_add': 'Points Added',
            'point_remove': 'Points Removed'
        }.get(transaction_type, transaction_type)
        
        # Determine color based on type
        if transaction_type in ['credit_add', 'point_add']:
            color = 0x2ECC71  # Green
        else:
            color = 0xE74C3C  # Red
        
        # Create embed
        embed = discord.Embed(
            title=f"🚨 Important Transaction Alert",
            description=f"A large transaction has been detected.",
            color=color
        )
        
        embed.add_field(name="User", value=user_display, inline=False)
        embed.add_field(name="Type", value=f"{type_emoji} {type_display}", inline=True)
        embed.add_field(name="Amount", value=f"`{amount}`", inline=True)
        embed.add_field(name="New Balance", value=f"`{balance_after}`", inline=True)
        
        if reason:
            embed.add_field(name="Reason", value=reason, inline=False)
        
        embed.set_footer(text=f"Transaction ID will be logged • User ID: {user_id}")
        
        await channel.send(embed=embed)
        logging.info(f"Sent important transaction notification for user {user_id}: {transaction_type} {amount}")
        
    except Exception as e:
        logging.error(f"Error sending important transaction notification: {e}", exc_info=True)
