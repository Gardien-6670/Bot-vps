import math

# --- Pricing ---
PRICES_LXC = {
 "cpu": 0.35, # per core
 "ram": 0.25, # per GB
 "disk": 0.025 # per GB
}
PRICES_KVM = {
 "cpu": 0.40, # per core
 "ram": 0.30, # per GB
 "disk": 0.04 # per GB
}

USD_TO_CREDITS_RATE = 100 / 1.14
EUR_TO_USD_RATE = 1.08 # Approximate rate, for OxaPay which takes USD

def usd_to_credits(usd_amount):
 return math.ceil(usd_amount * USD_TO_CREDITS_RATE)

def eur_to_usd(eur_amount):
 return eur_amount * EUR_TO_USD_RATE
