import discord
from discord.ext import commands
from utils.database import db
from datetime import datetime, timedelta
from utils.pricing import PRICES_LXC, usd_to_credits, PRICES_KVM
import math

async def renew_vps(user_id: int, container_name: str, months: int):
 """
 Renews a VPS for a specified number of months.

 Args:
 user_id (str): The ID of the user who owns the VPS.
 container_name (str): The name of the VPS container.
 months (int): The number of months to renew the VPS for.

 Returns:
 str: A message indicating the result of the renewal operation.
 """
 vps = db.get_vps_by_container_name(container_name)
 if not vps:
 return "VPS not found."

 if str(vps['user_id']) != user_id:
 return "You do not own this VPS."

 balance = db.get_balance(user_id)
 cpu = vps['cpu']
 ram = vps['ram']
 disk = vps['disk']
 vps_type = vps.get('vps_type', 'lxc') # Get vps_type

 if vps_type == 'kvm':
 prices = PRICES_KVM
 else:
 prices = PRICES_LXC

 cost_usd = (cpu * prices["cpu"]) + (ram * prices["ram"]) + (disk * prices["disk"])
 cost_credits = usd_to_credits(cost_usd)
 cost = cost_credits * months

 if balance < cost:
 return f"You do not have enough credits to renew this VPS for {months} months. You need {cost} credits, but you only have {balance}."

 conn = None
 cursor = None
 try:
 conn, cursor = db.start_transaction()

 # Deduct credits first
 db.add_credits(user_id, -cost, cursor=cursor, conn=conn)

 # Extend the due date
 db.extend_vps_due_date(vps['id'], months, cursor=cursor, conn=conn)

 db.commit_transaction(conn, cursor)

 return f"Successfully renewed {container_name} for {months} months for {cost} credits."
 except Exception as e:
 if conn and cursor:
 db.rollback_transaction(conn, cursor)
 return f"An error occurred while renewing the VPS: {e}"

class RenewModal(discord.ui.Modal, title="Renew VPS"):
 months_input = discord.ui.TextInput(
 label="Number of months to renew for",
 placeholder="e.g., 1, 3, 6, 12",
 required=True
 )

 def __init__(self, container_name: str):
 super().__init__()
 self.container_name = container_name

 async def on_submit(self, interaction: discord.Interaction):
 await interaction.response.defer(ephemeral=True, thinking=True)
 
 try:
 months = int(self.months_input.value)
 if months <= 0:
 await interaction.followup.send("Please enter a positive number of months.", ephemeral=True)
 return
 except ValueError:
 await interaction.followup.send("Please enter a valid number of months.", ephemeral=True)
 return

 user_id = interaction.user.id
 message = await renew_vps(user_id, self.container_name, months)
 
 await interaction.followup.send(message, ephemeral=True)
