import discord
from discord.ui import View, Button
from utils.database import db
from utils import node_manager
from utils.surveillance.geoip_deletion import SecureDataDeletion
import logging

logger = logging.getLogger(__name__)


class UnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=None)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Unsuspend", style=discord.ButtonStyle.success)
    async def unsuspend_button(self, interaction: discord.Interaction, button: Button):
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        confirm_view = ConfirmUnsuspendView(self.container_name, self.user_id, self.bot, self.vps_type)
        embed = discord.Embed(
            title=f"Confirm Unsuspend {entity_type}",
            description=f"Are you sure you want to unsuspend `{self.container_name}`?",
            color=discord.Color.orange()
        )
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)

    @discord.ui.button(label="Delete Data", style=discord.ButtonStyle.danger)
    async def delete_data_button(self, interaction: discord.Interaction, button: Button):
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        confirm_view = ConfirmDeleteView(self.container_name, self.user_id, self.bot, self.vps_type)
        embed = discord.Embed(
            title=f"Confirm Data Deletion for {entity_type}",
            description=f"This is irreversible. Are you sure you want to delete all data for `{self.container_name}`?",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)


class ConfirmUnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Yes, Unsuspend", style=discord.ButtonStyle.success)
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        try:
            db.unsuspend_vps(self.container_name)
            db.reset_suspicion_count(self.container_name)
            db.update_vps_threat_score(db.get_vps_by_container_name(self.container_name)['id'], 0)
            
            if self.vps_type != 'dedicated':
                node_info = node_manager.get_node_for_vps(self.container_name)
                if not node_info:
                    await interaction.followup.send(f"Failed to unsuspend: Could not determine node for {self.container_name}.", ephemeral=True)
                    return
                node_url, api_key = node_info['url'], node_info['api_key']

                if self.vps_type == 'lxc':
                    await node_manager.api_request('POST', f"/lxc/container/{self.container_name}/resume", node_url, api_key)
                elif self.vps_type == 'kvm':
                    await node_manager.api_request('POST', f"/kvm/vm/{self.container_name}/start", node_url, api_key)

            success_embed = discord.Embed(title="Unsuspended", description=f"{entity_type} `{self.container_name}` unsuspended.", color=discord.Color.green())
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
            try:
                user = await self.bot.fetch_user(self.user_id)
                await user.send(f"Your {entity_type.lower()} (`{self.container_name}`) has been unsuspended.")
            except Exception as e:
                logger.error(f"Failed to notify user about unsuspension: {e}")
            
            for item in self.children:
                item.disabled = True
            if interaction.message:
                await interaction.message.edit(view=self)
        except Exception as e:
            logger.error(f"Failed to unsuspend {self.container_name}: {e}")
            await interaction.followup.send(f"Failed to unsuspend: {e}", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)


class ConfirmDeleteView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Yes, Delete Data", style=discord.ButtonStyle.danger)
    async def confirm_delete_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        
        try:
            deleter = SecureDataDeletion()
            vps = db.get_vps_by_container_name(self.container_name)
            if not vps:
                await interaction.followup.send(f"VPS {self.container_name} not found in database.", ephemeral=True)
                return

            if self.vps_type == 'lxc':
                node_info = node_manager.get_node_for_vps(self.container_name)
                if not node_info:
                    await interaction.followup.send(f"Node not found for {self.container_name}.", ephemeral=True)
                    return
                await deleter.wipe_container_data(self.container_name, node_info['url'], node_info['api_key'])
            elif self.vps_type == 'kvm':
                node_info = node_manager.get_node_for_vps(self.container_name)
                if not node_info:
                    await interaction.followup.send(f"Node not found for {self.container_name}.", ephemeral=True)
                    return
                await deleter.wipe_kvm_data(self.container_name, node_info['url'], node_info['api_key'])
            elif self.vps_type == 'dedicated':
                await deleter.wipe_dedicated_server(vps)

            success_embed = discord.Embed(title="Data Wiped", description=f"All data for {entity_type} `{self.container_name}` has been securely deleted.", color=discord.Color.dark_red())
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
            for item in self.children:
                item.disabled = True
            if interaction.message:
                await interaction.message.edit(view=self)
        except Exception as e:
            logger.error(f"Failed to delete data for {self.container_name}: {e}")
            await interaction.followup.send(f"Failed to delete data: {e}", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)