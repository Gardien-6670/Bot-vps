"""
Advanced behavioral analysis for detecting hidden malicious activity
Zero-tolerance surveillance system
"""

import asyncio
import time
import statistics
from collections import defaultdict, deque
from datetime import datetime, timedelta
import hashlib
import re
from typing import Dict, List, Optional

logger_module = __import__('logging')
logger = logger_module.getLogger(__name__)


class BehavioralAnalyzer:
    """Analyse les patterns de comportement suspects sur la durée"""
    
    def __init__(self):
        self.cpu_history = defaultdict(lambda: deque(maxlen=288))
        self.network_history = defaultdict(lambda: deque(maxlen=288))
        self.process_history = defaultdict(lambda: deque(maxlen=288))
        
    def add_metrics(self, container_name: str, metrics: dict):
        """Enregistre les métriques pour analyse temporelle"""
        timestamp = time.time()
        
        self.cpu_history[container_name].append({
            'time': timestamp,
            'cpu': metrics.get('cpu_percent', 0),
            'processes': metrics.get('process_count', 0)
        })
        
        self.network_history[container_name].append({
            'time': timestamp,
            'tx_bytes': metrics.get('tx_bytes', 0),
            'rx_bytes': metrics.get('rx_bytes', 0),
            'connection_count': metrics.get('connection_count', 0)
        })
    
    def detect_sustained_high_cpu(self, container_name: str) -> dict:
        """Détection de CPU élevé soutenu (miners)"""
        history = self.cpu_history[container_name]
        
        if len(history) < 12:
            return {"suspicious": False, "confidence": 0}
        
        recent_data = list(history)[-12:]
        cpu_values = [d['cpu'] for d in recent_data]
        
        avg_cpu = statistics.mean(cpu_values)
        std_dev = statistics.stdev(cpu_values) if len(cpu_values) > 1 else 0
        
        # Patterns suspects
        high_stable_cpu = avg_cpu > 70 and std_dev < 5
        near_limit = avg_cpu > 85 and std_dev < 3
        
        gradual_increase = False
        if len(history) >= 36:
            last_3h = list(history)[-36:]
            cpu_trend = [d['cpu'] for d in last_3h]
            first_hour = statistics.mean(cpu_trend[:12])
            last_hour = statistics.mean(cpu_trend[-12:])
            gradual_increase = last_hour > first_hour + 20
        
        suspicious = high_stable_cpu or near_limit or gradual_increase
        confidence = 85 if near_limit else (70 if high_stable_cpu else (60 if gradual_increase else 0))
        
        return {
            "suspicious": suspicious,
            "avg_cpu": round(avg_cpu, 2),
            "std_dev": round(std_dev, 2),
            "pattern": "high_stable" if high_stable_cpu else ("near_limit" if near_limit else ("gradual_increase" if gradual_increase else "none")),
            "confidence": confidence
        }
    
    def detect_circadian_inversion(self, container_name: str) -> dict:
        """Activité nocturne anormale = suspect"""
        history = self.cpu_history[container_name]
        
        if len(history) < 144:
            return {"suspicious": False, "confidence": 0}
        
        night_cpu = []
        day_cpu = []
        
        for entry in history:
            entry_time = datetime.fromtimestamp(entry['time'])
            hour = entry_time.hour
            
            if 22 <= hour or hour <= 6:
                night_cpu.append(entry['cpu'])
            elif 8 <= hour <= 18:
                day_cpu.append(entry['cpu'])
        
        if not night_cpu or not day_cpu:
            return {"suspicious": False, "confidence": 0}
        
        avg_night = statistics.mean(night_cpu)
        avg_day = statistics.mean(day_cpu)
        inverted = avg_night > avg_day + 20
        
        return {
            "suspicious": inverted,
            "avg_night_cpu": round(avg_night, 2),
            "avg_day_cpu": round(avg_day, 2),
            "difference": round(avg_night - avg_day, 2),
            "confidence": 90 if inverted else 0
        }


class NetworkAnalyzer:
    """Analyse avancée du trafic réseau"""
    
    def analyze_connections(self, container_name: str, connections: list) -> dict:
        """Analyse comportementale des connexions réseau"""
        if not connections:
            return {"suspicious": False, "confidence": 0}
        
        suspicious_indicators = []
        confidence = 0
        
        long_connections = [c for c in connections if c.get('state') == 'ESTAB']
        unique_ips = set(c.get('remote_address') for c in long_connections 
                        if c.get('remote_address') not in ['N/A', '0.0.0.0', '127.0.0.1'])
        
        if len(unique_ips) <= 3 and len(long_connections) >= 2:
            suspicious_indicators.append("few_stable_connections")
            confidence += 30
        
        suspicious_ports = []
        for conn in connections:
            port = conn.get('remote_port')
            if port and str(port).isdigit():
                port_num = int(port)
                if (3000 <= port_num <= 10000) or port_num in [14444, 45560]:
                    suspicious_ports.append(port_num)
        
        if suspicious_ports:
            suspicious_indicators.append(f"suspicious_ports")
            confidence += 25
        
        outbound = sum(1 for c in connections if c.get('direction') == 'outbound')
        inbound = sum(1 for c in connections if c.get('direction') == 'inbound')
        
        if outbound > 0 and inbound / max(outbound, 1) < 0.2:
            suspicious_indicators.append("high_outbound_ratio")
            confidence += 20
        
        if len(connections) > 10:
            states = [c.get('state') for c in connections]
            time_wait_count = states.count('TIME-WAIT')
            if time_wait_count > len(connections) * 0.3:
                suspicious_indicators.append("high_connection_churn")
                confidence += 15
        
        return {
            "suspicious": len(suspicious_indicators) >= 2,
            "indicators": suspicious_indicators,
            "confidence": min(confidence, 95),
            "unique_destinations": len(unique_ips),
            "suspicious_ports": suspicious_ports,
            "connection_details": {
                "total": len(connections),
                "outbound": outbound,
                "inbound": inbound,
                "established": len(long_connections)
            }
        }


class ProcessAnalyzer:
    """Détection de processus déguisés"""
    
    OBFUSCATION_PATTERNS = [
        r'^(systemd|kworker|migration|ksoftirqd|rcu_|watchdog)\d+$',
        r'^[a-z]{1,3}$',
        r'^[a-z0-9]{8,16}$',
        r'^(apache|nginx|httpd|php-fpm)\d*$',
    ]
    
    def analyze_process_behavior(self, processes: list) -> dict:
        """Détection de processus suspects"""
        suspicious_processes = []
        confidence = 0
        
        for proc in processes:
            suspicion_score = 0
            reasons = []
            
            cmd = proc.get('command', '').lower()
            user = proc.get('user', '')
            cpu = float(proc.get('cpu_percent', 0))
            
            for pattern in self.OBFUSCATION_PATTERNS:
                if re.match(pattern, cmd.split()[0] if cmd else ''):
                    if cpu > 15:
                        suspicion_score += 40
                        reasons.append("obfuscated_name_high_cpu")
                    break
            
            suspicious_paths = ['/tmp/', '/dev/shm/', '/var/tmp/', '/run/', '/.cache/']
            if any(path in cmd for path in suspicious_paths):
                suspicion_score += 30
                reasons.append("suspicious_location")
            
            system_users = ['nobody', 'systemd-coredump', 'daemon', 'bin']
            if user in system_users and cpu > 10:
                suspicion_score += 25
                reasons.append("system_user_high_cpu")
            
            suspicious_args = [
                r'-o\s+[\d\.]+:\d+',
                r'--url\s+',
                r'--algo\s+',
                r'-u\s+\w+\.\w+',
                r'--donate-level',
                r'-k\s+',
            ]
            
            for pattern in suspicious_args:
                if re.search(pattern, cmd):
                    suspicion_score += 35
                    reasons.append("suspicious_args")
            
            ppid = proc.get('ppid', '')
            if ppid and ppid != '1' and cpu > 20:
                suspicion_score += 15
                reasons.append("high_cpu_child_process")
            
            mem = float(proc.get('mem_percent', 0))
            if cpu > 50 and mem < 1:
                suspicion_score += 20
                reasons.append("cpu_intensive_low_memory")
            
            if suspicion_score >= 50:
                suspicious_processes.append({
                    "process": proc,
                    "suspicion_score": suspicion_score,
                    "reasons": reasons
                })
                confidence = max(confidence, suspicion_score)
        
        return {
            "suspicious": len(suspicious_processes) > 0,
            "suspicious_processes": suspicious_processes,
            "confidence": min(confidence, 95),
            "count": len(suspicious_processes)
        }


class CorrelationAnalyzer:
    """Corrèle plusieurs métriques pour détecter patterns cachés"""
    
    def analyze_multi_metric_correlation(self, container_data: dict) -> dict:
        """Combine plusieurs signaux pour détection avancée"""
        indicators = []
        total_confidence = 0
        
        cpu = container_data.get('cpu_analysis', {})
        network = container_data.get('network_analysis', {})
        process = container_data.get('process_analysis', {})
        
        if (cpu.get('suspicious') and 
            network.get('unique_destinations', 0) <= 3 and
            process.get('suspicious')):
            indicators.append("mining_pattern_detected")
            total_confidence += 85
        
        if (cpu.get('std_dev', 0) > 10 and
            network.get('connection_details', {}).get('outbound', 0) > 50):
            indicators.append("ddos_pattern_detected")
            total_confidence += 80
        
        if (cpu.get('pattern') == 'circadian_inversion' and
            process.get('count', 0) > 0):
            indicators.append("stealth_mining_pattern")
            total_confidence += 90
        
        if (cpu.get('avg_cpu', 0) < 20 and
            network.get('connection_details', {}).get('total', 0) > 100):
            indicators.append("proxy_botnet_pattern")
            total_confidence += 75
        
        threat_level = "CRITICAL" if total_confidence > 85 else (
            "HIGH" if total_confidence > 70 else (
                "MEDIUM" if total_confidence > 50 else "LOW"))
        
        return {
            "suspicious": len(indicators) > 0,
            "patterns_detected": indicators,
            "confidence": min(total_confidence, 99),
            "threat_level": threat_level,
            "should_suspend": total_confidence >= 60
        }
