"""
Progressive Threat Surveillance for LXC Containers
"""

import asyncio, os, json, logging, traceback
from typing import Dict, Optional
from datetime import datetime, timedelta
from collections import defaultdict, deque

from groq import AsyncGroq


from discord.ext import tasks
from dotenv import load_dotenv
import discord

from utils.database import db
from utils import node_manager
from utils.surveillance.rate_limiter import PerMinuteRateLimiter
from utils.surveillance.ui_views import UnsuspendView
from utils.surveillance.geoip_deletion import GeoIPAnalyzer
from utils.surveillance.threat_detection import SecurityOrchestrator

load_dotenv()
logger = logging.getLogger(__name__)


class SurveillanceLXC:
    """
    Progressive surveillance system for LXC containers.
    Applies different actions based on a threat score.
    """
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        groq_key = os.getenv("GROQ_API_KEY")
        if not groq_key: raise ValueError("GROQ_API_KEY missing")
        
        self.groq_client = AsyncGroq(api_key=groq_key)
        self.models = [
            ("openai/gpt-oss-120b", PerMinuteRateLimiter(20)),
            ("openai/gpt-oss-20b", PerMinuteRateLimiter(30)),
            ("llama-3.1-8b-instant", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct-0905", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct", PerMinuteRateLimiter(30)),
        ]
        
        self.collected_data: Dict[str, deque[Dict]] = defaultdict(lambda: deque(maxlen=30)) # Store 30 minutes of data (1 entry per minute)
        
        self.orchestrator = SecurityOrchestrator()
        self.geoip = GeoIPAnalyzer()
        
        self.metrics = {
            'scans': 0,
            'threats_detected': 0,
            'suspended': 0,
            'cpu_throttled': 0,
        }

    async def _call_groq_with_fallback(
        self, 
        prompt: str, 
        timeout: int = 180 # Increased timeout for comprehensive analysis
    ) -> Optional[str]:
        """Call Groq API with automatic fallback"""
        for model_name, limiter in self.models:
            try:
                await limiter.acquire()
                logger.info(f"[LXC] Using Groq model: {model_name}")
                
                chat_completion = await asyncio.wait_for(
                    self.groq_client.chat.completions.create(
                        messages=[
                            {"role": "system", "content": "You are a helpful cybersecurity AI. Respond only in JSON format."},
                            {"role": "user", "content": prompt}
                        ],
                        model=model_name,
                        temperature=0.7,
                        max_tokens=2048,
                    ),
                    timeout=timeout
                )
                
                if chat_completion.choices and chat_completion.choices[0].message.content:
                    return chat_completion.choices[0].message.content
                else:
                    logger.warning(f"[LXC] Groq model {model_name} returned empty content.")
            except Exception as e:
                logger.warning(f"[LXC] Groq model {model_name} failed: {e}. Trying fallback if available.")
        
        logger.error("[LXC] Both primary and fallback Groq models failed to provide a response.")
        return None
        
    @tasks.loop(seconds=60) # Runs every minute
    async def collect_metrics_task(self):
        """Continuously collects metrics for all LXC containers."""
        # logger.info("[LXC] Collecting metrics...")
        
        try:
            vps_list = db.get_all_vps()
            lxc_vps = [v for v in vps_list if (v.get('vps_type') or 'lxc') == 'lxc']
            
            for vps in lxc_vps:
                container = vps['container_name']
                
                if db.is_vps_suspended(container):
                    continue
                
                node = node_manager.get_node_for_vps(container)
                if not node: continue
                
                try:
                    node_url, api_key = node['url'], node['api_key']
                    
                    status = await node_manager.api_request(
                        'GET', f"/lxc/container/{container}/status", node_url, api_key)
                    
                    if not status or not status.get('running'): continue
                    
                    threat_data = await self._collect_threat_data(container, node_url, api_key)
                    self.collected_data[container].append(threat_data)
                    db.update_vps_last_scan(vps['id'], datetime.now()) # Update last scan time for decay logic
                    # logger.debug(f"[LXC] Collected data for {container}. History length: {len(self.collected_data[container])}")

                except Exception as e:
                    logger.error(f"[LXC] Error collecting metrics for {container}: {e}\n{traceback.format_exc()}")
        
        finally:
            self.metrics['scans'] += 1
            # logger.info("[LXC] Metric collection finished.")

    @tasks.loop(minutes=30) # Runs every 30 minutes
    async def analyze_lxc_threats_task(self):
        logger.info("[LXC] Analyzing collected threats for all LXC containers (30-min interval)...")

        vps_list = db.get_all_vps()
        lxc_vps_map = {v['container_name']: v for v in vps_list if (v.get('vps_type') or 'lxc') == 'lxc'}

        for container_name, historical_data_deque in self.collected_data.items():
            if not historical_data_deque:
                continue

            vps = lxc_vps_map.get(container_name)
            if not vps or db.is_vps_suspended(container_name):
                # Clear data for suspended or non-existent VPS
                historical_data_deque.clear()
                continue
            
            node = node_manager.get_node_for_vps(container_name)
            if not node:
                historical_data_deque.clear()
                continue
            
            node_url, api_key = node['url'], node['api_key']

            # Compile historical data into a comprehensive prompt
            historical_threat_data = list(historical_data_deque)
            
            # Use the SecurityOrchestrator to get an initial assessment/summary
            # This assessment can then be passed to Groq for higher-level reasoning.
            # Here, we will simulate the assessment using all data for a single call for simplicity first.
            
            # The prompt needs to summarize the last 30 minutes effectively for the AI.
            # This is a critical part of the prompt engineering.
            
            summary_for_ai = {
                "container_name": container_name,
                "history": []
            }
            
            # Aggregate data for the prompt
            for minute_data in historical_threat_data:
                entry = {
                    "timestamp": minute_data.get("timestamp", datetime.now().isoformat()),
                    "metrics": minute_data.get("metrics", {}),
                    "processes_summary": [
                        {"command": p.get("command", ""), "cpu_percent": p.get("cpu_percent", 0), "user": p.get("user", "")}
                        for p in minute_data.get("processes", [])[:5] # Limit processes for prompt size
                    ]
                }
                summary_for_ai["history"].append(entry)

            prompt = f"""You are a highly advanced cybersecurity AI monitoring LXC containers.
Your task is to analyze the provided historical data for the container over the last 30 minutes and determine if there is any malicious activity (e.g., crypto mining, DDoS, hacking attempts, etc.).

Based on your analysis, you MUST provide a JSON response with the following structure:
{{
    "suspend": boolean,          // true if immediate suspension is required due to severe threat
    "reason": string,            // A concise reason for the decision, especially for suspension
    "threat_score": integer,     // An overall threat score from 0 (no threat) to 100 (critical threat)
    "threat_level": "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL", // Categorized threat level
    "details": string            // A brief explanation of the detected threats or patterns
}}

Consider the following indicators:
- Sustained high CPU usage, especially by non-system processes.
- Fluctuations in network activity (high outbound traffic, suspicious ports).
- Presence of known mining software, unauthorized processes, or processes in suspicious locations (/tmp, /dev/shm).
- Sudden changes in resource usage patterns (behavioral anomalies).
- Any correlation between CPU, network, and process activity suggesting coordinated malicious action.

Here is the historical data for the container '{container_name}' over the last 30 minutes:
{json.dumps(summary_for_ai, indent=2)}

Provide your analysis in JSON format ONLY, ensuring the 'suspend' field accurately reflects the need for immediate action.
"""
            
            try:
                ai_response_str = await self._call_groq_with_fallback(prompt)
                if not ai_response_str:
                    logger.warning(f"[LXC] No AI response for {container_name}.")
                    continue
                
                # Clean up markdown and parse JSON
                ai_response_str = ai_response_str.strip().strip('```json').strip('```').strip()
                ai_decision = json.loads(ai_response_str)

                suspend = ai_decision.get("suspend", False)
                reason = ai_decision.get("reason", "No specific reason provided by AI.")
                threat_score = ai_decision.get("threat_score", 0)
                threat_level = ai_decision.get("threat_level", "NONE")
                details = ai_decision.get("details", "")

                current_vps_db_info = db.get_vps_by_container_name(container_name)
                if not current_vps_db_info: # VPS might have been deleted while processing
                    historical_data_deque.clear()
                    continue

                # Apply score decay (if AI didn't suspend, existing score should decay)
                last_scan_time = current_vps_db_info.get('last_scan_time')
                if isinstance(last_scan_time, str):
                    try:
                        last_scan_time = datetime.fromisoformat(last_scan_time)
                    except ValueError:
                        last_scan_time = datetime.now()
                elif not isinstance(last_scan_time, datetime):
                    last_scan_time = datetime.now()

                time_since_last_full_analysis = datetime.now() - last_scan_time
                hours_elapsed = time_since_last_full_analysis.total_seconds() / 3600
                decay = int(hours_elapsed * 5) # 5 points per hour

                if suspend:
                    logger.critical(f"[LXC CRITICAL] AI decided to suspend {container_name}. Reason: {reason}")
                    db.log_security_threat(container_name, threat_score, json.dumps(ai_decision))
                    await self._execute_freeze(vps, ai_decision)
                    self.metrics['suspended'] += 1
                else:
                    # Update threat score based on AI analysis, applying decay if no new critical threat
                    current_db_score = current_vps_db_info.get('threat_score', 0)
                    new_score = max(0, current_db_score - decay) # Decay always applies if not suspended by AI
                    
                    if threat_score > new_score: # If AI detected a new threat more severe than current
                        new_score = threat_score
                    
                    db.update_vps_threat_score(vps['id'], new_score)
                    db.update_vps_last_scan(vps['id'], datetime.now()) # Update scan time after full analysis

                    logger.info(f"[LXC] AI analysis for {container_name}: Score {new_score}, Level: {threat_level}. Details: {details}")
                    db.log_security_threat(container_name, new_score, json.dumps(ai_decision))

                    if new_score >= 85:
                        await self._handle_high_score(vps, new_score, ai_decision) # High implies immediate investigation
                    elif new_score >= 50:
                        await self._handle_medium_score(vps, new_score, ai_decision, node_url, api_key)
                    elif new_score >= 30:
                        await self._handle_low_score(vps, new_score, ai_decision)
            
            except json.JSONDecodeError as e:
                logger.error(f"[LXC] Failed to parse AI response for {container_name}: {e}\nResponse: {ai_response_str[:500]}")
            except Exception as e:
                logger.error(f"[LXC] Error during AI analysis for {container_name}: {e}\n{traceback.format_exc()}")
            
            finally:
                historical_data_deque.clear() # Clear data after processing

    async def _collect_threat_data(self, container: str, node_url: str, api_key: str) -> Dict:
        data = {"timestamp": datetime.now().isoformat()}
        try:
            proc_result = await node_manager.api_request('GET', f"/lxc/container/{container}/processes", node_url, api_key)
            if proc_result:
                data["metrics"] = self._parse_metrics(proc_result.get("summary", {}))
                # Pass the full process list for detailed analysis
                if proc_result.get("processes"):
                    data["processes"] = proc_result["processes"]
        except Exception as e:
            logger.debug(f"Could not get processes for {container}: {e}")
            # If processes cannot be fetched, log it but continue with other data
            data["processes"] = [] # Ensure it's always a list, even if empty
        return data

    def _parse_metrics(self, summary: dict) -> Dict:
        return {
            "process_count": summary.get("process_count", 0),
            "total_connections": summary.get("total_connections", 0),
            "outbound_connections": summary.get("outbound_connections", 0),
            "inbound_connections": summary.get("inbound_connections", 0),
            "listening_ports": summary.get("listening_ports", 0),
        }

    async def _handle_low_score(self, vps: Dict, score: int, assessment: Dict):
        """Log + Increased Monitoring"""
        logger.info(f"[LXC LOW] {vps['container_name']} (Score: {score}). Threats: {assessment['threats']}. Monitoring increased.")
        db.log_security_threat(vps['container_name'], score, json.dumps(assessment))

    async def _handle_medium_score(self, vps: Dict, score: int, assessment: Dict, node_url: str, api_key: str):
        """Admin Alert + CPU Throttling"""
        container_name = vps['container_name']
        logger.warning(f"[LXC MEDIUM] {container_name} (Score: {score}). Throttling CPU and alerting admin.")
        db.log_security_threat(vps['container_name'], score, json.dumps(assessment))
        
        try:
            # Throttle CPU to 1 core
            await node_manager.api_request('POST', f"/lxc/container/{container_name}/cpu-limit", node_url, api_key, data={"limit": 1})
            self.metrics['cpu_throttled'] += 1
            logger.info(f"CPU for {container_name} throttled to 1 core.")
            db.update_vps_cpu_limit(vps['id'], 1)
        except Exception as e:
            logger.error(f"Failed to throttle CPU for {container_name}: {e}")

        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[LXC] Medium Threat Alert", description=f"Container `{vps['container_name']}` has a score of **{score}** and its CPU has been throttled.", color=discord.Color.orange())
        embed.add_field(name="User ID", value=f"`{vps['user_id']}`", inline=True)
        embed.add_field(name="Threats", value=", ".join(assessment['threats']), inline=False)
        await admin.send(embed=embed)

    async def _handle_high_score(self, vps: Dict, score: int, assessment: Dict):
        """Investigation Required + User Contact"""
        logger.error(f"[LXC HIGH] {vps['container_name']} (Score: {score}). Investigation required.")
        db.log_security_threat(vps['container_name'], score, json.dumps(assessment))

        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[LXC] High Threat Alert", description=f"Container `{vps['container_name']}` has a score of **{score}**. Manual investigation is required.", color=discord.Color.red())
        embed.add_field(name="User ID", value=f"`{vps['user_id']}`", inline=True)
        embed.add_field(name="Threats", value=", ".join(assessment['threats']), inline=False)
        await admin.send(embed=embed)
        
        try:
            user = await self.bot.fetch_user(vps['user_id'])
            await user.send(f"⚠️ A security issue has been detected on your container `{vps['container_name']}`. Please contact support immediately.")
        except Exception as e:
            logger.error(f"Failed to notify user {vps['user_id']}: {e}")

    async def _handle_critical_score(self, vps: Dict, score: int, assessment: Dict, node_url: str, api_key: str):
        """Suspension after verification (3+ alerts in 24h)"""
        container = vps['container_name']
        db.log_security_threat(container, score, json.dumps(assessment))
        
        recent_threats = db.get_security_threats(container)
        
        if len(recent_threats) >= 3:
            logger.critical(f"[LXC CRITICAL] {container} (Score: {score}). More than 3 alerts in 24h. Freezing container.")
            await self._execute_freeze(vps, assessment)
            self.metrics['suspended'] += 1
        else:
            logger.warning(f"[LXC CRITICAL] {container} (Score: {score}). Threats detected, but less than 3 alerts. Monitoring.")

    async def _execute_freeze(self, vps: Dict, assessment: Dict):
        """
        Freezes the container by suspending it.
        """
        container = vps['container_name']
        user_id = vps['user_id']
        
        try:
            logger.critical(f"[FREEZE] {container}")
            db.suspend_vps(container)
            
            node = node_manager.get_node_for_vps(container)
            if node:
                await node_manager.api_request('POST', f"/lxc/container/{container}/stop", node['url'], node['api_key'], data={"force": True})

            # NOTIFY ADMIN
            admin = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(title="CONTAINER FROZEN", color=discord.Color.blue())
            embed.add_field(name="Container", value=f"`{container}`", inline=False)
            embed.add_field(name="User", value=f"`{user_id}`", inline=False)
            embed.add_field(name="Threats", value=str(assessment['threats'])[:1024], inline=False)
            embed.add_field(name="Score", value=f"{assessment['score']}%", inline=True)
            embed.add_field(name="Level", value=assessment['threat_level'], inline=True)
            embed.add_field(name="Timestamp", value=datetime.now().isoformat(), inline=False)
            
            view = UnsuspendView(container, user_id, self.bot, 'lxc')
            await admin.send(embed=embed, view=view)
            
            # NOTIFY USER
            user = await self.bot.fetch_user(user_id)
            await user.send(f"**Container Frozen**\n\nContainer: `{container}`\nReason: High-risk security threat detected.\n\nYour container has been temporarily frozen. Please contact support for assistance.")
        
        except Exception as e:
            logger.error(f"Freeze failed: {e}\n{traceback.format_exc()}")

    @collect_metrics_task.before_loop
    async def before_collect_metrics_task(self):
        logger.info("[LXC] Waiting for bot...")
        await self.bot.wait_until_ready()
        logger.info("[LXC] Ready - Metric collection active")
        
    @analyze_lxc_threats_task.before_loop
    async def before_analyze_lxc_threats_task(self):
        await self.bot.wait_until_ready()
        logger.info("[LXC] Ready - LXC threat analysis active")