import asyncio
import os
import json
import logging
import time
import paramiko
import traceback
import random
from typing import Optional, Dict
from collections import defaultdict, deque
from datetime import datetime

from groq import AsyncGroq

from discord.ext import tasks
from dotenv import load_dotenv
import discord
import re

from utils.database import db
from utils.surveillance.rate_limiter import PerMinuteRateLimiter
from utils.surveillance.ui_views import UnsuspendView

load_dotenv()

logger = logging.getLogger(__name__)


class SurveillanceDedi:
    """Enhanced Dedicated Server surveillance system with progressive scoring."""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        groq_api_key = os.getenv("GROQ_API_KEY")
        if not groq_api_key:
            raise ValueError("GROQ_API_KEY not found in .env file")
        
        self.groq_client = AsyncGroq(api_key=groq_api_key)
        self.models = [
            ("openai/gpt-oss-120b", PerMinuteRateLimiter(20)),
            ("openai/gpt-oss-20b", PerMinuteRateLimiter(30)),
            ("llama-3.1-8b-instant", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct-0905", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct", PerMinuteRateLimiter(30)),
        ]
        
        self.collected_data: Dict[str, deque[Dict]] = defaultdict(lambda: deque(maxlen=30)) # Store 30 minutes of data (1 entry per minute)
        
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'suspended': 0,
            'api_calls': 0
        }

    async def _call_groq_with_fallback(
        self, 
        prompt: str, 
        timeout: int = 180 # Increased timeout for comprehensive analysis
    ) -> Optional[str]:
        """Call Groq API with automatic fallback"""
        for model_name, limiter in self.models:
            try:
                await limiter.acquire()
                logger.info(f"[DEDI] Using Groq model: {model_name}")
                self.metrics['api_calls'] += 1
                
                chat_completion = await asyncio.wait_for(
                    self.groq_client.chat.completions.create(
                        messages=[
                            {"role": "system", "content": "You are a helpful cybersecurity AI. Respond only in JSON format."},
                            {"role": "user", "content": prompt}
                        ],
                        model=model_name,
                        temperature=0.7,
                        max_tokens=2048,
                    ),
                    timeout=timeout
                )
                
                if chat_completion.choices and chat_completion.choices[0].message.content:
                    return chat_completion.choices[0].message.content
                else:
                    logger.warning(f"[DEDI] Groq model {model_name} returned empty content.")
            except Exception as e:
                logger.warning(f"[DEDI] Groq model {model_name} failed: {e}. Trying fallback if available.")
        
        logger.error("[DEDI] Both primary and fallback Groq models failed to provide a response.")
        return None

    @tasks.loop(seconds=60)
    async def collect_metrics_task(self):
        logger.info("[DEDI] Collecting metrics...")
        
        try:
            all_vps = db.get_all_vps()
            dedi_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'dedicated']
            
            if not dedi_vps:
                return

            for vps in dedi_vps:
                server_name = vps['container_name']
                if db.is_vps_suspended(server_name):
                    continue

                processes_text = await asyncio.to_thread(self._get_processes_ssh, vps)

                if processes_text:
                    threat_data = {
                        "timestamp": datetime.now().isoformat(),
                        "processes_text": processes_text
                    }
                    self.collected_data[server_name].append(threat_data)
                    db.update_vps_last_scan(vps['id'], datetime.now()) # Update last scan time for decay logic

        except Exception as e:
            logger.error(f"[DEDI] Error during metric collection: {e}\n{traceback.format_exc()}")
        finally:
            self.metrics['scans_completed'] += 1
            # logger.info("[DEDI] Metric collection finished.")

    @tasks.loop(minutes=30)
    async def analyze_dedi_threats_task(self):
        logger.info("[DEDI] Analyzing collected threats for all Dedicated servers (30-min interval)...")

        vps_list = db.get_all_vps()
        dedi_vps_map = {v['container_name']: v for v in vps_list if (v.get('vps_type') or '') == 'dedicated'}

        for server_name, historical_data_deque in self.collected_data.items():
            if not historical_data_deque:
                continue

            vps = dedi_vps_map.get(server_name)
            if not vps or db.is_vps_suspended(server_name):
                historical_data_deque.clear()
                continue
            
            # Dedicated servers don't have node_info in the same way, but the SSH credentials are in vps object
            # No node_info needed here as _get_processes_ssh handles it

            historical_threat_data = list(historical_data_deque)
            
            summary_for_ai = {
                "server_name": server_name,
                "history": []
            }
            
            for minute_data in historical_threat_data:
                entry = {
                    "timestamp": minute_data.get("timestamp", datetime.now().isoformat()),
                    "processes_output": minute_data.get("processes_text", "No data")
                }
                summary_for_ai["history"].append(entry)

            prompt = f"""You are a highly advanced cybersecurity AI monitoring Dedicated servers.
Your task is to analyze the provided historical process and network data for the server over the last 30 minutes and determine if there is any malicious activity (e.g., crypto mining, DDoS, hacking attempts, etc.).

Based on your analysis, you MUST provide a JSON response with the following structure:
{{
    "suspend": boolean,          // true if immediate suspension is required due to severe threat
    "reason": string,            // A concise reason for the decision, especially for suspension
    "threat_score": integer,     // An overall threat score from 0 (no threat) to 100 (critical threat)
    "threat_level": "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL", // Categorized threat level
    "details": string            // A brief explanation of the detected threats or patterns
}}

Consider the following indicators:
- Sustained high CPU usage, especially by non-system processes.
- Fluctuations in network activity (high outbound traffic, suspicious ports).
- Presence of known mining software, unauthorized processes, or processes in suspicious locations (/tmp, /var/tmp, /dev/shm).
- Sudden changes in resource usage patterns (behavioral anomalies).
- Any correlation between CPU, network, and process activity suggesting coordinated malicious action.

Here is the historical data for the dedicated server '{server_name}' over the last 30 minutes:
{json.dumps(summary_for_ai, indent=2)}

Provide your analysis in JSON format ONLY, ensuring the 'suspend' field accurately reflects the need for immediate action.
"""
            
            try:
                ai_response_str = await self._call_groq_with_fallback(prompt)
                if not ai_response_str:
                    logger.warning(f"[DEDI] No AI response for {server_name}.")
                    continue
                
                ai_response_str = ai_response_str.strip().strip('```json').strip('```').strip()
                ai_decision = json.loads(ai_response_str)

                suspend = ai_decision.get("suspend", False)
                reason = ai_decision.get("reason", "No specific reason provided by AI.")
                threat_score = ai_decision.get("threat_score", 0)
                threat_level = ai_decision.get("threat_level", "NONE")
                details = ai_decision.get("details", "")

                current_vps_db_info = db.get_vps_by_container_name(server_name)
                if not current_vps_db_info:
                    historical_data_deque.clear()
                    continue

                last_scan_time = current_vps_db_info.get('last_scan_time')
                if isinstance(last_scan_time, str):
                    try:
                        last_scan_time = datetime.fromisoformat(last_scan_time)
                    except ValueError:
                        last_scan_time = datetime.now()
                elif not isinstance(last_scan_time, datetime):
                    last_scan_time = datetime.now()

                time_since_last_full_analysis = datetime.now() - last_scan_time
                hours_elapsed = time_since_last_full_analysis.total_seconds() / 3600
                decay = int(hours_elapsed * 5)

                if suspend:
                    logger.critical(f"[DEDI CRITICAL] AI decided to suspend {server_name}. Reason: {reason}")
                    db.log_security_threat(server_name, threat_score, json.dumps(ai_decision))
                    await self._execute_freeze(vps) # _execute_freeze uses hardcoded reason
                    self.metrics['suspended'] += 1
                else:
                    current_db_score = current_vps_db_info.get('threat_score', 0)
                    new_score = max(0, current_db_score - decay)
                    
                    if threat_score > new_score:
                        new_score = threat_score
                    
                    db.update_vps_threat_score(vps['id'], new_score)
                    db.update_vps_last_scan(vps['id'], datetime.now())

                    logger.info(f"[DEDI] AI analysis for {server_name}: Score {new_score}, Level: {threat_level}. Details: {details}")
                    db.log_security_threat(server_name, new_score, json.dumps(ai_decision))

                    if new_score >= 85:
                        await self._handle_high_score(vps, new_score, ai_decision)
                    elif new_score >= 50:
                        await self._handle_medium_score(vps, new_score, ai_decision)
                    elif new_score >= 30:
                        await self._handle_low_score(vps, new_score, ai_decision)
            
            except json.JSONDecodeError as e:
                logger.error(f"[DEDI] Failed to parse AI response for {server_name}: {e}\nResponse: {ai_response_str[:500]}")
            except Exception as e:
                logger.error(f"[DEDI] Error during AI analysis for {server_name}: {e}\n{traceback.format_exc()}")
            
            finally:
                historical_data_deque.clear()

    async def _handle_low_score(self, vps: Dict, score: int, ai_decision: Dict):
        logger.info(f"[DEDI LOW] {vps['container_name']} (Score: {score}). Details: {ai_decision.get('details', 'No details')}")
        db.log_security_threat(vps['container_name'], score, json.dumps(ai_decision))

    async def _handle_medium_score(self, vps: Dict, score: int, ai_decision: Dict):
        logger.warning(f"[DEDI MEDIUM] {vps['container_name']} (Score: {score}). Alerting admin. Details: {ai_decision.get('details', 'No details')}")
        db.log_security_threat(vps['container_name'], score, json.dumps(ai_decision))
        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[DEDI] Medium Threat Alert", description=f"**Server:** `{vps['container_name']}`\n**User ID:** `{vps['user_id']}`\n\nThis server has a score of **{score}**.\n**Details:** {ai_decision.get('details', 'N/A')}", color=discord.Color.orange())
        await admin.send(embed=embed)

    async def _handle_high_score(self, vps: Dict, score: int, ai_decision: Dict):
        logger.error(f"[DEDI HIGH] {vps['container_name']} (Score: {score}). Investigation required. Details: {ai_decision.get('details', 'No details')}")
        db.log_security_threat(vps['container_name'], score, json.dumps(ai_decision))
        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[DEDI] High Threat Alert", description=f"**Server:** `{vps['container_name']}`\n**User ID:** `{vps['user_id']}`\n\nThis server has a score of **{score}**. Manual investigation is required.\n**Details:** {ai_decision.get('details', 'N/A')}", color=discord.Color.red())
        await admin.send(embed=embed)
        try:
            user = await self.bot.fetch_user(vps['user_id'])
            await user.send(f"⚠️ A security issue has been detected on your dedicated server `{vps['container_name']}`. Please contact support immediately.\n**Threat Score:** `{score}`\n**Details:** {ai_decision.get('details', 'N/A')}")
        except Exception as e:
            logger.error(f"Failed to notify user {vps['user_id']}: {e}")

    async def _handle_critical_score(self, vps: Dict, score: int):
        # This function is no longer called in the new flow, as the AI's 'suspend' decision directly triggers _execute_freeze.
        logger.warning(f"[DEDI] _handle_critical_score was called for {vps['container_name']} but should not be in the new AI-driven flow. Direct freeze from AI decision.")
        # Left for compatibility/old logic if needed elsewhere, but new flow bypasses it.

    async def _execute_freeze(self, vps: dict):
        server_name = vps['container_name']
        user_id = vps['user_id']
        try:
            db.suspend_vps(server_name)
            await self._shutdown_dedi_server(vps)
            
            logger.critical(f"Dedicated server {server_name} suspended and shut down")
            
            admin = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(title="DEDICATED SERVER FROZEN", description=f"**Server:** `{server_name}`\n**User:** `{user_id}`", color=discord.Color.blue())
            view = UnsuspendView(server_name, user_id, self.bot, 'dedicated')
            await admin.send(embed=embed, view=view)
            
            user = await self.bot.fetch_user(user_id)
            await user.send(f"**Dedicated Server Frozen**\n\nYour server `{server_name}` has been frozen due to high-risk activity.\nPlease contact support.")
        except Exception as e:
            logger.error(f"Error freezing dedicated server: {e}\n{traceback.format_exc()}")
            
    def _get_processes_ssh(self, vps: dict) -> Optional[str]:
        """Get process list via SSH"""
        ip_address = vps.get('ip_address')
        ssh_port = vps.get('ssh_port')
        ssh_password = vps.get('ssh_password')

        if not all([ip_address, ssh_port, ssh_password]):
            logging.error(f"Missing SSH credentials for {vps['container_name']}")
            return None

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # Use longer timeout for dedicated servers as they might be busier
            client.connect(ip_address, port=ssh_port, username='root', password=ssh_password, timeout=30)
            
            ps_command = "ps -eo %cpu,%mem,pid,user,args --sort=-%cpu | head -n 20"
            ss_command = "ss -tunp | head -n 10"
            
            stdin, stdout, stderr = client.exec_command(ps_command)
            ps_output = stdout.read().decode()
            
            stdin, stdout, stderr = client.exec_command(ss_command)
            ss_output = stdout.read().decode()
            
            client.close()
            
            return f"--- Top 20 Processes ---\n{ps_output}\n\n--- Top 10 Network Connections ---\n{ss_output}"
        except socket.timeout:
            logging.error(f"SSH connection timed out to {ip_address}:{ssh_port} for {vps['container_name']}. The server did not respond in time. Please check IP, port, network connectivity, and firewall rules.")
            return None
        except paramiko.ssh_exception.SSHException as e:
            logging.error(f"SSH error getting processes from {ip_address}:{ssh_port} for {vps['container_name']}: {e}. This could be due to an invalid SSH banner or other protocol issues.")
            return None
        except Exception as e:
            logging.error(f"An unexpected error occurred while getting processes via SSH from {ip_address}:{ssh_port} for {vps['container_name']}: {e}")
            return None

    def _is_only_monitoring_activity(self, processes_text: str) -> bool:
        if not processes_text: return False
        processes_lower = processes_text.lower()
        
        # Check for known mining/suspicious keywords
        if any(keyword in processes_lower for keyword in ['xmrig', 'miner', 'stratum', 'ddos', 'attack']):
            return False
        
        # Heuristic for dedicated servers: usually more complex than just SSHD.
        # Check for presence of common system/idle processes.
        system_process_keywords = ['systemd', 'kernel', 'bash', 'sshd', 'login', 'agetty', 'cron', 'rsyslog', 'qemu', 'kvm', 'mariadb', 'mysql', 'apache', 'nginx', 'php-fpm']
        system_process_count = 0
        total_relevant_processes = 0 # Count processes that are not just empty lines or headers
        
        for line in processes_text.splitlines():
            line = line.strip().lower()
            if not line or line.startswith('---'): continue # Skip empty lines and headers
            total_relevant_processes += 1
            if any(keyword in line for keyword in system_process_keywords):
                system_process_count += 1
        
        if total_relevant_processes == 0: return True # If no processes detected, might be idle

        if system_process_count / total_relevant_processes > 0.8: # More than 80% system processes
            return True

        return False

    def _prefilter_process_list(self, text: str) -> str:
        # This function is now less critical as the full text is sent, but can help reduce token count
        if not text: return ""
        lines = text.splitlines()
        # Filter out sshd processes related to our monitoring
        filtered_lines = [line for line in lines if not re.search(r'sshd:\s+\S+@notty', line, re.IGNORECASE) and line.strip() and not re.match(r"^===+", line.strip())]
        max_chars = 48000 # Keep the limit
        joined = "\n".join(filtered_lines).strip()
        return joined[:max_chars] if len(joined) > max_chars else joined

    async def analyze_all_servers(self, processes_dict, high_risk_servers=None):
        # This function is no longer used in the new 30-min analysis flow.
        logger.warning("[DEDI] analyze_all_servers is deprecated and should not be called in the new flow.")
        return {}

    async def _shutdown_dedi_server(self, vps: dict):
        # ... implementation remains the same
        pass

    @collect_metrics_task.before_loop
    async def before_collect_metrics_task(self):
        logging.info("[DEDI] Waiting for bot...")
        await self.bot.wait_until_ready()
        logging.info("[DEDI] Bot ready - Metric collection active")
        
    @analyze_dedi_threats_task.before_loop
    async def before_analyze_dedi_threats_task(self):
        await self.bot.wait_until_ready()
        logging.info("[DEDI] Bot ready - Dedicated threat analysis active")