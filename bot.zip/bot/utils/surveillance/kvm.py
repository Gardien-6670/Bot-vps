import asyncio
import os
import json
import logging
import re
import traceback
from typing import Optional, Dict
from datetime import datetime
from groq import AsyncGroq
from discord.ext import tasks
from dotenv import load_dotenv
import discord

from utils.database import db
from utils import node_manager
from utils.node_manager import NodeConnectionError # Import the new custom exception
from utils.surveillance.rate_limiter import PerMinuteRateLimiter
from utils.surveillance.ui_views import UnsuspendView

load_dotenv()

logger = logging.getLogger(__name__)


class SurveillanceKVM:
    """Enhanced KVM VM surveillance system with progressive scoring."""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        groq_api_key = os.getenv("GROQ_API_KEY")
        if not groq_api_key:
            raise ValueError("GROQ_API_KEY not found in .env file")
        
        self.groq_client = AsyncGroq(api_key=groq_api_key)
        self.models = [
            ("openai/gpt-oss-120b", PerMinuteRateLimiter(20)),
            ("openai/gpt-oss-20b", PerMinuteRateLimiter(30)),
            ("llama-3.1-8b-instant", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct-0905", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct", PerMinuteRateLimiter(30)),
        ]
        
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'suspended': 0,
            'api_calls': 0,
            'node_errors': 0,
            'parse_errors': 0
        }

    @tasks.loop(seconds=60)
    async def check_kvm_for_threats(self):
        logger.info("[KVM] Progressive Threat Scan starting...")
        
        try:
            all_vps = db.get_all_vps()
            kvm_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'kvm']
            
            if not kvm_vps:
                return

            processes_to_analyze = {}
            vps_map = {}

            for vps in kvm_vps:
                vm_name = vps['container_name']

                try: # Specific error handling for each VPS
                    if db.is_vps_suspended(vm_name):
                        continue

                    node_info = node_manager.get_node_for_vps(vm_name)
                    if not node_info:
                        logger.error(f"[KVM] No node for {vm_name}")
                        continue
                    node_url, api_key = node_info['url'], node_info['api_key']

                    status_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/status", node_url, api_key)
                    if not status_result or not status_result.get('running'):
                        continue

                    # Collect detailed metrics for database storage
                    try:
                        stats_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/stats", node_url, api_key)
                        
                        if stats_result:
                            # Extract metrics
                            cpu_percent = stats_result.get('cpu_percent', 0)
                            ram_mb = stats_result.get('memory_mb', 0)
                            disk_mb = stats_result.get('disk_mb', 0)
                            
                            # I/O metrics
                            io_stats = stats_result.get('io', {})
                            io_read_mb = io_stats.get('read_mb', 0)
                            io_write_mb = io_stats.get('write_mb', 0)
                            
                            # Network metrics
                            net_stats = stats_result.get('network', {})
                            net_rx_mb = net_stats.get('rx_mb', 0)
                            net_tx_mb = net_stats.get('tx_mb', 0)
                            
                            # Save metrics to database
                            db.save_metrics(vm_name, 'kvm', {
                                'cpu_percent': cpu_percent,
                                'ram_mb': ram_mb,
                                'disk_mb': disk_mb,
                                'disk_io_read_mb': io_read_mb,
                                'disk_io_write_mb': io_write_mb,
                                'network_rx_mb': net_rx_mb,
                                'network_tx_mb': net_tx_mb
                            })
                            
                            # Detect abuse
                            abuse_result = db.detect_abuse(vm_name, hours=1)
                            if abuse_result['abuse_detected']:
                                for abuse in abuse_result['abuse_types']:
                                    logger.warning(f"[KVM ABUSE] {vm_name}: {abuse['type']} - {abuse['value']} (threshold: {abuse['threshold']})")
                                    # Log abuse to database
                                    try:
                                        db.log_resource_abuse(vm_name, abuse['type'], abuse['value'])
                                    except Exception as e:
                                        logger.error(f"Failed to log abuse for {vm_name}: {e}")
                    except Exception as e:
                        logger.debug(f"Could not get detailed stats for {vm_name}: {e}")

                    process_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/processes", node_url, api_key)
                    if process_result and process_result.get('processes'):
                        processes_text = json.dumps(process_result.get('processes', ''), indent=2)
                        
                        if self._is_only_monitoring_activity(processes_text):
                            if vps.get('threat_score', 0) > 0:
                                db.update_vps_threat_score(vps['id'], 0)
                            continue

                        processes_to_analyze[vm_name] = processes_text
                        vps_map[vm_name] = vps

                except NodeConnectionError as e:
                    logger.error(f"[KVM] Node connection failed for {vm_name}: {e}")
                    self.metrics['node_errors'] += 1
                    continue # Move to the next VPS
                except json.JSONDecodeError as e: # This might occur if json.dumps fails on unexpected data
                    logger.error(f"[KVM] Invalid JSON processing for {vm_name}: {e}")
                    self.metrics['parse_errors'] += 1
                    continue # Move to the next VPS
                except Exception as e:
                    logger.error(f"[KVM] Unexpected error for {vm_name}: {e}\n{traceback.format_exc()}")
                    continue # Move to the next VPS

            if not processes_to_analyze:
                return

            analysis_results = await self.analyze_all_vms(processes_to_analyze)

            if not analysis_results:
                logger.warning("[KVM] No valid analysis from Groq.")
                return

            for vm_name, score in analysis_results.items():
                vps = vps_map.get(vm_name)
                if not vps:
                    continue

                current_score = vps.get('threat_score', 0)
                new_score = current_score + score
                db.update_vps_threat_score(vps['id'], new_score)

                logger.info(f"[KVM] {vm_name}: Score {new_score} (+{score}).")

                if new_score >= 85:
                    await self._handle_critical_score(vps, new_score)
                elif new_score >= 70:
                    await self._handle_high_score(vps, new_score)
                elif new_score >= 50:
                    await self._handle_medium_score(vps, new_score)
                elif new_score >= 30:
                    await self._handle_low_score(vps, new_score)

        except Exception as e: # Catch any errors outside the VPS loop (e.g., db.get_all_vps)
            logger.error(f"[KVM] Error during check: {e}\n{traceback.format_exc()}")
        finally:
            self.metrics['scans_completed'] += 1
            logger.info("[KVM] Progressive Threat Scan finished.")

    async def _handle_low_score(self, vps: Dict, score: int):
        logger.info(f"[KVM LOW] {vps['container_name']} (Score: {score}). Monitoring increased.")
        db.log_security_threat(vps['container_name'], score, "Low level threat detected by KVM-Surveillance.")

    async def _handle_medium_score(self, vps: Dict, score: int):
        logger.warning(f"[KVM MEDIUM] {vps['container_name']} (Score: {score}). Alerting admin. CPU Throttling not yet implemented for KVM.")
        db.log_security_threat(vps['container_name'], score, "Medium level threat detected by KVM-Surveillance.")
        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[KVM] Medium Threat Alert", description=f"**VM:** `{vps['container_name']}`\n**User ID:** `{vps['user_id']}`\n\nThis VM has a score of **{score}**.", color=discord.Color.orange())
        await admin.send(embed=embed)

    async def _handle_high_score(self, vps: Dict, score: int):
        logger.error(f"[KVM HIGH] {vps['container_name']} (Score: {score}). Investigation required.")
        db.log_security_threat(vps['container_name'], score, "High level threat detected by KVM-Surveillance.")
        admin = await self.bot.fetch_user(self.admin_user_id)
        embed = discord.Embed(title="[KVM] High Threat Alert", description=f"**VM:** `{vps['container_name']}`\n**User ID:** `{vps['user_id']}`\n\nThis VM has a score of **{score}**. Manual investigation is required.", color=discord.Color.red())
        await admin.send(embed=embed)
        try:
            user = await self.bot.fetch_user(vps['user_id'])
            await user.send(f"⚠️ A security issue has been detected on your VM `{vps['container_name']}`. Please contact support immediately.")
        except Exception as e:
            logger.error(f"Failed to notify user {vps['user_id']}: {e}")

    async def _handle_critical_score(self, vps: Dict, score: int):
        recent_threats = db.get_security_threats(vps['container_name'])
        if len(recent_threats) >= 3:
            logger.critical(f"[KVM CRITICAL] {vps['container_name']} (Score: {score}). More than 3 alerts. Freezing VM.")
            await self._execute_freeze(vps, score, recent_threats)
            self.metrics['suspended'] += 1
        else:
            db.log_security_threat(vps['container_name'], score, "Critical level threat detected, freeze pending more alerts.")
            logger.warning(f"[KVM CRITICAL] {vps['container_name']} (Score: {score}). Freeze pending more alerts.")
    
    async def _execute_freeze(self, vps: dict, score: int, recent_threats: list):
        vm_name = vps['container_name']
        user_id = vps['user_id']
        node_info = node_manager.get_node_for_vps(vm_name)
        if not node_info:
            logger.error(f"Cannot freeze {vm_name}: No node found")
            return
        try:
            node_url, api_key = node_info['url'], node_info['api_key']
            await node_manager.api_request('POST', f"/kvm/vm/{vm_name}/stop", node_url, api_key, data={"force": True})
            db.suspend_vps(vm_name)
            logger.critical(f"KVM {vm_name} suspended")
            
            admin = await self.bot.fetch_user(self.admin_user_id)
            
            # Summarize recent threats for the embed
            threat_summary = []
            for threat in recent_threats:
                # Assuming threat_data is a JSON string that can be parsed
                try:
                    threat_details = json.loads(threat.get('threat_data', '{}'))
                    if isinstance(threat_details, dict) and threat_details.get('threats'):
                        # Flattening list of threats if it exists in threat_details
                        threat_summary.extend([f"  - {t}" for t in threat_details['threats']])
                    else:
                        threat_summary.append(f"  - Score: {threat.get('threat_score')}, Severity: {threat.get('severity')}")
                except json.JSONDecodeError:
                    threat_summary.append(f"  - Score: {threat.get('threat_score')}, Severity: {threat.get('severity')}")
            
            threat_description = "\n".join(threat_summary[:5]) # Show up to 5 threats
            if len(threat_summary) > 5:
                threat_description += "\n  (...and more)"

            embed = discord.Embed(
                title="KVM VM FROZEN",
                description=f"**VM:** `{vm_name}`\n**User:** `{user_id}`\n**Current Score:** `{score}`\n\n**Recent Threats (Cause):**\n{threat_description or 'No specific threat details available.'}",
                color=discord.Color.red() # Changed color to red for critical alert
            )
            view = UnsuspendView(vm_name, user_id, self.bot, 'kvm')
            await admin.send(embed=embed, view=view)
            
            user = await self.bot.fetch_user(user_id)
            await user.send(f"**VM Frozen**\n\nYour VM `{{vm_name}}` has been frozen due to high-risk activity.\n**Threat Score:** `{score}`\n**Recent Alerts:**\n{threat_description or 'No specific threat details available.'}\n\nPlease contact support.")
        except Exception as e:
            logger.error(f"Error freezing KVM VM: {e}\n{traceback.format_exc()}")

    def _is_only_monitoring_activity(self, processes_text: str) -> bool:
        # Simplified check
        return 'sshpass' in processes_text and processes_text.count('sshpass') <= 2

    async def _call_groq_with_fallback(self, prompt: str) -> Optional[str]:
        """
        Attempts to call the primary Groq model, falling back to the secondary model on API errors.
        Returns the text response or None if both fail.
        """
        for model_name, limiter in self.models:
            try:
                await limiter.acquire()
                logger.info(f"[KVM] Using Groq model: {model_name}")
                self.metrics['api_calls'] += 1
                
                chat_completion = await asyncio.wait_for(
                    self.groq_client.chat.completions.create(
                        messages=[
                            {"role": "system", "content": "You are a helpful cybersecurity AI."},
                            {"role": "user", "content": prompt}
                        ],
                        model=model_name,
                        temperature=0.7,
                        max_tokens=2048,
                    ),
                    timeout=60
                )
                
                if chat_completion.choices and chat_completion.choices[0].message.content:
                    return chat_completion.choices[0].message.content
                else:
                    logger.warning(f"[KVM] Groq model {model_name} returned empty content.")
            except Exception as e:
                logger.warning(f"[KVM] Groq model {model_name} failed: {e}. Trying fallback if available.")
        
        logger.error("[KVM] Both primary and fallback Groq models failed to provide a response.")
        return None
    async def analyze_all_vms(self, processes_dict: Dict[str, str]) -> Optional[Dict[str, int]]:
        json_input = json.dumps(processes_dict, indent=2)
        prompt = f"""You are a cybersecurity AI detecting cryptocurrency mining.
Analyze this JSON and respond with ONLY a JSON object, no other text.

{json_input}

Respond ONLY with: {{'vm1': score, 'vm2': score}}
Do not include markdown, explanations, or any other text."""
        
        try:
            text = await self._call_groq_with_fallback(prompt)
            if not text:
                logger.warning("[KVM] No response from Groq models after fallback.")
                return None
            
            # Nettoyer le texte des balises markdown
            text = re.sub(r'```json\s*', '', text)
            text = re.sub(r'```\s*', '', text)
            text = text.strip()
            
            # --- Start of modified JSON extraction logic ---
            result = None
            try:
                # Attempt to parse directly first, assuming text is pure JSON after cleaning
                result = json.loads(text)
            except json.JSONDecodeError:
                # If direct parse fails, try to extract JSON using regex (in case of surrounding text)
                # The original regex was incorrect due to unescaped curly braces in f-string context.
                # A more general approach is to find the outermost curly braces.
                first_brace = text.find('{')
                last_brace = text.rfind('}')
                
                if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
                    json_str = text[first_brace : last_brace + 1]
                    try:
                        result = json.loads(json_str)
                    except json.JSONDecodeError as nested_json_e:
                        logger.error(f"[KVM] Nested JSON extract and parse error: {nested_json_e}\nRaw extracted JSON: {json_str[:300]}")
                        return None
                else:
                    logger.error(f"[KVM] No discernible JSON object found in text after direct parse failed: {text[:200]}")
                    return None

            if not result: # If result is still None after all attempts
                return None

            # Validation stricte
            validated = {}
            for k, v in result.items():
                if isinstance(k, str) and isinstance(v, (int, float)):
                    score = int(v)
                    if 0 <= score <= 100:
                        validated[k] = score
                
            return validated if validated else None
            # --- End of modified JSON extraction logic ---
        
        except Exception as e: # Catch any remaining unexpected errors (outside JSON processing)
            logger.error(f"[KVM] Groq analysis processing failed: {e}\n{traceback.format_exc()}")
            return None

    @check_kvm_for_threats.before_loop
    async def before_check_kvm_for_threats(self):
        await self.bot.wait_until_ready()
        logger.info("[KVM] Bot ready - KVM threat analysis active")