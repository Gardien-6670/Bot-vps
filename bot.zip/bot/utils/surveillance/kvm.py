import asyncio
import os
import json
import logging
import re
import traceback
from typing import Optional, Dict, List, Any
from datetime import datetime
from groq import AsyncGroq
from discord.ext import tasks
from dotenv import load_dotenv
import discord

from utils.database import db
from utils import node_manager
from utils.node_manager import NodeConnectionError # Import the new custom exception
from utils.surveillance.rate_limiter import PerMinuteRateLimiter
from utils.surveillance.ui_views import UnsuspendView

load_dotenv()

logger = logging.getLogger(__name__)


class SurveillanceKVM:
    """Enhanced KVM VM surveillance system with progressive scoring."""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        groq_api_key = os.getenv("GROQ_API_KEY")
        if not groq_api_key:
            raise ValueError("GROQ_API_KEY not found in .env file")
        
        self.groq_client = AsyncGroq(api_key=groq_api_key)
        self.models = [
            ("openai/gpt-oss-120b", PerMinuteRateLimiter(20)),
            ("openai/gpt-oss-20b", PerMinuteRateLimiter(30)),
            ("llama-3.1-8b-instant", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct-0905", PerMinuteRateLimiter(30)),
            ("moonshotai/kimi-k2-instruct", PerMinuteRateLimiter(30)),
        ]
        
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'suspended': 0,
            'api_calls': 0,
            'node_errors': 0,
            'parse_errors': 0
        }

    @tasks.loop(seconds=60)
    async def check_kvm_for_threats(self):
        logger.info("[KVM] Progressive Threat Scan starting...")

        try:
            all_vps = db.get_all_vps()
            kvm_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'kvm']

            if not kvm_vps:
                return

            processes_to_analyze: Dict[str, Dict[str, Any]] = {}
            vps_map: Dict[str, Dict[str, Any]] = {}

            for vps in kvm_vps:
                vm_name = vps['container_name']

                try:
                    if db.is_vps_suspended(vm_name):
                        continue

                    node_info = node_manager.get_node_for_vps(vm_name)
                    if not node_info:
                        logger.error(f"[KVM] No node for {vm_name}")
                        continue

                    node_url, api_key = node_info['url'], node_info['api_key']

                    status_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/status", node_url, api_key)
                    if not status_result or not status_result.get('running'):
                        continue

                    detailed_metrics = await self._collect_and_store_metrics(vm_name, node_url, api_key)

                    process_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/processes", node_url, api_key)
                    top_processes = self._select_top_processes(process_result.get('processes', []) if process_result else [])

                    if not top_processes:
                        continue

                    processes_to_analyze[vm_name] = {
                        "processes": top_processes,
                        "metrics": detailed_metrics
                    }
                    vps_map[vm_name] = vps

                except NodeConnectionError as e:
                    logger.error(f"[KVM] Node connection failed for {vm_name}: {e}")
                    self.metrics['node_errors'] += 1
                    continue
                except Exception as e:
                    logger.error(f"[KVM] Unexpected error for {vm_name}: {e}\n{traceback.format_exc()}")
                    continue

            if not processes_to_analyze:
                return

            analysis_results = await self.analyze_all_vms(processes_to_analyze)

            if not analysis_results:
                logger.warning("[KVM] No valid analysis from Groq.")
                return

            for vm_name, decision in analysis_results.items():
                vps = vps_map.get(vm_name)
                if not vps:
                    continue

                ai_reason = decision.get("reason", "No reason provided")
                suspend = decision.get("suspend", False)
                suspicious = decision.get("suspicious", suspend)

                record = {
                    "decision": decision,
                    "processes": processes_to_analyze.get(vm_name, {})
                }

                # Log without relying on numeric scoring
                db.log_security_threat(vm_name, 0, json.dumps(record))

                if suspend or suspicious:
                    self.metrics['threats_detected'] += 1

                if suspend:
                    await self._execute_freeze(vps, decision)
                else:
                    logger.info(f"[KVM] {vm_name}: AI cleared (suspicious={suspicious}). Reason: {ai_reason}")

        except Exception as e:
            logger.error(f"[KVM] Error during check: {e}\n{traceback.format_exc()}")
        finally:
            self.metrics['scans_completed'] += 1
            logger.info("[KVM] Progressive Threat Scan finished.")

    async def _execute_freeze(self, vps: dict, ai_decision: Dict[str, Any]):
        vm_name = vps['container_name']
        user_id = vps['user_id']
        reason = ai_decision.get("reason", "Suspicious activity detected")
        node_info = node_manager.get_node_for_vps(vm_name)
        if not node_info:
            logger.error(f"Cannot freeze {vm_name}: No node found")
            return
        try:
            node_url, api_key = node_info['url'], node_info['api_key']
            await node_manager.api_request('POST', f"/kvm/vm/{vm_name}/stop", node_url, api_key, data={"force": True})
            db.suspend_vps(vm_name, reason)
            logger.critical(f"KVM {vm_name} suspended")

            admin = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="KVM VM SUSPENDED",
                description=f"**VM:** `{vm_name}`\n**User:** `{user_id}`\n**Motif (IA):** {reason}",
                color=discord.Color.red()
            )
            embed.add_field(name="Détails", value=json.dumps(ai_decision, indent=2)[:1000], inline=False)
            view = UnsuspendView(vm_name, user_id, self.bot, 'kvm')
            await admin.send(embed=embed, view=view)

            try:
                user = await self.bot.fetch_user(user_id)
                await user.send(f"**VM suspendue**\n\nVotre VM `{vm_name}` a été suspendue après une analyse IA. Motif: {reason}")
            except Exception as notify_err:
                logger.error(f"Failed to notify user {user_id}: {notify_err}")
        except Exception as e:
            logger.error(f"Error freezing KVM VM: {e}\n{traceback.format_exc()}")

    def _select_top_processes(self, processes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Return top 20 processes by CPU, excluding SSH/SSHD related ones."""
        if not processes:
            return []

        filtered = []
        for proc in processes:
            cmd = str(proc.get('command') or proc.get('cmd') or proc.get('name') or '')
            if 'ssh' in cmd.lower():
                continue
            filtered.append({
                "pid": proc.get('pid'),
                "user": proc.get('user') or proc.get('uid'),
                "cpu_percent": float(proc.get('cpu_percent') or proc.get('cpu') or 0),
                "mem_percent": float(proc.get('mem_percent') or proc.get('mem') or 0),
                "command": cmd[:400]
            })

        filtered.sort(key=lambda p: p.get('cpu_percent', 0), reverse=True)
        return filtered[:20]

    async def _collect_and_store_metrics(self, vm_name: str, node_url: str, api_key: str) -> Dict[str, Any]:
        detailed = {}
        try:
            stats_result = await node_manager.api_request('GET', f"/kvm/vm/{vm_name}/stats", node_url, api_key)
            if stats_result:
                cpu_percent = stats_result.get('cpu_percent', 0)
                ram_mb = stats_result.get('memory_mb', 0)
                disk_mb = stats_result.get('disk_mb', 0)

                io_stats = stats_result.get('io', {})
                io_read_mb = io_stats.get('read_mb', 0)
                io_write_mb = io_stats.get('write_mb', 0)

                net_stats = stats_result.get('network', {})
                net_rx_mb = net_stats.get('rx_mb', 0)
                net_tx_mb = net_stats.get('tx_mb', 0)

                db.save_metrics(vm_name, 'kvm', {
                    'cpu_percent': cpu_percent,
                    'ram_mb': ram_mb,
                    'disk_mb': disk_mb,
                    'disk_io_read_mb': io_read_mb,
                    'disk_io_write_mb': io_write_mb,
                    'network_rx_mb': net_rx_mb,
                    'network_tx_mb': net_tx_mb
                })

                abuse_result = db.detect_abuse(vm_name, hours=1)
                if abuse_result['abuse_detected']:
                    for abuse in abuse_result['abuse_types']:
                        logger.warning(f"[KVM ABUSE] {vm_name}: {abuse['type']} - {abuse['value']} (threshold: {abuse['threshold']})")
                        try:
                            db.log_resource_abuse(vm_name, abuse['type'], abuse['value'])
                        except Exception as log_err:
                            logger.error(f"Failed to log abuse for {vm_name}: {log_err}")

                detailed = {
                    'cpu_percent': cpu_percent,
                    'ram_mb': ram_mb,
                    'disk_mb': disk_mb,
                    'io_read_mb': io_read_mb,
                    'io_write_mb': io_write_mb,
                    'net_rx_mb': net_rx_mb,
                    'net_tx_mb': net_tx_mb
                }
        except Exception as e:
            logger.debug(f"Could not get detailed stats for {vm_name}: {e}")

        return detailed

    async def _call_groq_with_fallback(self, prompt: str) -> Optional[str]:
        """
        Attempts to call the primary Groq model, falling back to the secondary model on API errors.
        Returns the text response or None if both fail.
        """
        for model_name, limiter in self.models:
            try:
                await limiter.acquire()
                logger.info(f"[KVM] Using Groq model: {model_name}")
                self.metrics['api_calls'] += 1
                
                chat_completion = await asyncio.wait_for(
                    self.groq_client.chat.completions.create(
                        messages=[
                            {"role": "system", "content": "You are a helpful cybersecurity AI."},
                            {"role": "user", "content": prompt}
                        ],
                        model=model_name,
                        temperature=0.7,
                        max_tokens=2048,
                    ),
                    timeout=60
                )
                
                if chat_completion.choices and chat_completion.choices[0].message.content:
                    return chat_completion.choices[0].message.content
                else:
                    logger.warning(f"[KVM] Groq model {model_name} returned empty content.")
            except Exception as e:
                logger.warning(f"[KVM] Groq model {model_name} failed: {e}. Trying fallback if available.")
        
        logger.error("[KVM] Both primary and fallback Groq models failed to provide a response.")
        return None
    async def analyze_all_vms(self, vm_payloads: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, Dict[str, Any]]]:
        json_input = json.dumps(vm_payloads, indent=2)
        prompt = (
            "You are a cybersecurity AI.\n"
            "For each VM, review the provided top processes (SSH already removed) and metrics. "
            "Flag mining, DDoS tools, or other abusive activity. Only suggest suspension when clearly malicious or abusive.\n"
            "Return strict JSON with this shape (no scores):\n"
            "{\"vm_name\": {\"suspicious\": bool, \"suspend\": bool, \"reason\": str, \"requested_files\": [..], \"notes\": str}}\n"
            "Do not add any text outside JSON."
        )

        try:
            text = await self._call_groq_with_fallback(f"{prompt}\n\nVM DATA:\n{json_input}")
            if not text:
                logger.warning("[KVM] No response from Groq models after fallback.")
                return None

            cleaned = re.sub(r'```json\s*', '', text)
            cleaned = re.sub(r'```\s*', '', cleaned).strip()

            try:
                result = json.loads(cleaned)
            except json.JSONDecodeError:
                first_brace = cleaned.find('{')
                last_brace = cleaned.rfind('}')
                if first_brace != -1 and last_brace != -1:
                    result = json.loads(cleaned[first_brace:last_brace+1])
                else:
                    logger.error(f"[KVM] No JSON object found in AI response: {cleaned[:200]}")
                    return None

            validated: Dict[str, Dict[str, Any]] = {}
            for vm, payload in result.items():
                if not isinstance(payload, dict):
                    continue
                validated[vm] = {
                    "suspicious": bool(payload.get("suspicious", False)),
                    "suspend": bool(payload.get("suspend", False)),
                    "reason": str(payload.get("reason", ""))[:500],
                    "requested_files": payload.get("requested_files", []) or [],
                    "notes": str(payload.get("notes", ""))[:1000]
                }

            return validated if validated else None

        except Exception as e:
            logger.error(f"[KVM] Groq analysis processing failed: {e}\n{traceback.format_exc()}")
            return None

    @check_kvm_for_threats.before_loop
    async def before_check_kvm_for_threats(self):
        await self.bot.wait_until_ready()
        logger.info("[KVM] Bot ready - KVM threat analysis active")
