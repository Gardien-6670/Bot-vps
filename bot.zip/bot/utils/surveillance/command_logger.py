import asyncio
import json
import logging
from discord.ext import tasks
from utils.database import db
from utils import node_manager

logger = logging.getLogger(__name__)

class CommandLogger:
    def __init__(self, bot):
        self.bot = bot
        self.command_log_file = "/var/log/commands.log.json"
        self.log_fetcher.start()
        self.log_analyzer.start()

    @tasks.loop(minutes=5)  # Reduce frequency
    async def log_fetcher(self):
        logger.info("Fetching command logs from VPSs...")
        all_vps = db.get_all_vps()
        
        # Process in batches with asyncio.gather
        batch_size = 10
        for i in range(0, len(all_vps), batch_size):
            batch = all_vps[i:i+batch_size]
            tasks = [self._fetch_logs_for_vps(vps) for vps in batch]
            await asyncio.gather(*tasks, return_exceptions=True)
            
            # Pause between batches
            await asyncio.sleep(1)

    async def _fetch_logs_for_vps(self, vps):
        if vps.get('is_suspended'):
            return
        
        # Skip dedicated servers - they use SSH, not node API
        if vps.get('is_dedicated'):
            return
        
        node_info = node_manager.get_node_for_vps(vps['container_name'])
        if not node_info:
            return

        node_url, api_key = node_info['url'], node_info['api_key']
        vps_type = vps.get('vps_type', 'lxc')
        
        try:
            # Read file content
            # Determine the correct endpoint part based on vps_type
            resource_type = "vm" if vps_type == "kvm" else "container"
            
            file_content = await node_manager.api_request(
                'GET', 
                f"/{vps_type}/{resource_type}/{vps['container_name']}/file?path={self.command_log_file}", 
                node_url, 
                api_key
            )            
            if file_content:
                # node_manager.api_request might return a dict if an API error occurs (e.g., 404)
                if isinstance(file_content, dict) and file_content.get('error'):
                    logger.warning(f"API error fetching logs for {vps['container_name']}: {file_content.get('error')}")
                    return # Skip processing for this VPS
                
                try:
                    # file_content is expected to be a string at this point for successful file reads
                    commands = json.loads(file_content)
                    if isinstance(commands, list):
                        for command in commands:
                            db.add_vps_command_log(vps['id'], command)
                        
                        logger.info(f"Logged {len(commands)} commands for {vps['container_name']}.")
                        # Delete the file after processing
                        delete_cmd = ["rm", "-f", self.command_log_file]
                        await node_manager.api_request(
                            'POST', 
                            f"/{vps_type}/{resource_type}/{vps['container_name']}/exec", 
                            node_url, 
                            api_key, 
                            data={"command": delete_cmd}
                        )
                except json.JSONDecodeError as e:
                    # Log the full content that failed to decode for better debugging
                    logger.warning(f"Invalid JSON in command log for {vps['container_name']}. Error: {e}. Content: {str(file_content)[:500]}")

        except Exception as e:
            logger.error(f"Error fetching logs for {vps['container_name']}: {e}")

    @tasks.loop(minutes=5)
    async def log_analyzer(self):
        logger.info("Analyzing command logs...")
        unanalyzed_logs = db.get_unanalyzed_command_logs()
        
        if not unanalyzed_logs:
            return

        commands_by_vps = {}
        log_ids_by_vps = {}
        for log in unanalyzed_logs:
            vps_id = log['vps_id']
            if vps_id not in commands_by_vps:
                commands_by_vps[vps_id] = []
                log_ids_by_vps[vps_id] = []
            commands_by_vps[vps_id].append(log['command'])
            log_ids_by_vps[vps_id].append(log['id'])

        for vps_id, commands in commands_by_vps.items():
            prompt = f"""Analyze the following shell commands for suspicious activity like crypto mining, DDoS, or hacking.
            Commands:
            {json.dumps(commands, indent=2)}

            Respond with a JSON object containing a 'suspicious_commands' key, which is a list of the exact suspicious commands from the input.
            If no commands are suspicious, the list should be empty.
            e.g. {{ "suspicious_commands": ["some_command", "another_command"] }}
            """
            try:
                # Find a surveillance instance to call groq
                if self.bot.surveillance_lxc_instance:
                    response = await self.bot.surveillance_lxc_instance._call_groq_with_fallback(prompt)
                elif self.bot.surveillance_dedi_instance:
                    response = await self.bot.surveillance_dedi_instance._call_groq_with_fallback(prompt)
                else:
                    logger.warning("No surveillance instance available to call Groq.")
                    continue
                
                if response:
                    analysis_result = json.loads(response)
                    suspicious_commands = analysis_result.get('suspicious_commands', [])
                    
                    all_log_ids = log_ids_by_vps[vps_id]
                    suspicious_log_ids = [log['id'] for log in unanalyzed_logs if log['vps_id'] == vps_id and log['command'] in suspicious_commands]

                    db.mark_commands_as_analyzed(all_log_ids, suspicious_log_ids)
                    
                    if suspicious_commands:
                        vps = db.get_vps_by_id(vps_id)
                        if vps:
                            current_score = vps.get('threat_score', 0)
                            # Add score for each suspicious command
                            new_score = current_score + 10 * len(suspicious_commands)
                            db.update_vps_threat_score(vps_id, new_score)
                            logger.warning(f"Suspicious commands found for VPS {vps_id}. Score increased to {new_score}.")

            except Exception as e:
                logger.error(f"Error analyzing commands for VPS {vps_id}: {e}")

    @log_fetcher.before_loop
    async def before_log_fetcher(self):
        await self.bot.wait_until_ready()
        logger.info("Command Log Fetcher is ready.")
        
    @log_analyzer.before_loop
    async def before_log_analyzer(self):
        await self.bot.wait_until_ready()
        logger.info("Command Log Analyzer is ready.")