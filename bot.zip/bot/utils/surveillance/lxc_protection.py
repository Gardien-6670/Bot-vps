import asyncio
import logging
import time
from datetime import datetime
from typing import Dict

import discord
from discord.ext import tasks

from utils.database import db

logging.basicConfig(level=logging.INFO)


class AntiDDoSMonitorLXC:
    """Monitor LXC network for DDoS detection"""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        self.threshold_mbps = 40
        self.violation_count = {}
        self.suspension_threshold = 2
        self.traffic_history = {}
        self.max_history_age = 300
        
    async def check_container_traffic(self, container_name: str, tx_bytes: int, previous_tx_bytes: int) -> bool:
        """Check if LXC traffic exceeds threshold"""
        try:
            current_time = time.time()
            bytes_delta = tx_bytes - previous_tx_bytes
            
            if container_name not in self.traffic_history:
                self.traffic_history[container_name] = []
            
            self.traffic_history[container_name].append((current_time, bytes_delta))
            self.traffic_history[container_name] = [
                (ts, bytes_) for ts, bytes_ in self.traffic_history[container_name]
                if current_time - ts < self.max_history_age
            ]
            
            sixty_sec_ago = current_time - 60
            recent_traffic = [bytes_ for ts, bytes_ in self.traffic_history[container_name] if ts > sixty_sec_ago]
            
            if recent_traffic:
                avg_bytes_per_sec = sum(recent_traffic) / 60
                avg_mbps = (avg_bytes_per_sec * 8) / (1024 * 1024)
                
                if avg_mbps > self.threshold_mbps:
                    if container_name not in self.violation_count:
                        self.violation_count[container_name] = 0
                    
                    self.violation_count[container_name] += 1
                    logging.warning(f"DDoS Alert LXC {container_name}: {avg_mbps:.2f} MB/s")
                    
                    await self._notify_admin(container_name, avg_mbps, self.violation_count[container_name])
                    
                    if self.violation_count[container_name] >= self.suspension_threshold:
                        logging.error(f"Suspending LXC {container_name}")
                        await self._suspend_container(container_name)
                        return True
                else:
                    if container_name in self.violation_count and self.violation_count[container_name] > 0:
                        self.violation_count[container_name] = 0
                        logging.info(f"{container_name} traffic normalized")
            
            return False
        except Exception as e:
            logging.error(f"Error checking traffic: {e}")
            return False
    
    async def _notify_admin(self, container_name: str, mbps: float, violation_num: int):
        """Notify admin about DDoS"""
        try:
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="LXC DDoS Detection Alert",
                color=discord.Color.red()
            )
            embed.add_field(name="Container", value=container_name, inline=False)
            embed.add_field(name="Traffic", value=f"{mbps:.2f} MB/s", inline=True)
            embed.add_field(name="Violation", value=f"{violation_num}/2", inline=True)
            embed.set_footer(text=f"Timestamp: {datetime.now().isoformat()}")
            
            await user.send(embed=embed)
        except Exception as e:
            logging.error(f"Failed to notify: {e}")
    
    async def _suspend_container(self, container_name: str):
        """Suspend LXC due to DDoS"""
        try:
            db.update_vps_status(container_name, "suspended")
            
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="LXC Suspended",
                color=discord.Color.dark_red()
            )
            embed.add_field(name="Container", value=container_name, inline=False)
            embed.add_field(name="Reason", value="DDoS threshold exceeded (2+ violations)", inline=False)
            
            await user.send(embed=embed)
        except Exception as e:
            logging.error(f"Failed to suspend: {e}")
