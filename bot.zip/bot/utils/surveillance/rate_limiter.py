import asyncio
import time
import logging

logger = logging.getLogger(__name__)


class PerMinuteRateLimiter:
    """Thread-safe rate limiter with semaphore"""
    def __init__(self, requests_per_minute: int):
        self.max_requests = requests_per_minute
        self.time_window = 60
        self.request_timestamps = []
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            now = time.time()
            
            # Nettoyer d'abord
            self.request_timestamps = [
                ts for ts in self.request_timestamps 
                if now - ts < self.time_window
            ]

            if len(self.request_timestamps) < self.max_requests:
                self.request_timestamps.append(now)
                return
            
            # Attendre en dehors du lock pour libérer les ressources
            oldest = self.request_timestamps[0]
            wait_time = self.time_window - (now - oldest) + 0.1
        
        # Attente hors du lock
        await asyncio.sleep(wait_time)
        # Réessayer récursivement
        return await self.acquire()
