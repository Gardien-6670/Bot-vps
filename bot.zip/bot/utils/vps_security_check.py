import discord
from discord.ext import commands, tasks
from utils.database import db
from utils import node_manager
import asyncio
import logging
import random
import re

# ====================================================================================================================
# 1. HELPER: VPS TRANSFER LOGIC
# ====================================================================================================================

async def _execute_vps_transfer(bot, vps_db_info: dict, new_node_name: str, new_node_info: dict):
 """
 Handles the technical logic of transferring a VPS from one node to another.
 This function is designed to be called from background tasks without a discord.Interaction context.
 """
 max_retries = 3
 container_name = vps_db_info['container_name']
 user_id = vps_db_info['user_id']
 user = await bot.fetch_user(user_id)

 logging.info(f"Starting automatic transfer of {container_name} for user {user_id} to node {new_node_name}.")

 old_node_info = node_manager.get_node_for_vps(container_name)
 if not old_node_info:
 logging.error(f"Transfer Aborted: Could not determine the original node for {container_name}.")
 await user.send(f"An automatic transfer of your VPS `{container_name}` failed because its original node could not be determined. Please contact support.")
 return

 old_node_url, old_api_key = old_node_info['url'], old_node_info['api_key']
 old_node_name = vps_db_info.get('node', 'Unknown')
 vps_type = vps_db_info.get('vps_type', 'lxc')
 endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

 # 1. Delete VPS from old node
 delete_result = None
 for attempt in range(max_retries):
 delete_result = await node_manager.api_request('DELETE', f"{endpoint_prefix}/{container_name}", old_node_url, old_api_key)
 if delete_result and (delete_result.get("deleted") or (vps_type == 'kvm' and delete_result.get("status") == "success")):
 logging.info(f"Successfully deleted {container_name} from old node {old_node_name} (Attempt {attempt + 1}).")
 break
 await asyncio.sleep(5)
 
 if not delete_result or (not delete_result.get("deleted") and not (vps_type == 'kvm' and delete_result.get("status") == "success")):
 logging.error(f"Transfer Failed: Could not delete {container_name} from {old_node_name} after {max_retries} attempts.")
 await user.send(f"An automatic transfer of your VPS `{container_name}` failed because it could not be removed from its original node. Please contact support.")
 return

 # 2. Create VPS on new node
 payload = {
 "user_id": vps_db_info['user_id'], "username": vps_db_info['username'],
 "cpu": vps_db_info['cpu'], "ram": vps_db_info['ram'], "disk": vps_db_info['disk']
 }
 create_result = None
 for attempt in range(max_retries):
 create_result = await node_manager.api_request('POST', endpoint_prefix, new_node_info['url'], new_node_info['api_key'], data=payload)
 if create_result and (create_result.get("status") == "success" or create_result.get("container_name") or create_result.get("vm_name")):
 logging.info(f"Successfully created new instance for {container_name} on {new_node_name} (Attempt {attempt + 1}).")
 break
 await asyncio.sleep(5)

 if create_result and (create_result.get("status") == "success" or create_result.get("container_name") or create_result.get("vm_name")):
 new_container_name = create_result.get("container_name") or create_result.get("vm_name")
 new_ssh_link = create_result.get("ssh_link") or create_result.get("ssh_connection")
 new_ssh_port = create_result.get("ssh_port")
 new_ssh_password = create_result.get("ssh_password")
 new_ip_address = create_result.get("vm_ip")

 if new_node_info.get("domain") and new_ssh_link:
 new_ssh_link = re.sub(r'@([\w.-]+)', f'@{new_node_info["domain"]}', new_ssh_link)

 if new_container_name:
 # 3. Update DB
 db.delete_vps_by_container_name(container_name)
 db.add_vps(
 user_id=vps_db_info['user_id'], username=vps_db_info['username'],
 container_name=new_container_name, cpu=vps_db_info['cpu'],
 ram=vps_db_info['ram'], disk=vps_db_info['disk'],
 cost_credits=vps_db_info['cost_credits'], ssh_link=new_ssh_link,
 ssh_port=new_ssh_port, ssh_password=new_ssh_password, vps_type=vps_type,
 ip_address=new_ip_address, node=new_node_name, due_date=vps_db_info.get('due_date')
 )
 logging.info(f"Transfer Complete: {container_name} moved to {new_container_name} on node {new_node_name}.")

 # 4. Notify User
 try:
 embed = discord.Embed(
 title="VPS Automatically Transferred",
 description=f"Your VPS `{container_name}` was on a premium node without the required role. It has been automatically transferred to a free node and is now named `{new_container_name}`.",
 color=0x99AAB5
 )
 embed.add_field(name="New SSH Connection", value=f"```\n{new_ssh_link}\n```", inline=False)
 embed.add_field(name="New Password", value=f"```\n{new_ssh_password}\n```", inline=False)
 await user.send(embed=embed)
 except discord.Forbidden:
 logging.warning(f"Could not DM user {user_id} about automatic transfer.")
 else:
 logging.error(f"Transfer Failed: New instance created for {container_name} but API returned no new name.")
 await user.send(f"The automatic transfer of your VPS `{container_name}` failed at the final step. Your credits have been refunded. Please create a new VPS. Contact support if issues persist.")
 db.add_credits(user_id, vps_db_info['cost_credits']) # Refund
 else:
 logging.error(f"Transfer Failed: Could not create new instance for {container_name} on {new_node_name}. Refunding user.")
 await user.send(f"The automatic transfer of your VPS `{container_name}` failed. Your old VPS was removed, but a new one could not be created. Your credits have been refunded. Please create a new VPS.")
 db.add_credits(user_id, vps_db_info['cost_credits']) # Refund

# ====================================================================================================================
# 2. COG DEFINITION
# ====================================================================================================================

class VpsSecurityMonitor(commands.Cog):
 def __init__(self, bot):
 self.bot = bot
 self.PREMIUM_ROLE_ID = 1358004192416890903
 self.check_premium_nodes.start()

 def cog_unload(self):
 self.check_premium_nodes.cancel()

 @tasks.loop(minutes=5)
 async def check_premium_nodes(self):
 logging.info("Running periodic check for non-compliant VPS on premium nodes...")
 all_vps = db.get_all_vps()
 if not all_vps:
 return

 guilds = self.bot.guilds
 if not guilds:
 logging.warning("VPS Security Check: Bot is not in any guilds.")
 return
 main_guild = guilds[0]

 ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
 BOOSTER_ROLE_ID = 1436388721086693567

 for vps in all_vps:
 node_info = node_manager.get_node_for_vps(vps['container_name'])
 if not node_info or not node_info.get('premium'):
 continue

 user_id = vps['user_id']
 has_permission = False

 if user_id in ADMIN_WHITELIST:
 has_permission = True
 else:
 try:
 member = await main_guild.fetch_member(user_id)
 user_roles = {role.id for role in member.roles}

 if BOOSTER_ROLE_ID in user_roles:
 has_permission = True
 elif self.PREMIUM_ROLE_ID in user_roles:
 has_permission = True
 elif db.has_completed_credit_transaction(user_id):
 has_permission = True
 
 except discord.NotFound:
 logging.warning(f"User {user_id} for VPS {vps['container_name']} not found in guild. Assuming no premium permission.")
 has_permission = False
 except Exception as e:
 logging.error(f"Error checking premium permissions for user {user_id}: {e}", exc_info=True)
 continue

 if not has_permission:
 logging.warning(f"Found non-compliant VPS: {vps['container_name']} (User: {vps['user_id']}) on premium node {vps.get('node')}.")
 
 free_nodes = {name: info for name, info in node_manager.NODES.items() if not info.get('premium')}
 if not free_nodes:
 logging.error(f"Cannot transfer {vps['container_name']}: No free nodes are configured.")
 continue

 target_node_name = None
 target_node_info = None
 shuffled_nodes = list(free_nodes.items())
 random.shuffle(shuffled_nodes)

 for node_name, node_info_item in shuffled_nodes:
 stats = await node_manager.get_node_stats(node_name, node_info_item)
 vps_type = vps.get('vps_type', 'lxc')
 
 current, max_cap = (stats.get('lxc_current', 0), stats.get('lxc_max', 0)) if vps_type == 'lxc' else (stats.get('kvm_current', 0), stats.get('kvm_max', 0))

 if max_cap > 0 and current < max_cap:
 target_node_name = node_name
 target_node_info = node_info_item
 break
 
 if target_node_name and target_node_info:
 await _execute_vps_transfer(self.bot, vps, target_node_name, target_node_info)
 else:
 logging.error(f"Cannot transfer {vps['container_name']}: All available free nodes are full.")
 
 await asyncio.sleep(2)

 @check_premium_nodes.before_loop
 async def before_check(self):
 await self.bot.wait_until_ready()

async def setup(bot):
 await bot.add_cog(VpsSecurityMonitor(bot))