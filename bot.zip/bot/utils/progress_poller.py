import aiohttp
import logging
import asyncio

logger = logging.getLogger(__name__)

async def get_current_progress(operation_id: str, node_url: str, api_key: str) -> dict | None:
    """
    Récupère la progression actuelle d'une opération depuis le backend.

    Returns:
        dict avec keys: percentage, message, completed, timestamp
        None si erreur ou opération introuvable
    """
    try:
        headers = {"X-API-KEY": api_key}
        url = f"{node_url}/progress/{operation_id}"

        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=5)) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "percentage": data.get("percentage", 0),
                        "message": data.get("message", "Processing..."),
                        "completed": data.get("completed", False),
                        "result": data.get("result"),  # AJOUT: Inclure le résultat
                        "timestamp": data.get("timestamp")
                    }
                elif response.status == 404:
                    logger.debug(f"Operation {operation_id} not found (might not be started yet)")
                    return None
                else:
                    logger.warning(f"Failed to get progress for {operation_id}: HTTP {response.status}")
                    return None

    except asyncio.TimeoutError:
        logger.debug(f"Timeout getting progress for {operation_id}")
        return None
    except Exception as e:
        logger.error(f"Error getting progress for {operation_id}: {e}")
        return None
