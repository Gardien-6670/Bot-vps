import os
import asyncio
import aiohttp
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, jsonify, url_for
from dotenv import load_dotenv
import logging
import secrets
import pytz

# Load environment variables
load_dotenv()

from .database import db

app = Flask(__name__)

app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict"
)


@app.after_request
def apply_security_headers(response):
    response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:"
    )
    response.headers.setdefault("Permissions-Policy", "geolocation=()")
    return response

# Configure logging
app.logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
app.logger.addHandler(handler)

# --- Constants ---
FLASK_BIND_HOST = os.getenv("FLASK_HOST", "0.0.0.0")
FLASK_PORT = 6029 # As requested
# SSL Configuration (optionnel)
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"
SSL_CERT = os.getenv("SSL_CERT_PATH", "/etc/letsencrypt/live/api-veridian.duckdns.org/fullchain.pem")
SSL_KEY = os.getenv("SSL_KEY_PATH", "/etc/letsencrypt/live/api-veridian.duckdns.org/privkey.pem")

# --- Datetime Helper ---
def ensure_aware(dt):
    """Convert naive datetime to UTC-aware datetime."""
    if dt and dt.tzinfo is None:
        return pytz.utc.localize(dt)
    return dt

# --- HTML Templates ---
VERIFY_PAGE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anti-Double Account Check</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #1e1e1e; color: #e0e0e0; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background-color: #2a2a2a; padding: 40px; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); max-width: 600px; width: 90%; text-align: center; border: 1px solid #444; }
        h1 { color: #bb86fc; margin-bottom: 20px; font-weight: 300; }
        p { font-size: 1.1em; color: #b0b0b0; line-height: 1.6; }
        .btn { padding: 14px 28px; border: none; border-radius: 8px; cursor: pointer; font-size: 1.1em; font-weight: 600; transition: all 0.3s; background-color: #03dac6; color: #1e1e1e; margin-top: 20px; letter-spacing: 0.5px; }
        .btn:hover { background-color: #ffffff; box-shadow: 0 4px 12px rgba(3, 218, 198, 0.3); }
        .footer { font-size: 0.8em; color: #666; margin-top: 30px; }
        .error-box { background-color: #333; border-left: 5px solid #cf6679; color: #cf6679; padding: 20px; margin-top: 20px; border-radius: 8px; text-align: left;}
        .error-box h3 { margin-top: 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Anti-Double Account Check</h1>
        <p>To continue, please complete this one-time eligibility check. This helps us prevent abuse and protect the community.</p>
        
        {% if is_valid_ip %}
            <form action="{{ url_for('confirm_check', user_id=user_id, token=token) }}" method="POST">
                <button type="submit" class="btn">Continue</button>
            </form>
        {% else %}
            <div class="error-box">
                <h3>Not eligible</h3>
                <p>{{ rejection_reason }}</p>
            </div>
        {% endif %}

        <p class="footer">This one-time check is for security only.</p>
    </div>
</body>
</html>
"""

MESSAGE_PAGE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #1e1e1e; color: #e0e0e0; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background-color: #2a2a2a; padding: 40px; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); max-width: 600px; text-align: center; border: 1px solid #444; }
        h1 { color: {{ color }}; font-weight: 300; }
        p { font-size: 1.2em; color: #b0b0b0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>{{ message }}</h1>
        <p>{{ extra_text }}</p>
    </div>
</body>
</html>
"""

# --- Flask Routes ---
@app.route('/verify/<int:user_id>/<string:token>')
async def verify_page(user_id, token):
    valid_token_data = db.get_ip_verification_token(user_id)
    
    if not valid_token_data or valid_token_data.get('token') != token or datetime.now(pytz.utc) > ensure_aware(valid_token_data.get('expires_at')):
        app.logger.warning(f"Invalid or expired verification token used for user_id: {user_id}")
        return render_template_string(MESSAGE_PAGE_HTML, title="Error", message="Invalid or Expired Link", extra_text="Please request a new verification link from the bot.", color="#cf6679"), 403

    ip_address = request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()

    ip_data = {'ip': ip_address}
    rejection_reason = None
    is_valid_ip = True

    # NEW: Check if IP is already in use by another user (excluding the current user)
    if db.is_ip_already_used(ip_address, user_id):
        is_valid_ip = False
        rejection_reason = "You are not eligible to continue at this time."
        return render_template_string(VERIFY_PAGE_HTML, ip_data=ip_data, user_id=user_id, token=token, is_valid_ip=is_valid_ip, rejection_reason=rejection_reason)


    async with aiohttp.ClientSession() as session:
        try:
            # Use ip-api.com, which provides proxy/hosting detection on its free tier
            # Request 'isp' field in addition to 'org' for better provider display
            api_url = f"http://ip-api.com/json/{ip_address}?fields=status,message,country,city,org,isp,proxy,hosting,mobile"
            async with session.get(api_url) as resp:
                if resp.status == 200:
                    api_response = await resp.json()
                    
                    if api_response.get('status') == 'success':
                        # ============================================================
                        # SECURITY CHECKS - VPN/PROXY/DATACENTER DETECTION
                        # ============================================================
                        
                        # Check 1: Proxy/VPN flag from ip-api.com
                        if api_response.get('proxy'):
                            is_valid_ip = False
                            rejection_reason = "You are not eligible to continue at this time."
                            app.logger.warning(f"IP {ip_address} rejected: VPN/Proxy detected (proxy flag)")
                        
                        # Check 2: Hosting/Datacenter flag from ip-api.com
                        elif api_response.get('hosting'):
                            is_valid_ip = False
                            rejection_reason = "You are not eligible to continue at this time."
                            app.logger.warning(f"IP {ip_address} rejected: Datacenter detected (hosting flag)")
                        
                        # Check 3: Known VPN/Datacenter providers in ISP/ORG name
                        else:
                            isp_org = (api_response.get('isp', '') + ' ' + api_response.get('org', '')).lower()
                            
                            # Liste des fournisseurs VPN/Datacenter connus
                            blocked_keywords = [
                                # VPN Providers
                                'vpn', 'proxy', 'nordvpn', 'expressvpn', 'surfshark', 'protonvpn',
                                'cyberghost', 'private internet access', 'pia', 'mullvad', 'windscribe',
                                'tunnelbear', 'hotspot shield', 'ipvanish', 'purevpn', 'vyprvpn',
                                
                                # Cloud/Datacenter Providers
                                'amazon', 'aws', 'google cloud', 'gcp', 'microsoft azure', 'azure',
                                'digitalocean', 'linode', 'vultr', 'ovh', 'hetzner', 'contabo',
                                'scaleway', 'oracle cloud', 'alibaba cloud', 'tencent cloud',
                                
                                # Hosting Providers
                                'hosting', 'datacenter', 'data center', 'server', 'dedicated',
                                'colocation', 'colo', 'cloud', 'vps', 'virtual private',
                                
                                # Specific Providers
                                'cloudflare', 'akamai', 'fastly', 'incapsula', 'sucuri',
                                'quadranet', 'psychz', 'choopa', 'servermania', 'leaseweb'
                            ]
                            
                            for keyword in blocked_keywords:
                                if keyword in isp_org:
                                    is_valid_ip = False
                                    rejection_reason = "You are not eligible to continue at this time."
                                    app.logger.warning(f"IP {ip_address} rejected: Blocked keyword '{keyword}' found in ISP/ORG")
                                    break
                        
                        # Log successful validation
                        if is_valid_ip:
                            app.logger.info(f"IP {ip_address} passed all security checks (ISP: {api_response.get('isp')})")
                    else:
                        is_valid_ip = False
                        rejection_reason = "You are not eligible to continue at this time."
                        app.logger.error(f"ip-api.com returned failure for {ip_address}: {api_response.get('message')}")
                else:
                    is_valid_ip = False
                    rejection_reason = "You are not eligible to continue at this time."
                    app.logger.error(f"ip-api.com returned status {resp.status} for IP {ip_address}")
        except Exception as e:
            app.logger.error(f"ip-api.com call failed for IP {ip_address}: {e}")
            is_valid_ip = False
            rejection_reason = "You are not eligible to continue at this time."

    return render_template_string(VERIFY_PAGE_HTML, ip_data=ip_data, user_id=user_id, token=token, is_valid_ip=is_valid_ip, rejection_reason=rejection_reason)

@app.route('/confirm/<int:user_id>/<string:token>', methods=['POST'])
async def confirm_check(user_id, token):
    valid_token_data = db.get_ip_verification_token(user_id)

    # Re-validate the token on POST
    if not valid_token_data or valid_token_data.get('token') != token or datetime.now(pytz.utc) > ensure_aware(valid_token_data.get('expires_at')):
        app.logger.warning(f"Invalid or expired token used on POST for user_id: {user_id}")
        return render_template_string(MESSAGE_PAGE_HTML, title="Error", message="Invalid or Expired Link", extra_text="Please request a new verification link from the bot.", color="#cf6679"), 403

    ip_address = request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()
    
    # ============================================================================
    # ANTI-DOUBLE COMPTE - Vérifier si cette IP est déjà utilisée
    # ============================================================================
    try:
        existing_user = db.get_user_by_ip(ip_address)
        if existing_user and existing_user['user_id'] != user_id:
            app.logger.warning(
                f"Anti-double compte: IP {ip_address} déjà utilisée par user {existing_user['user_id']}, "
                f"refus pour user {user_id}"
            )
            return render_template_string(
                MESSAGE_PAGE_HTML,
                title="Not eligible",
                message="Not Eligible",
                extra_text="You are not eligible to continue at this time.",
                color="#cf6679"
            ), 403
    except Exception as e:
        app.logger.error(f"Error checking for duplicate IP: {e}")
        # Continuer même en cas d'erreur de vérification
    
    try:
        db.update_user_ip_and_verify(user_id, ip_address)
        db.clear_ip_verification_token(user_id) # Invalidate the token after use
        app.logger.info(f"Successfully verified IP {ip_address} for user {user_id}")
        return render_template_string(MESSAGE_PAGE_HTML, title="Success!", message="Eligible", extra_text="You can now close this window and continue using the bot.", color="#03dac6")
    except Exception as e:
        app.logger.error(f"Failed to update database for user {user_id} during eligibility check: {e}")
        return render_template_string(MESSAGE_PAGE_HTML, title="Error", message="Database Error", extra_text="Could not save your information. Please try again later.", color="#cf6679"), 500

def run_ip_verify_flask_app():
    """Function to run the Flask app."""
    # This check is important to avoid running in a sub-process on some platforms
    if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
         app.logger.info(f"Starting Eligibility Check Flask server on {FLASK_BIND_HOST}:{FLASK_PORT}")
    
    ssl_context = (SSL_CERT, SSL_KEY) if SSL_ENABLED else None
    app.run(host=FLASK_BIND_HOST, port=FLASK_PORT, debug=False, use_reloader=False, ssl_context=ssl_context)
