"""
VPS Monitoring Channel System
Displays real-time metrics for all VPS in a dedicated channel
"""

import discord
from discord.ext import tasks
import logging
from datetime import datetime
from typing import Optional

from utils.database import db

logger = logging.getLogger(__name__)

MONITORING_CHANNEL_ID = 1471968359175422147

class VPSMonitoringChannel:
    """
    Manages the VPS monitoring channel
    Updates every 5 minutes with latest metrics
    """

    def __init__(self, bot):
        self.bot = bot
        self.channel_id = MONITORING_CHANNEL_ID
        self.message_id = None
        self.channel = None

    async def initialize(self):
        """Initialize the monitoring channel"""
        try:
            self.channel = self.bot.get_channel(self.channel_id)
            if not self.channel:
                logger.error(f"Monitoring channel {self.channel_id} not found")
                return False

            logger.info(f"VPS Monitoring channel initialized: {self.channel.name}")

            # Start the update task
            if not self.update_monitoring.is_running():
                self.update_monitoring.start()
                logger.info("VPS Monitoring update task started")

            return True
        except Exception as e:
            logger.error(f"Failed to initialize monitoring channel: {e}")
            return False

    @tasks.loop(minutes=5)
    async def update_monitoring(self):
        """Update the monitoring embed every 5 minutes"""
        try:
            if not self.channel:
                return

            embed = await self.create_monitoring_embed()

            if self.message_id:
                # Try to edit existing message
                try:
                    message = await self.channel.fetch_message(self.message_id)
                    await message.edit(embed=embed)
                except discord.NotFound:
                    # Message was deleted, create new one
                    message = await self.channel.send(embed=embed)
                    self.message_id = message.id
            else:
                # Create new message
                message = await self.channel.send(embed=embed)
                self.message_id = message.id

            logger.debug("VPS monitoring embed updated")

        except Exception as e:
            logger.error(f"Failed to update monitoring embed: {e}")

    async def create_monitoring_embed(self) -> discord.Embed:
        """Create the monitoring embed with all VPS metrics"""

        # Get all VPS with their latest metrics
        all_vps = db.get_all_vps()
        latest_metrics = db.get_all_latest_metrics()

        # Create a map of container_name -> metrics
        metrics_map = {m['container_name']: m for m in latest_metrics}

        # Separate LXC and KVM
        lxc_vps = [v for v in all_vps if v.get('vps_type') == 'lxc' and v.get('is_active')]
        kvm_vps = [v for v in all_vps if v.get('vps_type') == 'kvm' and v.get('is_active')]

        # Create embed
        embed = discord.Embed(
            title="VPS Monitoring Dashboard",
            description=f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            color=discord.Color.blue()
        )

        # LXC Section
        if lxc_vps:
            lxc_text = "**LXC Containers**\n\n"

            for vps in lxc_vps[:25]:  # Limit to 25 to avoid embed size limits
                container_name = vps['container_name']
                user_id = vps['user_id']
                username = vps.get('username', 'Unknown')

                # Get metrics
                metrics = metrics_map.get(container_name)

                if metrics:
                    cpu = metrics.get('cpu_percent', 0)
                    ram = metrics.get('ram_mb', 0)
                    disk = metrics.get('disk_mb', 0)
                    io_read = metrics.get('disk_io_read_mb', 0)
                    io_write = metrics.get('disk_io_write_mb', 0)
                    net_rx = metrics.get('network_rx_mb', 0)
                    net_tx = metrics.get('network_tx_mb', 0)

                    lxc_text += f"**{container_name}** | User: <@{user_id}> ({user_id})\n"
                    lxc_text += f"CPU: {cpu:.1f}% | RAM: {ram:.0f} MB | Disk: {disk:.1f} GB\n"
                    lxc_text += f"I/O: R:{io_read:.1f}MB W:{io_write:.1f}MB | Network: RX:{net_rx:.1f}MB TX:{net_tx:.1f}MB\n\n"
                else:
                    lxc_text += f"**{container_name}** | User: <@{user_id}> ({user_id})\n"
                    lxc_text += f"No metrics available\n\n"

            if len(lxc_vps) > 25:
                lxc_text += f"... and {len(lxc_vps) - 25} more LXC containers\n"

            embed.add_field(
                name="LXC Containers",
                value=lxc_text if lxc_text else "No active LXC containers",
                inline=False
            )

        # Separator
        if lxc_vps and kvm_vps:
            embed.add_field(
                name="\u200b",
                value=" " * 50,
                inline=False
            )

        # KVM Section
        if kvm_vps:
            kvm_text = "**KVM Containers**\n\n"

            for vps in kvm_vps[:25]:  # Limit to 25
                container_name = vps['container_name']
                user_id = vps['user_id']
                username = vps.get('username', 'Unknown')

                # Get metrics
                metrics = metrics_map.get(container_name)

                if metrics:
                    cpu = metrics.get('cpu_percent', 0)
                    ram = metrics.get('ram_mb', 0)
                    disk = metrics.get('disk_mb', 0)
                    io_read = metrics.get('disk_io_read_mb', 0)
                    io_write = metrics.get('disk_io_write_mb', 0)
                    net_rx = metrics.get('network_rx_mb', 0)
                    net_tx = metrics.get('network_tx_mb', 0)

                    kvm_text += f"**{container_name}** | User: <@{user_id}> ({user_id})\n"
                    kvm_text += f"CPU: {cpu:.1f}% | RAM: {ram:.0f} MB | Disk: {disk:.1f} GB\n"
                    kvm_text += f"I/O: R:{io_read:.1f}MB W:{io_write:.1f}MB | Network: RX:{net_rx:.1f}MB TX:{net_tx:.1f}MB\n\n"
                else:
                    kvm_text += f"**{container_name}** | User: <@{user_id}> ({user_id})\n"
                    kvm_text += f"No metrics available\n\n"

            if len(kvm_vps) > 25:
                kvm_text += f"... and {len(kvm_vps) - 25} more KVM containers\n"

            embed.add_field(
                name="KVM Containers",
                value=kvm_text if kvm_text else "No active KVM containers",
                inline=False
            )

        # Summary
        total_vps = len(lxc_vps) + len(kvm_vps)
        embed.set_footer(text=f"Total Active VPS: {total_vps} | LXC: {len(lxc_vps)} | KVM: {len(kvm_vps)}")

        return embed

    @update_monitoring.before_loop
    async def before_update_monitoring(self):
        """Wait for bot to be ready before starting the loop"""
        await self.bot.wait_until_ready()
        logger.info("VPS Monitoring task ready")

def setup_monitoring_channel(bot):
    """Setup the monitoring channel system"""
    monitor = VPSMonitoringChannel(bot)
    return monitor
