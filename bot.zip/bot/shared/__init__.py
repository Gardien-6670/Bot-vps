"""
Module Shared : Code partagé entre Bot et API
=============================================

Ce module contient le code partagé entre le bot Discord et l'API Flask
pour éviter la duplication et garantir la cohérence.
"""

__version__ = '1.0.0'
__author__ = 'bot-vps team'

# Importer les modules principaux
from . import database

__all__ = ['database']
