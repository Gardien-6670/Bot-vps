\"""
Wrapper de compatibilité pour database.py
=========================================

Ce module fournit une interface compatible avec l'ancien code
tout en utilisant les nouveaux modules shared.
\"""

import os
import logging
from dotenv import load_dotenv
# Import depuis le dossier local bot/shared/database
from .database import DatabaseCore, VPSManager, UserManager, CreditsManager

load_dotenv()
logger = logging.getLogger(__name__)


class Database:
    \"""
    Wrapper de compatibilité pour l'ancienne interface database.py
    
    Cette classe délègue toutes les opérations aux nouveaux modules shared
    tout en maintenant la compatibilité avec l'ancien code.
    \"""
    
    def __init__(self):
        \"""Initialise la base de données avec les nouveaux modules\"""
        # Configuration depuis les variables d'environnement
        config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': int(os.getenv('DB_PORT', 3306)),
            'user': os.getenv('DB_USER', 'root'),
            'password': os.getenv('DB_PASSWORD', ''),
            'database': os.getenv('DB_NAME', 'vps')
        }
        
        # Initialiser les modules
        self.core = DatabaseCore(**config)
        self.users = UserManager(self.core)
        self.credits = CreditsManager(self.core, self.users)
        self.vps = VPSManager(self.core)
        
    # ==========================================
    # Méthodes de transaction (délégation core)
    # ==========================================
    
    def start_transaction(self):
        \"""Démarre une transaction\"""
        return self.core.start_transaction()
        
    def commit_transaction(self, conn, cursor):
        \"""Commit une transaction\"""
        return self.core.commit_transaction(conn, cursor)
        
    def rollback_transaction(self, conn, cursor):
        \"""Rollback une transaction\"""
        return self.core.rollback_transaction(conn, cursor)
        
    # ==========================================
    # Méthodes VPS (délégation vps)
    # ==========================================
    
    def add_vps(self, *args, **kwargs):
        \"""Ajoute un VPS\"""
        return self.vps.add_vps(*args, **kwargs)
        
    def get_vps(self, *args, **kwargs):
        \"""Récupère un VPS\"""
        return self.vps.get_vps(*args, **kwargs)
        
    def get_user_vps(self, *args, **kwargs):
        \"""Récupère les VPS d'un utilisateur\"""
        return self.vps.get_user_vps(*args, **kwargs)
        
    def get_all_vps(self, *args, **kwargs):
        \"""Récupère tous les VPS\"""
        return self.vps.get_all_vps(*args, **kwargs)
        
    def update_vps(self, *args, **kwargs):
        \"""Met à jour un VPS\"""
        return self.vps.update_vps(*args, **kwargs)
        
    def delete_vps(self, *args, **kwargs):
        \"""Supprime un VPS\"""
        return self.vps.delete_vps(*args, **kwargs)
        
    def suspend_vps(self, *args, **kwargs):
        \"""Suspend un VPS\"""
        return self.vps.suspend_vps(*args, **kwargs)
        
    def unsuspend_vps(self, *args, **kwargs):
        \"""Réactive un VPS\"""
        return self.vps.unsuspend_vps(*args, **kwargs)
        
    def is_vps_suspended(self, *args, **kwargs):
        \"""Vérifie si un VPS est suspendu\"""
        return self.vps.is_vps_suspended(*args, **kwargs)
        
    def set_vps_due_date(self, *args, **kwargs):
        \"""Définit la date d'échéance d'un VPS\"""
        return self.vps.set_vps_due_date(*args, **kwargs)
        
    def get_vps_by_container_name(self, container_name):
        \"""Récupère un VPS par son nom de conteneur\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute("SELECT * FROM vps WHERE container_name = %s", (container_name,))
            return cursor.fetchone()
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_all_ad_tier_vps(self):
        \"""Récupère tous les VPS ad-supported\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute("SELECT * FROM vps WHERE plan_type = 'ad-supported'")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_all_invite_vps(self):
        \"""Récupère tous les VPS invite-based\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute("SELECT * FROM vps WHERE plan_type = 'invite'")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_suspended_ad_tier_vps_for_deletion(self, days=2):
        \"""Récupère les VPS ad-supported suspendus à supprimer\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM vps 
                WHERE plan_type = 'ad-supported' 
                AND is_suspended = 1 
                AND suspended_at < DATE_SUB(NOW(), INTERVAL %s DAY)
            \""", (days,))
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_all_users_with_vps(self):
        \"""Récupère tous les utilisateurs ayant des VPS\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT DISTINCT user_id FROM vps WHERE is_deleted = 0
            \""")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def update_unassigned_vps_nodes(self, node_name):
        \"""Met à jour les VPS sans node assigné\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                UPDATE vps SET node_name = %s 
                WHERE node_name IS NULL OR node_name = ''
            \""", (node_name,))
            conn.commit()
            return cursor.rowcount
        except Exception as e:
            conn.rollback()
            logger.error(f"Error updating unassigned VPS nodes: {e}")
            return 0
        finally:
            self.core.close_connection(conn, cursor)
        
    # ==========================================
    # Méthodes utilisateurs (délégation users)
    # ==========================================
    
    def get_user(self, *args, **kwargs):
        \"""Récupère un utilisateur\"""
        return self.users.get_user(*args, **kwargs)
        
    def ensure_user_exists(self, *args, **kwargs):
        \"""S'assure qu'un utilisateur existe\"""
        return self.users.ensure_user_exists(*args, **kwargs)
        
    def get_balance(self, *args, **kwargs):
        \"""Récupère le solde d'un utilisateur\"""
        return self.users.get_balance(*args, **kwargs)
        
    def set_balance(self, *args, **kwargs):
        \"""Définit le solde d'un utilisateur\"""
        return self.users.set_balance(*args, **kwargs)
        
    def get_pending_balance(self, *args, **kwargs):
        \"""Récupère le solde en attente\"""
        return self.users.get_pending_balance(*args, **kwargs)
        
    def add_pending_credits(self, *args, **kwargs):
        \"""Ajoute des crédits en attente\"""
        return self.users.add_pending_credits(*args, **kwargs)
        
    def remove_all_pending_credits(self, *args, **kwargs):
        \"""Supprime tous les crédits en attente\"""
        return self.users.remove_all_pending_credits(*args, **kwargs)
        
    def get_unrewarded_members(self, since_date):
        \"""Récupère les membres non récompensés\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM users 
                WHERE joined_at >= %s AND rewarded = 0
            \""", (since_date,))
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
        
    # ==========================================
    # Méthodes crédits (délégation credits)
    # ==========================================
    
    def add_credits(self, *args, **kwargs):
        \"""Ajoute des crédits\"""
        return self.credits.add_credits(*args, **kwargs)
        
    def get_vps_points(self, *args, **kwargs):
        \"""Récupère les points VPS\"""
        return self.credits.get_vps_points(*args, **kwargs)
        
    def add_vps_points(self, *args, **kwargs):
        \"""Ajoute des points VPS\"""
        return self.credits.add_vps_points(*args, **kwargs)
        
    def consume_vps_points(self, *args, **kwargs):
        \"""Consomme des points VPS\"""
        return self.credits.consume_vps_points(*args, **kwargs)
        
    def get_invites(self, *args, **kwargs):
        \"""Récupère les invitations\"""
        return self.credits.get_invites(*args, **kwargs)
        
    def add_invites(self, *args, **kwargs):
        \"""Ajoute des invitations\"""
        return self.credits.add_invites(*args, **kwargs)
        
    def consume_invites(self, *args, **kwargs):
        \"""Consomme des invitations\"""
        return self.credits.consume_invites(*args, **kwargs)
        
    # ==========================================
    # Méthodes transactions et paiements
    # ==========================================
    
    def get_pending_transactions(self):
        \"""Récupère les transactions en attente\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM transactions 
                WHERE status = 'pending'
            \""")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def archive_old_transaction_logs(self, days_old=365):
        \"""Archive les anciens logs de transactions\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                UPDATE transaction_logs 
                SET archived = 1 
                WHERE created_at < DATE_SUB(NOW(), INTERVAL %s DAY)
            \""", (days_old,))
            conn.commit()
            return cursor.rowcount
        except Exception as e:
            conn.rollback()
            logger.error(f"Error archiving old transaction logs: {e}")
            return 0
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes panels et messages
    # ==========================================
    
    def get_plan_panel_message(self, panel_type):
        \"""Récupère les infos d'un panel de plans\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT message_id, channel_id FROM plan_panels 
                WHERE panel_type = %s
            \""", (panel_type,))
            result = cursor.fetchone()
            return result if result else (None, None)
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_tos_message_id(self):
        \"""Récupère l'ID du message TOS\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute("SELECT message_id, channel_id FROM tos_message LIMIT 1")
            result = cursor.fetchone()
            return result if result else (None, None)
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes giveaways
    # ==========================================
    
    def get_all_running_giveaways(self):
        \"""Récupère tous les giveaways en cours\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM giveaways 
                WHERE status = 'running' AND end_time > NOW()
            \""")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes dedicated VPS
    # ==========================================
    
    def get_expiring_dedicated_vps_attributions(self, days_ahead=2):
        \"""Récupère les attributions de VPS dédiés qui expirent\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM dedicated_vps_attributions 
                WHERE expiry_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL %s DAY)
            \""", (days_ahead,))
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes surveillance et logs
    # ==========================================
    
    def get_unanalyzed_command_logs(self):
        \"""Récupère les logs de commandes non analysés\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM command_logs 
                WHERE analyzed = 0 
                ORDER BY created_at ASC 
                LIMIT 100
            \""")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    def get_virustotal_daily_requests(self, api_key):
        \"""Récupère le nombre de requêtes VirusTotal du jour\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT COUNT(*) as count FROM virustotal_requests 
                WHERE api_key = %s AND DATE(created_at) = CURDATE()
            \""", (api_key,))
            result = cursor.fetchone()
            return result['count'] if result else 0
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes earn/ads
    # ==========================================
    
    def get_users_for_ad_reminder(self):
        \"""Récupère les utilisateurs à rappeler pour les pubs\"""
        conn, cursor = self.core.get_connection()
        try:
            cursor.execute(\"""
                SELECT * FROM users 
                WHERE last_ad_watch < DATE_SUB(NOW(), INTERVAL 23 HOUR)
                AND ad_reminders_enabled = 1
            \""")
            return cursor.fetchall()
        finally:
            self.core.close_connection(conn, cursor)
            
    # ==========================================
    # Méthodes génériques pour compatibilité
    # ==========================================
    
    def __getattr__(self, name):
        \"""
        Fallback pour les méthodes non implémentées
        Log un warning et retourne une valeur par défaut
        \"""
        logger.warning(f"Method '{name}' not implemented in Database wrapper, returning default value")
        
        # Retourner une fonction qui retourne une valeur par défaut
        def default_method(*args, **kwargs):
            logger.debug(f"Called unimplemented method '{name}' with args={args}, kwargs={kwargs}")
            # Retourner une valeur par défaut selon le nom de la méthode
            if name.startswith('get_all_'):
                return []
            elif name.startswith('get_'):
                return None
            elif name.startswith('is_'):
                return False
            elif name.startswith('has_'):
                return False
            else:
                return None
                
        return default_method


# Instance globale pour compatibilité
db = Database()
