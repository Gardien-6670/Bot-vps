"""
Wrapper de compatibilité pour database.py
=========================================

Ce module fournit une interface compatible avec l'ancien code
tout en utilisant les nouveaux modules shared.
"""

import os
from dotenv import load_dotenv
# Import depuis le dossier local bot/shared/database
from .database import DatabaseCore, VPSManager, UserManager, CreditsManager

load_dotenv()


class Database:
    """
    Wrapper de compatibilité pour l'ancienne interface database.py
    
    Cette classe délègue toutes les opérations aux nouveaux modules shared
    tout en maintenant la compatibilité avec l'ancien code.
    """
    
    def __init__(self):
        """Initialise la base de données avec les nouveaux modules"""
        # Configuration depuis les variables d'environnement
        config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': int(os.getenv('DB_PORT', 3306)),
            'user': os.getenv('DB_USER', 'root'),
            'password': os.getenv('DB_PASSWORD', ''),
            'database': os.getenv('DB_NAME', 'vps')
        }
        
        # Initialiser les modules
        self.core = DatabaseCore(**config)
        self.users = UserManager(self.core)
        self.credits = CreditsManager(self.core, self.users)
        self.vps = VPSManager(self.core)
        
    # ==========================================
    # Méthodes de transaction (délégation core)
    # ==========================================
    
    def start_transaction(self):
        """Démarre une transaction"""
        return self.core.start_transaction()
        
    def commit_transaction(self, conn, cursor):
        """Commit une transaction"""
        return self.core.commit_transaction(conn, cursor)
        
    def rollback_transaction(self, conn, cursor):
        """Rollback une transaction"""
        return self.core.rollback_transaction(conn, cursor)
        
    # ==========================================
    # Méthodes VPS (délégation vps)
    # ==========================================
    
    def add_vps(self, *args, **kwargs):
        """Ajoute un VPS"""
        return self.vps.add_vps(*args, **kwargs)
        
    def get_vps(self, *args, **kwargs):
        """Récupère un VPS"""
        return self.vps.get_vps(*args, **kwargs)
        
    def get_user_vps(self, *args, **kwargs):
        """Récupère les VPS d'un utilisateur"""
        return self.vps.get_user_vps(*args, **kwargs)
        
    def get_all_vps(self, *args, **kwargs):
        """Récupère tous les VPS"""
        return self.vps.get_all_vps(*args, **kwargs)
        
    def update_vps(self, *args, **kwargs):
        """Met à jour un VPS"""
        return self.vps.update_vps(*args, **kwargs)
        
    def delete_vps(self, *args, **kwargs):
        """Supprime un VPS"""
        return self.vps.delete_vps(*args, **kwargs)
        
    def suspend_vps(self, *args, **kwargs):
        """Suspend un VPS"""
        return self.vps.suspend_vps(*args, **kwargs)
        
    def unsuspend_vps(self, *args, **kwargs):
        """Réactive un VPS"""
        return self.vps.unsuspend_vps(*args, **kwargs)
        
    def is_vps_suspended(self, *args, **kwargs):
        """Vérifie si un VPS est suspendu"""
        return self.vps.is_vps_suspended(*args, **kwargs)
        
    def set_vps_due_date(self, *args, **kwargs):
        """Définit la date d'échéance d'un VPS"""
        return self.vps.set_vps_due_date(*args, **kwargs)
        
    # ==========================================
    # Méthodes utilisateurs (délégation users)
    # ==========================================
    
    def get_user(self, *args, **kwargs):
        """Récupère un utilisateur"""
        return self.users.get_user(*args, **kwargs)
        
    def ensure_user_exists(self, *args, **kwargs):
        """S'assure qu'un utilisateur existe"""
        return self.users.ensure_user_exists(*args, **kwargs)
        
    def get_balance(self, *args, **kwargs):
        """Récupère le solde d'un utilisateur"""
        return self.users.get_balance(*args, **kwargs)
        
    def set_balance(self, *args, **kwargs):
        """Définit le solde d'un utilisateur"""
        return self.users.set_balance(*args, **kwargs)
        
    def get_pending_balance(self, *args, **kwargs):
        """Récupère le solde en attente"""
        return self.users.get_pending_balance(*args, **kwargs)
        
    def add_pending_credits(self, *args, **kwargs):
        """Ajoute des crédits en attente"""
        return self.users.add_pending_credits(*args, **kwargs)
        
    def remove_all_pending_credits(self, *args, **kwargs):
        """Supprime tous les crédits en attente"""
        return self.users.remove_all_pending_credits(*args, **kwargs)
        
    # ==========================================
    # Méthodes crédits (délégation credits)
    # ==========================================
    
    def add_credits(self, *args, **kwargs):
        """Ajoute des crédits"""
        return self.credits.add_credits(*args, **kwargs)
        
    def get_vps_points(self, *args, **kwargs):
        """Récupère les points VPS"""
        return self.credits.get_vps_points(*args, **kwargs)
        
    def add_vps_points(self, *args, **kwargs):
        """Ajoute des points VPS"""
        return self.credits.add_vps_points(*args, **kwargs)
        
    def consume_vps_points(self, *args, **kwargs):
        """Consomme des points VPS"""
        return self.credits.consume_vps_points(*args, **kwargs)
        
    def get_invites(self, *args, **kwargs):
        """Récupère les invitations"""
        return self.credits.get_invites(*args, **kwargs)
        
    def add_invites(self, *args, **kwargs):
        """Ajoute des invitations"""
        return self.credits.add_invites(*args, **kwargs)
        
    def consume_invites(self, *args, **kwargs):
        """Consomme des invitations"""
        return self.credits.consume_invites(*args, **kwargs)


# Instance globale pour compatibilité
db = Database()
