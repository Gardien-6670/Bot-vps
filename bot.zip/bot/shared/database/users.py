"""
Module Users : Gestion des utilisateurs
=======================================

Ce module gère toutes les opérations liées aux utilisateurs.
"""

import logging
from typing import Optional, Dict

logger = logging.getLogger(__name__)


class UserManager:
    """Gestionnaire des opérations utilisateurs"""
    
    def __init__(self, db_core):
        """
        Initialise le gestionnaire utilisateurs
        
        Args:
            db_core: Instance de DatabaseCore
        """
        self.db = db_core
        
    def get_user(self, user_id: int) -> Optional[Dict]:
        """
        Récupère un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Dictionnaire avec les infos de l'utilisateur ou None
        """
        try:
            query = "SELECT * FROM users WHERE user_id = %s"
            return self.db.fetch_one(query, (user_id,))
        except Exception as e:
            logger.error(f"Failed to get user {user_id}: {e}")
            return None
            
    def ensure_user_exists(self, user_id: int, cursor=None, conn=None) -> bool:
        """
        S'assure qu'un utilisateur existe dans la DB
        
        Args:
            user_id: ID de l'utilisateur
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            query = """
                INSERT INTO users (user_id, balance, pending_balance)
                VALUES (%s, 0, 0)
                ON DUPLICATE KEY UPDATE user_id = user_id
            """
            cursor.execute(query, (user_id,))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to ensure user {user_id} exists: {e}")
            return False
            
    def get_balance(self, user_id: int) -> int:
        """
        Récupère le solde d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Solde de l'utilisateur
        """
        try:
            self.ensure_user_exists(user_id)
            query = "SELECT balance FROM users WHERE user_id = %s"
            result = self.db.fetch_one(query, (user_id,))
            return result['balance'] if result else 0
        except Exception as e:
            logger.error(f"Failed to get balance for user {user_id}: {e}")
            return 0
            
    def set_balance(self, user_id: int, amount: int, cursor=None, conn=None) -> bool:
        """
        Définit le solde d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            amount: Nouveau solde
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            self.ensure_user_exists(user_id, cursor=cursor, conn=conn)
            
            query = "UPDATE users SET balance = %s WHERE user_id = %s"
            cursor.execute(query, (amount, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Balance set to {amount} for user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to set balance for user {user_id}: {e}")
            return False
            
    def get_pending_balance(self, user_id: int) -> int:
        """
        Récupère le solde en attente d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Solde en attente
        """
        try:
            self.ensure_user_exists(user_id)
            query = "SELECT pending_balance FROM users WHERE user_id = %s"
            result = self.db.fetch_one(query, (user_id,))
            return result['pending_balance'] if result else 0
        except Exception as e:
            logger.error(f"Failed to get pending balance for user {user_id}: {e}")
            return 0
            
    def add_pending_credits(self, user_id: int, amount: int, cursor=None, conn=None) -> bool:
        """
        Ajoute des crédits en attente
        
        Args:
            user_id: ID de l'utilisateur
            amount: Montant à ajouter
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            self.ensure_user_exists(user_id, cursor=cursor, conn=conn)
            
            query = "UPDATE users SET pending_balance = pending_balance + %s WHERE user_id = %s"
            cursor.execute(query, (amount, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Added {amount} pending credits to user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to add pending credits for user {user_id}: {e}")
            return False
            
    def remove_all_pending_credits(self, user_id: int, cursor=None, conn=None) -> bool:
        """
        Supprime tous les crédits en attente
        
        Args:
            user_id: ID de l'utilisateur
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            query = "UPDATE users SET pending_balance = 0 WHERE user_id = %s"
            cursor.execute(query, (user_id,))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Removed all pending credits for user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to remove pending credits for user {user_id}: {e}")
            return False
