"""
Module Credits : Gestion des crédits et points VPS
==================================================

Ce module gère toutes les opérations liées aux crédits et points VPS.
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class CreditsManager:
    """Gestionnaire des crédits et points VPS"""
    
    def __init__(self, db_core, user_manager):
        """
        Initialise le gestionnaire de crédits
        
        Args:
            db_core: Instance de DatabaseCore
            user_manager: Instance de UserManager
        """
        self.db = db_core
        self.users = user_manager
        
    def add_credits(self, user_id: int, amount: int, cursor=None, conn=None) -> bool:
        """
        Ajoute des crédits à un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            amount: Montant à ajouter (peut être négatif)
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            self.users.ensure_user_exists(user_id, cursor=cursor, conn=conn)
            
            query = "UPDATE users SET balance = balance + %s WHERE user_id = %s"
            cursor.execute(query, (amount, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            action = "added" if amount > 0 else "removed"
            logger.info(f"{action} {abs(amount)} credits for user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to add credits for user {user_id}: {e}")
            return False
            
    def get_vps_points(self, user_id: int) -> int:
        """
        Récupère les points VPS d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Nombre de points VPS
        """
        try:
            query = "SELECT vps_points FROM users WHERE user_id = %s"
            result = self.db.fetch_one(query, (user_id,))
            return result['vps_points'] if result and 'vps_points' in result else 0
        except Exception as e:
            logger.error(f"Failed to get VPS points for user {user_id}: {e}")
            return 0
            
    def add_vps_points(self, user_id: int, points: int, cursor=None, conn=None) -> bool:
        """
        Ajoute des points VPS à un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            points: Nombre de points à ajouter
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            self.users.ensure_user_exists(user_id, cursor=cursor, conn=conn)
            
            # Vérifier si la colonne vps_points existe
            query = "UPDATE users SET vps_points = COALESCE(vps_points, 0) + %s WHERE user_id = %s"
            cursor.execute(query, (points, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Added {points} VPS points to user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to add VPS points for user {user_id}: {e}")
            return False
            
    def consume_vps_points(self, user_id: int, points: int, cursor=None, conn=None) -> bool:
        """
        Consomme des points VPS
        
        Args:
            user_id: ID de l'utilisateur
            points: Nombre de points à consommer
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            # Vérifier que l'utilisateur a assez de points
            current_points = self.get_vps_points(user_id)
            if current_points < points:
                logger.warning(f"User {user_id} doesn't have enough VPS points ({current_points} < {points})")
                if own_connection:
                    self.db.rollback_transaction(conn, cursor)
                return False
                
            query = "UPDATE users SET vps_points = vps_points - %s WHERE user_id = %s"
            cursor.execute(query, (points, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Consumed {points} VPS points from user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to consume VPS points for user {user_id}: {e}")
            return False
            
    def get_invites(self, user_id: int) -> int:
        """
        Récupère le nombre d'invitations d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Nombre d'invitations
        """
        try:
            query = "SELECT invites FROM users WHERE user_id = %s"
            result = self.db.fetch_one(query, (user_id,))
            return result['invites'] if result and 'invites' in result else 0
        except Exception as e:
            logger.error(f"Failed to get invites for user {user_id}: {e}")
            return 0
            
    def add_invites(self, user_id: int, count: int, cursor=None, conn=None) -> bool:
        """
        Ajoute des invitations à un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            count: Nombre d'invitations à ajouter
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            self.users.ensure_user_exists(user_id, cursor=cursor, conn=conn)
            
            query = "UPDATE users SET invites = COALESCE(invites, 0) + %s WHERE user_id = %s"
            cursor.execute(query, (count, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Added {count} invites to user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to add invites for user {user_id}: {e}")
            return False
            
    def consume_invites(self, user_id: int, count: int, cursor=None, conn=None) -> bool:
        """
        Consomme des invitations
        
        Args:
            user_id: ID de l'utilisateur
            count: Nombre d'invitations à consommer
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            # Vérifier que l'utilisateur a assez d'invitations
            current_invites = self.get_invites(user_id)
            if current_invites < count:
                logger.warning(f"User {user_id} doesn't have enough invites ({current_invites} < {count})")
                if own_connection:
                    self.db.rollback_transaction(conn, cursor)
                return False
                
            query = "UPDATE users SET invites = invites - %s WHERE user_id = %s"
            cursor.execute(query, (count, user_id))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"Consumed {count} invites from user {user_id}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to consume invites for user {user_id}: {e}")
            return False
