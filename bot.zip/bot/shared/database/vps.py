"""
Module VPS : Gestion des opérations VPS
=======================================

Ce module gère toutes les opérations liées aux VPS.
"""

import logging
from typing import Optional, List, Dict, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)


class VPSManager:
    """Gestionnaire des opérations VPS"""
    
    def __init__(self, db_core):
        """
        Initialise le gestionnaire VPS
        
        Args:
            db_core: Instance de DatabaseCore
        """
        self.db = db_core
        
    def add_vps(self, user_id: int, container_name: str, node: str, vps_type: str,
                **kwargs) -> int:
        """
        Ajoute un nouveau VPS
        
        Args:
            user_id: ID de l'utilisateur
            container_name: Nom du conteneur
            node: Node où est le VPS
            vps_type: Type de VPS (lxc, kvm)
            **kwargs: Autres paramètres (cpu, ram, disk, etc.)
            
        Returns:
            ID du VPS créé
        """
        cursor = kwargs.get('cursor')
        conn = kwargs.get('conn')
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            # Construire la requête d'insertion
            columns = ['user_id', 'container_name', 'node', 'vps_type']
            values = [user_id, container_name, node, vps_type]
            
            # Ajouter les paramètres optionnels
            optional_fields = [
                'username', 'vmid', 'plan_id', 'hostname', 'cpu', 'ram', 'disk',
                'cpu_limit', 'memory_limit', 'disk_limit', 'cost_credits', 'due_date',
                'ssh_link', 'ssh_port', 'ssh_password', 'ip_address', 'payment_type',
                'cost_per_day', 'vm_username', 'vm_password', 'is_active', 'is_suspended',
                'status', 'is_dedicated', 'attributed_to_user_id', 'attribution_end_date',
                'surveillance_user', 'surveillance_password', 'plan_tier', 'invite_plan_tier'
            ]
            
            for field in optional_fields:
                if field in kwargs and kwargs[field] is not None:
                    columns.append(field)
                    values.append(kwargs[field])
                    
            placeholders = ', '.join(['%s'] * len(values))
            columns_str = ', '.join(columns)
            
            query = f"INSERT INTO vps ({columns_str}) VALUES ({placeholders})"
            cursor.execute(query, tuple(values))
            
            vps_id = cursor.lastrowid
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"VPS {container_name} created with ID {vps_id}")
            return vps_id
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to add VPS {container_name}: {e}")
            raise
            
    def get_vps(self, vps_id: int = None, container_name: str = None) -> Optional[Dict]:
        """
        Récupère un VPS par ID ou nom
        
        Args:
            vps_id: ID du VPS
            container_name: Nom du conteneur
            
        Returns:
            Dictionnaire avec les infos du VPS ou None
        """
        try:
            if vps_id:
                query = "SELECT * FROM vps WHERE id = %s"
                params = (vps_id,)
            elif container_name:
                query = "SELECT * FROM vps WHERE container_name = %s"
                params = (container_name,)
            else:
                raise ValueError("vps_id or container_name required")
                
            return self.db.fetch_one(query, params)
            
        except Exception as e:
            logger.error(f"Failed to get VPS: {e}")
            return None
            
    def get_user_vps(self, user_id: int) -> List[Dict]:
        """
        Récupère tous les VPS d'un utilisateur
        
        Args:
            user_id: ID de l'utilisateur
            
        Returns:
            Liste des VPS
        """
        try:
            query = "SELECT * FROM vps WHERE user_id = %s ORDER BY created_at DESC"
            return self.db.fetch_all(query, (user_id,))
        except Exception as e:
            logger.error(f"Failed to get user VPS: {e}")
            return []
            
    def get_all_vps(self) -> List[Dict]:
        """
        Récupère tous les VPS
        
        Returns:
            Liste de tous les VPS
        """
        try:
            query = "SELECT * FROM vps ORDER BY created_at DESC"
            return self.db.fetch_all(query)
        except Exception as e:
            logger.error(f"Failed to get all VPS: {e}")
            return []
            
    def update_vps(self, vps_id: int, **kwargs) -> bool:
        """
        Met à jour un VPS
        
        Args:
            vps_id: ID du VPS
            **kwargs: Champs à mettre à jour
            
        Returns:
            True si succès
        """
        cursor = kwargs.pop('cursor', None)
        conn = kwargs.pop('conn', None)
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            if not kwargs:
                return True
                
            set_clause = ', '.join([f"{k} = %s" for k in kwargs.keys()])
            values = list(kwargs.values()) + [vps_id]
            
            query = f"UPDATE vps SET {set_clause} WHERE id = %s"
            cursor.execute(query, tuple(values))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"VPS {vps_id} updated")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to update VPS {vps_id}: {e}")
            return False
            
    def delete_vps(self, vps_id: int, cursor=None, conn=None) -> bool:
        """
        Supprime un VPS
        
        Args:
            vps_id: ID du VPS
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            query = "DELETE FROM vps WHERE id = %s"
            cursor.execute(query, (vps_id,))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"VPS {vps_id} deleted")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to delete VPS {vps_id}: {e}")
            return False
            
    def suspend_vps(self, container_name: str, reason: str = None, cursor=None, conn=None) -> bool:
        """
        Suspend un VPS
        
        Args:
            container_name: Nom du conteneur
            reason: Raison de la suspension
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            query = """
                UPDATE vps 
                SET is_suspended = 1, 
                    suspension_reason = %s,
                    suspended_at = NOW()
                WHERE container_name = %s
            """
            cursor.execute(query, (reason, container_name))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"VPS {container_name} suspended: {reason}")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to suspend VPS {container_name}: {e}")
            return False
            
    def unsuspend_vps(self, container_name: str, cursor=None, conn=None) -> bool:
        """
        Réactive un VPS suspendu
        
        Args:
            container_name: Nom du conteneur
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.db.start_transaction()
                own_connection = True
                
            query = """
                UPDATE vps 
                SET is_suspended = 0,
                    suspension_reason = NULL,
                    suspended_at = NULL
                WHERE container_name = %s
            """
            cursor.execute(query, (container_name,))
            
            if own_connection:
                self.db.commit_transaction(conn, cursor)
                
            logger.info(f"VPS {container_name} unsuspended")
            return True
            
        except Exception as e:
            if own_connection and conn:
                self.db.rollback_transaction(conn, cursor)
            logger.error(f"Failed to unsuspend VPS {container_name}: {e}")
            return False
            
    def is_vps_suspended(self, container_name: str) -> bool:
        """
        Vérifie si un VPS est suspendu
        
        Args:
            container_name: Nom du conteneur
            
        Returns:
            True si suspendu
        """
        try:
            query = "SELECT is_suspended FROM vps WHERE container_name = %s"
            result = self.db.fetch_one(query, (container_name,))
            return result['is_suspended'] == 1 if result else False
        except Exception as e:
            logger.error(f"Failed to check VPS suspension: {e}")
            return False
            
    def set_vps_due_date(self, vps_id: int, due_date: datetime, cursor=None, conn=None) -> bool:
        """
        Définit la date d'échéance d'un VPS
        
        Args:
            vps_id: ID du VPS
            due_date: Nouvelle date d'échéance
            cursor: Curseur de transaction (optionnel)
            conn: Connexion de transaction (optionnelle)
            
        Returns:
            True si succès
        """
        return self.update_vps(vps_id, due_date=due_date, cursor=cursor, conn=conn)
