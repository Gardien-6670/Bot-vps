"""
Module partagé pour la gestion de base de données
=================================================

Ce module fournit une interface unifiée pour les opérations de base de données
utilisée par le bot Discord et l'API Flask.
"""

from .core import DatabaseCore
from .vps import VPSManager
from .users import UserManager
from .credits import CreditsManager

__all__ = [
    'DatabaseCore',
    'VPSManager',
    'UserManager',
    'CreditsManager',
]

__version__ = '2.0.0'
