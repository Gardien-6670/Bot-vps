"""
Module Core : Gestion des connexions et transactions
====================================================

Ce module gère les connexions à la base de données et les transactions.
"""

import mysql.connector
from mysql.connector import Error
import logging
from typing import Tuple, Optional
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class DatabaseCore:
    """Gestion de base : connexion, transactions"""
    
    def __init__(self, host: str, port: int, user: str, password: str, database: str):
        """
        Initialise la connexion à la base de données
        
        Args:
            host: Hôte MySQL
            port: Port MySQL
            user: Utilisateur MySQL
            password: Mot de passe MySQL
            database: Nom de la base de données
        """
        self.config = {
            'host': host,
            'port': port,
            'user': user,
            'password': password,
            'database': database,
            'autocommit': False,
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci'
        }
        self._test_connection()
        
    def _test_connection(self):
        """Teste la connexion à la base de données"""
        try:
            conn = mysql.connector.connect(**self.config)
            conn.close()
            logger.info(f"Database connection successful: {self.config['database']}")
        except Error as e:
            logger.error(f"Database connection failed: {e}")
            raise
            
    def get_connection(self):
        """
        Obtient une nouvelle connexion à la base de données
        
        Returns:
            Connexion MySQL
        """
        try:
            return mysql.connector.connect(**self.config)
        except Error as e:
            logger.error(f"Failed to get database connection: {e}")
            raise
            
    def start_transaction(self) -> Tuple:
        """
        Démarre une nouvelle transaction
        
        Returns:
            Tuple (connexion, curseur)
        """
        try:
            conn = self.get_connection()
            cursor = conn.cursor(dictionary=True)
            conn.start_transaction()
            logger.debug("Transaction started")
            return conn, cursor
        except Error as e:
            logger.error(f"Failed to start transaction: {e}")
            raise
            
    def commit_transaction(self, conn, cursor):
        """
        Commit une transaction
        
        Args:
            conn: Connexion MySQL
            cursor: Curseur MySQL
        """
        try:
            if conn and conn.is_connected():
                conn.commit()
                logger.debug("Transaction committed")
        except Error as e:
            logger.error(f"Failed to commit transaction: {e}")
            raise
        finally:
            self._close_connection(conn, cursor)
            
    def rollback_transaction(self, conn, cursor):
        """
        Rollback une transaction
        
        Args:
            conn: Connexion MySQL
            cursor: Curseur MySQL
        """
        try:
            if conn and conn.is_connected():
                conn.rollback()
                logger.warning("Transaction rolled back")
        except Error as e:
            logger.error(f"Failed to rollback transaction: {e}")
        finally:
            self._close_connection(conn, cursor)
            
    def _close_connection(self, conn, cursor):
        """
        Ferme la connexion et le curseur
        
        Args:
            conn: Connexion MySQL
            cursor: Curseur MySQL
        """
        try:
            if cursor:
                cursor.close()
            if conn and conn.is_connected():
                conn.close()
        except Error as e:
            logger.error(f"Error closing connection: {e}")
            
    @contextmanager
    def transaction(self):
        """
        Context manager pour les transactions
        
        Usage:
            with db.transaction() as (conn, cursor):
                # Opérations DB
                pass
        """
        conn, cursor = self.start_transaction()
        try:
            yield conn, cursor
            self.commit_transaction(conn, cursor)
        except Exception as e:
            self.rollback_transaction(conn, cursor)
            raise
            
    def execute_query(self, query: str, params: tuple = None, cursor=None, conn=None) -> Optional[list]:
        """
        Exécute une requête SQL
        
        Args:
            query: Requête SQL
            params: Paramètres de la requête
            cursor: Curseur existant (optionnel)
            conn: Connexion existante (optionnelle)
            
        Returns:
            Résultats de la requête ou None
        """
        own_connection = False
        
        try:
            if cursor is None or conn is None:
                conn, cursor = self.start_transaction()
                own_connection = True
                
            cursor.execute(query, params or ())
            
            # Si c'est un SELECT, retourner les résultats
            if query.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
            else:
                results = None
                
            if own_connection:
                self.commit_transaction(conn, cursor)
                
            return results
            
        except Error as e:
            if own_connection and conn:
                self.rollback_transaction(conn, cursor)
            logger.error(f"Query execution failed: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Params: {params}")
            raise
            
    def fetch_one(self, query: str, params: tuple = None) -> Optional[dict]:
        """
        Exécute une requête et retourne un seul résultat
        
        Args:
            query: Requête SQL
            params: Paramètres de la requête
            
        Returns:
            Dictionnaire avec le résultat ou None
        """
        results = self.execute_query(query, params)
        return results[0] if results else None
        
    def fetch_all(self, query: str, params: tuple = None) -> list:
        """
        Exécute une requête et retourne tous les résultats
        
        Args:
            query: Requête SQL
            params: Paramètres de la requête
            
        Returns:
            Liste de dictionnaires avec les résultats
        """
        results = self.execute_query(query, params)
        return results if results else []
