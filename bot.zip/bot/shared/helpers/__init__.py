"""
Helpers partagés
================

Ce module contient des fonctions helper réutilisables.
"""

from .refund_helper import (
    detect_vps_type,
    calculate_refund,
    process_refund,
    get_refund_summary,
    format_refund_message
)

from .validation_helper import (
    validate_port,
    validate_container_name,
    validate_hostname,
    validate_ip_address,
    validate_resource_limits,
    validate_vps_ownership,
    validate_vps_not_suspended,
    validate_credits_sufficient,
    validate_vps_points_sufficient
)

__all__ = [
    # Refund helpers
    'detect_vps_type',
    'calculate_refund',
    'process_refund',
    'get_refund_summary',
    'format_refund_message',
    
    # Validation helpers
    'validate_port',
    'validate_container_name',
    'validate_hostname',
    'validate_ip_address',
    'validate_resource_limits',
    'validate_vps_ownership',
    'validate_vps_not_suspended',
    'validate_credits_sufficient',
    'validate_vps_points_sufficient',
]

__version__ = '1.0.0'
