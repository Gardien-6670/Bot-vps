"""
Helper pour les validations
===========================

Ce module centralise toutes les validations communes.
"""

import logging
import re
from typing import Tuple, Optional

logger = logging.getLogger(__name__)


def validate_port(port: int) -> Tuple[bool, Optional[str]]:
    """
    Valide un numéro de port
    
    Args:
        port: Numéro de port à valider
        
    Returns:
        Tuple (is_valid, error_message)
    """
    if not isinstance(port, int):
        return False, "Port must be an integer"
        
    if port < 1 or port > 65535:
        return False, "Port must be between 1 and 65535"
        
    # Ports réservés
    reserved_ports = [22, 80, 443, 3306, 5432, 6379, 27017]
    if port in reserved_ports:
        return False, f"Port {port} is reserved"
        
    return True, None


def validate_container_name(name: str) -> Tuple[bool, Optional[str]]:
    """
    Valide un nom de conteneur
    
    Args:
        name: Nom du conteneur
        
    Returns:
        Tuple (is_valid, error_message)
    """
    if not name:
        return False, "Container name cannot be empty"
        
    if len(name) < 3:
        return False, "Container name must be at least 3 characters"
        
    if len(name) > 64:
        return False, "Container name must be at most 64 characters"
        
    # Doit commencer par une lettre
    if not name[0].isalpha():
        return False, "Container name must start with a letter"
        
    # Seulement lettres, chiffres, tirets et underscores
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', name):
        return False, "Container name can only contain letters, numbers, hyphens and underscores"
        
    return True, None


def validate_hostname(hostname: str) -> Tuple[bool, Optional[str]]:
    """
    Valide un hostname
    
    Args:
        hostname: Hostname à valider
        
    Returns:
        Tuple (is_valid, error_message)
    """
    if not hostname:
        return False, "Hostname cannot be empty"
        
    if len(hostname) > 253:
        return False, "Hostname must be at most 253 characters"
        
    # Valider chaque label du hostname
    labels = hostname.split('.')
    for label in labels:
        if not label:
            return False, "Hostname labels cannot be empty"
            
        if len(label) > 63:
            return False, "Hostname labels must be at most 63 characters"
            
        if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$', label):
            return False, "Invalid hostname format"
            
    return True, None


def validate_ip_address(ip: str) -> Tuple[bool, Optional[str]]:
    """
    Valide une adresse IP (IPv4 ou IPv6)
    
    Args:
        ip: Adresse IP à valider
        
    Returns:
        Tuple (is_valid, error_message)
    """
    if not ip:
        return False, "IP address cannot be empty"
        
    # IPv4
    ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if re.match(ipv4_pattern, ip):
        parts = ip.split('.')
        for part in parts:
            if int(part) > 255:
                return False, "Invalid IPv4 address"
        return True, None
        
    # IPv6 (simplifié)
    ipv6_pattern = r'^([0-9a-fA-F]{0,4}:){7}[0-9a-fA-F]{0,4}$'
    if re.match(ipv6_pattern, ip):
        return True, None
        
    return False, "Invalid IP address format"


def validate_resource_limits(cpu: int = None, ram: float = None, disk: float = None) -> Tuple[bool, Optional[str]]:
    """
    Valide les limites de ressources
    
    Args:
        cpu: Nombre de CPUs
        ram: RAM en GB
        disk: Disque en GB
        
    Returns:
        Tuple (is_valid, error_message)
    """
    if cpu is not None:
        if not isinstance(cpu, int) or cpu < 1:
            return False, "CPU must be at least 1"
        if cpu > 32:
            return False, "CPU cannot exceed 32"
            
    if ram is not None:
        if not isinstance(ram, (int, float)) or ram < 0.5:
            return False, "RAM must be at least 0.5 GB"
        if ram > 128:
            return False, "RAM cannot exceed 128 GB"
            
    if disk is not None:
        if not isinstance(disk, (int, float)) or disk < 5:
            return False, "Disk must be at least 5 GB"
        if disk > 1000:
            return False, "Disk cannot exceed 1000 GB"
            
    return True, None


def validate_vps_ownership(vps_info: dict, user_id: int) -> Tuple[bool, Optional[str]]:
    """
    Valide que l'utilisateur est propriétaire du VPS
    
    Args:
        vps_info: Informations du VPS
        user_id: ID de l'utilisateur
        
    Returns:
        Tuple (is_owner, error_message)
    """
    if not vps_info:
        return False, "VPS not found"
        
    vps_owner_id = vps_info.get('user_id')
    if vps_owner_id != user_id:
        return False, "You don't own this VPS"
        
    return True, None


def validate_vps_not_suspended(vps_info: dict) -> Tuple[bool, Optional[str]]:
    """
    Valide que le VPS n'est pas suspendu
    
    Args:
        vps_info: Informations du VPS
        
    Returns:
        Tuple (is_not_suspended, error_message)
    """
    if not vps_info:
        return False, "VPS not found"
        
    if vps_info.get('is_suspended'):
        reason = vps_info.get('suspension_reason', 'unknown reason')
        return False, f"VPS is suspended: {reason}"
        
    return True, None


def validate_credits_sufficient(user_balance: int, required_credits: int) -> Tuple[bool, Optional[str]]:
    """
    Valide que l'utilisateur a assez de crédits
    
    Args:
        user_balance: Solde de l'utilisateur
        required_credits: Crédits requis
        
    Returns:
        Tuple (is_sufficient, error_message)
    """
    if user_balance < required_credits:
        missing = required_credits - user_balance
        return False, f"Insufficient credits. You need {missing} more credits."
        
    return True, None


def validate_vps_points_sufficient(user_points: int, required_points: int) -> Tuple[bool, Optional[str]]:
    """
    Valide que l'utilisateur a assez de points VPS
    
    Args:
        user_points: Points VPS de l'utilisateur
        required_points: Points requis
        
    Returns:
        Tuple (is_sufficient, error_message)
    """
    if user_points < required_points:
        missing = required_points - user_points
        return False, f"Insufficient VPS points. You need {missing} more points."
        
    return True, None
