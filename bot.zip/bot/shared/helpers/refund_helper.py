"""
Helper pour les remboursements VPS
==================================

Ce module centralise toute la logique de remboursement.
"""

import logging
from typing import Dict, Tuple

logger = logging.getLogger(__name__)


def detect_vps_type(vps_info: Dict) -> Tuple[bool, str]:
    """
    Détecte le type de VPS (ads ou payant)
    
    Args:
        vps_info: Informations du VPS
        
    Returns:
        Tuple (is_ad_vps, vps_type_name)
    """
    plan_tier = vps_info.get('plan_tier')
    invite_plan_tier = vps_info.get('invite_plan_tier')
    
    is_ad_vps = (plan_tier and plan_tier != '') or (invite_plan_tier and invite_plan_tier != '')
    
    if is_ad_vps:
        if plan_tier:
            return True, f"ad-supported ({plan_tier})"
        else:
            return True, f"invite ({invite_plan_tier})"
    else:
        return False, "paid"


def calculate_refund(vps_info: Dict) -> Tuple[str, int, str]:
    """
    Calcule le remboursement pour un VPS
    
    Args:
        vps_info: Informations du VPS
        
    Returns:
        Tuple (refund_type, refund_amount, message)
        - refund_type: 'points' ou 'credits'
        - refund_amount: Montant à rembourser
        - message: Message pour l'utilisateur
    """
    is_ad_vps, vps_type_name = detect_vps_type(vps_info)
    
    if is_ad_vps:
        return 'points', 1, "Your VPS point has been refunded."
    else:
        cost_credits = vps_info.get('cost_credits', 0)
        if cost_credits > 0:
            return 'credits', cost_credits, f"Your {cost_credits} credits have been refunded."
        else:
            return 'credits', 0, "No refund needed (free VPS)."


def process_refund(db, user_id: int, vps_info: Dict, reason: str, cursor=None, conn=None) -> Tuple[bool, str]:
    """
    Traite un remboursement complet
    
    Args:
        db: Instance de la base de données
        user_id: ID de l'utilisateur
        vps_info: Informations du VPS
        reason: Raison du remboursement
        cursor: Curseur de transaction (optionnel)
        conn: Connexion de transaction (optionnelle)
        
    Returns:
        Tuple (success, message)
    """
    try:
        refund_type, refund_amount, refund_msg = calculate_refund(vps_info)
        
        if refund_amount == 0:
            logger.info(f"No refund needed for user {user_id} (free VPS)")
            return True, refund_msg
            
        if refund_type == 'points':
            success = db.add_vps_points(user_id, refund_amount, cursor=cursor, conn=conn)
        else:
            success = db.add_credits(user_id, refund_amount, cursor=cursor, conn=conn)
            
        if success:
            logger.info(f"Refunded {refund_amount} {refund_type} to user {user_id} (reason: {reason})")
            
            # Log dans le monitoring si disponible
            try:
                from bot.utils.refund_monitor import log_refund
                log_refund(db, user_id, refund_type, refund_amount, reason, vps_info)
            except ImportError:
                pass  # Module de monitoring non disponible
                
            return True, refund_msg
        else:
            logger.error(f"Failed to refund {refund_amount} {refund_type} to user {user_id}")
            return False, "Failed to process refund. Please contact support."
            
    except Exception as e:
        logger.error(f"Error processing refund for user {user_id}: {e}")
        return False, f"Error processing refund: {str(e)}"


def get_refund_summary(vps_list: list) -> Dict:
    """
    Génère un résumé des remboursements pour une liste de VPS
    
    Args:
        vps_list: Liste des VPS
        
    Returns:
        Dictionnaire avec le résumé des remboursements
    """
    summary = {
        'total_vps': len(vps_list),
        'ad_vps_count': 0,
        'paid_vps_count': 0,
        'total_points': 0,
        'total_credits': 0,
        'by_user': {}
    }
    
    for vps in vps_list:
        user_id = vps.get('user_id')
        refund_type, refund_amount, _ = calculate_refund(vps)
        
        if refund_type == 'points':
            summary['ad_vps_count'] += 1
            summary['total_points'] += refund_amount
        else:
            summary['paid_vps_count'] += 1
            summary['total_credits'] += refund_amount
            
        if user_id not in summary['by_user']:
            summary['by_user'][user_id] = {'points': 0, 'credits': 0}
            
        summary['by_user'][user_id][refund_type] += refund_amount
        
    return summary


def format_refund_message(refund_type: str, refund_amount: int, vps_name: str = None) -> str:
    """
    Formate un message de remboursement
    
    Args:
        refund_type: Type de remboursement ('points' ou 'credits')
        refund_amount: Montant remboursé
        vps_name: Nom du VPS (optionnel)
        
    Returns:
        Message formaté
    """
    vps_part = f" for VPS `{vps_name}`" if vps_name else ""
    
    if refund_type == 'points':
        unit = "point" if refund_amount == 1 else "points"
        return f"✅ Refunded {refund_amount} VPS {unit}{vps_part}"
    else:
        unit = "credit" if refund_amount == 1 else "credits"
        return f"✅ Refunded {refund_amount} {unit}{vps_part}"
