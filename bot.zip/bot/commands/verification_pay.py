import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
from utils.database import db

class VerifyPayment(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.oxapay_merchant_key = os.getenv("OXAPAY_MERCHANT_KEY")

    @commands.hybrid_command(name="verify_payment", description="Manually verify a payment and attribute credits.")
    @app_commands.guild_only()
    @app_commands.describe(track_id="The OxaPay payment tracking ID")
    async def verification_pay(self, ctx: commands.Context, track_id: str):
        if not self.oxapay_merchant_key:
            await ctx.send("The payment configuration is not complete. Please contact an administrator.", ephemeral=True)
            return

        conn = None
        cursor = None
        try:
            conn, cursor = db.start_transaction()
            transaction = db.get_transaction(track_id, cursor=cursor, conn=conn)

            if not transaction:
                await ctx.send("This payment ID is invalid.", ephemeral=True)
                db.rollback_transaction(conn, cursor)
                return

            # Ensure user_id and credits are integers
            user_id = int(transaction['user_id'])
            credits = int(transaction['credits'])
            current_status = transaction['status']

            if current_status != 'pending':
                await ctx.send(f"Credits for this payment have already been processed or are not pending. Current status: {current_status}", ephemeral=True)
                db.rollback_transaction(conn, cursor)
                return

            await ctx.defer(ephemeral=True)

            headers = {
                'merchant_api_key': self.oxapay_merchant_key,
                'Content-Type': 'application/json'
            }
            url = f'https://api.oxapay.com/v1/payment/{track_id}'

            data = None
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        data = await resp.json()

                        if data and data.get('status') == "success":
                            compensation = 1
                            total_credits = credits + compensation
                            db.add_credits(user_id, total_credits, cursor=cursor, conn=conn)
                            db.mark_transaction_as_completed(track_id, cursor=cursor, conn=conn)
                            db.commit_transaction(conn, cursor)

                            if ctx.interaction:
                                await ctx.interaction.followup.send(f"{total_credits} credits (including {compensation} as compensation) have been added to the user's account.", ephemeral=True)
                            else:
                                await ctx.send(f"{total_credits} credits (including {compensation} as compensation) have been added to the user's account.", ephemeral=True)
                            try:
                                user = await self.bot.fetch_user(user_id)
                                await user.send(f"Your payment has been manually verified. {total_credits} credits have been added to your account.")
                            except discord.Forbidden:
                                pass
                        else:
                            status_message = data.get('status') if data else "Unknown"
                            if ctx.interaction:
                                await ctx.interaction.followup.send(f"The payment has not yet been confirmed by OxaPay. Status: {status_message}", ephemeral=True)
                            else:
                                await ctx.send(f"The payment has not yet been confirmed by OxaPay. Status: {status_message}", ephemeral=True)
                            db.rollback_transaction(conn, cursor) # Rollback if OxaPay doesn't confirm payment
                    else:
                        if ctx.interaction:
                            await ctx.interaction.followup.send(f"OxaPay API Error: {resp.status}", ephemeral=True)
                        else:
                            await ctx.send(f"OxaPay API Error: {resp.status}", ephemeral=True)
                        db.rollback_transaction(conn, cursor) # Rollback on API error
        except Exception as e:
            if conn and cursor:
                db.rollback_transaction(conn, cursor)
            if ctx.interaction:
                await ctx.interaction.followup.send(f"An error occurred: {e}", ephemeral=True)
            else:
                await ctx.send(f"An error occurred: {e}", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(VerifyPayment(bot))
