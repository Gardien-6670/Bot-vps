import discord
from discord import app_commands
from discord.ext import commands, tasks
from utils.database import db
from datetime import datetime, timedelta
import logging
import io
import csv

try:
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    logging.warning("matplotlib not available, graph features will be disabled")

class DisplayTypeSelect(discord.ui.Select):
    """Select menu for choosing display type"""
    def __init__(self, parent_view):
        self.parent_view = parent_view
        options = [
            discord.SelectOption(label="📋 Transaction Logs", value="logs", description="View detailed transaction logs", emoji="📋"),
            discord.SelectOption(label="📊 Statistics", value="stats", description="View transaction statistics", emoji="📊"),
            discord.SelectOption(label="📈 Graph - Daily Activity", value="graph_daily", description="Daily transaction activity graph", emoji="📈"),
            discord.SelectOption(label="📉 Graph - By Type", value="graph_type", description="Transactions by type graph", emoji="📉"),
            discord.SelectOption(label="💹 Graph - Balance Over Time", value="graph_balance", description="Balance evolution graph", emoji="💹"),
            discord.SelectOption(label="💾 Export CSV", value="export", description="Export logs to CSV file", emoji="💾"),
        ]
        super().__init__(placeholder="Choose display type...", options=options, min_values=1, max_values=1)
    
    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        selected = self.values[0]
        
        if selected == "logs":
            await self.parent_view.show_logs(interaction)
        elif selected == "stats":
            await self.parent_view.show_stats(interaction)
        elif selected.startswith("graph_"):
            graph_type = selected.replace("graph_", "")
            await self.parent_view.show_graph(interaction, graph_type)
        elif selected == "export":
            await self.parent_view.export_csv(interaction)

class TransactionDisplayView(discord.ui.View):
    """View with select menu for transaction display options"""
    def __init__(self, bot, user: discord.User = None, transaction_type: str = None, 
                 min_amount: int = None, max_amount: int = None, days_back: int = 30, page: int = 1):
        super().__init__(timeout=300)
        self.bot = bot
        self.user = user
        self.transaction_type = transaction_type
        self.min_amount = min_amount
        self.max_amount = max_amount
        self.days_back = days_back
        self.page = page
        self.add_item(DisplayTypeSelect(self))
    
    async def show_logs(self, interaction: discord.Interaction):
        """Display transaction logs"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.days_back)
        
        per_page = 20
        offset = (self.page - 1) * per_page
        
        user_id = self.user.id if self.user else None
        
        logs = db.get_transaction_logs(
            user_id=user_id,
            transaction_type=self.transaction_type,
            min_amount=self.min_amount,
            max_amount=self.max_amount,
            start_date=start_date,
            end_date=end_date,
            limit=per_page,
            offset=offset
        )
        
        total_count = db.get_transaction_logs_count(
            user_id=user_id,
            transaction_type=self.transaction_type,
            min_amount=self.min_amount,
            max_amount=self.max_amount,
            start_date=start_date,
            end_date=end_date
        )
        
        if not logs:
            await interaction.followup.send("No transaction logs found with the current filters.", ephemeral=True)
            return
        
        total_pages = (total_count + per_page - 1) // per_page
        
        if self.user:
            title = f"Transaction Logs for {self.user.display_name}"
            color = 0x3498DB
        else:
            title = "Transaction Logs"
            color = 0xE5E6EB
        
        filters = []
        if self.transaction_type:
            filters.append(self.transaction_type.replace('_', ' ').title())
        if self.min_amount or self.max_amount:
            if self.min_amount and self.max_amount:
                filters.append(f"{self.min_amount}-{self.max_amount}")
            elif self.min_amount:
                filters.append(f"≥{self.min_amount}")
            elif self.max_amount:
                filters.append(f"≤{self.max_amount}")
        
        if filters:
            title += f" ({', '.join(filters)})"
        
        embed = discord.Embed(
            title=title,
            description=f"Page {self.page}/{total_pages} • Total: {total_count} transactions • Last {self.days_back} days",
            color=color
        )
        
        for log in logs:
            if not self.user:
                try:
                    log_user = await self.bot.fetch_user(log['user_id'])
                    user_display = f"{log_user.mention} (`{log['user_id']}`)"
                except:
                    user_display = f"User ID: `{log['user_id']}`"
            else:
                user_display = ""
            
            trans_type = log['transaction_type']
            type_emoji = {
                'credit_add': '💰',
                'credit_remove': '💸',
                'point_add': '⭐',
                'point_remove': '🔻'
            }.get(trans_type, '📝')
            
            type_display = {
                'credit_add': 'Credits Added',
                'credit_remove': 'Credits Removed',
                'point_add': 'Points Added',
                'point_remove': 'Points Removed'
            }.get(trans_type, trans_type)
            
            amount = log['amount']
            if trans_type in ['credit_add', 'point_add']:
                amount_display = f"+{amount}"
            else:
                amount_display = f"-{amount}"
            
            created_at = log['created_at']
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            date_display = created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            field_value = f"**Type:** {type_emoji} {type_display}\\n"
            if not self.user:
                field_value += f"**User:** {user_display}\\n"
            field_value += f"**Amount:** `{amount_display}`\\n"
            field_value += f"**Balance:** `{log['balance_before']}` → `{log['balance_after']}`\\n"
            if log.get('reason'):
                reason = log['reason']
                if len(reason) > 100:
                    reason = reason[:97] + "..."
                field_value += f"**Reason:** {reason}\\n"
            field_value += f"**Date:** {date_display}"
            
            embed.add_field(
                name=f"Transaction #{log['id']}",
                value=field_value,
                inline=False
            )
        
        embed.set_footer(text="Use the menu above to change display type")
        
        await interaction.followup.send(embed=embed, ephemeral=True, view=self)
    
    async def show_stats(self, interaction: discord.Interaction):
        """Display transaction statistics"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.days_back)
        
        user_id = self.user.id if self.user else None
        stats = db.get_transaction_statistics(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        
        if stats['total_transactions'] == 0:
            await interaction.followup.send(f"No transactions found in the last {self.days_back} days.", ephemeral=True)
            return
        
        if self.user:
            title = f"Transaction Statistics for {self.user.display_name}"
            color = 0x3498DB
        else:
            title = "Transaction Statistics (All Users)"
            color = 0xE5E6EB
        
        embed = discord.Embed(
            title=title,
            description=f"Analysis of last {self.days_back} days",
            color=color
        )
        
        embed.add_field(
            name="📊 Overall",
            value=f"**Total Transactions:** {stats['total_transactions']}",
            inline=False
        )
        
        if stats['total_credits_added'] > 0 or stats['total_credits_removed'] > 0:
            credits_net = stats['total_credits_added'] - stats['total_credits_removed']
            credits_value = f"**Added:** +{stats['total_credits_added']}\\n"
            credits_value += f"**Removed:** -{stats['total_credits_removed']}\\n"
            credits_value += f"**Net:** {credits_net:+d}"
            embed.add_field(
                name="💰 Credits",
                value=credits_value,
                inline=True
            )
        
        if stats['total_points_added'] > 0 or stats['total_points_removed'] > 0:
            points_net = stats['total_points_added'] - stats['total_points_removed']
            points_value = f"**Added:** +{stats['total_points_added']}\\n"
            points_value += f"**Removed:** -{stats['total_points_removed']}\\n"
            points_value += f"**Net:** {points_net:+d}"
            embed.add_field(
                name="⭐ VPS Points",
                value=points_value,
                inline=True
            )
        
        for trans_type, type_stats in stats['by_type'].items():
            type_emoji = {
                'credit_add': '💰',
                'credit_remove': '💸',
                'point_add': '⭐',
                'point_remove': '🔻'
            }.get(trans_type, '📝')
            
            type_name = {
                'credit_add': 'Credits Added',
                'credit_remove': 'Credits Removed',
                'point_add': 'Points Added',
                'point_remove': 'Points Removed'
            }.get(trans_type, trans_type)
            
            detail_value = f"**Count:** {type_stats['count']}\\n"
            detail_value += f"**Total:** {type_stats['total']}\\n"
            detail_value += f"**Average:** {type_stats['average']:.1f}\\n"
            detail_value += f"**Range:** {type_stats['min']} - {type_stats['max']}"
            
            embed.add_field(
                name=f"{type_emoji} {type_name}",
                value=detail_value,
                inline=True
            )
        
        embed.set_footer(text="Use the menu above to change display type")
        
        await interaction.followup.send(embed=embed, ephemeral=True, view=self)
    
    async def show_graph(self, interaction: discord.Interaction, graph_type: str):
        """Generate and display transaction graph"""
        if not MATPLOTLIB_AVAILABLE:
            await interaction.followup.send(
                "Graph feature is not available. Please install matplotlib: `pip install matplotlib`",
                ephemeral=True
            )
            return
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.days_back)
        
        user_id = self.user.id if self.user else None
        logs = db.get_transaction_logs(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            limit=10000,
            offset=0
        )
        
        if not logs:
            await interaction.followup.send("No transaction data available for the selected period.", ephemeral=True)
            return
        
        try:
            fig, ax = plt.subplots(figsize=(12, 6))
            
            if graph_type == "daily":
                daily_counts = {}
                for log in logs:
                    created_at = log['created_at']
                    if isinstance(created_at, str):
                        created_at = datetime.fromisoformat(created_at)
                    date_key = created_at.date()
                    daily_counts[date_key] = daily_counts.get(date_key, 0) + 1
                
                dates = sorted(daily_counts.keys())
                counts = [daily_counts[d] for d in dates]
                
                ax.bar(dates, counts, color='#3498DB', alpha=0.7)
                ax.set_xlabel('Date')
                ax.set_ylabel('Number of Transactions')
                ax.set_title(f'Daily Transaction Activity - Last {self.days_back} Days')
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                
            elif graph_type == "type":
                type_counts = {}
                type_amounts = {}
                
                for log in logs:
                    trans_type = log['transaction_type']
                    type_counts[trans_type] = type_counts.get(trans_type, 0) + 1
                    type_amounts[trans_type] = type_amounts.get(trans_type, 0) + log['amount']
                
                types = list(type_counts.keys())
                counts = [type_counts[t] for t in types]
                
                colors = {
                    'credit_add': '#2ECC71',
                    'credit_remove': '#E74C3C',
                    'point_add': '#F39C12',
                    'point_remove': '#E67E22'
                }
                bar_colors = [colors.get(t, '#95A5A6') for t in types]
                
                bars = ax.bar(types, counts, color=bar_colors, alpha=0.7)
                
                for i, (bar, trans_type) in enumerate(zip(bars, types)):
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{type_amounts[trans_type]} total',
                           ha='center', va='bottom', fontsize=9)
                
                ax.set_xlabel('Transaction Type')
                ax.set_ylabel('Number of Transactions')
                ax.set_title(f'Transactions by Type - Last {self.days_back} Days')
                ax.grid(True, alpha=0.3, axis='y')
                plt.xticks(rotation=45)
                
            elif graph_type == "balance":
                if not self.user:
                    await interaction.followup.send(
                        "Balance over time graph requires a specific user. Please specify a user.",
                        ephemeral=True
                    )
                    plt.close(fig)
                    return
                
                sorted_logs = sorted(logs, key=lambda x: x['created_at'])
                
                dates = []
                balances = []
                
                for log in sorted_logs:
                    created_at = log['created_at']
                    if isinstance(created_at, str):
                        created_at = datetime.fromisoformat(created_at)
                    dates.append(created_at)
                    balances.append(log['balance_after'])
                
                ax.plot(dates, balances, marker='o', linestyle='-', linewidth=2, markersize=4, color='#3498DB')
                ax.fill_between(dates, balances, alpha=0.3, color='#3498DB')
                ax.set_xlabel('Date')
                ax.set_ylabel('Balance')
                ax.set_title(f'Balance Over Time - {self.user.display_name}')
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                
                ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{int(x):,}'))
            
            plt.tight_layout()
            
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            plt.close(fig)
            
            file = discord.File(buffer, filename=f'transaction_graph_{graph_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png')
            
            embed = discord.Embed(
                title=f"📊 Transaction Graph - {graph_type.replace('_', ' ').title()}",
                description=f"Analysis of last {self.days_back} days",
                color=0x3498DB
            )
            if self.user:
                embed.set_footer(text=f"User: {self.user.display_name}")
            
            embed.set_image(url=f"attachment://{file.filename}")
            
            await interaction.followup.send(embed=embed, file=file, ephemeral=True, view=self)
            
        except Exception as e:
            logging.error(f"Error generating graph: {e}", exc_info=True)
            await interaction.followup.send(f"Error generating graph: {e}", ephemeral=True)
            if 'fig' in locals():
                plt.close(fig)
    
    async def export_csv(self, interaction: discord.Interaction):
        """Export logs to CSV"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.days_back)
        
        user_id = self.user.id if self.user else None
        
        logs = db.get_transaction_logs(
            user_id=user_id,
            transaction_type=self.transaction_type,
            min_amount=self.min_amount,
            max_amount=self.max_amount,
            start_date=start_date,
            end_date=end_date,
            limit=10000,
            offset=0
        )
        
        if not logs:
            await interaction.followup.send("No logs to export.", ephemeral=True)
            return
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow(['ID', 'User ID', 'Type', 'Amount', 'Balance Before', 'Balance After', 'Reason', 'Date'])
        
        for log in logs:
            created_at = log['created_at']
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            
            writer.writerow([
                log['id'],
                log['user_id'],
                log['transaction_type'],
                log['amount'],
                log['balance_before'],
                log['balance_after'],
                log.get('reason', ''),
                created_at.strftime('%Y-%m-%d %H:%M:%S')
            ])
        
        output.seek(0)
        file = discord.File(io.BytesIO(output.getvalue().encode()), filename=f'transaction_logs_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv')
        await interaction.followup.send(f"Exported {len(logs)} transaction logs", file=file, ephemeral=True, view=self)

class TransactionLogs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.archive_old_logs.start()

    def cog_unload(self):
        self.archive_old_logs.cancel()

    @tasks.loop(hours=24)
    async def archive_old_logs(self):
        """Automatically archive logs older than 1 year."""
        await self.bot.wait_until_ready()
        try:
            archived_count = db.archive_old_transaction_logs(days_old=365)
            if archived_count > 0:
                logging.info(f"Automatically archived {archived_count} old transaction logs")
        except Exception as e:
            logging.error(f"Error archiving old logs: {e}", exc_info=True)

    @app_commands.command(name="transactions", description="View transaction logs with multiple display options")
    @app_commands.describe(
        user="User to view logs for (optional)",
        transaction_type="Filter by type: credit_add, credit_remove, point_add, point_remove",
        min_amount="Minimum amount to filter",
        max_amount="Maximum amount to filter",
        days_back="Number of days to look back (default: 30)",
        page="Page number (default: 1)"
    )
    @app_commands.choices(transaction_type=[
        app_commands.Choice(name="Credits Added", value="credit_add"),
        app_commands.Choice(name="Credits Removed", value="credit_remove"),
        app_commands.Choice(name="Points Added", value="point_add"),
        app_commands.Choice(name="Points Removed", value="point_remove"),
    ])
    async def transactions(
        self, 
        interaction: discord.Interaction, 
        user: discord.User = None,
        transaction_type: str = None,
        min_amount: int = None,
        max_amount: int = None,
        days_back: int = 30,
        page: int = 1
    ):
        """Unified transaction viewer with multiple display options via select menu."""
        await interaction.response.defer(ephemeral=True)
        
        if page < 1:
            page = 1
        if days_back < 1:
            days_back = 30
        
        view = TransactionDisplayView(
            self.bot, user, transaction_type, min_amount, max_amount, days_back, page
        )
        
        embed = discord.Embed(
            title="📊 Transaction Viewer",
            description="Select a display type from the menu below to view your transactions.",
            color=0x3498DB
        )
        
        filters = []
        if user:
            filters.append(f"**User:** {user.mention}")
        if transaction_type:
            filters.append(f"**Type:** {transaction_type.replace('_', ' ').title()}")
        if min_amount:
            filters.append(f"**Min Amount:** {min_amount}")
        if max_amount:
            filters.append(f"**Max Amount:** {max_amount}")
        filters.append(f"**Period:** Last {days_back} days")
        
        if filters:
            embed.add_field(name="🔍 Active Filters", value="\\n".join(filters), inline=False)
        
        embed.set_footer(text="Choose an option from the menu below")
        
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="archive_logs", description="Archive old transaction logs (Admin only)")
    @app_commands.describe(
        days_old="Archive logs older than this many days (default: 365)"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def archive_logs(
        self,
        interaction: discord.Interaction,
        days_old: int = 365
    ):
        """Archive old transaction logs."""
        await interaction.response.defer(ephemeral=True)
        
        if days_old < 30:
            await interaction.followup.send("Cannot archive logs less than 30 days old.", ephemeral=True)
            return
        
        try:
            archived_count = db.archive_old_transaction_logs(days_old=days_old)
            
            if archived_count > 0:
                embed = discord.Embed(
                    title="✅ Logs Archived",
                    description=f"Successfully archived {archived_count} transaction logs older than {days_old} days.",
                    color=0x2ECC71
                )
                embed.add_field(name="Archive Table", value="`transaction_logs_archive`", inline=False)
                embed.set_footer(text="Archived logs are preserved but removed from the main table for performance.")
            else:
                embed = discord.Embed(
                    title="ℹ️ No Logs to Archive",
                    description=f"No transaction logs found older than {days_old} days.",
                    color=0x3498DB
                )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            logging.error(f"Error archiving logs: {e}", exc_info=True)
            await interaction.followup.send(f"Error archiving logs: {e}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TransactionLogs(bot))
