import discord
from discord import app_commands
from discord.ext import commands, tasks
from utils.database import db
from datetime import datetime, timedelta
import logging
import io
import csv

class TransactionLogs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.archive_old_logs.start()  # Start automatic archiving task

    def cog_unload(self):
        self.archive_old_logs.cancel()

    @tasks.loop(hours=24)
    async def archive_old_logs(self):
        """Automatically archive logs older than 1 year."""
        await self.bot.wait_until_ready()
        try:
            archived_count = db.archive_old_transaction_logs(days_old=365)
            if archived_count > 0:
                logging.info(f"Automatically archived {archived_count} old transaction logs")
        except Exception as e:
            logging.error(f"Error archiving old logs: {e}", exc_info=True)

    @app_commands.command(name="logs_point_credits", description="View transaction logs for credits and VPS points")
    @app_commands.describe(
        user="User to view logs for (optional)",
        transaction_type="Filter by type: credit_add, credit_remove, point_add, point_remove",
        min_amount="Minimum amount to filter",
        max_amount="Maximum amount to filter",
        days_back="Number of days to look back (default: 30)",
        page="Page number (default: 1)",
        export_csv="Export results to CSV file"
    )
    @app_commands.choices(transaction_type=[
        app_commands.Choice(name="Credits Added", value="credit_add"),
        app_commands.Choice(name="Credits Removed", value="credit_remove"),
        app_commands.Choice(name="Points Added", value="point_add"),
        app_commands.Choice(name="Points Removed", value="point_remove"),
    ])
    async def logs_point_credits(
        self, 
        interaction: discord.Interaction, 
        user: discord.User = None,
        transaction_type: str = None,
        min_amount: int = None,
        max_amount: int = None,
        days_back: int = 30,
        page: int = 1,
        export_csv: bool = False
    ):
        """View transaction logs for credits and VPS points with advanced filters."""
        await interaction.response.defer(ephemeral=True)
        
        # Validate inputs
        if page < 1:
            page = 1
        if days_back < 1:
            days_back = 30
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Items per page
        per_page = 20
        offset = (page - 1) * per_page
        
        # Get logs with filters
        user_id = user.id if user else None
        
        if export_csv:
            # Export all matching logs (no pagination)
            logs = db.get_transaction_logs(
                user_id=user_id,
                transaction_type=transaction_type,
                min_amount=min_amount,
                max_amount=max_amount,
                start_date=start_date,
                end_date=end_date,
                limit=10000,  # Max export limit
                offset=0
            )
            
            if not logs:
                await interaction.followup.send("No logs to export.", ephemeral=True)
                return
            
            # Create CSV
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Write header
            writer.writerow(['ID', 'User ID', 'Type', 'Amount', 'Balance Before', 'Balance After', 'Reason', 'Date'])
            
            # Write data
            for log in logs:
                created_at = log['created_at']
                if isinstance(created_at, str):
                    created_at = datetime.fromisoformat(created_at)
                
                writer.writerow([
                    log['id'],
                    log['user_id'],
                    log['transaction_type'],
                    log['amount'],
                    log['balance_before'],
                    log['balance_after'],
                    log.get('reason', ''),
                    created_at.strftime('%Y-%m-%d %H:%M:%S')
                ])
            
            # Send CSV file
            output.seek(0)
            file = discord.File(io.BytesIO(output.getvalue().encode()), filename=f'transaction_logs_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv')
            await interaction.followup.send(f"Exported {len(logs)} transaction logs", file=file, ephemeral=True)
            return
        
        # Get paginated logs
        logs = db.get_transaction_logs(
            user_id=user_id,
            transaction_type=transaction_type,
            min_amount=min_amount,
            max_amount=max_amount,
            start_date=start_date,
            end_date=end_date,
            limit=per_page,
            offset=offset
        )
        
        total_count = db.get_transaction_logs_count(
            user_id=user_id,
            transaction_type=transaction_type,
            min_amount=min_amount,
            max_amount=max_amount,
            start_date=start_date,
            end_date=end_date
        )
        
        if not logs:
            filters_text = []
            if user:
                filters_text.append(f"user: {user.mention}")
            if transaction_type:
                filters_text.append(f"type: {transaction_type}")
            if min_amount:
                filters_text.append(f"min: {min_amount}")
            if max_amount:
                filters_text.append(f"max: {max_amount}")
            
            filter_str = " with filters: " + ", ".join(filters_text) if filters_text else ""
            await interaction.followup.send(f"No transaction logs found{filter_str}.", ephemeral=True)
            return
        
        # Calculate total pages
        total_pages = (total_count + per_page - 1) // per_page
        
        # Create embed
        if user:
            title = f"Transaction Logs for {user.display_name}"
            color = 0x3498DB
        else:
            title = "Transaction Logs"
            color = 0xE5E6EB
        
        # Add filter info to title
        filters = []
        if transaction_type:
            filters.append(transaction_type.replace('_', ' ').title())
        if min_amount or max_amount:
            if min_amount and max_amount:
                filters.append(f"{min_amount}-{max_amount}")
            elif min_amount:
                filters.append(f"≥{min_amount}")
            elif max_amount:
                filters.append(f"≤{max_amount}")
        
        if filters:
            title += f" ({', '.join(filters)})"
        
        embed = discord.Embed(
            title=title,
            description=f"Page {page}/{total_pages} • Total: {total_count} transactions • Last {days_back} days",
            color=color
        )
        
        # Format logs
        for log in logs:
            # Get user mention if not filtering by user
            if not user:
                try:
                    log_user = await self.bot.fetch_user(log['user_id'])
                    user_display = f"{log_user.mention} (`{log['user_id']}`)"
                except:
                    user_display = f"User ID: `{log['user_id']}`"
            else:
                user_display = ""
            
            # Format transaction type
            trans_type = log['transaction_type']
            type_emoji = {
                'credit_add': '💰',
                'credit_remove': '💸',
                'point_add': '⭐',
                'point_remove': '🔻'
            }.get(trans_type, '📝')
            
            type_display = {
                'credit_add': 'Credits Added',
                'credit_remove': 'Credits Removed',
                'point_add': 'Points Added',
                'point_remove': 'Points Removed'
            }.get(trans_type, trans_type)
            
            # Format amount with sign
            amount = log['amount']
            if trans_type in ['credit_add', 'point_add']:
                amount_display = f"+{amount}"
            else:
                amount_display = f"-{amount}"
            
            # Format date
            created_at = log['created_at']
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            date_display = created_at.strftime('%Y-%m-%d %H:%M:%S')
            
            # Build field value
            field_value = f"**Type:** {type_emoji} {type_display}\\n"
            if not user:
                field_value += f"**User:** {user_display}\\n"
            field_value += f"**Amount:** `{amount_display}`\\n"
            field_value += f"**Balance:** `{log['balance_before']}` → `{log['balance_after']}`\\n"
            if log.get('reason'):
                # Truncate long reasons
                reason = log['reason']
                if len(reason) > 100:
                    reason = reason[:97] + "..."
                field_value += f"**Reason:** {reason}\\n"
            field_value += f"**Date:** {date_display}"
            
            # Add field (use transaction ID as name)
            embed.add_field(
                name=f"Transaction #{log['id']}",
                value=field_value,
                inline=False
            )
        
        # Add footer with navigation and export info
        footer_parts = []
        if page < total_pages:
            footer_parts.append(f"Use page:{page+1} for next page")
        footer_parts.append("Use export_csv:True to export to CSV")
        
        embed.set_footer(text=" • ".join(footer_parts))
        
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="transaction_stats", description="View statistics about credit and point transactions")
    @app_commands.describe(
        user="User to view stats for (optional)",
        days_back="Number of days to analyze (default: 30)"
    )
    async def transaction_stats(
        self,
        interaction: discord.Interaction,
        user: discord.User = None,
        days_back: int = 30
    ):
        """View statistics about transactions."""
        await interaction.response.defer(ephemeral=True)
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Get statistics
        user_id = user.id if user else None
        stats = db.get_transaction_statistics(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        
        if stats['total_transactions'] == 0:
            if user:
                await interaction.followup.send(f"No transactions found for {user.mention} in the last {days_back} days.", ephemeral=True)
            else:
                await interaction.followup.send(f"No transactions found in the last {days_back} days.", ephemeral=True)
            return
        
        # Create embed
        if user:
            title = f"Transaction Statistics for {user.display_name}"
            color = 0x3498DB
        else:
            title = "Transaction Statistics (All Users)"
            color = 0xE5E6EB
        
        embed = discord.Embed(
            title=title,
            description=f"Analysis of last {days_back} days",
            color=color
        )
        
        # Overall stats
        embed.add_field(
            name="📊 Overall",
            value=f"**Total Transactions:** {stats['total_transactions']}",
            inline=False
        )
        
        # Credits stats
        if stats['total_credits_added'] > 0 or stats['total_credits_removed'] > 0:
            credits_net = stats['total_credits_added'] - stats['total_credits_removed']
            credits_value = f"**Added:** +{stats['total_credits_added']}\\n"
            credits_value += f"**Removed:** -{stats['total_credits_removed']}\\n"
            credits_value += f"**Net:** {credits_net:+d}"
            embed.add_field(
                name="💰 Credits",
                value=credits_value,
                inline=True
            )
        
        # Points stats
        if stats['total_points_added'] > 0 or stats['total_points_removed'] > 0:
            points_net = stats['total_points_added'] - stats['total_points_removed']
            points_value = f"**Added:** +{stats['total_points_added']}\\n"
            points_value += f"**Removed:** -{stats['total_points_removed']}\\n"
            points_value += f"**Net:** {points_net:+d}"
            embed.add_field(
                name="⭐ VPS Points",
                value=points_value,
                inline=True
            )
        
        # Detailed stats by type
        for trans_type, type_stats in stats['by_type'].items():
            type_emoji = {
                'credit_add': '💰',
                'credit_remove': '💸',
                'point_add': '⭐',
                'point_remove': '🔻'
            }.get(trans_type, '📝')
            
            type_name = {
                'credit_add': 'Credits Added',
                'credit_remove': 'Credits Removed',
                'point_add': 'Points Added',
                'point_remove': 'Points Removed'
            }.get(trans_type, trans_type)
            
            detail_value = f"**Count:** {type_stats['count']}\\n"
            detail_value += f"**Total:** {type_stats['total']}\\n"
            detail_value += f"**Average:** {type_stats['average']:.1f}\\n"
            detail_value += f"**Range:** {type_stats['min']} - {type_stats['max']}"
            
            embed.add_field(
                name=f"{type_emoji} {type_name}",
                value=detail_value,
                inline=True
            )
        
        embed.set_footer(text="Use /logs_point_credits for detailed transaction history")
        
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="archive_logs", description="Archive old transaction logs (Admin only)")
    @app_commands.describe(
        days_old="Archive logs older than this many days (default: 365)"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def archive_logs(
        self,
        interaction: discord.Interaction,
        days_old: int = 365
    ):
        """Archive old transaction logs."""
        await interaction.response.defer(ephemeral=True)
        
        if days_old < 30:
            await interaction.followup.send("Cannot archive logs less than 30 days old.", ephemeral=True)
            return
        
        try:
            archived_count = db.archive_old_transaction_logs(days_old=days_old)
            
            if archived_count > 0:
                embed = discord.Embed(
                    title="✅ Logs Archived",
                    description=f"Successfully archived {archived_count} transaction logs older than {days_old} days.",
                    color=0x2ECC71
                )
                embed.add_field(name="Archive Table", value="`transaction_logs_archive`", inline=False)
                embed.set_footer(text="Archived logs are preserved but removed from the main table for performance.")
            else:
                embed = discord.Embed(
                    title="ℹ️ No Logs to Archive",
                    description=f"No transaction logs found older than {days_old} days.",
                    color=0x3498DB
                )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            logging.error(f"Error archiving logs: {e}", exc_info=True)
            await interaction.followup.send(f"Error archiving logs: {e}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TransactionLogs(bot))
