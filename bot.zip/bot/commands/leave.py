import discord
from discord.ext import commands
import logging
import os
from utils.database import db
from utils import node_manager

class LeaveCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """
        Handles the event when a member leaves the server.
        This function will delete all of the user's VPS containers and KVMs and reset their credits.
        """
        logging.info(f"Member {member.id} ({member.name}) has left the server. Cleaning up resources.")
        
        user_vps_list = db.get_user_vps(member.id)
        
        if user_vps_list:
            logging.info(f"Found {len(user_vps_list)} VPS for user {member.id}. Deleting them.")
            for vps in user_vps_list:
                vps_id = vps['id']
                vps_type = vps.get('vps_type', 'lxc') # Default to lxc if not specified

                if vps_type == 'kvm':
                    endpoint_prefix = 'kvm/vm'
                    vps_name = vps.get('vm_name') or vps.get('container_name')
                else: # 'lxc'
                    endpoint_prefix = 'lxc/container'
                    vps_name = vps.get('container_name')
                
                if not vps_name:
                    logging.warning(f"VPS name not found for vps_id {vps_id} (type: {vps_type}). Deleting from DB.")
                    db.delete_vps(vps_id)
                    continue

                node_info = node_manager.get_node_for_vps(vps_name)
                if not node_info:
                    logging.error(f"Could not determine the node for VPS {vps_name}. Skipping deletion for this VPS.")
                    continue
                node_url, api_key = node_info['url'], node_info['api_key']

                # Delete the VPS via API
                delete_result = await node_manager.api_request('DELETE', f"/{endpoint_prefix}/{vps_name}", node_url, api_key)

                if delete_result and (delete_result.get("deleted", False) or delete_result.get("success", False) or delete_result.get("status") == "success"):
                    logging.info(f"Successfully deleted {vps_type.upper()} {vps_name} for user {member.id} via API.")
                    # Delete the VPS from the database
                    db.delete_vps(vps_id)
                    logging.info(f"Successfully deleted VPS record {vps_id} from database for user {member.id}.")
                else:
                    logging.error(f"Failed to delete {vps_type.upper()} {vps_name} for user {member.id} via API. It might have been already deleted. Deleting from DB anyway.")
                    # Still delete from DB to prevent orphaned entries
                    db.delete_vps(vps_id)
        else:
            logging.info(f"No VPS found for user {member.id}.")

        # Set user's credits to 0
        logging.info(f"Resetting credits for user {member.id}.")
        db.set_balance(member.id, 0)
        db.remove_all_pending_credits(member.id) # Also clear pending credits
        logging.info(f"Credits for user {member.id} have been reset to 0.")

async def setup(bot):
    await bot.add_cog(LeaveCog(bot))
