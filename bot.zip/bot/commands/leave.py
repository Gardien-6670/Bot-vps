import discord
from discord.ext import commands
import logging
import os
from utils.database import db
from utils import node_manager


class LeaveCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """
        Handles the event when a member leaves the server.
        This function will delete all of the user's VPS containers and KVMs and reset their credits.
        """
        logging.info(
            f"Member {member.id} ({member.name}) has left the server. Cleaning up resources."
        )

        user_vps_list = db.get_user_vps(member.id)

        if user_vps_list:
            logging.info(
                f"Found {len(user_vps_list)} VPS for user {member.id}. Deleting them."
            )
            
            # ✅ Collecter les VPS à supprimer de la DB (seulement ceux supprimés du système)
            vps_ids_to_delete = []
            
            for vps in user_vps_list:
                vps_id = vps["id"]
                vps_type = vps.get("vps_type", "lxc")  # Default to lxc if not specified

                if vps_type == "kvm":
                    endpoint_prefix = "kvm/vm"
                    vps_name = vps.get("vm_name") or vps.get("container_name")
                else:  # 'lxc'
                    endpoint_prefix = "lxc/container"
                    vps_name = vps.get("container_name")

                if not vps_name:
                    logging.warning(
                        f"VPS name not found for vps_id {vps_id} (type: {vps_type}). Will delete from DB."
                    )
                    vps_ids_to_delete.append(vps_id)
                    continue

                node_info = node_manager.get_node_for_vps(vps_name)
                if not node_info:
                    logging.error(
                        f"Could not determine the node for VPS {vps_name}. Skipping deletion for this VPS."
                    )
                    continue
                node_url, api_key = node_info["url"], node_info["api_key"]

                # ✅ Delete the VPS via API D'ABORD
                try:
                    delete_result = await node_manager.api_request(
                        "DELETE", f"/{endpoint_prefix}/{vps_name}", node_url, api_key
                    )

                    if delete_result and (
                        delete_result.get("deleted", False)
                        or delete_result.get("success", False)
                        or delete_result.get("status") == "success"
                    ):
                        logging.info(
                            f"Successfully deleted {vps_type.upper()} {vps_name} for user {member.id} via API."
                        )
                        # ✅ Ajouter à la liste seulement si suppression API réussie
                        vps_ids_to_delete.append(vps_id)
                    else:
                        logging.warning(
                            f"API returned unsuccessful status for {vps_type.upper()} {vps_name}. Checking if it exists..."
                        )
                        # Vérifier si le VPS existe encore
                        # Si l'API dit qu'il n'existe pas, on peut le supprimer de la DB
                        if delete_result and delete_result.get("error") and "not found" in str(delete_result.get("error")).lower():
                            logging.info(f"VPS {vps_name} not found on system, safe to delete from DB")
                            vps_ids_to_delete.append(vps_id)
                        else:
                            logging.error(
                                f"Failed to delete {vps_type.upper()} {vps_name} for user {member.id} via API. NOT deleting from DB to avoid orphan VPS."
                            )
                except Exception as e:
                    logging.error(
                        f"Exception while deleting {vps_type.upper()} {vps_name} for user {member.id}: {e}. NOT deleting from DB."
                    )
            
            # ✅ Supprimer de la DB dans une transaction atomique
            if vps_ids_to_delete:
                conn, cursor = db.start_transaction()
                try:
                    for vps_id in vps_ids_to_delete:
                        db.delete_vps(vps_id, cursor=cursor, conn=conn)
                    
                    # Réinitialiser les crédits dans la même transaction
                    db.set_balance(member.id, 0, cursor=cursor, conn=conn)
                    db.remove_all_pending_credits(member.id, cursor=cursor, conn=conn)
                    
                    db.commit_transaction(conn, cursor)
                    logging.info(
                        f"Successfully deleted {len(vps_ids_to_delete)} VPS records and reset credits for user {member.id} in DB."
                    )
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Failed to cleanup user {member.id} in DB: {e}")
                    raise
            else:
                logging.info(f"No VPS were successfully deleted from system for user {member.id}, skipping DB cleanup.")
        else:
            logging.info(f"No VPS found for user {member.id}.")
            
            # ✅ Réinitialiser les crédits même s'il n'y a pas de VPS
            conn, cursor = db.start_transaction()
            try:
                db.set_balance(member.id, 0, cursor=cursor, conn=conn)
                db.remove_all_pending_credits(member.id, cursor=cursor, conn=conn)
                db.commit_transaction(conn, cursor)
                logging.info(f"Credits for user {member.id} have been reset to 0.")
            except Exception as e:
                db.rollback_transaction(conn, cursor)
                logging.error(f"Failed to reset credits for user {member.id}: {e}")
                raise


async def setup(bot):
    await bot.add_cog(LeaveCog(bot))
