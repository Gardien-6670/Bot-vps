import discord
from discord.ext import commands, tasks
from discord import app_commands
from utils.database import db
import logging
from utils.pricing import PRICES_LXC, PRICES_KVM, usd_to_credits


class PaidPlansView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="Buy LXC VPS", style=discord.ButtonStyle.success, custom_id="paid_buy_lxc"
    )
    async def buy_lxc_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        from .plans import VpsConfigModal

        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        BOOSTER_ROLE_ID = 1436388721086693567

        is_admin = interaction.user.id in ADMIN_WHITELIST

        has_booster_role = False
        if interaction.guild:
            booster_role = interaction.guild.get_role(BOOSTER_ROLE_ID)
            if booster_role and booster_role in interaction.user.roles:
                has_booster_role = True

        has_transaction = db.has_completed_credit_transaction(interaction.user.id)

        if is_admin or has_booster_role or has_transaction:
            modal = VpsConfigModal(self.bot, "lxc")
            await interaction.response.send_modal(modal)
        else:
            await interaction.response.defer(ephemeral=True)
            embed = discord.Embed(
                title="Access Denied",
                description="You need to purchase credits first OR have the booster role to unlock paid VPS purchases.",
                color=0x992D22,
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(
        label="Buy KVM VPS", style=discord.ButtonStyle.success, custom_id="paid_buy_kvm"
    )
    async def buy_kvm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        from .plans import VpsConfigModal

        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        BOOSTER_ROLE_ID = 1436388721086693567

        is_admin = interaction.user.id in ADMIN_WHITELIST

        has_booster_role = False
        if interaction.guild:
            booster_role = interaction.guild.get_role(BOOSTER_ROLE_ID)
            if booster_role and booster_role in interaction.user.roles:
                has_booster_role = True

        has_transaction = db.has_completed_credit_transaction(interaction.user.id)

        if is_admin or has_booster_role or has_transaction:
            modal = VpsConfigModal(self.bot, "kvm")
            await interaction.response.send_modal(modal)
        else:
            await interaction.response.defer(ephemeral=True)
            embed = discord.Embed(
                title="Access Denied",
                description="You need to purchase credits first OR have the booster role to unlock paid VPS purchases.",
                color=0x992D22,
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(
        label="Balance", style=discord.ButtonStyle.secondary, custom_id="paid_balance"
    )
    async def balance_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)
        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(
            name="Pending Credits", value=f"**{pending_balance}**", inline=True
        )
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)


class PaidPlans(commands.Cog):
    DEFAULT_PAID_PLANS_CHANNEL_ID = 1338196704188698757

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(PaidPlansView(bot))
        self.update_paid_plans_message.start()

    def cog_unload(self):
        self.update_paid_plans_message.cancel()

    def build_plans_embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="Hosting Plans",
            description="Here are our competitive prices for LXC and KVM virtual private servers.",
            color=0xE5E6EB,
        )

        lxc_price_info = (
            f"**CPU:** ${PRICES_LXC['cpu']:.2f} / {usd_to_credits(PRICES_LXC['cpu'])} credits per core\n"
            f"**RAM:** ${PRICES_LXC['ram']:.2f} / {usd_to_credits(PRICES_LXC['ram'])} credits per GB\n"
            f"**Disk:** ${PRICES_LXC['disk']:.2f} / {usd_to_credits(PRICES_LXC['disk'])} credits per GB"
        )
        embed.add_field(name="LXC Plans", value=lxc_price_info, inline=False)

        kvm_price_info = (
            f"**CPU:** ${PRICES_KVM['cpu']:.2f} / {usd_to_credits(PRICES_KVM['cpu'])} credits per core\n"
            f"**RAM:** ${PRICES_KVM['ram']:.2f} / {usd_to_credits(PRICES_KVM['ram'])} credits per GB\n"
            f"**Disk:** ${PRICES_KVM['disk']:.2f} / {usd_to_credits(PRICES_KVM['disk'])} credits per GB"
        )
        embed.add_field(name="KVM Plans", value=kvm_price_info, inline=False)

        embed.set_footer(text="To purchase a custom plan, use the /plans command.")
        return embed

    @tasks.loop(hours=1)
    async def update_paid_plans_message(self):
        await self.send_paid_plans_message()

    @commands.Cog.listener()
    async def on_ready(self):
        await self.send_paid_plans_message()

    async def send_paid_plans_message(self):
        await self.bot.wait_until_ready()
        message_id, channel_id = db.get_paid_plans_message_id()

        target_channel_id = self.DEFAULT_PAID_PLANS_CHANNEL_ID or channel_id
        if not target_channel_id:
            logging.warning("No channel ID is configured for paid plans message.")
            return

        try:
            channel = self.bot.get_channel(target_channel_id)
            if not channel:
                channel = await self.bot.fetch_channel(target_channel_id)
        except (discord.NotFound, discord.Forbidden):
            logging.error(
                f"Could not find or access the channel with ID {target_channel_id}."
            )
            return

        embed = self.build_plans_embed()

        if message_id:
            try:
                message = await channel.fetch_message(message_id)
                await message.edit(embed=embed, view=PaidPlansView(self.bot))
                logging.info(
                    f"Updated paid plans message in channel {target_channel_id}."
                )
                return
            except discord.NotFound:
                logging.warning(
                    f"Paid plans message with ID {message_id} not found. A new one will be created."
                )
            except discord.Forbidden:
                logging.error(
                    f"Bot does not have permissions to edit message {message_id} in channel {target_channel_id}."
                )
                return
            except Exception as e:
                logging.error(f"Error updating paid plans message: {e}")

        try:
            new_message = await channel.send(embed=embed, view=PaidPlansView(self.bot))
            db.save_paid_plans_message_id(new_message.id, new_message.channel.id)
            logging.info(
                f"Sent new paid plans message to channel {new_message.channel.id} and saved to DB."
            )
        except discord.Forbidden:
            logging.error(
                f"Bot does not have permissions to send messages in channel {target_channel_id}."
            )
        except Exception as e:
            logging.error(f"Error sending new paid plans message: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(PaidPlans(bot))
