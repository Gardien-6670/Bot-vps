import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
from datetime import datetime, timedelta
import asyncio
import logging

class Invite(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.invite_log_channel_id = 1430123132030681119
        self.invite_cache = {} # In-memory cache: {guild_id: {invite_code: uses}}
        self._lock = asyncio.Lock()
        self._cache_ready = False  # Flag pour savoir si le cache est prêt
        self._sync_in_progress = {}  # Track ongoing syncs per guild

    @commands.Cog.listener()
    async def on_ready(self):
        """Synchronize invites with Discord and cache them on startup."""
        print("="*70)
        print("🔄 SYNCHRONIZING INVITES ON STARTUP")
        print("="*70)
        
        for guild in self.bot.guilds:
            try:
                # 1. Fetch OLD state from database (before bot restart)
                db_invites_list = await asyncio.to_thread(db.get_guild_invites, guild.id)
                old_invite_map = {inv['invite_code']: inv for inv in db_invites_list}
                
                # 2. Fetch CURRENT state from Discord API (after bot restart)
                discord_invites = await guild.invites()
                current_invite_map = {invite.code: invite for invite in discord_invites}

                # Initialize cache for this guild
                if guild.id not in self.invite_cache:
                    self.invite_cache[guild.id] = {}

                # 3. DETECT AND ATTRIBUTE MISSED INVITES (happened during bot downtime)
                print(f"\n📊 Analyzing {guild.name}:")
                missed_invites_detected = False
                
                for invite_code, current_invite in current_invite_map.items():
                    old_uses = old_invite_map.get(invite_code, {}).get('uses', 0)
                    current_uses = current_invite.uses or 0
                    
                    # If uses increased while bot was offline
                    if current_uses > old_uses:
                        difference = current_uses - old_uses
                        inviter = current_invite.inviter
                        
                        print(f"  ⚠️  MISSED: Invite {invite_code} used {difference} time(s) while offline")
                        print(f"     Old uses: {old_uses} → Current uses: {current_uses}")
                        
                        if inviter:
                            # AMÉLIORATION: Attribuer les invitations manquées
                            print(f"     ✅ Attributing {difference} missed invite(s) to {inviter.name}")
                            
                            # Créer des enregistrements pour les invitations manquées
                            # Note: On ne peut pas savoir exactement qui a rejoint, donc on crée des enregistrements "fantômes"
                            # avec un flag spécial pour indiquer qu'ils ont été détectés pendant le downtime
                            for i in range(difference):
                                # Créer un enregistrement avec member_id = 0 (inconnu)
                                # et un flag dans invite_code pour indiquer que c'est une invitation manquée
                                missed_join_time = datetime.now() - timedelta(minutes=i+1)
                                
                                try:
                                    # On enregistre dans invited_members_monthly pour le comptage
                                    month_id = db.get_current_month_id()
                                    await asyncio.to_thread(
                                        db._execute_query,
                                        """INSERT IGNORE INTO invited_members_monthly 
                                           (month_id, inviter_id, invited_member_id, joined_at, invite_code, invite_plan_eligible) 
                                           VALUES (?, ?, ?, ?, ?, ?)""",
                                        (month_id, inviter.id, 0, missed_join_time, f"{invite_code}_MISSED_{i}", True)
                                    )
                                    logging.info(f"Missed invite attributed to {inviter.id} (code: {invite_code})")
                                except Exception as e:
                                    logging.error(f"Failed to attribute missed invite: {e}")
                        else:
                            print(f"     ⚠️  Cannot attribute: No inviter found")
                        
                        missed_invites_detected = True
                    
                    # Update cache with current state
                    self.invite_cache[guild.id][invite_code] = current_uses
                    
                    # Update database with current state
                    inviter_id = current_invite.inviter.id if current_invite.inviter else None
                    await asyncio.to_thread(
                        db.save_guild_invite,
                        guild_id=guild.id,
                        invite_code=current_invite.code,
                        inviter_id=inviter_id,
                        uses=current_uses
                    )

                # 4. Remove invites from DB and cache that no longer exist on Discord
                for invite_code in old_invite_map.keys():
                    if invite_code not in current_invite_map:
                        await asyncio.to_thread(db.delete_guild_invite, guild.id, invite_code)
                        if invite_code in self.invite_cache[guild.id]:
                            del self.invite_cache[guild.id][invite_code]
                        print(f"  🗑️  Removed expired invite: {invite_code}")
                
                if not missed_invites_detected:
                    print(f"  ✅ No missed invites detected")
                    
            except discord.Forbidden:
                print(f"❌ No permission to view invites for {guild.name}")
            except Exception as e:
                print(f"❌ Error during invite synchronization for {guild.name}: {e}")
                import traceback
                traceback.print_exc()
        
        self._cache_ready = True
        print("\n" + "="*70)
        print("✅ INVITES SYNCHRONIZED AND CACHED SUCCESSFULLY")
        print("="*70 + "\n")

    @commands.Cog.listener()
    async def on_invite_create(self, invite: discord.Invite):
        """Update cache and DB when an invite is created."""
        if not invite.guild:
            return
        inviter_id = invite.inviter.id if invite.inviter else None

        # Update DB
        await asyncio.to_thread(
            db.save_guild_invite,
            guild_id=invite.guild.id,
            invite_code=invite.code,
            inviter_id=inviter_id,
            uses=invite.uses or 0
        )
        # Update cache
        if invite.guild.id not in self.invite_cache:
            self.invite_cache[invite.guild.id] = {}
        self.invite_cache[invite.guild.id][invite.code] = invite.uses or 0
        print(f"New invite created and updated in cache/DB: {invite.code} by {inviter_id}")

    @commands.Cog.listener()
    async def on_invite_delete(self, invite: discord.Invite):
        """Remove invite from cache and DB when it is deleted."""
        if not invite.guild:
            return
        
        # Update DB
        await asyncio.to_thread(
            db.delete_guild_invite,
            invite.guild.id,
            invite.code
        )
        # Update cache
        if invite.guild.id in self.invite_cache and invite.code in self.invite_cache[invite.guild.id]:
            del self.invite_cache[invite.guild.id][invite.code]
        print(f"Invite deleted and removed from cache/DB: {invite.code}")

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Detect who invited the member using the in-memory cache with improved robustness."""
        if member.bot:
            return

        async with self._lock:
            guild = member.guild
            
            # Éviter les synchronisations multiples simultanées
            if guild.id in self._sync_in_progress:
                print(f"⏳ Sync already in progress for {guild.name}, waiting...")
                await asyncio.sleep(2)
            
            try:
                # AMÉLIORATION 1: Toujours récupérer l'état actuel de Discord
                # pour éviter les problèmes de cache obsolète
                try:
                    current_invites = await guild.invites()
                except discord.Forbidden:
                    print(f"❌ No permission to view invites for {guild.name}")
                    return
                except Exception as e:
                    print(f"❌ Error fetching invites: {e}")
                    # RETRY une fois après 2 secondes
                    await asyncio.sleep(2)
                    try:
                        current_invites = await guild.invites()
                    except:
                        print(f"❌ Retry failed, cannot track invite for {member.name}")
                        return
                
                # AMÉLIORATION 2: Utiliser la DB comme source de vérité si le cache n'est pas prêt
                if not self._cache_ready:
                    print(f"⚠️ Cache not ready yet, using DB for {member.name}")
                    db_invites = await asyncio.to_thread(db.get_guild_invites, guild.id)
                    old_invites_state = {inv['invite_code']: inv['uses'] for inv in db_invites}
                else:
                    # Utiliser le cache en mémoire
                    old_invites_state = self.invite_cache.get(guild.id, {}).copy()
                
                # AMÉLIORATION 3: Si le cache est vide, utiliser la DB comme fallback
                if not old_invites_state:
                    print(f"⚠️ Empty cache for {guild.name}, loading from DB...")
                    db_invites = await asyncio.to_thread(db.get_guild_invites, guild.id)
                    old_invites_state = {inv['invite_code']: inv['uses'] for inv in db_invites}
                
                inviter = None
                used_invite_code = None
                detected_method = None

                # AMÉLIORATION 4: Comparer avec plusieurs méthodes de détection
                # Méthode 1: Détection par augmentation d'utilisation
                for invite in current_invites:
                    old_uses = old_invites_state.get(invite.code, 0)
                    current_uses = invite.uses or 0
                    
                    # Détection d'une utilisation
                    if current_uses > old_uses:
                        inviter = invite.inviter
                        used_invite_code = invite.code
                        detected_method = f"uses increased ({old_uses} → {current_uses})"
                        print(f"✅ Detected: {invite.code} uses increased from {old_uses} to {current_uses}")
                        break
                
                # Méthode 2: Nouvelle invitation utilisée pour la première fois
                if not inviter:
                    for invite in current_invites:
                        current_uses = invite.uses or 0
                        if invite.code not in old_invites_state and current_uses >= 1:
                            inviter = invite.inviter
                            used_invite_code = invite.code
                            detected_method = f"new invite first use (uses: {current_uses})"
                            print(f"✅ Detected: New invite {invite.code} used for first time")
                            break
                
                # Méthode 3: Si toujours pas détecté, chercher l'invitation avec le plus d'utilisations récentes
                if not inviter:
                    print(f"⚠️ Standard detection failed for {member.name}, trying alternative method...")
                    # Trouver l'invitation qui a le plus de chances d'avoir été utilisée
                    # (celle avec le plus d'utilisations ou la plus récente)
                    max_uses_invite = None
                    max_uses = 0
                    for invite in current_invites:
                        if invite.inviter and (invite.uses or 0) > max_uses:
                            max_uses = invite.uses or 0
                            max_uses_invite = invite
                    
                    if max_uses_invite and max_uses > 0:
                        inviter = max_uses_invite.inviter
                        used_invite_code = max_uses_invite.code
                        detected_method = f"fallback (highest uses: {max_uses})"
                        print(f"⚠️ Using fallback: Attributing to invite {used_invite_code} with {max_uses} uses")

                # AMÉLIORATION 5: Mettre à jour le cache IMMÉDIATEMENT pour éviter les désynchronisations
                if guild.id not in self.invite_cache:
                    self.invite_cache[guild.id] = {}
                
                for invite in current_invites:
                    self.invite_cache[guild.id][invite.code] = invite.uses or 0

                # AMÉLIORATION 6: Mettre à jour la base de données avec le nouvel état
                for invite in current_invites:
                    inviter_id = invite.inviter.id if invite.inviter else None
                    await asyncio.to_thread(
                        db.save_guild_invite,
                        guild_id=guild.id,
                        invite_code=invite.code,
                        inviter_id=inviter_id,
                        uses=invite.uses or 0
                    )

                # AMÉLIORATION 7: Enregistrer l'invitation même si l'inviter n'est pas détecté
                if inviter and inviter.id != member.id:
                    joined_at = datetime.now().isoformat()
                    
                    try:
                        await asyncio.to_thread(
                            db.add_invited_member,
                            member_id=member.id,
                            inviter_id=inviter.id,
                            joined_at=joined_at,
                            invite_code=used_invite_code,
                            invite_plan_eligible=True
                        )
                        
                        print(f"✅ {member.name} was invited by {inviter.name} (code: {used_invite_code}, method: {detected_method})")
                        
                        try:
                            log_channel = guild.get_channel(self.invite_log_channel_id)
                            if log_channel and isinstance(log_channel, (discord.TextChannel, discord.Thread)):
                                embed = discord.Embed(
                                    description=f"{member.mention} was invited by {inviter.mention}",
                                    color=0xE5E6EB
                                )
                                embed.set_footer(text=f"Detection: {detected_method}")
                                await log_channel.send(embed=embed)
                        except Exception as e:
                            print(f"Error sending invite log: {e}")
                    except Exception as e:
                        logging.error(f"Failed to record invitation for {member.name}: {e}")
                        # RETRY une fois
                        await asyncio.sleep(1)
                        try:
                            await asyncio.to_thread(
                                db.add_invited_member,
                                member_id=member.id,
                                inviter_id=inviter.id,
                                joined_at=joined_at,
                                invite_code=used_invite_code,
                                invite_plan_eligible=True
                            )
                            print(f"✅ Retry successful for {member.name}")
                        except Exception as retry_error:
                            logging.error(f"Retry failed for {member.name}: {retry_error}")
                else:
                    print(f"⚠️ Could not determine who invited {member.name}")
                    # Log pour investigation
                    logging.warning(f"Invite detection failed for {member.name} ({member.id}) in {guild.name}")

            except discord.Forbidden:
                print(f"❌ No permission to view invites for {guild.name}")
            except Exception as e:
                print(f"❌ Error processing invite on member join: {e}")
                import traceback
                traceback.print_exc()

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        """Detects when a member leaves the server and updates their invite status."""
        if member.bot:
            return

        left_at_iso = datetime.now().isoformat()
        
        invited_member_data = await asyncio.to_thread(db.get_invited_member, member.id)
        
        if invited_member_data:
            await asyncio.to_thread(db.update_member_leave_time, member.id, left_at_iso)
            print(f"{member.name} left the server.")

    @commands.hybrid_command(name="invite", description="Display your invite statistics.")
    @app_commands.guild_only()
    async def invite(self, ctx: commands.Context, member: discord.Member | None = None):
        """Displays the invite statistics of a member."""
        target = member or ctx.author
        user_id = target.id
        
        invited_members_data = await asyncio.to_thread(db.get_members_invited_by, user_id)

        total_invites = len(invited_members_data)
        left_invites = sum(1 for m in invited_members_data if m['left_at'])
        valid_invites = total_invites - left_invites

        embed = discord.Embed(
            title=f"Invite Statistics - {target.display_name}",
            color=0xE5E6EB
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        
        embed.add_field(name="Total Invites", value=f"**{total_invites}**", inline=True)
        embed.add_field(name="Valid Invites", value=f"**{valid_invites}** (in server)", inline=True)
        embed.add_field(name="Left Invites", value=f"**{left_invites}**", inline=True)

        await ctx.send(embed=embed, ephemeral=True)

    @commands.hybrid_command(name="addinvite", description="[ADMIN] Manually add an invitation record.")
    @app_commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def addinvite(self, ctx: commands.Context, inviter: discord.Member, invited: discord.Member, invite_code: str = "MANUAL"):
        """
        Manually add an invitation record to the database.
        Usage: !addinvite @inviter @invited [invite_code]
        """
        # Vérifications de sécurité
        if inviter.bot or invited.bot:
            await ctx.send("❌ Cannot add invitations for bots.", ephemeral=True)
            return
        
        if inviter.id == invited.id:
            await ctx.send("❌ A member cannot invite themselves.", ephemeral=True)
            return
        
        # Vérifier si l'invited est bien dans le serveur
        if invited not in ctx.guild.members:
            await ctx.send(f"❌ {invited.mention} is not in this server.", ephemeral=True)
            return
        
        # Vérifier si cette invitation existe déjà
        existing_record = await asyncio.to_thread(db.get_invited_member, invited.id)
        if existing_record:
            # Récupérer l'ancien inviter
            try:
                old_inviter = await ctx.guild.fetch_member(existing_record['inviter_id'])
                old_inviter_mention = old_inviter.mention
            except:
                old_inviter_mention = f"<@{existing_record['inviter_id']}>"
            
            await ctx.send(
                f"⚠️ **Warning:** {invited.mention} already has an invitation record.\n"
                f"Current inviter: {old_inviter_mention}\n"
                f"Do you want to **replace** it with {inviter.mention}?\n"
                f"React with ✅ to confirm or ❌ to cancel.",
                ephemeral=True
            )
            
            # Attendre la confirmation (note: pour simplifier, on va juste demander une nouvelle commande)
            await ctx.send(
                f"To replace, use: `!replaceinvite {invited.id} {inviter.id} {invite_code}`",
                ephemeral=True
            )
            return
        
        # === MISE À JOUR DES INVITATIONS (DB + CACHE) ===
        try:
            await ctx.send("🔄 Updating invite cache and database...", ephemeral=True)
            
            # Récupérer toutes les invitations actuelles de Discord
            current_invites = await ctx.guild.invites()
            
            # Initialiser le cache si nécessaire
            if ctx.guild.id not in self.invite_cache:
                self.invite_cache[ctx.guild.id] = {}
            
            # Mettre à jour la DB et le cache pour chaque invitation
            updated_count = 0
            for invite in current_invites:
                inviter_id = invite.inviter.id if invite.inviter else None
                current_uses = invite.uses or 0
                
                # Mettre à jour la DB
                await asyncio.to_thread(
                    db.save_guild_invite,
                    guild_id=ctx.guild.id,
                    invite_code=invite.code,
                    inviter_id=inviter_id,
                    uses=current_uses
                )
                
                # Mettre à jour le cache
                self.invite_cache[ctx.guild.id][invite.code] = current_uses
                updated_count += 1
            
            print(f"✅ Updated {updated_count} invites in cache and database for {ctx.guild.name}")
            
        except discord.Forbidden:
            await ctx.send("⚠️ Cannot update invites: Missing permissions to view server invites.", ephemeral=True)
        except Exception as e:
            await ctx.send(f"⚠️ Error updating invites: {e}", ephemeral=True)
            print(f"Error updating invites in addinvite: {e}")
        
        # === AJOUTER L'INVITATION MANUELLE ===
        joined_at = datetime.now().isoformat()
        try:
            await asyncio.to_thread(
                db.add_invited_member,
                member_id=invited.id,
                inviter_id=inviter.id,
                joined_at=joined_at,
                invite_code=invite_code,
                invite_plan_eligible=True
            )
            
            # Log dans le channel d'invitations
            try:
                log_channel = ctx.guild.get_channel(self.invite_log_channel_id)
                if log_channel and isinstance(log_channel, (discord.TextChannel, discord.Thread)):
                    embed = discord.Embed(
                        description=f"[MANUAL] {invited.mention} was manually added as invited by {inviter.mention} (by {ctx.author.mention})",
                        color=0xFFA500  # Orange pour les ajouts manuels
                    )
                    await log_channel.send(embed=embed)
            except Exception as e:
                print(f"Error sending manual invite log: {e}")
            
            # Confirmation
            embed = discord.Embed(
                title="✅ Invitation Added",
                description=f"{invited.mention} has been added as invited by {inviter.mention}",
                color=0x00FF00
            )
            embed.add_field(name="Invite Code", value=f"`{invite_code}`", inline=True)
            embed.add_field(name="Invites Updated", value=f"`{updated_count}` invite links synced", inline=True)
            embed.add_field(name="Added by", value=ctx.author.mention, inline=False)
            await ctx.send(embed=embed, ephemeral=True)
            
            print(f"[MANUAL] {invited.name} added as invited by {inviter.name} (code: {invite_code}) by admin {ctx.author.name}")
            
        except Exception as e:
            await ctx.send(f"❌ Error adding invitation: {e}", ephemeral=True)
            print(f"Error in addinvite command: {e}")
            import traceback
            traceback.print_exc()

    @commands.hybrid_command(name="removeinvite", description="[ADMIN] Remove an invitation record.")
    @app_commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def removeinvite(self, ctx: commands.Context, invited: discord.Member):
        """
        Remove an invitation record from the database.
        Usage: !removeinvite @invited
        """
        existing_record = await asyncio.to_thread(db.get_invited_member, invited.id)
        
        if not existing_record:
            await ctx.send(f"❌ No invitation record found for {invited.mention}.", ephemeral=True)
            return
        
        # Supprimer l'enregistrement en marquant left_at
        left_at = datetime.now().isoformat()
        await asyncio.to_thread(db.update_member_leave_time, invited.id, left_at)
        
        embed = discord.Embed(
            title="🗑️ Invitation Removed",
            description=f"Invitation record for {invited.mention} has been removed.",
            color=0xFF0000
        )
        embed.add_field(name="Removed by", value=ctx.author.mention, inline=True)
        await ctx.send(embed=embed, ephemeral=True)
        
        print(f"[MANUAL] Invitation record for {invited.name} removed by admin {ctx.author.name}")

    @commands.hybrid_command(name="syncinvites", description="[ADMIN] Manually synchronize all invite links with Discord.")
    @app_commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def syncinvites(self, ctx: commands.Context):
        """
        Manually synchronize all server invites with the database and cache.
        This updates all invite links and their use counts.
        Usage: !syncinvites
        """
        await ctx.defer(ephemeral=True)
        
        # Marquer la synchronisation en cours
        self._sync_in_progress[ctx.guild.id] = True
        
        try:
            guild = ctx.guild
            
            # Récupérer l'ancien état (DB)
            db_invites_list = await asyncio.to_thread(db.get_guild_invites, guild.id)
            old_invite_map = {inv['invite_code']: inv for inv in db_invites_list}
            
            # Récupérer l'état actuel (Discord)
            current_invites = await guild.invites()
            current_invite_map = {invite.code: invite for invite in current_invites}
            
            # Initialiser le cache si nécessaire
            if guild.id not in self.invite_cache:
                self.invite_cache[guild.id] = {}
            
            updated_count = 0
            new_count = 0
            removed_count = 0
            changes_detected = []
            
            # Mettre à jour les invitations existantes et ajouter les nouvelles
            for invite_code, current_invite in current_invite_map.items():
                inviter_id = current_invite.inviter.id if current_invite.inviter else None
                current_uses = current_invite.uses or 0
                old_uses = old_invite_map.get(invite_code, {}).get('uses', 0)
                
                # Détecter les changements
                if invite_code in old_invite_map:
                    if current_uses != old_uses:
                        changes_detected.append(f"• `{invite_code}`: {old_uses} → {current_uses} uses")
                    updated_count += 1
                else:
                    changes_detected.append(f"• `{invite_code}`: New invite (0 → {current_uses} uses)")
                    new_count += 1
                
                # Mettre à jour la DB
                await asyncio.to_thread(
                    db.save_guild_invite,
                    guild_id=guild.id,
                    invite_code=invite_code,
                    inviter_id=inviter_id,
                    uses=current_uses
                )
                
                # Mettre à jour le cache
                self.invite_cache[guild.id][invite_code] = current_uses
            
            # Supprimer les invitations qui n'existent plus sur Discord
            for invite_code in old_invite_map.keys():
                if invite_code not in current_invite_map:
                    await asyncio.to_thread(db.delete_guild_invite, guild.id, invite_code)
                    if invite_code in self.invite_cache[guild.id]:
                        del self.invite_cache[guild.id][invite_code]
                    changes_detected.append(f"• `{invite_code}`: Removed (expired/deleted)")
                    removed_count += 1
            
            # Créer l'embed de confirmation
            embed = discord.Embed(
                title="✅ Invite Synchronization Complete",
                color=0x00FF00
            )
            
            embed.add_field(
                name="📊 Summary",
                value=f"**Updated:** {updated_count}\n**New:** {new_count}\n**Removed:** {removed_count}",
                inline=False
            )
            
            if changes_detected:
                changes_text = "\n".join(changes_detected[:10])  # Limiter à 10 changements
                if len(changes_detected) > 10:
                    changes_text += f"\n... and {len(changes_detected) - 10} more changes"
                embed.add_field(
                    name="🔍 Changes Detected",
                    value=changes_text,
                    inline=False
                )
            else:
                embed.add_field(
                    name="🔍 Changes Detected",
                    value="No changes detected. All invites were already up to date.",
                    inline=False
                )
            
            embed.set_footer(text=f"Synchronized by {ctx.author.display_name}")
            embed.timestamp = datetime.now()
            
            await ctx.send(embed=embed, ephemeral=True)
            
            print(f"[SYNC] Invites synchronized by {ctx.author.name}: {updated_count} updated, {new_count} new, {removed_count} removed")
            
        except discord.Forbidden:
            await ctx.send("❌ Cannot synchronize invites: Missing permissions to view server invites.", ephemeral=True)
        except Exception as e:
            await ctx.send(f"❌ Error synchronizing invites: {e}", ephemeral=True)
            print(f"Error in syncinvites command: {e}")
            import traceback
            traceback.print_exc()
        finally:
            # Retirer le flag de synchronisation en cours
            if ctx.guild.id in self._sync_in_progress:
                del self._sync_in_progress[ctx.guild.id]

async def setup(bot: commands.Bot):
    await bot.add_cog(Invite(bot))
