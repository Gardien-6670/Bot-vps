import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db

class AddCredits(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="add_credits", description="Add credits to a user")
    @app_commands.guild_only()
    @app_commands.describe(user="The user to add credits to", amount="The amount of credits to add")
    async def add_credits(self, ctx: commands.Context, user: discord.User, amount: int):
        AUTHORIZED_USER_ID = 1047760053509312642  # REPLACE THIS WITH THE AUTHORIZED USER ID

        if ctx.author.id not in [AUTHORIZED_USER_ID, 1286418351035388006]:
            await ctx.send("You do not have permission to use this command.", ephemeral=True)
            return

        if amount <= 0:
            await ctx.send("The amount must be positive.", ephemeral=True)
            return

        db.add_credits(user.id, amount)
        new_balance = db.get_balance(user.id)

        embed = discord.Embed(title="Credits Added", color=0xE5E6EB)
        embed.add_field(name="User", value=user.mention, inline=True)
        embed.add_field(name="Amount", value=amount, inline=True)
        embed.add_field(name="New Balance", value=new_balance, inline=False)

        await ctx.send(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(AddCredits(bot))
