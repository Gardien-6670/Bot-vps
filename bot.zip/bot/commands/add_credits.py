import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
from utils.transaction_notifications import notify_important_transaction
import logging

class AddCredits(commands.Cog):
 def __init__(self, bot: commands.Bot):
 self.bot = bot

 @commands.hybrid_command(name="add_credits", description="Add credits to a user")
 @app_commands.guild_only()
 @app_commands.describe(
 user="The user to add credits to",
 amount="The amount of credits to add",
 reason="Reason for adding credits (required)"
 )
 async def add_credits(self, ctx: commands.Context, user: discord.User, amount: int, *, reason: str):
 AUTHORIZED_USER_ID = 1047760053509312642 # REPLACE THIS WITH THE AUTHORIZED USER ID

 if ctx.author.id not in [AUTHORIZED_USER_ID, 1286418351035388006]:
 await ctx.send("You do not have permission to use this command.", ephemeral=True)
 return

 if amount <= 0:
 await ctx.send("The amount must be positive.", ephemeral=True)
 return
 
 if not reason or len(reason.strip()) < 3:
 await ctx.send("Please provide a valid reason (at least 3 characters).", ephemeral=True)
 return

 try:
 # Get balance before
 balance_before = db.get_balance(user.id)
 
 # Add credits with reason
 db.add_credits(user.id, amount, reason=f"Admin {ctx.author.name}: {reason}")
 
 # Get balance after
 new_balance = db.get_balance(user.id)
 
 # Send notification for important transactions
 await notify_important_transaction(
 self.bot,
 user.id,
 'credit_add',
 amount,
 new_balance,
 f"Admin {ctx.author.name}: {reason}"
 )

 embed = discord.Embed(title="[OK] Credits Added", color=0x2ECC71)
 embed.add_field(name="User", value=user.mention, inline=True)
 embed.add_field(name="Amount", value=f"+{amount}", inline=True)
 embed.add_field(name="Balance", value=f"{balance_before} → {new_balance}", inline=False)
 embed.add_field(name="Reason", value=reason, inline=False)
 embed.set_footer(text=f"Transaction logged • Admin: {ctx.author.name}")

 await ctx.send(embed=embed)
 
 # Notify user
 try:
 user_embed = discord.Embed(
 title=" Credits Added to Your Account",
 description=f"An administrator has added **{amount} credits** to your account.",
 color=0x2ECC71
 )
 user_embed.add_field(name="New Balance", value=f"{new_balance} credits", inline=True)
 user_embed.add_field(name="Reason", value=reason, inline=False)
 await user.send(embed=user_embed)
 except discord.Forbidden:
 logging.warning(f"Could not send credit notification to user {user.id} (DMs disabled)")
 
 except Exception as e:
 logging.error(f"Error adding credits: {e}", exc_info=True)
 await ctx.send(f"Error adding credits: {e}", ephemeral=True)

async def setup(bot: commands.Bot):
 await bot.add_cog(AddCredits(bot))
