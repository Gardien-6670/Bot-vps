import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
import aiohttp
import os
import time
import logging
import asyncio
from datetime import datetime, timedelta
from utils.database import db
from utils.billing import try_renew_vps

PAYPAL_CATEGORY_ID = 1338195687317311508
ADMIN_ID = 1047760053509312642
PAYPAL_EMAIL = "jordancordierzhang@gmail.com"


class CreditsModal(ui.Modal, title="Add Credits"):
    credits = ui.TextInput(label="Amount of credits to add")

    def __init__(self, bot, channel_id):
        super().__init__()
        self.bot = bot
        self.channel_id = channel_id

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            credits_to_add = int(self.credits.value)
        except ValueError:
            await interaction.followup.send(
                "Please enter a valid number.", ephemeral=True
            )
            return

        if credits_to_add <= 0:
            await interaction.followup.send(
                "Please enter a positive number.", ephemeral=True
            )
            return

        conn = None
        cursor = None
        try:
            transaction = db.get_paypal_transaction_by_channel(self.channel_id)
            if not transaction:
                await interaction.followup.send(
                    "Could not find the transaction for this channel.", ephemeral=True
                )
                return

            if transaction["status"] != "pending":
                await interaction.followup.send(
                    f"Transaction {transaction['track_id']} is not pending. Current status: {transaction['status']}.",
                    ephemeral=True,
                )
                return

            conn, cursor = db.start_transaction()

            db.approve_paypal_transaction(
                transaction["id"],
                credits_to_add,
                interaction.user.id,
                cursor=cursor,
                conn=conn,
            )
            db.add_credits(
                transaction["user_id"], credits_to_add, cursor=cursor, conn=conn
            )
            db.commit_transaction(conn, cursor)

            user = await self.bot.fetch_user(transaction["user_id"])
            if interaction.guild:
                try:
                    member = await interaction.guild.fetch_member(
                        transaction["user_id"]
                    )
                    if member:
                        role = member.guild.get_role(1358004192416890903)
                        if role and role not in member.roles:
                            await member.add_roles(role)
                except discord.HTTPException:
                    pass
            try:
                embed = discord.Embed(
                    title="Payment Approved",
                    description=f"{credits_to_add} credits have been added to your account.",
                    color=0xE5E6EB,
                )
                await user.send(embed=embed)
            except discord.Forbidden:
                pass

            if isinstance(interaction.channel, (discord.TextChannel, discord.Thread)):
                await interaction.channel.delete()
        except ValueError as ve:
            if conn and cursor:
                db.rollback_transaction(conn, cursor)
            await interaction.followup.send(f"Error: {ve}", ephemeral=True)
        except Exception as e:
            if conn and cursor:
                db.rollback_transaction(conn, cursor)
            await interaction.followup.send(
                f"An unexpected error occurred: {e}", ephemeral=True
            )


class AdminApprovalView(ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @ui.button(
        label="Approve",
        style=discord.ButtonStyle.success,
        custom_id="admin_approve_button",
    )
    async def approve_button(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in [ADMIN_ID, 1286418351035388006]:
            await interaction.response.send_message(
                "You are not authorized to perform this action.", ephemeral=True
            )
            return

        if not interaction.channel_id:
            await interaction.response.send_message(
                "Could not determine channel ID.", ephemeral=True
            )
            return
        await interaction.response.send_modal(
            CreditsModal(self.bot, interaction.channel_id)
        )

    @ui.button(label="Decline", style=discord.ButtonStyle.danger)
    async def decline_button(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=True)
        if interaction.user.id not in [ADMIN_ID, 1286418351035388006]:
            await interaction.followup.send(
                "You are not authorized to perform this action.", ephemeral=True
            )
            return

        if not interaction.channel_id:
            await interaction.followup.send(
                "Could not determine channel ID.", ephemeral=True
            )
            return
        transaction = db.get_paypal_transaction_by_channel(interaction.channel_id)
        if not transaction:
            await interaction.followup.send(
                "Could not find the transaction for this channel.", ephemeral=True
            )
            return

        db.decline_paypal_transaction(transaction["id"], interaction.user.id)

        user = await self.bot.fetch_user(transaction["user_id"])
        try:
            embed = discord.Embed(
                title="Payment Declined",
                description="Your payment has been refused, and no credits will be added.",
                color=0x992D22,
            )
            await user.send(embed=embed)
        except discord.Forbidden:
            pass

        if isinstance(interaction.channel, (discord.TextChannel, discord.Thread)):
            await interaction.channel.delete()


class PaypalUsernameModal(ui.Modal, title="PayPal Transaction"):
    paypal_username = ui.TextInput(label="Please enter your PayPal username")

    def __init__(self, view):
        super().__init__()
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        paypal_username = self.paypal_username.value
        if not interaction.guild:
            await interaction.followup.send(
                "This command must be used in a server.", ephemeral=True
            )
            return
        category = self.view.bot.get_channel(PAYPAL_CATEGORY_ID)
        if not category:
            await interaction.followup.send(
                "Could not find the PayPal category.", ephemeral=True
            )
            return

        admin_user = interaction.guild.get_member(ADMIN_ID)
        if not admin_user:
            await interaction.followup.send(
                "Could not find the admin user.", ephemeral=True
            )
            return

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(
                read_messages=False
            ),
            self.view.target_user: discord.PermissionOverwrite(
                read_messages=True, send_messages=True
            ),
            admin_user: discord.PermissionOverwrite(
                read_messages=True, send_messages=True
            ),
        }

        channel = await category.create_text_channel(
            name=f"paypal-{self.view.target_user.name}",
            overwrites=overwrites,
        )

        db.create_paypal_transaction(
            self.view.target_user.id, channel.id, paypal_username
        )

        embed = discord.Embed(
            title="PayPal Payment",
            description=f"Please send the desired amount to the following PayPal address: `{PAYPAL_EMAIL}`",
            color=0xE5E6EB,
        )
        embed.add_field(
            name="Important", value="All transaction fees are your responsibility."
        )
        embed.add_field(
            name="Verification",
            value="Your payment will be manually verified within 24 hours.",
        )
        embed.add_field(
            name="Credits to buy", value=f"{self.view.credits}", inline=True
        )
        embed.add_field(name="PayPal User", value=paypal_username, inline=True)

        await channel.send(embed=embed, view=AdminApprovalView(self.view.bot))

        await interaction.followup.send(
            f"A private channel has been created for your PayPal payment: {channel.mention}",
            ephemeral=True,
        )


class PaymentView(ui.View):
    def __init__(self, bot, price, credits, target_user):
        super().__init__(timeout=180)
        self.bot = bot
        self.price = price
        self.credits = credits
        self.target_user = target_user
        self.oxapay_merchant_key = os.getenv("OXAPAY_MERCHANT_KEY")

    @ui.button(label="Cryptocurrency", style=discord.ButtonStyle.primary)
    async def crypto_button(self, interaction: discord.Interaction, button: ui.Button):
        if not self.oxapay_merchant_key:
            await interaction.response.send_message(
                "The cryptocurrency payment configuration is not complete. Please contact an administrator.",
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        async with aiohttp.ClientSession() as session:
            payload = {
                "merchant": self.oxapay_merchant_key,
                "amount": self.price,
                "currency": "USD",
                "lifeTime": 90,
            }
            try:
                # ✅ Ajouter un timeout pour éviter les blocages
                async with session.post(
                    "https://api.oxapay.com/merchants/request", 
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pay_link = data.get("payLink")
                        track_id = data.get("trackId")

                        if pay_link and track_id:
                            expiration_time = datetime.now() + timedelta(minutes=90)
                            db.add_transaction(
                                track_id,
                                self.target_user.id,
                                self.credits,
                                expiration_time,
                                interaction.guild.id,
                            )

                            embed = discord.Embed(
                                title="Payment for Credits",
                                description=f"Click the link below to pay **${self.price:.2f}** for **{self.credits} credits**.",
                                color=0xE5E6EB,
                            )
                            embed.add_field(
                                name="Payment Link",
                                value=f"[Click here to pay]({pay_link})",
                                inline=False,
                            )
                            embed.add_field(
                                name="Transaction ID", value=f"`{track_id}`", inline=False
                            )
                            embed.add_field(
                                name="Valid for", value="90 minutes", inline=False
                            )
                            embed.set_footer(
                                text="The bot will automatically detect your payment."
                            )

                            try:
                                await self.target_user.send(embed=embed)
                                await interaction.followup.send(
                                    "Payment link sent to your DMs!", ephemeral=True
                                )
                            except discord.Forbidden:
                                await interaction.followup.send(embed=embed, ephemeral=True)
                        else:
                            await interaction.followup.send(
                                "An error occurred while creating the payment. Please try again.",
                                ephemeral=True,
                            )
                    else:
                        await interaction.followup.send(
                            f"OxaPay API Error: {resp.status}", ephemeral=True
                        )
            except Exception as e:
                await interaction.followup.send(f"An error occurred: {e}", ephemeral=True)

    @ui.button(label="PayPal", style=discord.ButtonStyle.secondary)
    async def paypal_button(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(PaypalUsernameModal(self))


class BuyCredits(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.oxapay_merchant_key = os.getenv("OXAPAY_MERCHANT_KEY")
        self.check_payments.start()

    async def cog_unload(self) -> None:
        self.check_payments.cancel()

    @commands.hybrid_command(name="buy_credits", description="Buy credits")
    @app_commands.guild_only()
    @app_commands.describe(
        credits="The amount of credits to buy",
        user="The user to buy credits for (optional)",
    )
    async def buy_credits(
        self, ctx: commands.Context, credits: int, user: discord.User | None = None
    ):
        if credits < 9:
            await ctx.send("The minimum amount of credits to buy is 9.", ephemeral=True)
            return

        target_user = user if user else ctx.author
        price = round((credits / 100) * 1.14, 2)

        embed = discord.Embed(
            title="Choose your payment method",
            description=f"You are about to buy **{credits}** credits for **${price:.2f}**.",
            color=0xE5E6EB,
        )

        await ctx.send(
            embed=embed,
            view=PaymentView(self.bot, price, credits, target_user),
            ephemeral=True,
        )

    @tasks.loop(seconds=5)
    async def check_payments(self):
        # 1. Check for regular credit purchases
        pending_transactions = db.get_pending_transactions()

        for transaction in pending_transactions:
            await self.process_credit_transaction(transaction)
        await asyncio.sleep(1)

        # 2. Check for dedicated server order payments
        pending_dedicated_orders = db.get_pending_dedicated_orders()
        for order in pending_dedicated_orders:
            await self.process_dedicated_order(order)
        await asyncio.sleep(1)

        # 3. Check for dedicated VPS renewal payments
        try:
            pending_renewal_orders = db.get_pending_dedicated_renewal_orders()
            for order in pending_renewal_orders:
                await self.process_dedicated_renewal_order(order)
            await asyncio.sleep(1)
        except AttributeError:
            # Function doesn't exist yet, skip
            pass

    async def process_credit_transaction(self, transaction: dict):
        track_id = transaction["track_id"]
        user_id = int(transaction["user_id"])
        credits = int(transaction["credits"])
        expiration_time = transaction["expiration_time"]
        guild_id = transaction.get("guild_id")

        db.mark_transaction_as_processing(track_id)

        if datetime.now() > expiration_time:
            db.mark_transaction_as_expired(track_id)
            return

        is_paid = await self.is_oxapay_paid(track_id)
        if is_paid:
            conn, cursor = db.start_transaction()
            try:
                check_trans = db.get_transaction(track_id, cursor=cursor, conn=conn)
                if check_trans["status"] == "completed":
                    db.rollback_transaction(conn, cursor)
                    return

                db.add_credits(user_id, credits, cursor=cursor, conn=conn)
                db.mark_transaction_as_completed(track_id, cursor=cursor, conn=conn)
                db.commit_transaction(conn, cursor)
                logging.info(
                    f"Successfully processed and committed transaction {track_id} for user {user_id}."
                )

                await try_renew_vps(self.bot, user_id)
                member = None
                if guild_id:
                    guild = self.bot.get_guild(guild_id)
                    if guild:
                        member = guild.get_member(user_id)
                        if not member:
                            try:
                                member = await guild.fetch_member(user_id)
                            except discord.NotFound:
                                member = None

                if member:
                    role_id = 1358004192416890903
                    role = guild.get_role(role_id)
                    if role and role not in member.roles:
                        try:
                            await member.add_roles(role)
                            logging.info(
                                f"Assigned role {role.name} to member {user_id} in guild {guild_id}."
                            )
                        except discord.Forbidden:
                            logging.warning(f"Failed to add role to member {user_id}.")
                        except discord.HTTPException as e:
                            logging.error(
                                f"HTTP error adding role to member {user_id}: {e}"
                            )

                user = await self.bot.fetch_user(user_id)
                embed = discord.Embed(
                    title="Payment Confirmed!",
                    description=f"**{credits} credits** have been added to your account.",
                    color=0x2ECC71,
                )
                embed.add_field(
                    name="Transaction ID", value=f"`{track_id}`", inline=False
                )
                try:
                    await user.send(embed=embed)
                except discord.Forbidden:
                    logging.warning(
                        f"Could not send DM to user {user_id} for transaction {track_id}."
                    )

            except Exception as e:
                if (
                    conn
                    and cursor
                    and hasattr(conn, "is_connected")
                    and conn.is_connected()
                ):
                    db.rollback_transaction(conn, cursor)
                print(f"Error processing database transaction for {track_id}: {e}")
                db.mark_transaction_as_pending(track_id)
                return
        else:
            db.mark_transaction_as_pending(track_id)

    async def process_dedicated_order(self, order: dict):
        track_id = order["track_id"]
        order_id = order["id"]
        user_id = order["user_id"]

        is_paid = await self.is_oxapay_paid(track_id)
        if is_paid:
            conn, cursor = db.start_transaction()
            try:
                check_order = db.get_dedicated_order(order_id, cursor=cursor, conn=conn)
                if check_order and check_order["status"] != "pending_payment":
                    db.rollback_transaction(conn, cursor)
                    return

                db.update_dedicated_order_status(
                    order_id, "paid", cursor=cursor, conn=conn
                )
                db.commit_transaction(conn, cursor)

                plans_cog = self.bot.get_cog("Plans")
                if plans_cog:
                    await plans_cog.notify_admin_for_setup(order_id)

                try:
                    user = await self.bot.fetch_user(user_id)
                    embed = discord.Embed(
                        title="Dedicated Server Payment Confirmed!",
                        description="Your order has been paid and an administrator has been notified. Your server will be provisioned shortly.",
                        color=0x2ECC71,
                    )
                    embed.add_field(
                        name="Order ID", value=f"`{order_id}`", inline=False
                    )
                    await user.send(embed=embed)
                except discord.Forbidden:
                    pass

            except Exception as e:
                if conn and cursor:
                    db.rollback_transaction(conn, cursor)
                print(f"Error processing paid dedicated order {order_id}: {e}")

    async def process_dedicated_renewal_order(self, order: dict):
        """Process a dedicated VPS renewal order payment."""
        track_id = order["track_id"]
        order_id = order["id"]
        user_id = order["user_id"]
        container_name = order["container_name"]
        months = order["months"]

        is_paid = await self.is_oxapay_paid(track_id)
        if is_paid:
            conn, cursor = db.start_transaction()
            try:
                check_order = db.get_dedicated_renewal_order_by_track_id(
                    track_id, cursor=cursor, conn=conn
                )
                if check_order and check_order["status"] != "pending":
                    db.rollback_transaction(conn, cursor)
                    return

                success = db.extend_vps_expiry_by_months(
                    container_name, months, cursor=cursor, conn=conn
                )
                if success:
                    db.update_dedicated_renewal_order_status(
                        order_id, "completed", cursor=cursor, conn=conn
                    )
                    db.commit_transaction(conn, cursor)

                    vps_info = db.get_vps_by_container_name(container_name)
                    new_due_date = vps_info.get("due_date") if vps_info else None

                    try:
                        user = await self.bot.fetch_user(user_id)
                        embed = discord.Embed(
                            title="[OK] VPS Renewal Confirmed!",
                            description=f"Your VPS `{container_name}` has been successfully renewed for **{months} month(s)**.",
                            color=0x2ECC71,
                        )
                        if new_due_date:
                            if isinstance(new_due_date, str):
                                new_due_date = datetime.fromisoformat(new_due_date)
                            embed.add_field(
                                name="New Expiry Date",
                                value=new_due_date.strftime("%Y-%m-%d %H:%M UTC"),
                                inline=False,
                            )
                        embed.add_field(
                            name="Duration Added",
                            value=f"{months} month(s)",
                            inline=True,
                        )
                        embed.set_footer(text="Thank you for your payment!")
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(
                            f"Could not send renewal confirmation to user {user_id} (DMs disabled)"
                        )
                    except Exception as e:
                        logging.error(
                            f"Error sending renewal confirmation to user {user_id}: {e}"
                        )
                else:
                    db.rollback_transaction(conn, cursor)
                    logging.error(
                        f"Failed to extend VPS {container_name} expiry for renewal order {order_id}"
                    )

            except Exception as e:
                if conn and cursor:
                    db.rollback_transaction(conn, cursor)
                logging.error(
                    f"Error processing paid renewal order {order_id}: {e}",
                    exc_info=True,
                )

    async def is_oxapay_paid(self, track_id: str) -> bool:
        """Checks if an OxaPay transaction is paid. Returns True if paid, False otherwise."""
        if not self.oxapay_merchant_key:
            return False
        headers = {"merchant_api_key": self.oxapay_merchant_key}
        url = f"https://api.oxapay.com/v1/payment/{track_id}"
        async with aiohttp.ClientSession() as session:
            try:
                # ✅ Ajouter un timeout pour éviter les blocages
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data.get("data", {}).get("status") == "paid"
                    else:
                        print(
                            f"OxaPay API Error checking track_id {track_id}: {resp.status}"
                        )
                        return False
            except Exception as e:
                print(f"Error checking OxaPay payment {track_id}: {e}")
                return False

    @check_payments.before_loop
    async def before_check_payments(self):
        await self.bot.wait_until_ready()


async def setup(bot: commands.Bot):
    await bot.add_cog(BuyCredits(bot))
