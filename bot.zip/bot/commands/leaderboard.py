import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
import asyncio
from datetime import datetime  # Import datetime


class Leaderboard(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(
        name="leaderboard", description="Displays the invite leaderboard."
    )
    @app_commands.guild_only()
    async def leaderboard(self, ctx: commands.Context):
        leaderboard_data = await asyncio.to_thread(db.get_inviter_leaderboard_data)

        if not leaderboard_data:
            embed = discord.Embed(
                title="Invite Leaderboard",
                description="No invite data available yet.",
                color=0xE5E6EB,
            )
            await ctx.send(embed=embed, ephemeral=True)
            return

        leaderboard_data.sort(
            key=lambda x: x["valid_invites_count"] + x["left_invites_count"],
            reverse=True,
        )

        embed = discord.Embed(
            title="Invite Leaderboard",
            description="Top 10 inviters in the server.",
            color=0xE5E6EB,
        )

        for i, entry in enumerate(leaderboard_data[:10]):
            inviter_id = entry["inviter_id"]
            valid_invites = entry["valid_invites_count"]
            left_invites = entry["left_invites_count"]
            total_invites = valid_invites + left_invites

            inviter_user = self.bot.get_user(inviter_id)
            if not inviter_user:
                try:
                    inviter_user = await self.bot.fetch_user(inviter_id)
                except discord.NotFound:
                    inviter_user = None

            inviter_name = (
                inviter_user.display_name
                if inviter_user
                else f"Unknown User (ID: {inviter_id})"
            )

            embed.add_field(
                name=f"#{i+1} - {inviter_name}",
                value=f"**Valid:** {valid_invites} | **Left:** {left_invites}| **Total:** {total_invites}",
                inline=False,
            )

        embed.set_footer(text="Leaderboard based on all-time invites.")

        await ctx.send(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Leaderboard(bot))
