import discord
from discord.ext import commands, tasks
from discord import app_commands
import os
import requests
from datetime import datetime, timedelta
from utils.database import db
from utils.flask_earn_server import generate_random_token, normalize_ad_info, ensure_aware
import random
import string
import pytz
import logging

# Flask server details
PUBLIC_FLASK_HOST = os.getenv("PUBLIC_FLASK_HOST", "api-veridian.duckdns.org")
FLASK_PORT = 6028
FLASK_BASE_URL = f"https://{PUBLIC_FLASK_HOST}:{FLASK_PORT}"

# For internal communication from the bot to the flask server
INTERNAL_FLASK_URL = f"https://127.0.0.1:{FLASK_PORT}"

class AdReminderView(discord.ui.View):
 def __init__(self, command_cog, user_id, next_available_time_utc):
 super().__init__(timeout=Noe)
 self.command_cog = command_cog
 self.user_id = user_id
 self.next_available_time_utc = next_available_time_utc

 @discord.ui.button(label="Automatic Reminder", style=discord.ButtonStyle.green, custom_id="ad_reminder_enable")
 async def enable_reminder_button(self, interaction: discord.Interaction, button: discord.ui.Button):
 if interaction.user.id != self.user_id:
 await interaction.response.send_message("This button is not for you!", ephemeral=True)
 return
 db.set_ad_reminder(self.user_id, True, self.next_available_time_utc)
 await interaction.response.send_message(f"Automatic reminder enabled! I will send you a DM on {self.next_available_time_utc.strftime('%Y-%m-%d at %H:%M UTC')} when you can watch ads again.", ephemeral=True)

 @discord.ui.button(label="Disable Automatic Reminder", style=discord.ButtonStyle.red, custom_id="ad_reminder_disable")
 async def disable_reminder_button(self, interaction: discord.Interaction, button: discord.ui.Button):
 if interaction.user.id != self.user_id:
 await interaction.response.send_message("This button is not for you!", ephemeral=True)
 return
 db.set_ad_reminder(self.user_id, False)
 await interaction.response.send_message("Automatic reminder disabled.", ephemeral=True)

class WatchAds(commands.Cog):
 def __init__(self, bot: commands.Bot):
 self.bot = bot
 self.check_ad_reminders_loop.start()

 def cog_unload(self):
 self.check_ad_reminders_loop.cancel()

 @tasks.loop(minutes=1)
 async def check_ad_reminders_loop(self):
 await self.bot.wait_until_ready()
 users_to_remind = db.get_users_for_ad_reminder()
 for user_data in users_to_remind:
 user_id = user_data['user_id']
 try:
 user = await self.bot.fetch_user(user_id)
 if user:
 embed = discord.Embed(
 title="Your Daily Ad Watch is Available!",
 description="You can now watch ads again to earn credits. Use the `/earn` command to get your new link!",
 color=0xE5E6EB
 )
 await user.send(embed=embed)
 db.set_ad_reminder(user_id, False) # Disable reminder after sending
 self.bot.logger.info(f"Sent ad reminder to user {user_id}")
 except discord.Forbidden:
 db.set_ad_reminder(user_id, False)
 logging.warning(f"Cannot send ad reminder to user {user_id}. They may have blocked the bot or disabled DMs. Disabling reminders for this user.")
 except discord.HTTPException as e:
 logging.error(f"Failed to send ad reminder to user {user_id}: {e}")
 except Exception as e:
 logging.error(f"An unexpected error occurred while sending ad reminder to user {user_id}: {e}")

 @check_ad_reminders_loop.before_loop
 async def before_check_ad_reminders_loop(self):
 logging.info("Waiting for bot to be ready before starting ad reminder check loop...")
 await self.bot.wait_until_ready()
 logging.info("Bot ready, starting ad reminder check loop.")

 async def _get_or_create_ad_session(self, user_id: int) -> tuple[str, datetime, bool]:
 """
 Checks for an active ad session for the user. If one exists with a linkvertise method
 and no code yet, returns it. Otherwise generates a new one. No time limit on linkvertise.
 Returns: ad_token, expiration_time, is_new_session
 """
 logging.debug(f"[_get_or_create_ad_session] Starting for user {user_id}")
 ad_info = db.get_ad_code_info(user_id)
 logging.debug(f"[_get_or_create_ad_session] Raw ad_info from DB for user {user_id}: {ad_info}")
 
 if ad_info:
 ad_info = normalize_ad_info(ad_info)
 logging.debug(f"[_get_or_create_ad_session] Normalized ad_info for user {user_id}: {ad_info}")

 current_utc_time = datetime.now(pytz.utc)
 logging.debug(f"[_get_or_create_ad_session] Current UTC time: {current_utc_time}")

 # Check if user has an active linkvertise link without code
 if ad_info and ad_info.get('token') and ad_info.get('current_ad_method') == 'linkvertise':
 token_from_db = ad_info.get('token')
 token_length = len(token_from_db) if token_from_db else 0
 has_code = ad_info.get('current_ad_code') is not Noe
 
 logging.debug(f"[_get_or_create_ad_session] Found linkvertise session - Token: {token_from_db}, Has code: {has_code}")
 
 # If token is valid and no code yet, reuse it
 if token_length == 30 and not has_code:
 logging.debug(f"[_get_or_create_ad_session] Returning existing linkvertise session for user {user_id}. No code yet, can reuse.")
 # No expiration time limit for linkvertise, return a far future date
 return ad_info['token'], ad_info.get('ad_code_expiration') or (current_utc_time + timedelta(days=365)), False
 
 logging.debug(f"[_get_or_create_ad_session] No reusable linkvertise session found. Generating new session.")
 # Generate new session
 ad_token = generate_random_token(30)
 token_length = len(ad_token)
 # Expiration is now 4 hours. Will be extended for linkvertise on the flask server.
 expiration_time = current_utc_time + timedelta(hours=4)
 
 logging.debug(f"[_get_or_create_ad_session] Generated token: {ad_token}, Length: {token_length}")
 
 if token_length != 30:
 logging.error(f"[_get_or_create_ad_session] CRITICAL: Generated token has wrong length ({token_length})! Token: {ad_token}")
 ad_token = ''.join(random.choices(string.ascii_letters + string.digits, k=30))
 logging.debug(f"[_get_or_create_ad_session] Fallback token generated: {ad_token}, Length: {len(ad_token)}")
 
 db.store_ad_code(user_id, Noe, expiration_time, ad_token, Noe)
 logging.debug(f"[_get_or_create_ad_session] Generated and stored new session for user {user_id}. Token: {ad_token}")
 return ad_token, expiration_time, True

 @commands.hybrid_command(name="earn", description="Watch ads to earn credits (2 per day per method).")
 @app_commands.guild_only()
 async def earn(self, ctx: commands.Context):
 logging.info(f"Earn command called by {ctx.author.id} in guild {ctx.guild.id if ctx.guild else 'DM'}")
 await ctx.defer(ephemeral=True)
 user_id = ctx.author.id

 # Vérification simplifiée des limites quotidiennes
 if user_id not in [1047760053509312642, 1286418351035388006]:
 last_watch_cuty = db.get_last_watch_date(user_id, 'cuty')
 
 cuty_done = last_watch_cuty and (datetime.now(pytz.utc) - last_watch_cuty).days < 1
 
 # Check linkvertise limit
 daily_watches = db.get_linkvertise_daily_watches(user_id)
 today_utc = datetime.now(pytz.utc).date()
 today_watches = [watch for watch in daily_watches if watch.astimezone(pytz.utc).date() == today_utc]
 linkvertise_done = len(today_watches) >= 5

 if cuty_done and linkvertise_done:
 embed = discord.Embed(
 title="Daily Ad Limit Reached",
 description="You have already earned credits from all available methods today. Please try again tomorrow.",
 color=0x992D22
 )
 await ctx.send(embed=embed, ephemeral=True)
 return

 ad_token, expiration_time, is_new_session = await self._get_or_create_ad_session(user_id)

 flask_url = f"{FLASK_BASE_URL}/watch-ads/{user_id}/{ad_token}"

 if not is_new_session:
 embed = discord.Embed(
 title="You already have an active ad link!",
 description=(
 "You currently have an active ad session. Please use the existing link to earn VPS Points.\n\n"
 f"**Your active link:** [Continue Watching Ads]({flask_url})\n\n"
 "Linkvertise links never expire and can be reused until you submit a code."
 ),
 color=0x99AAB5
 )
 else:
 embed = discord.Embed(
 title="Watch Ads, Earn VPS Points!",
 description=(
 "Click the link below to go to our ad portal where you can choose an ad provider and earn **1 VPS Point**.\n\n"
 f"**[Click here to Watch Ads]({flask_url})**\n\n"
 "You will complete the entire process on the website, from choosing the provider to entering the final code.\n\n"
 "**Note:** Linkvertise links never expire. If you don't enter a code, the same link will be offered next time."
 ),
 color=0xE5E6EB
 )
 embed.set_footer(text="You can earn VPS Points from each ad provider (Cuty: 1/day, Linkvertise: 5/day).")

 await ctx.send(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
 await bot.add_cog(WatchAds(bot))