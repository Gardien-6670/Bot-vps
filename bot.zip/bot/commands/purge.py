import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
from utils import node_manager
import logging
import asyncio
from collections import defaultdict

AUTHORIZED_USER_ID = 1047760053509312642

# --- New Purge Flow Views (Steps 4-7) ---


class FinalConfirmationView(discord.ui.View):
    """Step 6/7: Final confirmation before executing the purge, refunds, and compensation."""

    def __init__(
        self, bot: commands.Bot, vps_to_delete: list, credit_refunds: dict, point_refunds: dict, compensation: int
    ):
        super().__init__(timeout=300)
        self.bot = bot
        self.vps_to_delete = vps_to_delete
        self.credit_refunds = credit_refunds
        self.point_refunds = point_refunds
        self.compensation = compensation

    @discord.ui.button(
        label="CONFIRM AND EXECUTE PURGE", style=discord.ButtonStyle.danger
    )
    async def confirm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.send_message(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        for item in self.children:
            item.disabled = True
        await interaction.edit_original_response(
            content="Purge operation in progress...", view=self, embed=None
        )

        # --- Step 1: Process Refunds and Compensation ---
        refund_report = []
        
        # Combine all users who need refunds
        all_users = set(self.credit_refunds.keys()) | set(self.point_refunds.keys())
        
        for user_id in all_users:
            credits_to_add = self.credit_refunds.get(user_id, 0) + self.compensation
            points_to_add = self.point_refunds.get(user_id, 0)
            
            conn = None
            cursor = None
            try:
                conn, cursor = db.start_transaction()
                
                # Add credits (refund + compensation)
                if credits_to_add > 0:
                    db.add_credits(user_id, credits_to_add, cursor=cursor, conn=conn)
                
                # Add VPS points (for ad-supported VPS)
                if points_to_add > 0:
                    db.add_vps_points(user_id, points_to_add, cursor=cursor, conn=conn)
                
                db.commit_transaction(conn, cursor)
                
                user = await self.bot.fetch_user(user_id)
                
                refund_parts = []
                if self.credit_refunds.get(user_id, 0) > 0:
                    refund_parts.append(f"{self.credit_refunds[user_id]} credits")
                if self.compensation > 0:
                    refund_parts.append(f"{self.compensation} compensation credits")
                if points_to_add > 0:
                    refund_parts.append(f"{points_to_add} VPS point{'s' if points_to_add > 1 else ''}")
                
                refund_text = " + ".join(refund_parts)
                refund_report.append(
                    f"- {refund_text} to {user.name} (`{user_id}`)."
                )
            except Exception as e:
                if conn and cursor:
                    db.rollback_transaction(conn, cursor)
                logging.error(f"Purge: Failed to refund/compensate user {user_id}: {e}")
                refund_report.append(
                    f"- **Failed** to process refunds for user `{user_id}`."
                )

        # --- Step 2: Delete VPS ---
        total_vps = len(self.vps_to_delete)
        deleted_count = 0
        failed_deletions = []

        for i, vps in enumerate(self.vps_to_delete):
            container_name = vps["container_name"]
            vps_id = vps["id"]
            vps_type = vps.get("vps_type", "lxc")

            await interaction.followup.send(
                f"Deleting VPS {i+1}/{total_vps}: `{container_name}`...", ephemeral=True
            )

            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                logging.error(
                    f"Purge: Could not determine node for {container_name}. Skipping deletion."
                )
                failed_deletions.append(f"`{container_name}` (Node not found)")
                db.delete_vps(vps_id)
                continue

            node_url, api_key = node_info["url"], node_info["api_key"]
            endpoint_prefix = (
                f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"
            )

            delete_result = await node_manager.api_request(
                "DELETE", f"{endpoint_prefix}/{container_name}", node_url, api_key
            )

            # ✅ Vérifier le résultat AVANT de supprimer de la DB
            if delete_result and (
                delete_result.get("deleted")
                or (vps_type == "kvm" and delete_result.get("status") == "success")
            ):
                # ✅ Supprimer de la DB SEULEMENT si l'API a réussi
                db.delete_vps(vps_id)
                logging.info(f"Purge: Deleted {vps_type.upper()} {container_name} from DB.")
                deleted_count += 1
            else:
                failed_deletions.append(
                    f"`{container_name}` (API error or already deleted)"
                )
                logging.error(f"Purge: Failed to delete {container_name} from API, not removing from DB")

        # --- Step 3: Final Report ---
        embed = discord.Embed(
            title="Purge - Step 7/7 - Purge Complete",
            color=0xE5E6EB if not failed_deletions else 0x99AAB5,
        )

        refund_report_text = (
            "\n".join(refund_report) if refund_report else "No refunds processed."
        )
        if len(refund_report_text) > 1024:
            refund_report_text = refund_report_text[:1020] + "\n..."

        embed.add_field(
            name="Credit Refunds & Compensation", value=refund_report_text, inline=False
        )
        embed.add_field(
            name="Successfully Deleted from DB", value=str(deleted_count), inline=True
        )
        embed.add_field(
            name="API Failures", value=str(len(failed_deletions)), inline=True
        )

        if failed_deletions:
            failed_deletions_text = "\n".join(failed_deletions)
            if len(failed_deletions_text) > 1024:
                failed_deletions_text = failed_deletions_text[:1020] + "\n..."
            embed.add_field(
                name="Failures (still deleted from DB)",
                value=failed_deletions_text,
                inline=False,
            )

        await interaction.followup.send(embed=embed, ephemeral=True)
        await interaction.edit_original_response(
            content="Purge operation finished.", embed=None, view=None
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.send_message(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            content="Purge cancelled.", embed=None, view=self
        )


class CompensationModal(discord.ui.Modal, title="Enter Compensation Amount"):
    compensation_amount = discord.ui.TextInput(
        label="Credits per user",
        style=discord.TextStyle.short,
        placeholder="e.g., 100",
        required=True,
        default="0",
    )

    def __init__(self, bot: commands.Bot, vps_to_delete: list, credit_refunds: dict, point_refunds: dict):
        super().__init__()
        self.bot = bot
        self.vps_to_delete = vps_to_delete
        self.credit_refunds = credit_refunds
        self.point_refunds = point_refunds

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        try:
            compensation = int(self.compensation_amount.value)
            if compensation < 0:
                raise ValueError
        except ValueError:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "Invalid amount. Please enter a non-negative number.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        # Move to final confirmation (Step 6)
        embed = discord.Embed(
            title="Purge - Step 6/7 - Final Confirmation",
            description="**WARNING:** This is the final step. The actions listed below are irreversible.",
            color=0x992D22,
        )

        total_credit_refund = sum(self.credit_refunds.values())
        total_point_refund = sum(self.point_refunds.values())
        
        refund_summary = []
        if total_credit_refund > 0:
            refund_summary.append(f"{total_credit_refund} credits")
        if total_point_refund > 0:
            refund_summary.append(f"{total_point_refund} VPS points")
        
        embed.add_field(
            name="Total Refunds",
            value=" + ".join(refund_summary) if refund_summary else "No refunds",
            inline=False,
        )
        embed.add_field(
            name="Compensation per User", value=f"{compensation} credits", inline=False
        )
        embed.add_field(
            name="Total VPS to Delete", value=f"{len(self.vps_to_delete)}", inline=False
        )

        view = FinalConfirmationView(
            self.bot, self.vps_to_delete, self.credit_refunds, self.point_refunds, compensation
        )
        await interaction.edit_original_response(embed=embed, view=view)


class CompensationView(discord.ui.View):
    """Step 5/7: Asks if compensation should be given."""

    def __init__(self, bot: commands.Bot, vps_to_delete: list, credit_refunds: dict, point_refunds: dict):
        super().__init__(timeout=300)
        self.bot = bot
        self.vps_to_delete = vps_to_delete
        self.credit_refunds = credit_refunds
        self.point_refunds = point_refunds

    @discord.ui.button(
        label="Yes, give compensation", style=discord.ButtonStyle.primary
    )
    async def yes_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        modal = CompensationModal(self.bot, self.vps_to_delete, self.credit_refunds, self.point_refunds)
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="No, just refund and purge", style=discord.ButtonStyle.secondary
    )
    async def no_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        embed = discord.Embed(
            title="Purge - Step 6/7 - Final Confirmation",
            description=f"**WARNING:** This is the final step. The actions listed below are irreversible.",
            color=0x992D22,
        )

        total_credit_refund = sum(self.credit_refunds.values())
        total_point_refund = sum(self.point_refunds.values())
        
        refund_summary = []
        if total_credit_refund > 0:
            refund_summary.append(f"{total_credit_refund} credits")
        if total_point_refund > 0:
            refund_summary.append(f"{total_point_refund} VPS points")
        
        embed.add_field(
            name="Total Refunds",
            value=" + ".join(refund_summary) if refund_summary else "No refunds",
            inline=False,
        )
        embed.add_field(name="Compensation per User", value="0 credits", inline=False)
        embed.add_field(
            name="Total VPS to Delete", value=f"{len(self.vps_to_delete)}", inline=False
        )

        view = FinalConfirmationView(self.bot, self.vps_to_delete, self.credit_refunds, self.point_refunds, 0)
        await interaction.edit_original_response(embed=embed, view=view)


class RefundConfirmationView(discord.ui.View):
    """Step 4/7: Shows calculated refunds and asks for confirmation."""

    def __init__(self, bot: commands.Bot, vps_to_delete: list, credit_refunds: dict, point_refunds: dict):
        super().__init__(timeout=300)
        self.bot = bot
        self.vps_to_delete = vps_to_delete
        self.credit_refunds = credit_refunds
        self.point_refunds = point_refunds

    @discord.ui.button(
        label="Confirm Refund and Continue", style=discord.ButtonStyle.danger
    )
    async def confirm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.send_message(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        # Move to compensation view (Step 5)
        embed = discord.Embed(
            title="Purge - Step 5/7 - Compensation",
            description="Should a compensation (in credits) be given to the affected users in addition to the refund?",
            color=0x99AAB5,
        )
        view = CompensationView(self.bot, self.vps_to_delete, self.credit_refunds, self.point_refunds)
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.send_message(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            content="Purge cancelled.", embed=None, view=self
        )


# --- Helper function to start the new purge flow ---


async def start_purge_flow(
    interaction: discord.Interaction,
    bot: commands.Bot,
    vps_to_delete: list,
    users_affected: set,
):
    """Calculates refunds and starts the new multi-step confirmation process."""
    if not vps_to_delete:
        await interaction.followup.send(
            "No VPS to delete for the selected users and their invitees.",
            ephemeral=True,
        )
        return

    # Calculate refunds - separate credits and VPS points
    credit_refunds = defaultdict(int)  # For paid VPS
    point_refunds = defaultdict(int)   # For ad-supported VPS
    
    for vps in vps_to_delete:
        user_id = vps["user_id"]
        plan_tier = vps.get("plan_tier")
        invite_plan_tier = vps.get("invite_plan_tier")
        
        # Check if it's an ad-supported VPS (has plan_tier or invite_plan_tier)
        is_ad_vps = (plan_tier and plan_tier != '') or (invite_plan_tier and invite_plan_tier != '')
        
        if is_ad_vps:
            # For ad-supported VPS, refund VPS points (typically 1 point per VPS)
            point_refunds[user_id] += 1
        else:
            # For paid VPS, refund credits based on cost
            cost = vps.get("cost_credits", 0)
            if cost > 0:
                credit_refunds[user_id] += cost

    total_credit_refund = sum(credit_refunds.values())
    total_point_refund = sum(point_refunds.values())
    
    # Combine all users who will receive refunds
    all_refund_users = set(credit_refunds.keys()) | set(point_refunds.keys())

    # Create refund confirmation embed (Step 4)
    embed = discord.Embed(
        title="Purge - Step 4/7 - Refunds",
        description="The following refunds will be processed for deleted VPS:\n• **Credits** for paid VPS\n• **VPS Points** for ad-supported VPS",
        color=0x99AAB5,
    )

    refund_details = []
    for user_id in all_refund_users:
        try:
            user = await bot.fetch_user(user_id)
            user_name = user.name
        except discord.NotFound:
            user_name = "Unknown User"
        
        credits = credit_refunds.get(user_id, 0)
        points = point_refunds.get(user_id, 0)
        
        refund_parts = []
        if credits > 0:
            refund_parts.append(f"{credits} credits")
        if points > 0:
            refund_parts.append(f"{points} VPS point{'s' if points > 1 else ''}")
        
        refund_text = " + ".join(refund_parts)
        refund_details.append(f"- **{user_name}** (`{user_id}`): {refund_text}")

    refund_text = "\n".join(refund_details)
    if len(refund_text) > 1024:
        refund_text = refund_text[:1020] + "\n..."

    embed.add_field(
        name=f"Refunds for {len(all_refund_users)} Users", value=refund_text, inline=False
    )
    
    summary_parts = []
    if total_credit_refund > 0:
        summary_parts.append(f"**{total_credit_refund} credits**")
    if total_point_refund > 0:
        summary_parts.append(f"**{total_point_refund} VPS point{'s' if total_point_refund > 1 else ''}**")
    
    summary_text = " + ".join(summary_parts) if summary_parts else "No refunds"
    
    embed.add_field(
        name="Total Refunds",
        value=summary_text,
        inline=False,
    )
    embed.add_field(
        name="VPS to be Deleted", value=f"{len(vps_to_delete)}", inline=False
    )

    view = RefundConfirmationView(bot, vps_to_delete, credit_refunds, point_refunds)
    await interaction.followup.send(embed=embed, view=view, ephemeral=True)


# --- Modified Original Views ---


class SpecificUserIDModal(discord.ui.Modal, title="Enter Specific User IDs"):
    user_ids_input = discord.ui.TextInput(
        label="User IDs (comma-separated)",
        style=discord.TextStyle.paragraph,
        placeholder="e.g., 1047760053509312642, 987654321098765432",
        required=True,
    )

    def __init__(self, bot: commands.Bot, node_name: str, vps_type: str):
        super().__init__()
        self.bot = bot
        self.node_name = node_name
        self.vps_type = vps_type

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        try:
            selected_user_ids_str = self.user_ids_input.value.split(",")
            selected_user_ids = [
                int(uid.strip()) for uid in selected_user_ids_str if uid.strip()
            ]
        except ValueError:
            await interaction.followup.send(
                "Invalid User ID format. Please enter comma-separated numbers.",
                ephemeral=True,
            )
            return

        vps_to_delete = []
        users_affected = set(selected_user_ids)

        all_vps_from_db = db.get_all_vps()

        for user_id in selected_user_ids:
            for vps in all_vps_from_db:
                if (
                    vps["user_id"] == user_id
                    and vps.get("node") == self.node_name
                    and vps.get("vps_type") == self.vps_type
                ):
                    vps_to_delete.append(vps)

        for user_id in selected_user_ids:
            invited_members = db.get_members_invited_by(user_id)
            for invited in invited_members:
                invited_id = invited["member_id"]
                users_affected.add(invited_id)
                for vps in all_vps_from_db:
                    if (
                        vps["user_id"] == invited_id
                        and vps.get("node") == self.node_name
                        and vps.get("vps_type") == self.vps_type
                    ):
                        vps_to_delete.append(vps)

        vps_to_delete_unique_dict = {vps["id"]: vps for vps in vps_to_delete}

        vps_to_delete_unique = list(vps_to_delete_unique_dict.values())

        # Instead of showing old confirmation, start the new flow
        await start_purge_flow(interaction, self.bot, vps_to_delete_unique, users_affected)


class UserSelectionView(discord.ui.View):
    def __init__(
        self, bot: commands.Bot, node_name: str, vps_type: str, user_vps_map: dict
    ):
        super().__init__(timeout=300)
        self.bot = bot
        self.node_name = node_name
        self.vps_type = vps_type
        self.user_vps_map = user_vps_map

    @discord.ui.button(
        label="Enter Specific User IDs to Purge", style=discord.ButtonStyle.danger
    )
    async def enter_specific_ids_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        modal = SpecificUserIDModal(self.bot, self.node_name, self.vps_type)
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="Purge ALL Users on this Node/Type", style=discord.ButtonStyle.red
    )
    async def purge_all_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        selected_user_ids = list(self.user_vps_map.keys())

        if not selected_user_ids:
            await interaction.followup.send(
                "No users found to purge on this node/type.", ephemeral=True
            )
            return

        vps_to_delete = []
        users_affected = set(selected_user_ids)

        all_vps_from_db = db.get_all_vps()

        for user_id in selected_user_ids:
            for vps in all_vps_from_db:
                if (
                    vps["user_id"] == user_id
                    and vps.get("node") == self.node_name
                    and vps.get("vps_type") == self.vps_type
                ):
                    vps_to_delete.append(vps)

        for user_id in selected_user_ids:
            invited_members = db.get_members_invited_by(user_id)
            for invited in invited_members:
                invited_id = invited["member_id"]
                users_affected.add(invited_id)
                for vps in all_vps_from_db:
                    if (
                        vps["user_id"] == invited_id
                        and vps.get("node") == self.node_name
                        and vps.get("vps_type") == self.vps_type
                    ):
                        vps_to_delete.append(vps)

        vps_to_delete_unique_dict = {vps["id"]: vps for vps in vps_to_delete}
        vps_to_delete_unique = list(vps_to_delete_unique_dict.values())

        # Instead of showing old confirmation, start the new flow
        await start_purge_flow(
            interaction, self.bot, vps_to_delete_unique, users_affected
        )


class TypeSelectionView(discord.ui.View):
    def __init__(self, bot: commands.Bot, node_name: str):
        super().__init__(timeout=180)
        self.bot = bot
        self.node_name = node_name

    @discord.ui.button(
        label="KVM", style=discord.ButtonStyle.primary, custom_id="purge_type:kvm"
    )
    async def kvm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await self.type_button_callback(interaction, "kvm")

    @discord.ui.button(
        label="LXC", style=discord.ButtonStyle.secondary, custom_id="purge_type:lxc"
    )
    async def lxc_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await self.type_button_callback(interaction, "lxc")

    async def type_button_callback(
        self, interaction: discord.Interaction, vps_type: str
    ):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        all_vps = db.get_all_vps()
        logging.info(
            f"Purge check: Searching for VPS with node='{self.node_name}' and type='{vps_type}' among {len(all_vps)} total VPS."
        )

        target_vps = [
            vps
            for vps in all_vps
            if vps.get("node")
            and vps.get("node").strip().lower() == self.node_name.lower()
            and vps.get("vps_type")
            and vps.get("vps_type").strip().lower() == vps_type.lower()
        ]

        logging.info(f"Purge check: Found {len(target_vps)} matching VPS.")

        if not target_vps:
            embed = discord.Embed(
                title="No VPS Found",
                description=f"No {vps_type.upper()} VPS found on node '{self.node_name}'.",
                color=0x992D22,
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        user_vps_map = {}
        for vps in target_vps:
            uid = vps["user_id"]
            if uid not in user_vps_map:
                user_vps_map[uid] = []
            user_vps_map[uid].append(vps["container_name"])

        embed = discord.Embed(
            title="Purge - Step 3/7 - Select Users",
            description=f"Found {len(target_vps)} {vps_type.upper()} VPS across {len(user_vps_map)} users on node '{self.node_name}'.\nChoose to purge all of them, or select specific root users (which will also include their invitees).",
            color=0x99AAB5,
        )

        user_list_text = ""
        for user_id, vps_list in user_vps_map.items():
            try:
                user = await self.bot.fetch_user(user_id)
                user_line = f"- **{user.name}** ({user_id}): {len(vps_list)} VPS\n"
            except discord.NotFound:
                user_line = f"- **Unknown User** ({user_id}): {len(vps_list)} VPS\n"

            if len(user_list_text) + len(user_line) > 1024:
                user_list_text += "- ...and more."
                break
            user_list_text += user_line

        embed.add_field(
            name="Users on this Node/Type", value=user_list_text, inline=False
        )

        view = UserSelectionView(self.bot, self.node_name, vps_type, user_vps_map)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)


class NodeSelectionView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=180)
        self.bot = bot
        self.add_node_buttons()

    def add_node_buttons(self):
        if not node_manager.NODES:
            self.add_item(
                discord.ui.Button(
                    label="No Nodes Configured",
                    style=discord.ButtonStyle.danger,
                    disabled=True,
                )
            )
            return
        for node_name in node_manager.NODES.keys():
            button = discord.ui.Button(
                label=node_name.capitalize(),
                style=discord.ButtonStyle.secondary,
                custom_id=f"purge_node:{node_name}",
            )
            button.callback = self.node_button_callback
            self.add_item(button)

    async def node_button_callback(self, interaction: discord.Interaction):
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "You are not authorized to interact with this.", ephemeral=True
            )
            return

        # ✅ Vérifier que le custom_id est valide
        custom_id_parts = interaction.data["custom_id"].split(":")
        if len(custom_id_parts) < 2:
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(
                "Invalid interaction data.", ephemeral=True
            )
            return
        
        node_name = custom_id_parts[1]

        embed = discord.Embed(
            title=f"Purge - Step 2/7 - Select Type on Node '{node_name}'",
            description="Please select the type of VPS to purge.",
            color=0x99AAB5,
        )
        view = TypeSelectionView(self.bot, node_name)
        await interaction.response.edit_message(embed=embed, view=view)


# --- Main Cog ---


class Purge(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="purge", description="Purge VPS from a node.")
    @app_commands.guild_only()
    async def purge(self, ctx: commands.Context):
        if ctx.author.id not in [AUTHORIZED_USER_ID, 1286418351035388006]:
            await ctx.send(
                "You are not authorized to use this command.", ephemeral=True
            )
            return

        embed = discord.Embed(
            title="Purge - Step 1/7 - Select Node",
            description="Please select the node you want to purge VPS from.",
            color=0x99AAB5,
        )
        view = NodeSelectionView(self.bot)
        await ctx.send(embed=embed, view=view, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Purge(bot))
