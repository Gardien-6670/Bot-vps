import discord
from discord.ext import commands
from discord import app_commands
import time
import asyncio
import aiohttp
import os
from utils import node_manager


class Ping(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(
        name="ping", description="Displays the bot's latencies and server stats"
    )
    @app_commands.guild_only()
    async def ping(self, ctx: commands.Context):
        await ctx.defer()

        # WebSocket Latency (Discord)
        socket_latency = round(self.bot.latency * 1000)

        embed = discord.Embed(title="Bot Latencies", color=0xE5E6EB)

        # Discord
        embed.add_field(
            name="Discord WebSocket", value=f"{socket_latency}ms", inline=True
        )

        # Node Stats
        for node_name, node_info in node_manager.NODES.items():
            server_stats = None
            server_status = "Unreachable"
            server_latency = None

            try:
                start_server_time = time.time()
                stats_result = await node_manager.api_request(
                    "GET",
                    "/system/stats",
                    node_info["url"],
                    node_info["api_key"],
                    timeout_seconds=5,
                )
                end_server_time = time.time()
                server_latency = round((end_server_time - start_server_time) * 1000)

                if stats_result and stats_result.get("status") != 500:
                    server_stats = stats_result
                    server_status = "Online"
                else:
                    server_status = f"Code {stats_result.get("status", "N/A")}"
            except asyncio.TimeoutError:
                server_status = "Timeout (>5s)"
            except Exception as e:
                server_status = f"Error: {type(e).__name__}"

            lxc_active_count = "N/A"
            kvm_active_count = "N/A"
            try:
                lxc_stats_result = await node_manager.api_request(
                    "GET",
                    "/lxc/stats",
                    node_info["url"],
                    node_info["api_key"],
                    timeout_seconds=5,
                )
                if (
                    lxc_stats_result
                    and lxc_stats_result.get("active_containers") is not None
                ):
                    lxc_active_count = lxc_stats_result["active_containers"]
            except Exception:
                pass

            try:
                kvm_stats_result = await node_manager.api_request(
                    "GET",
                    "/kvm/stats",
                    node_info["url"],
                    node_info["api_key"],
                    timeout_seconds=5,
                )
                if kvm_stats_result and kvm_stats_result.get("active_vms") is not None:
                    kvm_active_count = kvm_stats_result["active_vms"]
            except Exception:
                pass

            # Get partner info
            partner_env_var = f"{node_name.upper()}_PARTNER"
            partner_info = os.getenv(partner_env_var)
            partner_display = f"Partner: {partner_info}\n" if partner_info else ""

            # Get premium status
            type_display = "Premium" if node_info.get("premium") else "Free"

            if server_stats:
                server_info = (
                    f"Type: **{type_display}**\n"
                    + partner_display
                    + f"Status: {server_status}\n"
                    + f"Latency: {server_latency}ms\n"
                    + f"CPU: {server_stats['cpu']['percent']}%\n"
                    + f"RAM: {server_stats['ram']['used_gb']}/{server_stats['ram']['total_gb']}GB ({server_stats['ram']['percent']}%)\n"
                    + f"Swap: {server_stats['swap']['used_gb']}/{server_stats['swap']['total_gb']}GB ({server_stats['swap']['percent']}%)\n"
                    + f"Disk: {server_stats['disk']['used_gb']}/{server_stats['disk']['total_gb']}GB ({server_stats['disk']['percent']}%)\n"
                    + f"Active LXC: {lxc_active_count}\n"
                    + f"Active KVM: {kvm_active_count}"
                )
            else:
                server_info = (
                    f"Type: **{type_display}**\n"
                    + partner_display
                    + f"Status: {server_status}\n"
                )
                if server_latency:
                    server_info += f"Latency: {server_latency}ms\n"
                else:
                    server_info += "Latency: N/A\n"
                server_info += f"Active LXC: {lxc_active_count}\n"
                server_info += f"Active KVM: {kvm_active_count}"

            embed.add_field(name=f"Node: {node_name}", value=server_info, inline=False)

        embed.set_footer(text="Node stats are collected from configured API endpoints.")

        # Bot Latency (Round-trip time for sending the embed)
        start_bot_time = time.time()
        message = await ctx.send(embed=embed)
        end_bot_time = time.time()
        bot_latency = round((end_bot_time - start_bot_time) * 1000)

        # Update the embed with bot latency, then edit the message
        embed.add_field(name="Bot Latency", value=f"{bot_latency}ms", inline=True)
        await message.edit(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Ping(bot))
