import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import discord
from discord.ext import commands, tasks
from discord import app_commands
import datetime
import random
import re
import json
import logging
from utils.database import db


def parse_duration(duration_str: str) -> datetime.timedelta:
    """Parses a duration string (e.g., 1d, 3h, 30m) into a timedelta object."""
    match = re.match(r"(\d+)([smhd])", duration_str.lower())
    if not match:
        raise ValueError("Invalid duration format. Use s, m, h, or d.")

    value, unit = match.groups()
    value = int(value)

    if unit == "s":
        return datetime.timedelta(seconds=value)
    elif unit == "m":
        return datetime.timedelta(minutes=value)
    elif unit == "h":
        return datetime.timedelta(hours=value)
    elif unit == "d":
        return datetime.timedelta(days=value)
    else:
        raise ValueError("Invalid duration unit.")


class GiveawayView(discord.ui.View):
    def __init__(self, bot, message_id=None):
        super().__init__(timeout=None)
        self.bot = bot
        self.message_id = message_id

    async def update_embed(self, interaction: discord.Interaction):
        """Met à jour l'embed avec le nombre de participants"""
        giveaway = db.get_giveaway(interaction.message.id)
        if not giveaway:
            return

        participants = json.loads(giveaway.get("participants", "[]"))

        embed = interaction.message.embeds[0]
        embed.set_field_at(
            2, name="Participants", value=str(len(participants)), inline=True
        )
        await interaction.message.edit(embed=embed)

    async def has_required_status(self, member, required_status):
        """Vérifie si un membre a le status requis dans son custom status"""
        if not member or not member.activities:
            return False

        required_lower = required_status.lower()

        for activity in member.activities:
            if isinstance(activity, discord.CustomActivity):
                if activity.name and required_lower in activity.name.lower():
                    return True
                if activity.state and required_lower in activity.state.lower():
                    return True
                if hasattr(activity, "emoji") and activity.emoji:
                    if hasattr(activity.emoji, "name") and activity.emoji.name:
                        if required_lower in activity.emoji.name.lower():
                            return True
        return False

    @discord.ui.button(
        label="Enter", style=discord.ButtonStyle.green, custom_id="giveaway_enter"
    )
    async def enter_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        member = interaction.guild.get_member(interaction.user.id)

        if not member:
            await interaction.response.send_message(
                "An error occurred. Please try again.", ephemeral=True
            )
            return

        message_id = interaction.message.id
        required_status = "Free Monthly VPS -> .gg/JHbGvZsvUH"

        if not await self.has_required_status(member, required_status):
            await interaction.response.send_message(
                f"You need to have `{required_status}` in your custom status to participate.\n\n"
                f"**How to add this status:**\n"
                f"1. Click on your Discord profile\n"
                f"2. Click 'Set a custom status'\n"
                f"3. Add the text: `{required_status}`",
                ephemeral=True,
            )
            return

        participants = db.get_giveaway_participants(message_id)
        if member.id in participants:
            await interaction.response.send_message(
                "You are already in the giveaway.", ephemeral=True
            )
            return

        db.add_participant(message_id, member.id)
        await self.update_embed(interaction)
        await interaction.response.send_message(
            "You have entered the giveaway!", ephemeral=True
        )

    @discord.ui.button(
        label="Leave", style=discord.ButtonStyle.red, custom_id="giveaway_leave"
    )
    async def leave_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        member = interaction.guild.get_member(interaction.user.id)

        if not member:
            await interaction.response.send_message(
                "An error occurred. Please try again.", ephemeral=True
            )
            return

        message_id = interaction.message.id
        participants = db.get_giveaway_participants(message_id)
        if member.id not in participants:
            await interaction.response.send_message(
                "You are not in the giveaway.", ephemeral=True
            )
            return

        db.remove_participant(message_id, member.id)
        await self.update_embed(interaction)
        await interaction.response.send_message(
            "You have left the giveaway.", ephemeral=True
        )

    @discord.ui.button(
        label="Participants",
        style=discord.ButtonStyle.blurple,
        custom_id="giveaway_participants",
    )
    async def participants_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        message_id = interaction.message.id
        participants_ids = db.get_giveaway_participants(message_id)
        if not participants_ids:
            await interaction.response.send_message(
                "There are no participants yet.", ephemeral=True
            )
            return

        participants_info = []
        for user_id in participants_ids:
            try:
                user = await self.bot.fetch_user(user_id)
                if user:
                    participants_info.append(
                        f"**{user.name}** (ID: {user.id})\nCreated at: {user.created_at.strftime('%Y-%m-%d')}"
                    )
            except Exception:
                participants_info.append(f"**Unknown User** (ID: {user_id})")

        description = "\n".join(participants_info)
        embed = discord.Embed(
            title="Giveaway Participants",
            description=description,
            color=discord.Color.dark_grey(),
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.persistent_views_added = False
        logging.info("Giveaways cog __init__ called")
        self.check_giveaways.start()
        logging.info("check_giveaways loop started from __init__")

    @commands.Cog.listener()
    async def on_ready(self):
        logging.info("Giveaways cog on_ready triggered")
        if not self.persistent_views_added:
            try:
                running_giveaways = db.get_all_running_giveaways()
                logging.info(
                    f"Found {len(running_giveaways)} running giveaways in database"
                )

                for giveaway in running_giveaways:
                    view = GiveawayView(self.bot, message_id=giveaway["message_id"])
                    self.bot.add_view(view, message_id=giveaway["message_id"])
                    logging.info(
                        f"Registered view for giveaway {giveaway['message_id']}"
                    )

                self.persistent_views_added = True
                logging.info(
                    f"Registered views for {len(running_giveaways)} active giveaways."
                )
            except Exception as e:
                logging.error(f"Error registering persistent views: {e}", exc_info=True)

    def cog_unload(self):
        self.check_giveaways.cancel()

    @app_commands.command(
        name="debug_giveaways", description="Debug giveaway system (admin only)"
    )
    async def debug_giveaways(self, interaction: discord.Interaction):
        """Commande de debug pour vérifier l'état des giveaways"""
        if interaction.user.id not in [1047760053509312642, 1286418351035388006]:
            await interaction.response.send_message(
                "You don't have permission to use this command.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        try:
            running = db.get_all_running_giveaways()
            now = datetime.datetime.now(datetime.timezone.utc)

            msg = f"**Giveaway Debug Info**\n\n"
            msg += f"**Current time (UTC):** {now}\n"
            msg += f"**Loop running:** {self.check_giveaways.is_running()}\n"
            msg += f"**Active giveaways:** {len(running)}\n\n"

            if len(running) == 0:
                msg += "No active giveaways found in database.\n"
            else:
                for i, g in enumerate(running, 1):
                    msg += f"**Giveaway #{i}:**\n"
                    msg += f" Message ID: `{g['message_id']}`\n"
                    msg += f" Prize: {g.get('prize')} credits\n"
                    msg += f" Winners: {g.get('winners_count')}\n"

                    end_time = g["end_time"]
                    msg += f" End time (raw): `{end_time}` (type: `{type(end_time).__name__}`)\n"

                    if isinstance(end_time, str):
                        try:
                            end_time = datetime.datetime.fromisoformat(
                                end_time.replace("Z", "+00:00")
                            )
                        except Exception:
                            end_time = datetime.datetime.strptime(
                                end_time, "%Y-%m-%d %H:%M:%S"
                            )

                    if end_time.tzinfo is None:
                        end_time = end_time.replace(tzinfo=datetime.timezone.utc)

                    diff = (end_time - now).total_seconds()
                    msg += f" Time remaining: `{diff:.0f}s` ({diff/60:.1f} minutes)\n"
                    msg += f" Should end NOW: `{now >= end_time}`\n"
                    msg += f" Participants: {len(db.get_giveaway_participants(g['message_id']))}\n\n"

            if len(msg) > 1900:
                msg = msg[:1900] + "\n\n... (message truncated)"

            await interaction.followup.send(msg, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Error: {e}", ephemeral=True)
            logging.error(f"Debug command error: {e}", exc_info=True)

    @app_commands.command(
        name="gcancel", description="Cancel an active giveaway (admin only)"
    )
    @app_commands.describe(message_id="The message ID of the giveaway to cancel")
    async def gcancel(self, interaction: discord.Interaction, message_id: str):
        """Annule un giveaway active"""
        if interaction.user.id not in [1047760053509312642, 1286418351035388006]:
            await interaction.response.send_message(
                "You don't have permission to use this command.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        try:
            msg_id = int(message_id)
            giveaway = db.get_giveaway(msg_id)

            if not giveaway:
                await interaction.followup.send(
                    "[ERROR] Giveaway not found.", ephemeral=True
                )
                return

            if giveaway.get("status") != "running":
                await interaction.followup.send(
                    "[ERROR] This giveaway has already ended.", ephemeral=True
                )
                return

            db._execute_query(
                "UPDATE giveaways SET status = 'cancelled', prize_distributed = 1 WHERE message_id = ?",
                (msg_id,),
            )

            channel = self.bot.get_channel(giveaway["channel_id"])
            if channel:
                try:
                    message = await channel.fetch_message(msg_id)
                    embed = message.embeds[0]
                    embed.title = "Giveaway Cancelled!"
                    embed.description = (
                        "This giveaway has been cancelled by an administrator."
                    )
                    embed.color = discord.Color.dark_red()
                    await message.edit(embed=embed, view=None)
                    await message.reply(
                        "This giveaway has been cancelled by an administrator."
                    )
                except discord.NotFound:
                    pass

            await interaction.followup.send(
                f"[OK] Giveaway {msg_id} has been cancelled.", ephemeral=True
            )
            logging.info(f"Giveaway {msg_id} cancelled by {interaction.user.id}")

        except ValueError:
            await interaction.followup.send(
                "[ERROR] Invalid message ID format.", ephemeral=True
            )
        except Exception as e:
            await interaction.followup.send(f"[ERROR] Error: {e}", ephemeral=True)
            logging.error(f"Error cancelling giveaway: {e}", exc_info=True)

    @app_commands.command(name="giveaway", description="Create a giveaway")
    @app_commands.describe(
        credits="The number of credits to give away",
        winners="The number of winners",
        duration="The duration of the giveaway (e.g., 1d, 3h, 30m)",
    )
    @commands.check(
        lambda interaction: interaction.user.id
        in [1047760053509312642, 1286418351035388006]
    )
    @commands.has_permissions(administrator=True)
    async def giveaway(
        self,
        interaction: discord.Interaction,
        credits: int,
        winners: int,
        duration: str,
    ):
        # Validations
        if credits <= 0:
            await interaction.response.send_message(
                "[ERROR] Credits must be greater than 0.", ephemeral=True
            )
            return

        if credits > 10000:
            await interaction.response.send_message(
                "[ERROR] Credits cannot exceed 10,000 per giveaway.", ephemeral=True
            )
            return

        if winners <= 0:
            await interaction.response.send_message(
                "[ERROR] Number of winners must be greater than 0.", ephemeral=True
            )
            return

        if winners > 100:
            await interaction.response.send_message(
                "[ERROR] Number of winners cannot exceed 100.", ephemeral=True
            )
            return

        try:
            credits = int(credits)
            winners = int(winners)
            logging.info(
                f"Giveaway command called with credits={credits}, winners={winners}, duration='{duration}' by user {interaction.user.id}"
            )
            delta = parse_duration(duration)
            logging.info(f"Parsed duration: {delta}")

            if delta.total_seconds() < 60:
                await interaction.response.send_message(
                    "[ERROR] Duration must be at least 1 minute.", ephemeral=True
                )
                return

            if delta.total_seconds() > 2592000:
                await interaction.response.send_message(
                    "[ERROR] Duration cannot exceed 30 days.", ephemeral=True
                )
                return
        except ValueError as e:
            await interaction.response.send_message(str(e), ephemeral=True)
            return
        except Exception as e:
            logging.error(f"Error during giveaway creation setup: {e}", exc_info=True)
            await interaction.response.send_message(
                "An unexpected error occurred while setting up the giveaway.",
                ephemeral=True,
            )
            return

        end_time = datetime.datetime.now(datetime.timezone.utc) + delta
        logging.info(f"Giveaway will end at: {end_time} (UTC)")
        logging.info(
            f"Current time: {datetime.datetime.now(datetime.timezone.utc)} (UTC)"
        )

        embed = discord.Embed(
            title="Giveaway!",
            description=f"Click the 'Enter' button to join!\n\nPrize: **{credits} credits**\nWinners: **{winners}**",
            color=discord.Color.light_grey(),
        )
        embed.add_field(
            name="Ends at", value=f"<t:{int(end_time.timestamp())}:F>", inline=True
        )
        embed.add_field(name="Hosted by", value=interaction.user.mention, inline=True)
        embed.add_field(name="Participants", value="0", inline=True)
        embed.set_footer(text="Giveaway started at")
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)

        await interaction.response.send_message(embed=embed)
        message = await interaction.original_response()
        logging.info(f"Giveaway message sent with ID: {message.id}")

        # Créer et attacher la vue
        view = GiveawayView(self.bot, message.id)
        await message.edit(view=view)
        logging.info(f"View attached to message {message.id}")

        try:
            db.add_giveaway(
                message.id,
                interaction.channel_id,
                interaction.guild_id,
                end_time,
                winners,
                credits,
            )
            saved_giveaway = db.get_giveaway(message.id)
            logging.info(
                f"Giveaway created successfully. Message ID: {message.id}, Prize: {credits}"
            )
            logging.info(f"Saved giveaway data: {saved_giveaway}")
            if saved_giveaway:
                logging.info(
                    f"End time saved: {saved_giveaway.get('end_time')} (type: {type(saved_giveaway.get('end_time'))})"
                )
                logging.info(
                    f"Current time: {datetime.datetime.now(datetime.timezone.utc)}"
                )
            else:
                logging.error("Giveaway was not saved properly to database!")
        except Exception as e:
            logging.error(
                f"Failed to add giveaway to database. Message ID: {message.id}, Prize: {credits}. Error: {e}",
                exc_info=True,
            )
            await interaction.followup.send(
                "Failed to save the giveaway to the database. Please try again.",
                ephemeral=True,
            )

    @tasks.loop(seconds=30)
    async def check_giveaways(self):
        """Vérifie les giveaways toutes les 30 seconds"""
        await self.bot.wait_until_ready()

        try:
            running_giveaways = db.get_all_running_giveaways()
            now = datetime.datetime.now(datetime.timezone.utc)

            logging.info(
                f"Checking giveaways... Found {len(running_giveaways)} active giveaway(s). Current time: {now}"
            )

            for giveaway in running_giveaways:
                try:
                    end_time = giveaway["end_time"]

                    if isinstance(end_time, str):
                        logging.warning(
                            f"end_time is a string: {end_time}, converting to datetime"
                        )
                        try:
                            end_time = datetime.datetime.fromisoformat(
                                end_time.replace("Z", "+00:00")
                            )
                        except Exception:
                            end_time = datetime.datetime.strptime(
                                end_time, "%Y-%m-%d %H:%M:%S"
                            )

                    if end_time.tzinfo is None:
                        end_time = end_time.replace(tzinfo=datetime.timezone.utc)
                        logging.info("Added UTC timezone to end_time")

                    time_remaining = (end_time - now).total_seconds()
                    logging.info(
                        f"Giveaway {giveaway['message_id']}: ends at {end_time}, time remaining: {time_remaining:.0f}s"
                    )

                    if now >= end_time:
                        logging.info(
                            f"Giveaway {giveaway['message_id']} has ended, processing..."
                        )
                        await self.end_giveaway(giveaway)
                    elif time_remaining <= 300:
                        await self.check_participants_status(giveaway)
                except Exception as e:
                    logging.error(
                        f"Error checking giveaway {giveaway.get('message_id')}: {e}",
                        exc_info=True,
                    )
        except Exception as e:
            logging.error(f"Critical error in check_giveaways loop: {e}", exc_info=True)

    @check_giveaways.before_loop
    async def before_check_giveaways(self):
        """Attend que le bot soit prêt avant de start la boucle"""
        await self.bot.wait_until_ready()
        logging.info("Bot is ready, check_giveaways loop will start now")

    @check_giveaways.error
    async def check_giveaways_error(self, error):
        """Gère les errors de la boucle"""
        logging.error(f"Error in check_giveaways task: {error}", exc_info=True)

    async def _update_giveaway_message(self, message_id: int, channel_id: int):
        """Met à jour le message du giveaway avec le nombre de participants"""
        channel = self.bot.get_channel(channel_id)
        if not channel:
            logging.warning(f"Channel {channel_id} not found for giveaway {message_id}")
            return

        try:
            message = await channel.fetch_message(message_id)
            giveaway = db.get_giveaway(message_id)
            if not giveaway:
                return

            participants = json.loads(giveaway.get("participants", "[]"))

            embed = message.embeds[0]
            embed.set_field_at(
                2, name="Participants", value=str(len(participants)), inline=True
            )
            await message.edit(embed=embed)
        except discord.NotFound:
            logging.warning(f"Message {message_id} not found (deleted)")
        except Exception as e:
            logging.error(f"Failed to update giveaway message {message_id}: {e}")

    async def end_giveaway(self, giveaway_data):
        """Termine le giveaway et distribue les credits"""
        message_id = giveaway_data["message_id"]

        if giveaway_data.get("prize_distributed") == 1:
            logging.info(
                f"Giveaway {message_id} already had prizes distributed. Skipping."
            )
            return

        prize = giveaway_data["prize"]
        if isinstance(prize, str):
            prize = int(prize)

        logging.info(f"Ending giveaway {message_id}. Prize: {prize} credits")

        channel_id = giveaway_data["channel_id"]
        guild_id = giveaway_data["guild_id"]
        winners_count = giveaway_data["winners_count"]

        channel = self.bot.get_channel(channel_id)
        if not channel:
            logging.error(f"Channel {channel_id} not found for giveaway {message_id}")
            db.end_giveaway(message_id, "[]")
            return

        try:
            message = await channel.fetch_message(message_id)
        except discord.NotFound:
            logging.warning(f"Message {message_id} not found (deleted)")
            db.end_giveaway(message_id, "[]")
            return

        participants_ids = db.get_giveaway_participants(message_id)

        winners = []
        if participants_ids:
            if len(participants_ids) <= winners_count:
                winner_ids = participants_ids
            else:
                winner_ids = random.sample(participants_ids, winners_count)
        else:
            winner_ids = []

        for uid in winner_ids:
            try:
                user = await self.bot.fetch_user(uid)
                if user:
                    winners.append(user)
            except Exception as e:
                logging.error(f"[ERROR] Failed to fetch user {uid}: {e}")

        winner_mentions = [w.mention for w in winners]

        if winners:
            # ✅ Utiliser une transaction pour end_giveaway + add_credits
            conn, cursor = db.start_transaction()
            try:
                db.end_giveaway(message_id, json.dumps([w.id for w in winners]), cursor=cursor, conn=conn)

                successful_winners = []
                for winner in winners:
                    try:
                        db.add_credits(winner.id, prize, cursor=cursor, conn=conn)
                        new_balance = db.get_balance(winner.id, cursor=cursor, conn=conn)
                        successful_winners.append(winner)
                        logging.info(
                            f"Added {prize} credits to {winner.name} (ID: {winner.id}). New balance: {new_balance}"
                        )
                    except Exception as e:
                        logging.error(f"Failed to add credits to winner {winner.id}: {e}")
                        raise  # Rollback si un gagnant échoue
                
                db.commit_transaction(conn, cursor)
            except Exception as e:
                db.rollback_transaction(conn, cursor)
                logging.error(f"Failed to process giveaway winners: {e}")
                await interaction.followup.send(
                    f"❌ Error processing giveaway: {e}",
                    ephemeral=True
                )
                return
            
            # Envoyer les DMs après le commit (pas critique)
            for winner in successful_winners:
                try:
                    new_balance = db.get_balance(winner.id)
                    embed = discord.Embed(
                        title="Congratulations! You won a giveaway!",
                        description=f"You won **{prize} credits**!",
                        color=discord.Color.light_grey(),
                    )
                    embed.add_field(
                        name="Prize", value=f"{prize} credits", inline=True
                    )
                    embed.add_field(
                        name="New Balance",
                        value=f"{new_balance} credits",
                        inline=True,
                    )
                    await winner.send(embed=embed)
                except discord.Forbidden:
                    logging.warning(f"Cannot send DM to {winner.name}")
                except Exception as e:
                    logging.error(
                        f"Failed to add credits to {winner.name} (ID: {winner.id}): {e}"
                    )

            if successful_winners:
                win_mentions = [w.mention for w in successful_winners]
                win_text = f"Congratulations {', '.join(win_mentions)}! You won **{prize} credits** each!"
                await message.reply(win_text)
            else:
                await message.reply(
                    "The giveaway has ended, but there was an error distributing the credits."
                )
        else:
            db.end_giveaway(message_id, "[]")
            await message.reply(
                " The giveaway has ended, but there were no participants."
            )

        try:
            embed = message.embeds[0]
            embed.title = "Giveaway Ended!"
            embed.description = f"Prize: **{prize} credits**\n\n{'Winners: ' + ', '.join(winner_mentions) if winner_mentions else 'No winners'}"
            embed.color = discord.Color.dark_grey()
            await message.edit(embed=embed, view=None)
        except Exception as e:
            logging.error(f"Failed to update embed for giveaway {message_id}: {e}")

    async def check_participants_status(self, giveaway_data):
        """Vérifie que les participants ont toujours le status requis"""
        required_status = "Free Monthly VPS -> .gg/JHbGvZsvUH"
        participants_ids = db.get_giveaway_participants(giveaway_data["message_id"])
        guild = self.bot.get_guild(giveaway_data["guild_id"])
        if not guild:
            return

        participants_changed = False
        for user_id in participants_ids[:]:
            member = guild.get_member(user_id)

            if not member:
                db.remove_participant(giveaway_data["message_id"], user_id)
                participants_changed = True
                logging.info(f"Removed user {user_id} from giveaway (left server)")
                continue

            if member.status == discord.Status.offline:
                continue

            view = GiveawayView(self.bot)
            has_status = await view.has_required_status(member, required_status)

            if not has_status:
                db.remove_participant(giveaway_data["message_id"], user_id)
                participants_changed = True
                logging.info(f"Removed {member.name} from giveaway (status removed)")
                try:
                    await member.send(
                        f"You have been removed from the giveaway in **{guild.name}** because you removed the required status:\n"
                        f"`{required_status}`"
                    )
                except discord.Forbidden:
                    pass

        if participants_changed:
            await self._update_giveaway_message(
                giveaway_data["message_id"], giveaway_data["channel_id"]
            )


async def setup(bot):
    cog = Giveaways(bot)
    await bot.add_cog(cog)
    logging.info("Giveaways cog setup completed")
