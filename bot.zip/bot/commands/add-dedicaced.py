import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
import asyncio
import logging
from datetime import datetime, timedelta
import paramiko
import socket  # Import socket for TimeoutError


class AddDedicaced(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(
        name="add-dedicaced", description="Manage dedicated servers."
    )
    @app_commands.guild_only()
    async def add_dedicaced(self, ctx: commands.Context):
        # Only allow specific roles or users to use this command
        # For now, let's assume only the bot owner can use it.
        if ctx.author.id not in [1047760053509312642, 1286418351035388006]:
            await ctx.send(
                "You are not authorized to use this command.", ephemeral=True
            )
            return

            embed = discord.Embed(
                title="Dedicated Server Management",
                description="Please select an action below.",
                color=0xE5E6EB,
            )
        view = AddDedicacedMainView(self.bot, ctx.author.id, self)
        await ctx.send(embed=embed, view=view, ephemeral=True)


class AddDedicacedMainView(discord.ui.View):
    def __init__(self, bot: commands.Bot, author_id: int, cog):
        super().__init__(timeout=180)
        self.bot = bot
        self.author_id = author_id
        self.cog = cog

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.author_id:
            return True
        await interaction.response.send_message(
            "You are not authorized to interact with this.", ephemeral=True
        )
        return False

    @discord.ui.button(label="Add New Server", style=discord.ButtonStyle.success)
    async def add_server_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        modal = AddServerModal(self.bot, self.cog)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Attribute Server", style=discord.ButtonStyle.primary)
    async def attribute_server_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.defer(ephemeral=True)
        unattributed_vps = db.get_dedicated_unattributed_vps()

        if not unattributed_vps:
            await interaction.followup.send(
                "No unattributed dedicated servers available.", ephemeral=True
            )
            return

        options = [
            discord.SelectOption(
                label=f"{vps['container_name']} ({vps['ip_address']})",
                value=vps["container_name"],
            )
            for vps in unattributed_vps
        ]

        select_view = SelectDedicatedServerView(options, self.bot, self.cog)
        await interaction.followup.send(
            "Select a dedicated server to attribute:", view=select_view, ephemeral=True
        )

    @discord.ui.button(label="List Servers", style=discord.ButtonStyle.secondary)
    async def list_servers_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.defer(ephemeral=True, thinking=True)
        all_dedicated_vps = db.get_all_dedicated_vps()

        if not all_dedicated_vps:
            await interaction.followup.send(
                "No dedicated servers found.", ephemeral=True
            )
            return

        embed = discord.Embed(title="All Dedicated Servers", color=0xE5E6EB)

        for vps in all_dedicated_vps:
            status = "Unattributed"
            if vps["attributed_to_user_id"]:
                end_date = vps["attribution_end_date"]
                if isinstance(end_date, str):
                    try:
                        end_date = datetime.strptime(end_date, "%Y-%m-%d %H:%M:%S.%f")
                    except ValueError:
                        end_date = datetime.strptime(end_date, "%Y-%m-%d %H:%M:%S")
                status = f"Attributed to User ID: {vps['attributed_to_user_id']} (Expires: {end_date.strftime('%Y-%m-%d')})"

            embed.add_field(
                name=f"Server: {vps['container_name']}",
                value=(
                    f"IP: {vps['ip_address']}:{vps['ssh_port']}\n"
                    f"CPU: {vps['cpu']} cores, RAM: {vps['ram']}GB, Disk: {vps['disk']}GB\n"
                    f"Status: {status}"
                ),
                inline=False,
            )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(label="Remove Attribution", style=discord.ButtonStyle.danger)
    async def remove_attribution_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.defer(ephemeral=True)
        attributed_vps = [
            vps for vps in db.get_all_dedicated_vps() if vps["attributed_to_user_id"]
        ]

        if not attributed_vps:
            await interaction.followup.send(
                "No attributed dedicated servers available.", ephemeral=True
            )
            return

        options = [
            discord.SelectOption(
                label=f"{vps['container_name']} (User: {vps['attributed_to_user_id']})",
                value=vps["container_name"],
            )
            for vps in attributed_vps
        ]

        select_view = SelectToRemoveAttributionView(options, self.bot, self.cog)
        await interaction.followup.send(
            "Select a dedicated server to remove attribution from:",
            view=select_view,
            ephemeral=True,
        )


class AddServerModal(discord.ui.Modal, title="Add New Dedicated Server - Step 1/2"):
    ip_address = discord.ui.TextInput(
        label="Server IP Address", placeholder="e.g., 192.168.1.100", required=True
    )
    ssh_port = discord.ui.TextInput(
        label="SSH Port", placeholder="e.g., 22", required=True
    )
    ssh_password = discord.ui.TextInput(
        label="SSH Password",
        placeholder="Server's root/admin password",
        required=True,
        style=discord.TextStyle.short,
    )

    def __init__(self, bot: commands.Bot, cog):
        super().__init__()
        self.bot = bot
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        ip_address = self.ip_address.value
        ssh_port = int(self.ssh_port.value)
        ssh_password = self.ssh_password.value

        ssh_ok = await test_ssh_connection(ip_address, ssh_port, ssh_password)

        if not ssh_ok:
            await interaction.followup.send(
                f"Failed to connect to {ip_address}:{ssh_port} via SSH. Please check the IP, port, and password.",
                ephemeral=True,
            )
            return

        view = OpenSpecsModalView(
            self.bot, self.cog, ip_address, ssh_port, ssh_password
        )
        await interaction.followup.send(
            "SSH connection successful. Click the button below to continue.",
            view=view,
            ephemeral=True,
        )


class OpenSpecsModalView(discord.ui.View):
    def __init__(self, bot, cog, ip_address, ssh_port, ssh_password):
        super().__init__(timeout=180)
        self.bot = bot
        self.cog = cog
        self.ip_address = ip_address
        self.ssh_port = ssh_port
        self.ssh_password = ssh_password

    @discord.ui.button(label="Continue", style=discord.ButtonStyle.success)
    async def continue_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        modal = AddServerSpecsModal(
            self.bot, self.cog, self.ip_address, self.ssh_port, self.ssh_password
        )
        await interaction.response.send_modal(modal)


class AddServerSpecsModal(
    discord.ui.Modal, title="Add New Dedicated Server - Step 2/2"
):
    cpu_cores = discord.ui.TextInput(
        label="CPU Cores", placeholder="e.g., 4", required=True
    )
    ram_gb = discord.ui.TextInput(
        label="RAM (GB)", placeholder="e.g., 16", required=True
    )
    disk_gb = discord.ui.TextInput(
        label="Disk (GB)", placeholder="e.g., 256", required=True
    )

    def __init__(
        self, bot: commands.Bot, cog, ip_address: str, ssh_port: int, ssh_password: str
    ):
        super().__init__()
        self.bot = bot
        self.cog = cog
        self.ip_address = ip_address
        self.ssh_port = ssh_port
        self.ssh_password = ssh_password

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        cpu_cores = int(self.cpu_cores.value)
        ram_gb = float(self.ram_gb.value)
        disk_gb = float(self.disk_gb.value)

        if db.get_vps_by_ip_and_port(self.ip_address, self.ssh_port):
            await interaction.followup.send(
                f"A server with the IP address `{self.ip_address}` and SSH port `{self.ssh_port}` already exists in the database.",
                ephemeral=True,
            )
            return

        try:
            container_name = (
                f"dedicated-{self.ip_address.replace('.', '-')}-{self.ssh_port}"
            )
            db.add_vps(
                user_id=0,
                username="system",
                container_name=container_name,
                cpu=cpu_cores,
                ram=ram_gb,
                disk=disk_gb,
                cost_credits=0,
                ssh_link=f"ssh://root@{self.ip_address}:{self.ssh_port}",
                ssh_port=self.ssh_port,
                ssh_password=self.ssh_password,
                vps_type="dedicated",
                ip_address=self.ip_address,
                node="dedicated_host",
                is_dedicated=True,
                attributed_to_user_id=None,
                attribution_end_date=None,
            )
            await interaction.followup.send(
                f"Dedicated server {container_name} ({self.ip_address}) added successfully to the database. It is now available for attribution.",
                ephemeral=True,
            )
            logging.info(
                f"Dedicated server {container_name} ({self.ip_address}) added. KVM surveillance integration pending."
            )

        except Exception as e:
            logging.error(
                f"Error adding dedicated server {self.ip_address} to database: {e}"
            )
            await interaction.followup.send(
                f"An error occurred while adding the dedicated server to the database: {e}",
                ephemeral=True,
            )


async def test_ssh_connection(ip_address: str, port: int, password: str) -> bool:
    """
    Tests SSH connectivity to a given IP address and port using paramiko.
    Returns True if connection is successful, False otherwise.
    """

    def ssh_connect():
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(
                ip_address, port=port, username="root", password=password, timeout=15
            )
            client.close()
            logging.info(f"SSH connection successful to {ip_address}:{port}")
            return True
        except socket.timeout:
            logging.error(
                f"SSH connection timed out to {ip_address}:{port}. The server did not respond in time. Please check IP, port, network connectivity, and firewall rules."
            )
            return False
        except paramiko.ssh_exception.SSHException as e:
            logging.error(
                f"SSH error testing connection to {ip_address}:{port}: {e}. This could be due to an invalid SSH banner or other protocol issues."
            )
            return False
        except Exception as e:
            logging.error(
                f"An unexpected error occurred while testing SSH connection to {ip_address}:{port}: {e}"
            )
            return False

    return await asyncio.to_thread(ssh_connect)


class SelectDedicatedServerView(discord.ui.View):
    def __init__(self, options: list[discord.SelectOption], bot: commands.Bot, cog):
        super().__init__(timeout=180)
        self.bot = bot
        self.cog = cog

        if not options:
            select = discord.ui.Select(
                placeholder="No servers available",
                options=[
                    discord.SelectOption(
                        label="No servers available", value="no_servers"
                    )
                ],
                custom_id="dedicated_server_select",
                disabled=True,
            )
        else:
            select = discord.ui.Select(
                placeholder="Choose a server...",
                options=options,
                custom_id="dedicated_server_select",
            )
        select.callback = self.select_server_callback

        self.add_item(select)

    async def select_server_callback(self, interaction: discord.Interaction):
        selected_container_name = interaction.data["values"][0]

        modal = AttributeServerModal(self.bot, self.cog, selected_container_name)
        await interaction.response.send_modal(modal)


class AttributeServerModal(discord.ui.Modal, title="Attribute Dedicated Server"):
    user_id = discord.ui.TextInput(
        label="Target User ID", placeholder="e.g., 123456789012345678", required=True
    )
    duration_days = discord.ui.TextInput(
        label="Attribution Duration (days)", placeholder="e.g., 30", required=True
    )

    def __init__(self, bot: commands.Bot, cog, container_name: str):
        super().__init__()
        self.bot = bot
        self.cog = cog
        self.container_name = container_name

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        try:
            target_user_id = int(self.user_id.value)
            duration_days = int(self.duration_days.value)
        except ValueError:
            await interaction.followup.send(
                "Invalid User ID or Duration. Please enter numbers only.",
                ephemeral=True,
            )
            return

        attribution_end_date = datetime.now() + timedelta(days=duration_days)

        try:
            db.update_dedicated_vps_attribution(
                self.container_name, target_user_id, attribution_end_date
            )

            all_vps = db.get_all_dedicated_vps()
            vps = next(
                (v for v in all_vps if v["container_name"] == self.container_name), None
            )

            dm_status_message = ""
            if vps:
                try:
                    user = await self.bot.fetch_user(target_user_id)
                    embed = discord.Embed(
                        title="Your Dedicated Server is Ready!",
                        description=f"Your dedicated server `{vps['container_name']}` has been assigned to you.",
                        color=0xE5E6EB,
                    )
                    embed.add_field(
                        name="Connection",
                        value=f"```ssh root@{vps['ip_address']} -p {vps['ssh_port']}```",
                        inline=False,
                    )
                    embed.add_field(
                        name="Password",
                        value=f"||{vps['ssh_password']}||",
                        inline=False,
                    )
                    embed.set_footer(
                        text=f"This server is assigned to you until {attribution_end_date.strftime('%Y-%m-%d')}."
                    )
                    await user.send(embed=embed)
                    dm_status_message = "Credentials sent to the user."
                except Exception as e:
                    logging.error(
                        f"Failed to send credentials DM to user {target_user_id}: {e}"
                    )
                    dm_status_message = "Failed to send credentials to the user via DM."

            await interaction.followup.send(
                f"Dedicated server {self.container_name} successfully attributed to user {target_user_id} until {attribution_end_date.strftime('%Y-%m-%d')}. {dm_status_message}",
                ephemeral=True,
            )
        except Exception as e:
            logging.error(
                f"Error attributing dedicated server {self.container_name} to user: {e}"
            )
            await interaction.followup.send(
                f"An error occurred while attributing the server: {e}", ephemeral=True
            )


class SelectToRemoveAttributionView(discord.ui.View):
    def __init__(self, options: list[discord.SelectOption], bot: commands.Bot, cog):
        super().__init__(timeout=180)
        self.bot = bot
        self.cog = cog

        select = discord.ui.Select(
            placeholder="Choose a server to remove attribution...",
            options=options,
            custom_id="remove_attribution_select",
        )
        select.callback = self.select_server_callback
        self.add_item(select)

    async def select_server_callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        selected_container_name = interaction.data["values"][0]

        view = ConfirmRemoveAttributionView(self.bot, self.cog, selected_container_name)
        await interaction.followup.send(
            f"Are you sure you want to remove attribution for {selected_container_name}?",
            view=view,
            ephemeral=True,
        )


class ConfirmRemoveAttributionView(discord.ui.View):
    def __init__(self, bot: commands.Bot, cog, container_name: str):
        super().__init__(timeout=60)
        self.bot = bot
        self.cog = cog
        self.container_name = container_name

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def confirm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            db.update_dedicated_vps_attribution(self.container_name, None, None)
            await interaction.followup.send(
                f"Attribution for {self.container_name} has been removed.",
                ephemeral=True,
            )
        except Exception as e:
            logging.error(
                f"Error removing attribution for dedicated server {self.container_name}: {e}"
            )
            await interaction.followup.send(
                f"An error occurred while removing attribution: {e}", ephemeral=True
            )

        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.edit_message(content="Removal cancelled.", view=None)
        self.stop()


async def setup(bot: commands.Bot):
    await bot.add_cog(AddDedicaced(bot))
