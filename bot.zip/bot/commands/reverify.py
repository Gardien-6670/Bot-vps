import logging
import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db

AUTHORIZED_ADMIN_IDS = [1047760053509312642, 1286418351035388006]


class Reverify(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(
        name="reverify",
        description="[ADMIN] Resets a user's anti-double account eligibility status",
    )
    @app_commands.guild_only()
    @app_commands.describe(user="The user to reset eligibility for")
    async def reverify(self, interaction: discord.Interaction, user: discord.Member):
        """Allows an admin to reset a user's eligibility status."""
        if interaction.user.id not in AUTHORIZED_ADMIN_IDS:
            await interaction.response.send_message(
                "[ERROR] You don't have permission to use this command.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        user_id = user.id

        try:
            db.reset_user_ip_verification(user_id)
            logging.info(
                f"Admin {interaction.user.id} reset eligibility status for user {user_id}"
            )
            embed = discord.Embed(
                title="Status Reset",
                description=f"Eligibility status has been successfully reset for {user.mention}.\nThey will be prompted to complete the check again on their next command.",
                color=discord.Color.green(),
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            logging.error(f"Failed to reset eligibility status for user {user_id}: {e}")
            embed = discord.Embed(
                title="Error",
                description="An error occurred while resetting the status. Please try again.",
                color=discord.Color.red(),
            )
            await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Reverify(bot))
