import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
import asyncio
from utils.renew_vps import RenewModal
import math
import re
from datetime import datetime, timedelta
import aiohttp
import os
import logging
from utils import node_manager
import paramiko
import pytz
from .plans import LXC_AD_TIERS, WatchAdsForVpsView

# Flask server details for ads
PUBLIC_FLASK_HOST = os.getenv("PUBLIC_FLASK_HOST", "api-veridian.duckdns.org")
FLASK_PORT = 6028
FLASK_BASE_URL = f"https://{PUBLIC_FLASK_HOST}:{FLASK_PORT}"

# ====================================================================================================================
# 1. CONSTANTS & CONFIG
# ====================================================================================================================

MINING_PORTS = [
    3333, 4444, 5555, 7777, 8888, 9999, 14444, 45700, 1800, 8000, 8001, 8008, 8118, 9000, 9001, 12000, 65000,
    25, 80, 302, 303, 44158, 44159, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009,
    6000, 6001, 6002, 6003, 6004, 6005, 6006, 6007, 6008, 6009, 7000, 7001, 7002, 7003, 7004, 7005,
    7006, 7007, 7008, 7009,
]

# ====================================================================================================================
# 2. HELPER FUNCTIONS
# ====================================================================================================================

def _create_embed(title: str, description: str, color: discord.Color = 0xE5E6EB) -> discord.Embed:
    """Creates a Discord embed with a consistent style."""
    return discord.Embed(title=title, description=description, color=color)

# ====================================================================================================================
# 3. UI COMPONENTS (VIEWS & MODALS)
# ====================================================================================================================

class AuthorRestrictedView(discord.ui.View):
    """A view that only allows the original author of the command to interact."""
    def __init__(self, author_id: int, timeout=180):
        super().__init__(timeout=timeout)
        self.author_id = author_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user and interaction.user.id == self.author_id:
            return True
        await interaction.response.defer(ephemeral=True, thinking=False)
        await interaction.followup.send(
            embed=_create_embed("Permission Denied", "You are not authorized to interact with this.", 0x992D22),
            ephemeral=True
        )
        return False

class PortForwardView(AuthorRestrictedView):
    """View for managing port forwarding on a VPS."""
    def __init__(self, author_id: int, container_name: str, bot: commands.Bot, existing_forwards: list, manage_cog, node_info: dict):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.bot = bot
        self.existing_forwards = existing_forwards
        self.manage_cog = manage_cog
        self.node_info = node_info

    @discord.ui.button(label="Add Port", style=discord.ButtonStyle.success)
    async def add_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = PortForwardModal(self.container_name, self.bot, self.existing_forwards, self.node_info)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Delete Port", style=discord.ButtonStyle.danger)
    async def delete_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = PortDeleteModal(self.container_name, self.bot)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.secondary)
    async def refresh_ports(self, interaction: discord.Interaction, button: discord.ui.Button):
        node_info = node_manager.get_node_for_vps(self.container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        result = await node_manager.api_request('GET', f"/lxc/container/{self.container_name}/ports", node_url, api_key)
        updated_forwards = result.get("ports", []) if result else []

        if updated_forwards:
            domain = self.node_info.get('domain', 'jupyterhive.duckdns.org')
            forward_list = [f"- {f} ({domain}:{f.split('/')[0]})" for f in updated_forwards]
            description = "```\n" + "\n".join(forward_list) + "\n```"
            embed = _create_embed(f"Forwarded Ports for {self.container_name}", description)
        else:
            embed = _create_embed(f"Forwarded Ports for {self.container_name}", "No ports are currently forwarded.")
        
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary)
    async def back_to_vps_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.container_name)

class ConfirmReinstallView(AuthorRestrictedView):
    """Confirmation view for reinstalling a VPS."""
    def __init__(self, author_id: int, container_name: str, manage_cog, original_embed: discord.Embed | None):
        super().__init__(author_id, timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.original_embed = original_embed

    @discord.ui.button(label="Confirm Reinstall", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        for child in self.children:
            child.disabled = True  # type: ignore
        
        await interaction.response.edit_message(
            embed=_create_embed("Reinstalling... [5%]", "Initializing reinstallation process.", 0xE5E6EB),
            view=self
        )

        node_info = node_manager.get_node_for_vps(self.container_name)
        if not node_info:
            await interaction.edit_original_response(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), view=None)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(self.container_name)
        if not vps_db_info:
            await interaction.edit_original_response(embed=_create_embed("Database Error", "Could not find VPS information in the database."), view=None)
            return

        vps_type = vps_db_info.get('vps_type', 'lxc')
        endpoint_prefix = f"/{vps_type}/{ 'vm' if vps_type == 'kvm' else 'container'}"

        reinstall_result = None
        max_retries = 3
        for attempt in range(max_retries):
            start_time = asyncio.get_event_loop().time()
            check_interval = 2
            last_update = 0
            
            async def monitor_reinstall_progress():
                nonlocal last_update
                elapsed = 0
                while elapsed < 1800:  # Max 30 mins
                    elapsed = asyncio.get_event_loop().time() - start_time
                    if elapsed - last_update >= check_interval:
                        last_update = elapsed
                        progress_percent = min(int(15 + (elapsed / 1800) * 75), 89)
                        await interaction.edit_original_response(
                            embed=_create_embed(
                                f"Reinstalling... [{progress_percent}%]", 
                                f"Processing on node `{vps_db_info.get('node')}`... ({int(elapsed)}s elapsed, Attempt {attempt + 1}/{max_retries})",
                                0xE5E6EB
                            ),
                            view=self
                        )
                    await asyncio.sleep(0.5)
            
            monitor_task = asyncio.create_task(monitor_reinstall_progress())
            try:
                reinstall_result = await node_manager.api_request('POST', f"{endpoint_prefix}/{self.container_name}/reinstall", node_url, api_key)
            finally:
                monitor_task.cancel()
                try:
                    await monitor_task
                except asyncio.CancelledError:
                    pass
            
            if reinstall_result and (reinstall_result.get("status") == "success" or reinstall_result.get("result")):
                break
            await asyncio.sleep(5)

        if reinstall_result and (reinstall_result.get("status") == "success" or reinstall_result.get("result")):
            await interaction.edit_original_response(
                embed=_create_embed("Reinstalling... [90%]", "Processing response and updating database...", 0xE5E6EB),
                view=self
            )

            new_container_name = None
            new_ssh_link = None
            new_ssh_password = None
            new_ssh_port = None
            new_vm_ip = None

            if vps_type == 'lxc':
                result_data = reinstall_result.get("result", [])
                if len(result_data) == 4:
                    new_container_name, new_ssh_link, new_ssh_port, new_ssh_password = result_data
            else: # kvm
                new_container_name = reinstall_result.get("new_vm_name")
                new_ssh_link = reinstall_result.get("ssh_connection")
                new_ssh_password = reinstall_result.get("ssh_password")
                new_ssh_port = reinstall_result.get("ssh_port")
                new_vm_ip = reinstall_result.get("vm_ip")

            if node_info.get("domain") and new_ssh_link:
                new_ssh_link = re.sub(r'@([\w.-]+)', f'@{node_info["domain"]}', new_ssh_link)

            if new_container_name and new_ssh_link and new_ssh_password and new_ssh_port:
                await interaction.edit_original_response(
                    embed=_create_embed("Reinstalling... [95%]", "Saving new credentials...", 0xE5E6EB),
                    view=self
                )
                db.delete_vps_by_container_name(self.container_name)
                db.add_vps(
                    user_id=vps_db_info['user_id'],
                    username=vps_db_info['username'],
                    container_name=new_container_name,
                    cpu=vps_db_info['cpu'],
                    ram=vps_db_info['ram'],
                    disk=vps_db_info['disk'],
                    cost_credits=vps_db_info['cost_credits'],
                    ssh_link=new_ssh_link,
                    ssh_port=new_ssh_port,
                    ssh_password=new_ssh_password,
                    vps_type=vps_type,
                    ip_address=new_vm_ip if vps_type == 'kvm' else None,
                    node=vps_db_info.get('node'), # Re-use the same node
                    due_date=vps_db_info.get('due_date'),
                    plan_tier=vps_db_info.get('plan_tier') # Add plan_tier
                )

                private_ssh_embed = _create_embed(
                    f"New SSH Details for {new_container_name}",
                    f"**SSH Link:**\n```\n{new_ssh_link}\n```\n**Password:**\n```\n{new_ssh_password}\n```"
                )
                await interaction.followup.send(embed=private_ssh_embed, ephemeral=True)

                await interaction.edit_original_response(
                    content=None,
                    embed=_create_embed("Reinstall Success [100%]", f"{self.container_name} was reinstalled as {new_container_name}. New SSH credentials have been sent to you.", 0xE5E6EB),
                    view=None
                )
            else:
                await interaction.edit_original_response(embed=_create_embed("Reinstall Failed", f"API returned unexpected data for {self.container_name} after {max_retries} attempts."), view=None)

        else:
            conn = None
            cursor = None
            try:
                conn, cursor = db.start_transaction()
                db.add_credits(vps_db_info['user_id'], vps_db_info['cost_credits'], cursor=cursor, conn=conn)
                db.commit_transaction(conn, cursor)
                await interaction.edit_original_response(embed=_create_embed("Reinstall Failed", f"Failed to reinstall {self.container_name} after {max_retries} attempts. Your credits for this VPS have been refunded."), view=None)
            except Exception as e:
                if conn and cursor:
                    db.rollback_transaction(conn, cursor)
                logging.error(f"Reinstall: Failed to refund user {vps_db_info['user_id']} credits: {e}")
                await interaction.edit_original_response(embed=_create_embed("Reinstall Failed (Refund Error)", f"Failed to reinstall {self.container_name} AND failed to refund credits. Please contact support.", 0x992D22), view=None)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=_create_embed("Cancelled", "Reinstallation has been cancelled."), view=None)
        self.stop()

class ConfirmDeleteView(AuthorRestrictedView):
    """Confirmation view for deleting a VPS."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=60)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Confirm Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        await interaction.edit_original_response(
            embed=_create_embed("Deleting VPS", f"Stopping and deleting {self.container_name}...", 0xE5E6EB),
            view=None
        )
        
        node_info = node_manager.get_node_for_vps(self.container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(self.container_name)
        vps_type = vps_db_info.get('vps_type', 'lxc') if vps_db_info else 'lxc'
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        # It's often better to attempt deletion directly. The API should handle stopping if necessary.
        delete_result = await node_manager.api_request('DELETE', f"{endpoint_prefix}/{self.container_name}", node_url, api_key)

        if delete_result and (delete_result.get("deleted") or (vps_type == 'kvm' and delete_result.get("status") == "success")):
            db.delete_vps_by_container_name(self.container_name)
            await interaction.edit_original_response(
                embed=_create_embed("Deletion Success", f"{self.container_name} has been permanently deleted.", 0xE5E6EB)
            )
        else:
            # Even if API fails, if the VPS is gone from DB, it might be okay.
            if not db.get_vps_by_container_name(self.container_name):
                 await interaction.edit_original_response(
                    embed=_create_embed("Deletion Success", f"{self.container_name} has been permanently deleted.", 0xE5E6EB)
                )
            else:
                await interaction.edit_original_response(
                    embed=_create_embed("Deletion Failed", f"Failed to delete {self.container_name}. It may have already been deleted or an API error occurred.", 0x992D22)
                )


    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=_create_embed("Cancelled", "Deletion has been cancelled.", 0x99AAB5),
            view=None
        )

class PortDeleteModal(discord.ui.Modal, title="Delete Port Forward"):
    port_input = discord.ui.TextInput(label="Port to Delete", placeholder="e.g., 8080", required=True)

    def __init__(self, container_name: str, bot: commands.Bot):
        super().__init__()
        self.container_name = container_name
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        node_info = node_manager.get_node_for_vps(self.container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        port_to_delete_str = self.port_input.value.strip()
        if not port_to_delete_str.isdigit():
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter a valid port number.", 0x992D22), ephemeral=True)
            return
        
        port_to_delete = int(port_to_delete_str)
        result = await node_manager.api_request('DELETE', f"/lxc/container/{self.container_name}/ports", node_url, api_key, data={"port": port_to_delete})

        if result and result.get("result"):
            embed = _create_embed("Success", f"Port forward for port {port_to_delete} has been deleted.", 0xE5E6EB)
        else:
            embed = _create_embed("Error", f"Failed to delete port {port_to_delete}. It might not exist or an error occurred.", 0x992D22)
        await interaction.followup.send(embed=embed, ephemeral=True)

class PortForwardModal(discord.ui.Modal, title="Add Port Forward"):
    ports_input = discord.ui.TextInput(label="Ports to Forward (hyphen-separated)", placeholder="e.g., 80-443-8080", required=True)

    def __init__(self, container_name: str, bot: commands.Bot, existing_forwards: list, node_info: dict):
        super().__init__()
        self.container_name = container_name
        self.bot = bot
        self.node_info = node_info

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        node_info = node_manager.get_node_for_vps(self.container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        ports_str = self.ports_input.value
        ports_to_forward = [p.strip() for p in ports_str.split('-') if p.strip().isdigit()]

        if not ports_to_forward:
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter valid port numbers separated by hyphens.", 0x992D22), ephemeral=True)
            return

        success_messages, error_messages = [], []
        for port in ports_to_forward:
            if int(port) in MINING_PORTS:
                error_messages.append(f"Port {port} is a known mining port and cannot be forwarded.")
                continue
            try:
                result = await node_manager.api_request('POST', f"/lxc/container/{self.container_name}/ports", node_url, api_key, data={"port": int(port)})
                if result and result.get("result"):
                    domain = self.node_info.get('domain', 'jupyterhive.duckdns.org')
                    success_messages.append(f"Port {port} forwarded to {domain}:{port}")
                else:
                    error_messages.append(f"Failed to forward port {port}. (API Error)")
            except Exception as e:
                error_messages.append(f"Error forwarding port {port}: {e}")
        
        description = ""
        if success_messages:
            description += "**Successes:**\n" + "\n".join(success_messages)
        if error_messages:
            description += "\n\n**Errors:**\n" + "\n".join(error_messages)

        color = 0xE5E6EB if not error_messages else (0x992D22 if not success_messages else 0x99AAB5)
        await interaction.followup.send(embed=_create_embed("Port Forwarding Results", description, color), ephemeral=True)


class KVM_PortForwardModal(discord.ui.Modal, title="Add KVM Port Forward"):
    external_port_input = discord.ui.TextInput(label="External Port", placeholder="e.g., 8080", required=True)
    internal_port_input = discord.ui.TextInput(label="Internal Port (VM's port)", placeholder="e.g., 80", required=True)

    def __init__(self, vm_name: str, bot: commands.Bot, node_info: dict):
        super().__init__()
        self.vm_name = vm_name
        self.bot = bot
        self.node_info = node_info

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        node_info = node_manager.get_node_for_vps(self.vm_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VM."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        external_port_str = self.external_port_input.value.strip()
        internal_port_str = self.internal_port_input.value.strip()

        if not external_port_str.isdigit() or not internal_port_str.isdigit():
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter valid port numbers.", 0x992D22), ephemeral=True)
            return
        
        external_port = int(external_port_str)
        internal_port = int(internal_port_str)

        if external_port in MINING_PORTS or internal_port in MINING_PORTS:
            await interaction.followup.send(embed=_create_embed("Invalid Port", "Mining ports cannot be forwarded.", 0x992D22), ephemeral=True)
            return

        result = await node_manager.api_request('POST', f"/kvm/vm/{self.vm_name}/ports", node_url, api_key, data={"external_port": external_port, "internal_port": internal_port})

        if result and result.get("result"):
            embed = _create_embed("Success", f"Port forward {external_port} -> {internal_port} has been added.", 0xE5E6EB)
        else:
            embed = _create_embed("Error", f"Failed to add port forward {external_port} -> {internal_port}. It might already exist or an error occurred.", 0x992D22)
        await interaction.followup.send(embed=embed, ephemeral=True)


class KVM_PortDeleteModal(discord.ui.Modal, title="Delete KVM Port Forward"):
    external_port_input = discord.ui.TextInput(label="External Port to Delete", placeholder="e.g., 8080", required=True)

    def __init__(self, vm_name: str, bot: commands.Bot, node_info: dict):
        super().__init__()
        self.vm_name = vm_name
        self.bot = bot
        self.node_info = node_info

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        node_info = node_manager.get_node_for_vps(self.vm_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VM."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        external_port_str = self.external_port_input.value.strip()
        if not external_port_str.isdigit():
            await interaction.followup.send(embed=_create_embed("Invalid Input", "Please enter a valid port number.", 0x992D22), ephemeral=True)
            return
        
        external_port = int(external_port_str)
        result = await node_manager.api_request('DELETE', f"/kvm/vm/{self.vm_name}/ports/{external_port}", node_url, api_key)

        if result and result.get("result"):
            embed = _create_embed("Success", f"Port forward for external port {external_port} has been deleted.", 0xE5E6EB)
        else:
            embed = _create_embed("Error", f"Failed to delete port {external_port}. It might not exist or an error occurred.", 0x992D22)
        await interaction.followup.send(embed=embed, ephemeral=True)


class KVM_PortForwardView(AuthorRestrictedView):
    """View for managing port forwarding on a KVM VM."""
    def __init__(self, author_id: int, vm_name: str, bot: commands.Bot, existing_forwards: list, manage_cog, node_info: dict):
        super().__init__(author_id, timeout=180)
        self.vm_name = vm_name
        self.bot = bot
        self.existing_forwards = existing_forwards
        self.manage_cog = manage_cog
        self.node_info = node_info

    @discord.ui.button(label="Add Port", style=discord.ButtonStyle.success)
    async def add_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = KVM_PortForwardModal(self.vm_name, self.bot, self.node_info)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Delete Port", style=discord.ButtonStyle.danger)
    async def delete_port(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = KVM_PortDeleteModal(self.vm_name, self.bot, self.node_info)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Refresh", style=discord.ButtonStyle.secondary)
    async def refresh_ports(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        
        node_info = node_manager.get_node_for_vps(self.vm_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VM."), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        result = await node_manager.api_request('GET', f"/kvm/vm/{self.vm_name}/ports", node_url, api_key)
        updated_forwards = result.get("ports", []) if result else []

        if updated_forwards:
            forward_list = [f"- {f}" for f in updated_forwards]
            description = "```\n" + "\n".join(forward_list) + "\n```"
            embed = _create_embed(f"Forwarded Ports for {self.vm_name}", description)
        else:
            embed = _create_embed(f"Forwarded Ports for {self.vm_name}", "No ports are currently forwarded.")
        
        await interaction.edit_original_response(embed=embed, view=self)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary)
    async def back_to_vps_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.vm_name)





class VPSActionView(AuthorRestrictedView):
    """Main view for VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, custom_id="start")
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._start_callback(interaction, self.container_name)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, custom_id="restart")
    async def restart_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._restart_callback(interaction, self.container_name)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger, custom_id="stop")
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._stop_callback(interaction, self.container_name)

    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.secondary, custom_id="reinstall")
    async def reinstall_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._reinstall_callback(interaction, self.container_name)

    @discord.ui.button(label="Other", style=discord.ButtonStyle.primary, custom_id="other")
    async def other_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._other_callback(interaction, self.container_name)


class OtherActionsView(AuthorRestrictedView):
    """View for additional VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog, bot: commands.Bot):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.bot = bot

    @discord.ui.button(label="View SSH", style=discord.ButtonStyle.primary, custom_id="view_ssh")
    async def view_ssh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._view_ssh_callback(interaction, self.container_name)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, custom_id="delete")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._delete_callback(interaction, self.container_name)

    @discord.ui.button(label="Port Forward", style=discord.ButtonStyle.secondary, custom_id="port_forward")
    async def port_forward_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._port_forward_callback(interaction, self.container_name)

    @discord.ui.button(label="Renew", style=discord.ButtonStyle.success, custom_id="renew")
    async def renew_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        vps_info = db.get_vps_by_container_name(self.container_name)
        if not vps_info:
            await interaction.response.send_message(embed=_create_embed("Error", "Could not find VPS information."), ephemeral=True)
            return

        plan_tier = vps_info.get('plan_tier')
        invite_plan_tier = vps_info.get('invite_plan_tier')

        if plan_tier and plan_tier in LXC_AD_TIERS:
            # Ad-supported renewal logic using VPS points
            await interaction.response.defer(ephemeral=True, thinking=True)
            
            tier_info = LXC_AD_TIERS[plan_tier]
            required_points = tier_info['ads_required']  # Number of points needed per day
            
            user_vps_points = db.get_vps_points(interaction.user.id)
            
            if user_vps_points >= required_points:
                # Consume points and renew for 1 day using transaction
                conn, cursor = db.start_transaction()
                try:
                    # Consume the points
                    if db.consume_vps_points(interaction.user.id, required_points, cursor=cursor, conn=conn):
                        # Extend the VPS due date
                        db.extend_vps_due_date_by_days(vps_info['id'], 1, cursor=cursor, conn=conn)
                        db.commit_transaction(conn, cursor)
                        
                        remaining_points = db.get_vps_points(interaction.user.id)
                        
                        embed = discord.Embed(
                            title="Renewal Successful",
                            description=f"Your VPS `{self.container_name}` has been renewed for 1 day using **{required_points} VPS Points**.",
                            color=0x2ECC71
                        )
                        embed.add_field(name="Remaining VPS Points", value=f"{remaining_points}", inline=True)
                        embed.add_field(name="Next Renewal", value="You need to earn more VPS Points by watching linkvertise ads.", inline=False)
                        await interaction.followup.send(embed=embed, ephemeral=True)
                    else:
                        db.rollback_transaction(conn, cursor)
                        embed = discord.Embed(
                            title="Error",
                            description="Failed to consume VPS points. Please try again.",
                            color=0x992D22
                        )
                        await interaction.followup.send(embed=embed, ephemeral=True)
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Error during VPS renewal for {interaction.user.id}: {e}")
                    embed = discord.Embed(
                        title="Error",
                        description="An error occurred during renewal. Please try again.",
                        color=0x992D22
                    )
                    await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                points_needed = required_points - user_vps_points
                embed = discord.Embed(
                    title="Not Enough VPS Points",
                    description=f"To renew your ad-supported VPS, you need **{required_points}** VPS Points. "
                                f"You have **{user_vps_points}** VPS Points. "
                                f"You need **{points_needed} more** VPS Points to renew.",
                    color=0x992D22 # Red
                )
                embed.add_field(name="How to Get VPS Points", value="Watch **Linkvertise** ads on `/earn` command. Each ad watched = 1 VPS Point.", inline=False)
                view = WatchAdsForVpsView(self.bot, interaction.user.id)
                await interaction.followup.send(embed=embed, view=view, ephemeral=True)

        elif invite_plan_tier:
            await interaction.response.send_message(embed=_create_embed("Info", "Invite-based VPS are renewed automatically based on your monthly invite count. There is no manual renewal option.", 0x3498DB), ephemeral=True)

        else:
            # Paid plan renewal logic - NOW AUTOMATIC
            await interaction.response.defer(ephemeral=True, thinking=True)

            renewal_cost = vps_info.get('cost_credits')
            if not renewal_cost or renewal_cost <= 0:
                await interaction.followup.send(embed=_create_embed("Error", "This VPS does not have a credit cost and cannot be renewed this way.", 0x992D22), ephemeral=True)
                return
            
            user_id = interaction.user.id
            user_balance = db.get_balance(user_id)

            if user_balance >= renewal_cost:
                conn, cursor = db.start_transaction()
                try:
                    db.add_credits(user_id, -renewal_cost, cursor=cursor, conn=conn)
                    db.extend_vps_due_date_by_days(vps_info['id'], 30, cursor=cursor, conn=conn)
                    db.commit_transaction(conn, cursor)

                    updated_vps_info = db.get_vps_by_container_name(self.container_name)
                    new_due_date = updated_vps_info.get('due_date')

                    embed = _create_embed("Renewal Successful", f"Your VPS `{self.container_name}` has been renewed for 30 days.", 0x2ECC71)
                    embed.add_field(name="Cost", value=f"{renewal_cost} credits", inline=True)
                    embed.add_field(name="New Balance", value=f"{db.get_balance(user_id)} credits", inline=True)
                    new_due_date_str = new_due_date.strftime('%Y-%m-%d %H:%M') if new_due_date else 'N/A'
                    embed.add_field(name="New Expiry Date", value=new_due_date_str, inline=False)
                    await interaction.followup.send(embed=embed, ephemeral=True)
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    logging.error(f"Error during manual renewal for {self.container_name}: {e}")
                    await interaction.followup.send(embed=_create_embed("Error", "An unexpected error occurred during the transaction.", 0x992D22), ephemeral=True)
            else:
                embed = _create_embed("Insufficient Credits", f"You need {renewal_cost} credits to renew for 30 days, but you only have {user_balance}.", 0x992D22)
                await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(label="Transfer", style=discord.ButtonStyle.secondary, custom_id="transfer")
    async def transfer_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._transfer_callback(interaction, self.container_name)

    @discord.ui.button(label="Fix SSH", style=discord.ButtonStyle.secondary, custom_id="fix_ssh")
    async def fix_ssh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._fix_ssh_callback(interaction, self.container_name)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, custom_id="back")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.container_name)


class ForceTransferView(AuthorRestrictedView):
    """A view that only shows the transfer button for users on premium nodes without a role."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Transfer to Free Node", style=discord.ButtonStyle.danger)
    async def transfer_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._transfer_callback(interaction, self.container_name)


# New View for Node Selection during Transfer
class TransferNodeSelectionView(AuthorRestrictedView):
    def __init__(self, author_id: int, container_name: str, manage_cog, original_interaction: discord.Interaction):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog
        self.original_interaction = original_interaction

    @classmethod
    async def create(cls, author_id: int, container_name: str, manage_cog, original_interaction: discord.Interaction):
        view = cls(author_id, container_name, manage_cog, original_interaction)
        await view.add_node_buttons()
        return view

    async def add_node_buttons(self):
        current_vps_info = db.get_vps_by_container_name(self.container_name)
        current_node = current_vps_info.get('node') if current_vps_info else None
        vps_type = current_vps_info.get('vps_type', 'lxc')

        # --- Check for forced transfer to free node ---
        current_node_info = node_manager.get_node_for_vps(self.container_name)
        user = self.original_interaction.user
        user_roles = [role.id for role in user.roles]
        PREMIUM_ROLE_ID = 1358004192416890903
        BOOSTER_ROLE_ID = 1436388721086693567
        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        
        # User can stay on premium if they have: admin, premium role, booster role, or bought credits
        has_admin = user.id in ADMIN_WHITELIST
        has_premium_role = PREMIUM_ROLE_ID in user_roles
        has_booster_role = BOOSTER_ROLE_ID in user_roles
        has_paid = db.has_completed_credit_transaction(user.id)
        
        can_use_premium = has_admin or has_premium_role or has_booster_role or has_paid
        force_to_free_node = current_node_info and current_node_info.get('premium') and not can_use_premium
        # --- End of Check ---

        node_stats_tasks = [node_manager.get_node_stats(name, info) for name, info in node_manager.NODES.items()]
        node_results = await asyncio.gather(*node_stats_tasks)

        for i, (node_name, node_info) in enumerate(node_manager.NODES.items()):
            # Allow all transfers, but will show warnings based on direction
            # Don't skip premium nodes anymore - let the user choose
            
            if i >= 5:
                break
            
            stats = node_results[i]
            if vps_type == 'lxc':
                max_cap = stats.get('lxc_max', 0)
            else:
                max_cap = stats.get('kvm_max', 0)

            is_disabled = (node_name == current_node) or (max_cap == 0)
            
            button = discord.ui.Button(
                label=node_name.capitalize(),
                style=discord.ButtonStyle.secondary,
                custom_id=f"transfer_to_node:{node_name}",
                disabled=is_disabled
            )
            button.callback = self.node_button_callback
            self.add_item(button)

    async def node_button_callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        selected_node_name = interaction.data['custom_id'].split(':')[1]
        selected_node_info = node_manager.NODES.get(selected_node_name)

        if not selected_node_info:
            await interaction.followup.send("Selected node not found or configured.", ephemeral=True)
            return

        current_vps_info = db.get_vps_by_container_name(self.container_name)
        current_node_info = node_manager.NODES.get(current_vps_info.get('node')) if current_vps_info else None
        vps_type = current_vps_info.get('vps_type', 'lxc')
        
        # Get target node capabilities
        stats = await node_manager.get_node_stats(selected_node_name, selected_node_info)
        if vps_type == 'lxc':
            max_cap = stats.get('lxc_max', 0)
            current = stats.get('lxc_current', 0)
        else:
            max_cap = stats.get('kvm_max', 0)
            current = stats.get('kvm_current', 0)

        if max_cap == 0:
            await interaction.followup.send(f"Node `{selected_node_name}` does not support {vps_type.upper()} VPSs.", ephemeral=True)
            return
        if current >= max_cap:
            await interaction.followup.send(f"Node `{selected_node_name}` is now full. Please try another node.", ephemeral=True)
            return

        PREMIUM_ROLE_ID = 1358004192416890903
        BOOSTER_ROLE_ID = 1436388721086693567
        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        
        current_is_premium = current_node_info and current_node_info.get('premium', False)
        target_is_premium = selected_node_info.get('premium', False)
        
        # Premium to Free transfer: Show warning
        if current_is_premium and not target_is_premium:
            user_roles = [role.id for role in interaction.user.roles]
            has_admin = interaction.user.id in ADMIN_WHITELIST
            has_premium_role = PREMIUM_ROLE_ID in user_roles
            has_booster_role = BOOSTER_ROLE_ID in user_roles
            has_paid = db.has_completed_credit_transaction(interaction.user.id)
            
            can_use_premium = has_admin or has_premium_role or has_booster_role or has_paid
            
            if can_use_premium:
                # User has permission to use premium but wants to transfer to free
                embed = discord.Embed(
                    title="⚠️ Warning: Transferring to Free Node",
                    description=f"You are transferring your VPS from a **premium node** to a **free node**.\n\n"
                                f"**⚠️ Important:** Your data on free nodes may be **deleted at any time** without notice. Free nodes are not guaranteed to be reliable.\n\n"
                                f"Are you sure you want to continue?",
                    color=0xF39C12
                )
                
                class ConfirmTransferView(discord.ui.View):
                    def __init__(self, parent_view):
                        super().__init__(timeout=60)
                        self.parent_view = parent_view
                    
                    @discord.ui.button(label="Continue Transfer", style=discord.ButtonStyle.danger)
                    async def confirm(self, button_interaction: discord.Interaction, button: discord.ui.Button):
                        await button_interaction.response.defer(ephemeral=True)
                        await self.parent_view.manage_cog._execute_vps_transfer(
                            interaction,
                            self.parent_view.container_name,
                            selected_node_name,
                            selected_node_info
                        )
                        self.stop()
                    
                    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
                    async def cancel(self, button_interaction: discord.Interaction, button: discord.ui.Button):
                        await button_interaction.response.defer(ephemeral=True)
                        await interaction.followup.send("Transfer cancelled.", ephemeral=True)
                        self.stop()
                
                await interaction.followup.send(embed=embed, view=ConfirmTransferView(self), ephemeral=True)
                return
        
        # Free to Premium transfer: Check permissions but no warning
        elif not current_is_premium and target_is_premium:
            user_roles = [role.id for role in interaction.user.roles]
            
            # User can transfer to premium if they have: admin, premium role, booster role, or bought credits
            has_admin = interaction.user.id in ADMIN_WHITELIST
            has_premium_role = PREMIUM_ROLE_ID in user_roles
            has_booster_role = BOOSTER_ROLE_ID in user_roles
            has_paid = db.has_completed_credit_transaction(interaction.user.id)
            
            can_use_premium = has_admin or has_premium_role or has_booster_role or has_paid
            
            if not can_use_premium:
                await interaction.followup.send("You do not have the required role/payment to transfer to a premium node. You need to be an admin, have the premium role, booster role, or have purchased credits.", ephemeral=True)
                return
        
        # Normal transfer (premium to premium or free to free): No confirmation needed
        await self.manage_cog._execute_vps_transfer(
            self.original_interaction,
            self.container_name,
            selected_node_name,
            selected_node_info
        )
        self.stop()


class VPSSelectView(discord.ui.View):
    def __init__(self, author_id: int, vps_list: list, manage_cog):
        super().__init__(timeout=180)
        self.author_id = author_id
        self.manage_cog = manage_cog

        options = [
            discord.SelectOption(label=f"{vps['container_name']} ({vps['vps_type'].upper()})", value=vps['container_name'])
            for vps in vps_list
        ]
        self.select = discord.ui.Select(placeholder="Select a VPS to manage...", options=options)
        self.select.callback = self.select_callback
        self.add_item(self.select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.author_id:
            return True
        await interaction.response.defer(ephemeral=True, thinking=False)
        await interaction.followup.send("You are not authorized to interact with this.", ephemeral=True)
        return False

    async def select_callback(self, interaction: discord.Interaction):
        selected_container = self.select.values[0]
        await self.manage_cog.display_vps_info(interaction, selected_container)


class DedicatedVPSActionView(AuthorRestrictedView):
    """Main view for Dedicated VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="View SSH", style=discord.ButtonStyle.primary, custom_id="view_ssh_dedicated")
    async def view_ssh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._view_ssh_callback(interaction, self.container_name)

    @discord.ui.button(label="Un-attribute", style=discord.ButtonStyle.danger, custom_id="unattribute_dedicated")
    async def unattribute_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._unattribute_dedicated_callback(interaction, self.container_name)

    @discord.ui.button(label="Other", style=discord.ButtonStyle.primary, custom_id="other_dedicated")
    async def other_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._other_dedicated_callback(interaction, self.container_name)


class DedicatedOtherActionsView(AuthorRestrictedView):
    """View for additional Dedicated VPS actions."""
    def __init__(self, author_id: int, container_name: str, manage_cog):
        super().__init__(author_id, timeout=180)
        self.container_name = container_name
        self.manage_cog = manage_cog

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, custom_id="delete_dedicated")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog._delete_callback(interaction, self.container_name)

    @discord.ui.button(label="Back", style=discord.ButtonStyle.secondary, custom_id="back_dedicated")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.manage_cog.display_vps_info(interaction, self.container_name)


# ====================================================================================================================
# 4. MANAGE COMMAND COG
# ====================================================================================================================

class Manage(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _get_kvm_stats_ssh(self, vps_info: dict) -> dict:
        """Gets KVM stats via a direct SSH connection."""
        stats = {
            "uptime": "N/A", "cpu_usage": "N/A", "ram_usage": "N/A",
            "disk_usage": "N/A", "status": "Offline"
        }
        
        ssh_link = vps_info.get('ssh_link')
        ssh_password = vps_info.get('ssh_password')

        if not ssh_link or not ssh_password:
            stats["status"] = "SSH Info Missing"
            return stats

        match = re.search(r'ssh\s+\w+@([\w.-]+)\s+-p\s+(\d+)', ssh_link)
        if not match:
            stats["status"] = "Invalid SSH Link"
            return stats
        
        host, port_str = match.groups()
        port = int(port_str)

        try:
            async with asyncssh.connect(host, port=port, username='root', password=ssh_password, known_hosts=None, connect_timeout=10) as conn:
                stats["status"] = "Online"

                # Uptime
                uptime_result = await conn.run("uptime -p", check=False, timeout=5)
                if uptime_result.exit_status == 0 and uptime_result.stdout:
                    stats["uptime"] = uptime_result.stdout.strip().replace("up ", "")

                # CPU Usage
                cpu_result = await conn.run("top -bn1 | grep '^%Cpu' | grep -oE '[0-9.]+us|[0-9.]+sy' | sed 's/[a-z]*$//' | awk '{s+=$1} END {print s}'", check=False, timeout=5)
                if cpu_result.exit_status == 0 and cpu_result.stdout:
                    try:
                        stats["cpu_usage"] = f"{float(cpu_result.stdout.strip()):.1f}%"
                    except ValueError:
                        stats["cpu_usage"] = "N/A"

                # RAM Usage
                ram_result = await conn.run("free -m", check=False, timeout=5)
                if ram_result.exit_status == 0 and ram_result.stdout:
                    lines = ram_result.stdout.split('\n')
                    if len(lines) > 1 and 'Mem:' in lines[1]:
                        parts = lines[1].split()
                        if len(parts) >= 4:
                            total_ram_mb, used_ram_mb = int(parts[1]), int(parts[2])
                            stats["ram_usage"] = f"{used_ram_mb / 1024:.2f}GB / {total_ram_mb / 1024:.2f}GB"
                
                # Disk Usage
                disk_result = await conn.run("df -h --output=pcent,used,size /", check=False, timeout=5)
                if disk_result.exit_status == 0 and disk_result.stdout:
                    lines = disk_result.stdout.split('\n')
                    if len(lines) > 1:
                        disk_line = lines[1].strip()
                        parts = disk_line.split()
                        if len(parts) >= 3:
                            pcent, used, size = parts
                            stats["disk_usage"] = f"{used} / {size} ({pcent})"

        except (asyncssh.Error, socket.gaierror, OSError, asyncio.TimeoutError) as e:
            logging.warning(f"SSH connection for KVM stats failed for {vps_info['container_name']}: {e}")
            stats["status"] = "SSH Conn. Failed"
        except Exception as e:
            logging.error(f"Unexpected error getting KVM stats via SSH for {vps_info['container_name']}: {e}")
            stats["status"] = "Error"
            
        return stats

    async def _get_dedicated_stats_ssh(self, vps_info: dict) -> dict:
        stats = {
            "uptime": "N/A",
            "cpu_usage": "N/A",
            "ram_usage": "N/A",
            "disk_usage": "N/A",
            "status": "Offline"
        }
        
        ip_address = vps_info.get('ip_address')
        ssh_port = vps_info.get('ssh_port')
        ssh_password = vps_info.get('ssh_password')

        if not all([ip_address, ssh_port, ssh_password]):
            return stats

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            await asyncio.to_thread(client.connect, ip_address, port=ssh_port, username='root', password=ssh_password, timeout=5)
            stats["status"] = "Online"

            # Uptime
            stdin, stdout, stderr = client.exec_command("uptime -p")
            uptime_output = stdout.read().decode().strip()
            if uptime_output:
                stats["uptime"] = uptime_output.replace("up ", "")

            # CPU Usage
            stdin, stdout, stderr = client.exec_command("top -bn1 | grep '^%Cpu' | grep -oE '[0-9.]+us|[0-9.]+sy' | sed 's/[a-z]*$//' | awk '{s+=$1} END {print s}'")
            cpu_output = stdout.read().decode().strip()
            if cpu_output:
                try:
                    stats["cpu_usage"] = f"{float(cpu_output):.1f}%"
                except ValueError:
                    stats["cpu_usage"] = "N/A"

            # RAM Usage
            stdin, stdout, stderr = client.exec_command("free -m")
            ram_output = stdout.read().decode()
            lines = ram_output.split('\n')
            if len(lines) > 1:
                mem_line = lines[1]
                parts = mem_line.split()
                if len(parts) >= 4:
                    used_ram = int(parts[2])
                    total_ram = int(parts[1])
                    stats["ram_usage"] = f"{used_ram / 1024:.2f}GB / {total_ram / 1024:.2f}GB"

            # Disk Usage
            stdin, stdout, stderr = client.exec_command("df -h --output=pcent,used,size /")
            disk_output = stdout.read().decode()
            lines = disk_output.split('\n')
            if len(lines) > 1:
                disk_line = lines[1].strip()
                parts = disk_line.split()
                if len(parts) >= 3:
                    pcent = parts[0]
                    used = parts[1]
                    size = parts[2]
                    stats["disk_usage"] = f"{used} / {size} ({pcent})"

            client.close()
        except Exception as e:
            pass

        return stats

    @commands.hybrid_command(name="manage", description="Displays information and management options for your VPS.")
    @app_commands.describe(container_name="The name of your container (optional, e.g., itsblazu-12345).")
    @app_commands.guild_only()
    async def manage(self, ctx: commands.Context, container_name: str | None = None):
        """Displays information and management options for your VPS."""
        # --- Blacklist Role Check ---
        BLACKLISTED_ROLE_ID = 1442634477963710545
        user_roles = [role.id for role in ctx.author.roles]
        if BLACKLISTED_ROLE_ID in user_roles:
            embed = _create_embed(
                "Access Denied",
                "You are not permitted to manage a VPS with your current roles.",
                0x992D22
            )
            await ctx.send(embed=embed, ephemeral=True)
            return
        # --- End of Check ---
        
        user_id = ctx.author.id

        if container_name:
            vps_info = db.get_vps_by_container_name(container_name)
            if not vps_info or (vps_info['user_id'] != user_id and vps_info['attributed_to_user_id'] != user_id):
                await ctx.send(embed=_create_embed("VPS Not Found", f"No VPS with the name `{container_name}` was found for your account.", 0x992D22), ephemeral=True)
                return
            await self.display_vps_info(ctx, container_name)
        else:
            user_vps_list = db.get_user_vps(user_id)
            dedicated_vps_list = db.get_dedicated_vps_by_user(user_id)
            
            all_vps_list = user_vps_list + dedicated_vps_list

            if not all_vps_list:
                await ctx.send(embed=_create_embed("No VPS", "You currently do not have any VPS.", 0xE5E6EB), ephemeral=True)
            elif len(all_vps_list) == 1:
                await self.display_vps_info(ctx, all_vps_list[0]['container_name'])
            else:
                view = VPSSelectView(user_id, all_vps_list, self)
                await ctx.send(embed=_create_embed("Select a VPS", "You have multiple VPS. Please select one from the list below."), view=view, ephemeral=True)

    async def display_vps_info(self, ctx: discord.Interaction | commands.Context, container_name: str):
        if isinstance(ctx, discord.Interaction) and not ctx.response.is_done():
            await ctx.response.defer(ephemeral=True)

        vps_db_info = db.get_vps_by_container_name(container_name)
        if not vps_db_info: 
            embed = _create_embed("Error", f"Could not find VPS {container_name} in the database.", 0x992D22)
            if isinstance(ctx, discord.Interaction):
                await ctx.followup.send(embed=embed, ephemeral=True)
            else:
                await ctx.send(embed=embed, ephemeral=True)
            return

        is_dedicated = vps_db_info.get('is_dedicated', False)

        if is_dedicated:
            stats = await self._get_dedicated_stats_ssh(vps_db_info)
            
            description = f"**Status:** {stats['status']}\n**Uptime:** {stats['uptime']}"
            embed = _create_embed(f"Dedicated Server: {container_name}", description)

            total_resources = f"**CPU:** {vps_db_info.get('cpu')} cores\n**RAM:** {vps_db_info.get('ram')}GB\n**Disk:** {vps_db_info.get('disk')}GB"
            embed.add_field(name="Total Resources", value=total_resources, inline=False)

            if stats['status'] == "Online":
                consumed_resources = f"**CPU:** {stats['cpu_usage']}\n**RAM:** {stats['ram_usage']}\n**Disk:** {stats['disk_usage']}"
                embed.add_field(name="Consumed Resources", value=consumed_resources, inline=False)
            else:
                embed.add_field(name="Consumed Resources", value="Server is offline.", inline=False)

            if isinstance(ctx, discord.Interaction):
                await ctx.followup.send(embed=embed, view=None, ephemeral=True)
            else:
                await ctx.send(embed=embed, view=None, ephemeral=True)
            return

        # Logic for non-dedicated VPS
        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            embed = _create_embed("Node Error", f"Could not determine the node for VPS {container_name}. Please check the configuration.", 0x992D22)
            if isinstance(ctx, discord.Interaction):
                await ctx.followup.send(embed=embed, ephemeral=True)
            else:
                await ctx.send(embed=embed, ephemeral=True)
            return

        # --- Premium Node Role Check ---
        PREMIUM_ROLE_ID = 1358004192416890903
        BOOSTER_ROLE_ID = 1436388721086693567
        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        user = ctx.author if isinstance(ctx, commands.Context) else ctx.user
        user_roles = [role.id for role in user.roles]

        is_on_premium = node_info.get('premium', False)
        
        # User can stay on premium if they have: admin, premium role, booster role, or bought credits
        has_admin = user.id in ADMIN_WHITELIST
        has_premium_role = PREMIUM_ROLE_ID in user_roles
        has_booster_role = BOOSTER_ROLE_ID in user_roles
        has_paid = db.has_completed_credit_transaction(user.id)
        
        can_use_premium = has_admin or has_premium_role or has_booster_role or has_paid

        if is_on_premium and not can_use_premium:
            embed = _create_embed(
                "Transfer Required",
                f"Your VPS `{container_name}` is on a premium node, but you do not have the required permissions. You must transfer it to a free node to continue managing it.",
                0x992D22
            )
            view = ForceTransferView(user.id, container_name, self)
            if isinstance(ctx, discord.Interaction):
                # The defer is already done at the start of the function
                await ctx.followup.send(embed=embed, view=view, ephemeral=True)
            else:
                await ctx.send(embed=embed, view=view, ephemeral=True)
            return
        # --- End of Check ---

        node_url = node_info['url']
        api_key = node_info['api_key']
        node_ip = node_info.get('ip', 'Not Configured')

        if vps_db_info.get('node') is None:
            found_node_name = "Unknown"
            for name, info in node_manager.NODES.items():
                if info['url'] == node_url:
                    found_node_name = name
                    break
            vps_db_info['node'] = found_node_name

        vps_type = vps_db_info.get('vps_type', 'lxc')
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        status, ipv4, ram_usage, disk_usage, uptime = "N/A", "N/A", "N/A", "N/A", "N/A"
        cpu_display, ram_display, disk_display = "N/A", "N/A", "N/A"
        cpu_usage_percent, network_rx, network_tx = "N/A", "N/A", "N/A"
        is_running = False

        vps_info_raw = await node_manager.api_request('GET', f"{endpoint_prefix}/{container_name}/info", node_url, api_key)

        if vps_type == 'lxc':
            if vps_info_raw and vps_info_raw.get('status') == 'running':
                status = 'running'
                is_running = True
                ipv4 = vps_info_raw.get('ipv4', 'N/A')
                
                # Get state data
                state_data = vps_info_raw.get('state', {})
                
                # Memory usage
                memory_data = state_data.get('memory', {})
                memory_usage_bytes = memory_data.get('usage', 0)
                memory_total_bytes = memory_data.get('total', 0)
                
                db_ram_value = vps_db_info.get('ram', 'N/A')
                if isinstance(db_ram_value, (int, float)) and db_ram_value >= 1:
                    ram_usage = f"{memory_usage_bytes / (1024**3):.2f}GB / {int(db_ram_value)}GB"
                else:
                    ram_usage = f"{memory_usage_bytes / (1024**2):.2f}MiB / {db_ram_value}MB"

                # Disk usage
                disk_data = state_data.get('disk', {}).get('root', {})
                disk_usage_bytes = disk_data.get('usage', 0)
                disk_total_bytes = disk_data.get('total', 0)
                disk_usage = f"{disk_usage_bytes / (1024**3):.2f}GB / {vps_db_info.get('disk', 'N/A')}GB"

                # Uptime
                uptime_seconds = state_data.get('uptime', 0)
                if uptime_seconds:
                    hours = uptime_seconds // 3600
                    minutes = (uptime_seconds % 3600) // 60
                    uptime = f"{hours}h {minutes}m"
                else:
                    uptime = "N/A"

                # CPU usage
                cpu_usage_percent = state_data.get('cpu_usage', 0)
                if cpu_usage_percent:
                    cpu_usage_percent = f"{cpu_usage_percent}%"
                else:
                    cpu_usage_percent = "N/A"

                # Network statistics
                network_data = state_data.get('network', {}).get('eth0', {})
                if network_data:
                    rx_bytes = network_data.get('bytes_received', 0)
                    tx_bytes = network_data.get('bytes_sent', 0)
                    
                    # Convert to human-readable format
                    def bytes_to_human(bytes_val):
                        if bytes_val >= 1024**3:
                            return f"{bytes_val / (1024**3):.2f}GB"
                        elif bytes_val >= 1024**2:
                            return f"{bytes_val / (1024**2):.2f}MB"
                        elif bytes_val >= 1024:
                            return f"{bytes_val / 1024:.2f}KB"
                        else:
                            return f"{bytes_val}B"
                    
                    network_rx = bytes_to_human(rx_bytes)
                    network_tx = bytes_to_human(tx_bytes)
                else:
                    network_rx = "N/A"
                    network_tx = "N/A"

                cpu_display = f"{vps_db_info.get('cpu', 'N/A')} cores"
                db_ram_value = vps_db_info.get('ram', 'N/A')
                if isinstance(db_ram_value, (int, float)) and db_ram_value >= 1:
                    ram_display = f"{int(db_ram_value)}GB"
                else:
                    ram_display = f"{db_ram_value}MB"
                disk_display = f"{vps_db_info.get('disk', 'N/A')}GB"
                
            elif vps_info_raw and vps_info_raw.get('status') == 'stopped':
                status = 'stopped'
                ipv4 = vps_info_raw.get('ipv4', 'N/A')
                cpu_display = f"{vps_db_info.get('cpu', 'N/A')} cores"
                db_ram_value = vps_db_info.get('ram', 'N/A')
                if isinstance(db_ram_value, (int, float)) and db_ram_value >= 1:
                    ram_display = f"{int(db_ram_value)}GB"
                else:
                    ram_display = f"{db_ram_value}MB"
                disk_display = f"{vps_db_info.get('disk', 'N/A')}GB"
            else:
                status = 'unknown'

        elif vps_type == 'kvm':
            if vps_info_raw and 'running' in vps_info_raw.get('State', 'shut off').lower():
                status = 'running'
                is_running = True
                ipv4 = vps_info_raw.get('ipv4', 'N/A')

                # --- Uptime Parsing ---
                uptime = 'N/A'
                uptime_keys = ['Uptime', 'CPU time', 'Time']
                uptime_str = 'N/A'
                for key in uptime_keys:
                    if key in vps_info_raw:
                        uptime_str = vps_info_raw[key]
                        break
                
                if uptime_str != 'N/A':
                    try:
                        # Case 1: "1 day, 2 hours, 3 minutes, 4 seconds"
                        if any(unit in uptime_str for unit in ['day', 'hour', 'minute']):
                            uptime = uptime_str
                        # Case 2: "123.45s"
                        elif 's' in uptime_str.lower():
                            uptime_seconds = float(uptime_str.lower().replace('s', ''))
                            uptime = str(timedelta(seconds=int(uptime_seconds)))
                        # Case 3: "12345" (seconds)
                        elif uptime_str.replace('.', '', 1).isdigit():
                            uptime_seconds = float(uptime_str)
                            uptime = str(timedelta(seconds=int(uptime_seconds)))
                        else:
                            uptime = uptime_str
                    except (ValueError, TypeError):
                        uptime = uptime_str # Fallback to raw string
                
                cpu_usage_percent = "N/A"
                
                # Try to get CPU usage from vps_info_raw for KVM
                if isinstance(vps_info_raw, dict):
                    # KVM domstats format: cpu.time, cpu.user, cpu.system (in nanoseconds)
                    # We'll estimate CPU usage from available data
                    cpu_time_ns = vps_info_raw.get('cpu.time')
                    cpu_user_ns = vps_info_raw.get('cpu.user')
                    
                    if cpu_time_ns or cpu_user_ns:
                        try:
                            # If we have cpu.user, use it as percentage estimate
                            if cpu_user_ns:
                                # Convert nanoseconds to a rough percentage
                                # This is a simplified estimate
                                cpu_value = float(cpu_user_ns) / 1e9  # Convert to seconds
                                # Cap it at 100% for display purposes
                                cpu_usage_percent = f"{min(cpu_value % 100, 100):.1f}%"
                            elif cpu_time_ns:
                                cpu_value = float(cpu_time_ns) / 1e9
                                cpu_usage_percent = f"{min(cpu_value % 100, 100):.1f}%"
                        except (ValueError, TypeError):
                            cpu_usage_percent = "N/A"
                
                # Try to get better CPU usage from get_vm_processes endpoint
                try:
                    processes_info = await node_manager.api_request('GET', f"{endpoint_prefix}/{container_name}/processes", node_url, api_key)
                    if processes_info and isinstance(processes_info, dict):
                        # Check summary for CPU percentage
                        summary = processes_info.get('summary', {})
                        # Try to calculate CPU usage from top processes
                        if 'processes' in processes_info:
                            total_cpu_percent = 0
                            for proc in processes_info.get('processes', []):
                                try:
                                    cpu_pct = float(proc.get('cpu_percent', 0))
                                    total_cpu_percent += cpu_pct
                                except (ValueError, TypeError):
                                    pass
                            if total_cpu_percent > 0:
                                cpu_usage_percent = f"{min(total_cpu_percent, 100):.1f}%"
                except Exception as e:
                    logging.debug(f"Could not get CPU from processes info: {e}")
                
                # --- RAM Usage Parsing ---
                # For KVM, balloon.current is the total allocated RAM (not used)
                # Try to get real usage from get_vm_processes endpoint
                ram_usage = "N/A"
                try:
                    # Call get_vm_processes to get detailed memory info
                    processes_info = await node_manager.api_request('GET', f"{endpoint_prefix}/{container_name}/processes", node_url, api_key)
                    if processes_info and isinstance(processes_info, dict):
                        # Parse memory usage from summary if available
                        summary = processes_info.get('summary', {})
                        # Try to calculate from processes list
                        if 'processes' in processes_info:
                            total_rss_mb = 0
                            for proc in processes_info.get('processes', []):
                                try:
                                    rss_mb = float(proc.get('resident_memory_mb', 0))
                                    total_rss_mb += rss_mb
                                except (ValueError, TypeError):
                                    pass
                            db_ram_gb = vps_db_info.get('ram', 0)
                            if total_rss_mb > 0:
                                ram_usage = f"{total_rss_mb:.2f} MiB / {db_ram_gb * 1024:.2f} MiB"
                except Exception as e:
                    logging.debug(f"Could not get processes info for RAM: {e}")
                
                # Fallback to balloon if processes info failed
                if ram_usage == "N/A":
                    balloon_current_kib = vps_info_raw.get('balloon.current')
                    if balloon_current_kib:
                        try:
                            balloon_kib = float(balloon_current_kib)
                            db_ram_gb = vps_db_info.get('ram', 0)
                            balloon_unused_kib = vps_info_raw.get('balloon.unused')
                            
                            if balloon_unused_kib:
                                try:
                                    unused_kib = float(balloon_unused_kib)
                                    used_kib = balloon_kib - unused_kib
                                    ram_usage = f"{used_kib / 1024:.2f} MiB / {db_ram_gb * 1024:.2f} MiB"
                                except (ValueError, TypeError):
                                    ram_usage = f"{balloon_kib / 1024:.2f} MiB / {db_ram_gb * 1024:.2f} MiB"
                            else:
                                ram_usage = f"{balloon_kib / 1024:.2f} MiB / {db_ram_gb * 1024:.2f} MiB"
                        except (ValueError, TypeError):
                            ram_usage = "N/A"

                # --- Disk Usage Parsing ---
                # Get real disk usage via direct SSH call to the VM
                disk_usage = f"N/A / {vps_db_info.get('disk', 0.0):.2f} GB"
                try:
                    # Get VPS info for SSH connection
                    vps_ssh_info = db.get_vps_by_container_name(container_name)
                    if vps_ssh_info:
                        ssh_port = vps_ssh_info.get('ssh_port')
                        vm_ip = vps_ssh_info.get('ip_address') or (ipv4 if ipv4 != 'N/A' else None)
                        ssh_user = vps_ssh_info.get('surveillance_user') or 'root'
                        ssh_pass = vps_ssh_info.get('surveillance_password') or vps_ssh_info.get('ssh_password')
                        
                        logging.debug(f"SSH Info: port={ssh_port}, ip={vm_ip}, user={ssh_user}, has_pass={bool(ssh_pass)}")
                        
                        if all([ssh_port, vm_ip, ssh_pass]):
                            # Execute df command via SSH to get disk usage
                            import os as os_module
                            process_env = os_module.environ.copy()
                            process_env["SSHPASS"] = ssh_pass
                            
                            # Command to get disk usage in 1K blocks, POSIX format
                            df_cmd = ["sshpass", "-e", "ssh",
                                     "-o", "StrictHostKeyChecking=no",
                                     "-o", "UserKnownHostsFile=/dev/null",
                                     "-o", "ConnectTimeout=5",
                                     "-p", str(ssh_port),
                                     f"{ssh_user}@{vm_ip}",
                                     "df -kP | grep ' /$'"]

                            logging.debug(f"Executing: {' '.join(df_cmd)}")

                            proc = await asyncio.create_subprocess_exec(
                                *df_cmd,
                                stdout=asyncio.subprocess.PIPE,
                                stderr=asyncio.subprocess.PIPE,
                                env=process_env
                            )
                            try:
                                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15.0)
                                if proc.returncode == 0:
                                    df_output = stdout.decode().strip()
                                    logging.debug(f"df output for {container_name}: {df_output}")
                                    if df_output:
                                        parts = df_output.split()
                                        if len(parts) >= 3: # Expecting at least 3 columns: Filesystem, 1024-blocks, Used
                                            used_kb_str = parts[2] # 'Used' column is the 3rd column (index 2)
                                            if used_kb_str.isdigit():
                                                used_kb = int(used_kb_str)
                                                used_gb = used_kb / (1024 * 1024)
                                                disk_usage = f"{used_gb:.2f}GB / {vps_db_info.get('disk', 0.0):.2f} GB"
                                                logging.info(f"Disk usage for {container_name}: {disk_usage}")
                                            else:
                                                logging.warning(f"Could not parse 'used' value from df output for {container_name}: '{used_kb_str}' in '{df_output}'")
                                        else:
                                            logging.warning(f"Unexpected df output format for {container_name}: '{df_output}'")
                                else:
                                    stderr_msg = stderr.decode().strip()
                                    if stderr_msg:
                                        logging.warning(f"df command failed for {container_name}: {stderr_msg}")
                                    else:
                                        logging.warning(f"df command failed for {container_name} with no stderr. stdout: {stdout.decode().strip()}")
                            except asyncio.TimeoutError:
                                logging.warning(f"Timeout getting disk usage for {container_name}")
                        else:
                            logging.warning(f"Missing SSH info for {container_name}: port={ssh_port}, ip={vm_ip}, pass={bool(ssh_pass)}")
                except Exception as e:
                    logging.warning(f"Could not get disk usage via SSH: {e}", exc_info=True)
                    disk_usage = f"N/A / {vps_db_info.get('disk', 0.0):.2f} GB"
                network_rx = "N/A"
                network_tx = "N/A"
            
            elif vps_info_raw:
                status = vps_info_raw.get('State', 'unknown')
                ipv4 = vps_info_raw.get('ipv4', 'N/A')
            else:
                status = 'unknown'
                ipv4 = 'N/A'

        cpu_display = f"{vps_db_info.get('cpu', 'N/A')} cores"
        db_ram_value = vps_db_info.get('ram', 'N/A')
        if isinstance(db_ram_value, (int, float)) and db_ram_value >= 1:
            ram_display = f"{int(db_ram_value)}GB"
        else:
            ram_display = f"{db_ram_value}MB"
        disk_display = f"{vps_db_info.get('disk', 'N/A')}GB"

        status_display = status.capitalize() if status != "N/A" else "Unknown"
        node_name = vps_db_info.get('node', 'Unknown')
        
        description = f"**Node:** `{node_name}`\n"

        # Add partner info if available in environment variables
        partner_env_var = f"{node_name.upper()}_PARTNER"
        partner_info = os.getenv(partner_env_var)
        if partner_info:
            description += f"**Partner:** {partner_info}\n"

        description += f"**Status:** {status_display}\n" + \
                      f"**IPv4 Public:** `{node_ip}`\n" + \
                      f"**IPv4 Private:** ||`{ipv4}`||\n" + \
                      f"**Uptime:** {uptime}\n"

        embed = _create_embed(f"VPS Management: {container_name}", description)
        embed.add_field(name="Resources", value=f"**CPU:** {cpu_display}\n**RAM:** {ram_display}\n**Disk:** {disk_display}", inline=False)

        if is_running:
            usage_value = f"**CPU:** {cpu_usage_percent}\n**RAM:** {ram_usage}\n**Disk:** {disk_usage}"
            if network_rx != "N/A" and network_tx != "N/A":
                usage_value += f"\n**Network RX:** {network_rx}\n**Network TX:** {network_tx}"
            embed.add_field(name="Usage", value=usage_value, inline=False)
        else:
            embed.add_field(name="Usage", value="*VPS must be running to display usage*", inline=False)

        if vps_db_info:
            try:
                due_date_raw = vps_db_info.get('due_date')
                cost = vps_db_info.get('cost_credits')
                
                if due_date_raw:
                    try:
                        if isinstance(due_date_raw, str):
                            due_date_obj = datetime.fromisoformat(due_date_raw)
                            # Ensure the object is timezone-aware before formatting
                            if due_date_obj.tzinfo is None:
                                due_date_obj = pytz.utc.localize(due_date_obj)
                            due_date_formatted = due_date_obj.strftime("%Y-%m-%d %H:%M %Z")
                        else:
                            due_date_formatted = str(due_date_raw)
                        embed.add_field(name="Expiry Date", value=f"{due_date_formatted}", inline=True)
                    except Exception as e:
                        logging.warning(f"Could not parse due_date '{due_date_raw}': {e}")
                        embed.add_field(name="Expiry Date", value=f"{due_date_raw}", inline=True)
                
                plan_tier = vps_db_info.get('plan_tier')
                invite_plan_tier = vps_db_info.get('invite_plan_tier')

                # For ad-tier VPS, show VPS points needed per renewal
                if plan_tier and plan_tier in LXC_AD_TIERS:
                    tier_info = LXC_AD_TIERS[plan_tier]
                    user_points = db.get_vps_points(user.id)
                    embed.add_field(name="Renewal Cost", value=f"{tier_info['ads_required']} VPS Points / day", inline=True)
                    embed.add_field(name="Your Points", value=f"{user_points}", inline=True)
                
                # For invite-tier VPS, renewal is automatic, so no cost is displayed
                elif invite_plan_tier:
                    pass

                # For credit-based plans
                elif cost and cost > 0:
                    embed.add_field(name="Renewal Cost", value=f"{cost} credits / 30 days", inline=True)
            except (KeyError, TypeError):
                pass

        user_id = ctx.author.id if isinstance(ctx, commands.Context) else ctx.user.id
        if db.is_vps_suspended(container_name):
            embed.description += "\n\n**This VPS is suspended.**"
            view = None
        else:
            view = VPSActionView(user_id, container_name, self)

        if isinstance(ctx, discord.Interaction):
            if view:
                await ctx.followup.send(embed=embed, view=view, ephemeral=True)
            else:
                await ctx.followup.send(embed=embed, ephemeral=True)
        elif isinstance(ctx, commands.Context):
            if view:
                await ctx.send(embed=embed, view=view, ephemeral=True)
            else:
                await ctx.send(embed=embed, ephemeral=True)
    # ----------------------------------------------------------------------------------------------------------------
    # 5. ACTION CALLBACKS
    # ----------------------------------------------------------------------------------------------------------------

    async def _transfer_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        await interaction.edit_original_response(
            embed=_create_embed("Loading available nodes...", "Please wait while we fetch node information."),
            view=None
        )

        vps_db_info = db.get_vps_by_container_name(container_name)
        if not vps_db_info:
            await interaction.edit_original_response(embed=_create_embed("Error", f"Could not find VPS {container_name} in the database."))
            return

        current_node = vps_db_info.get('node', 'Unknown')

        embed = _create_embed(
            "Transfer VPS",
            f"Your VPS `{container_name}` is currently on node `{current_node}`.\n\nPlease select a new node to transfer it to:",
            0xE5E6EB
        )
        view = await TransferNodeSelectionView.create(interaction.user.id, container_name, self, interaction)
        await interaction.edit_original_response(embed=embed, view=view)

    async def _execute_vps_transfer(self, original_interaction: discord.Interaction, container_name: str, new_node_name: str, new_node_info: dict):
        max_retries = 3
        await original_interaction.edit_original_response(
            embed=_create_embed("Transferring VPS [0%]", f"Initializing transfer of {container_name} to {new_node_name}...", 0xE5E6EB),
            view=None
        )

        vps_db_info = db.get_vps_by_container_name(container_name)
        if not vps_db_info:
            await original_interaction.followup.send(embed=_create_embed("Error", f"Could not find VPS {container_name} in the database during transfer."), ephemeral=True)
            return

        old_node_info = node_manager.get_node_for_vps(container_name)
        if not old_node_info:
            await original_interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the original node for this VPS. Cannot transfer."), ephemeral=True)
            return

        old_node_url, old_api_key = old_node_info['url'], old_node_info['api_key']
        old_node_name = vps_db_info.get('node', 'Unknown')
        vps_type = vps_db_info.get('vps_type', 'lxc')
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        # 1. Delete VPS from old node with retries
        delete_result = None
        for attempt in range(max_retries):
            await original_interaction.edit_original_response(
                embed=_create_embed(f"Transferring VPS [25%] (Attempt {attempt + 1}/{max_retries})", f"Deleting VPS from original node `{old_node_name}`...", 0xE5E6EB),
                view=None
            )
            delete_result = await node_manager.api_request('DELETE', f"{endpoint_prefix}/{container_name}", old_node_url, old_api_key)
            if delete_result and (delete_result.get("deleted") or (vps_type == 'kvm' and delete_result.get("status") == "success")):
                break
            await asyncio.sleep(5)
        
        if not delete_result or (not delete_result.get("deleted") and not (vps_type == 'kvm' and delete_result.get("status") == "success")):
            await original_interaction.followup.send(embed=_create_embed("Transfer Failed", f"Failed to delete {container_name} from its original node after {max_retries} attempts. Transfer aborted.", 0x992D22), ephemeral=True)
            return

        # 2. Create VPS on new node with retries
        payload = {
            "user_id": vps_db_info['user_id'],
            "username": vps_db_info['username'],
            "cpu": vps_db_info['cpu'],
            "ram": vps_db_info['ram'],
            "disk": vps_db_info['disk']
        }
        create_result = None
        for attempt in range(max_retries):
            await original_interaction.edit_original_response(
                embed=_create_embed(f"Transferring VPS [50%] (Attempt {attempt + 1}/{max_retries})", f"Creating VPS on new node `{new_node_name}`...", 0xE5E6EB),
                view=None
            )
            create_result = await node_manager.api_request('POST', endpoint_prefix, new_node_info['url'], new_node_info['api_key'], data=payload)
            if create_result and (create_result.get("status") == "success" or create_result.get("container_name") or create_result.get("vm_name")):
                break
            await asyncio.sleep(5)

        if create_result and (create_result.get("status") == "success" or create_result.get("container_name") or create_result.get("vm_name")):
            new_container_name = create_result.get("container_name") or create_result.get("vm_name")
            new_ssh_link = create_result.get("ssh_link") or create_result.get("ssh_connection")
            new_ssh_port = create_result.get("ssh_port")
            new_ssh_password = create_result.get("ssh_password")
            new_ip_address = create_result.get("vm_ip")

            if new_node_info.get("domain") and new_ssh_link:
                new_ssh_link = re.sub(r'@([\w.-]+)', f'@{new_node_info["domain"]}', new_ssh_link)

            if new_container_name:
                # 3. Update DB entry
                await original_interaction.edit_original_response(
                    embed=_create_embed("Transferring VPS [90%]", "Finalizing transfer and updating database...", 0xE5E6EB),
                    view=None
                )
                db.delete_vps_by_container_name(container_name)
                db.add_vps(
                    user_id=vps_db_info['user_id'],
                    username=vps_db_info['username'],
                    container_name=new_container_name,
                    cpu=vps_db_info['cpu'],
                    ram=vps_db_info['ram'],
                    disk=vps_db_info['disk'],
                    cost_credits=vps_db_info['cost_credits'],
                    ssh_link=new_ssh_link,
                    ssh_port=new_ssh_port,
                    ssh_password=new_ssh_password,
                    vps_type=vps_type,
                    ip_address=new_ip_address,
                    node=new_node_name,
                    due_date=vps_db_info.get('due_date')
                )

                success_embed = _create_embed("Transfer Success [100%]", f"Your VPS `{container_name}` has been successfully transferred to `{new_node_name}` and is now `{new_container_name}`.", 0xE5E6EB)
                await original_interaction.edit_original_response(embed=success_embed, view=None)

                creds_embed = _create_embed("New VPS Credentials", f"Here are the new credentials for `{new_container_name}`.")
                creds_embed.add_field(name="New SSH Connection", value=f"```\n{new_ssh_link}\n```", inline=False)
                creds_embed.add_field(name="New Password", value=f"```\n{new_ssh_password}\n```", inline=False)
                await original_interaction.followup.send(embed=creds_embed, ephemeral=True)
            else:
                await original_interaction.followup.send(embed=_create_embed("Transfer Failed", "VPS created on new node, but no container name returned. Please contact support.", 0x992D22), ephemeral=True)
        else:
            conn = None
            cursor = None
            try:
                conn, cursor = db.start_transaction()
                db.add_credits(vps_db_info['user_id'], vps_db_info['cost_credits'], cursor=cursor, conn=conn)
                db.commit_transaction(conn, cursor)
                await original_interaction.followup.send(embed=_create_embed("Transfer Failed", f"Failed to create VPS on {new_node_name} after {max_retries} attempts. Transfer aborted. Your old VPS has been deleted. The credits for this VPS have been refunded.", 0x992D22), ephemeral=True)
            except Exception as e:
                if conn and cursor:
                    db.rollback_transaction(conn, cursor)
                logging.error(f"Transfer: Failed to refund user {vps_db_info['user_id']} credits: {e}")
                await original_interaction.followup.send(embed=_create_embed("Transfer Failed (Refund Error)", f"Failed to create VPS on {new_node_name} AND failed to refund credits. Please contact support.", 0x992D22), ephemeral=True)

    async def _restart_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=_create_embed("Action Failed", "This VPS is suspended and cannot be restarted.", 0x992D22), ephemeral=True)
            return

        await interaction.response.defer(ephemeral=False)
        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS.", 0x992D22), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(container_name)
        vps_type = vps_db_info.get('vps_type', 'lxc') if vps_db_info else 'lxc'
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        result = await node_manager.api_request('POST', f"{endpoint_prefix}/{container_name}/restart", node_url, api_key)

        if result and (result.get("status") == "success" or result.get("result") is True):
            await asyncio.sleep(5) # Give time for the container to boot
            ssh_result = await node_manager.api_request('POST', f"{endpoint_prefix}/{container_name}/regenerate-ssh", node_url, api_key)
            if ssh_result and (ssh_result.get("status") == "success" or ssh_result.get("ssh_link") or ssh_result.get("ssh_connection")):
                new_ssh = ssh_result.get("ssh_link") or ssh_result.get("ssh_connection")
                db.update_vps_ssh_link(container_name, new_ssh)
            
            await self.display_vps_info(interaction, container_name)
            await interaction.followup.send(embed=_create_embed("Success", f"{container_name} restarted successfully.", 0xE5E6EB), ephemeral=True)
        else:
            await interaction.followup.send(embed=_create_embed("Restart Failed", f"An error occurred while restarting {container_name}.", 0x992D22), ephemeral=True)

    async def _stop_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS.", 0x992D22), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(container_name)
        vps_type = vps_db_info.get('vps_type', 'lxc') if vps_db_info else 'lxc'
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        result = await node_manager.api_request('POST', f"{endpoint_prefix}/{container_name}/stop", node_url, api_key)

        if result and (result.get("status") == "success" or result.get("result") is True or result.get("result") is None):
            api_result = result.get("result")
            if api_result is True:
                db.update_vps_ssh_link(container_name, None)
                embed = _create_embed("Success", f"{container_name} stopped successfully.", 0xE5E6EB)
            elif api_result is None:
                db.update_vps_ssh_link(container_name, None)
                embed = _create_embed("Info", f"{container_name} is already stopped.", 0xE5E6EB)
            else:
                embed = _create_embed("Error", f"Failed to stop {container_name}.", 0x992D22)
        else:
            embed = _create_embed("Error", f"API Error: Failed to stop {container_name}.", 0x992D22)
        
        await interaction.edit_original_response(content=None, embed=embed, view=None)

    async def _start_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=_create_embed("Action Failed", "This VPS is suspended.", 0x992D22), ephemeral=True)
            return

        await interaction.response.defer()
        await interaction.followup.send(embed=_create_embed("Processing", f"Starting {container_name}...", 0xE5E6EB), ephemeral=True)

        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS.", 0x992D22), ephemeral=True)
            return
        node_url, api_key = node_info['url'], node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(container_name)
        vps_type = vps_db_info.get('vps_type', 'lxc') if vps_db_info else 'lxc'
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        result = await node_manager.api_request('POST', f"{endpoint_prefix}/{container_name}/start", node_url, api_key)

        if result and (result.get("status") == "success" or result.get("result") is True or result.get("result") is None):
            api_result = result.get("result")
            if api_result is True:
                await asyncio.sleep(5)
                ssh_result = await node_manager.api_request('POST', f"{endpoint_prefix}/{container_name}/regenerate-ssh", node_url, api_key)
                if ssh_result and (ssh_result.get("status") == "success" or ssh_result.get("ssh_link") or ssh_result.get("ssh_connection")):
                    new_ssh = ssh_result.get("ssh_link") or ssh_result.get("ssh_connection")
                    db.update_vps_ssh_link(container_name, new_ssh)
                await self.display_vps_info(interaction, container_name)
            elif api_result is None:
                await interaction.followup.send(embed=_create_embed("Info", f"{container_name} is already running.", 0xE5E6EB), ephemeral=True)
            else:
                await interaction.followup.send(embed=_create_embed("Error", f"Failed to start {container_name}.", 0x992D22), ephemeral=True)
        else:
            await interaction.followup.send(embed=_create_embed("Error", f"API Error: Failed to start {container_name}.", 0x992D22), ephemeral=True)

    async def _reinstall_callback(self, interaction: discord.Interaction, container_name: str):
        if db.is_vps_suspended(container_name):
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=_create_embed("Action Failed", "This VPS is suspended.", 0x992D22), ephemeral=True)
            return

        view = ConfirmReinstallView(interaction.user.id, container_name, self, None)
        embed = _create_embed("Confirmation Required", f"This will delete and recreate **{container_name}**. Are you sure?", 0x992D22)
        await interaction.response.send_message(embed=embed, ephemeral=True, view=view)

    async def _view_ssh_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        vps_db_info = db.get_vps_by_container_name(container_name)
        
        if vps_db_info:
            ssh_link = vps_db_info.get('ssh_link') or "N/A"
            ssh_password = vps_db_info.get('ssh_password') or "N/A"
        else:
            ssh_link = "N/A"
            ssh_password = "N/A"
        
        port = "N/A"
        if ssh_link != "N/A":
            port_match = re.search(r"-p (\d+)", ssh_link)
            if port_match:
                port = port_match.group(1)

        desc = f"**SSH Link:**\n```\n{ssh_link}\n```\n**Password:**\n```\n{ssh_password}\n```\n**Port:** {port}"
        embed = _create_embed(f"SSH Details for {container_name}", desc)
        
        await interaction.followup.send(embed=embed, ephemeral=True)

    async def _delete_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        view = ConfirmDeleteView(interaction.user.id, container_name, self)
        embed = _create_embed("Confirmation Required", f"Are you sure you want to delete **{container_name}**? This action cannot be undone.", 0x992D22)
        await interaction.followup.send(embed=embed, ephemeral=True, view=view)

    async def _port_forward_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)
        
        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return

        node_url = node_info['url']
        api_key = node_info['api_key']

        vps_db_info = db.get_vps_by_container_name(container_name)
        vps_type = vps_db_info.get('vps_type', 'lxc') if vps_db_info else 'lxc'
        endpoint_prefix = f"/{vps_type}/{'vm' if vps_type == 'kvm' else 'container'}"

        result = await node_manager.api_request('GET', f"{endpoint_prefix}/{container_name}/ports", node_url, api_key)
        existing_forwards = result.get("ports", []) if result else []

        if existing_forwards:
            if vps_type == 'lxc':
                domain = node_info.get('domain', 'jupyterhive.duckdns.org')
                forward_list = [f"- {f} ({domain}:{f.split('/')[0]})" for f in existing_forwards]
            else: # kvm
                forward_list = [f"- {f}" for f in existing_forwards]
            description = "```\n" + "\n".join(forward_list) + "\n```"
            embed = _create_embed(f"Forwarded Ports for {container_name}", description)
        else:
            embed = _create_embed(f"Forwarded Ports for {container_name}", "No ports are currently forwarded.")
        
        if vps_type == 'lxc':
            view = PortForwardView(interaction.user.id, container_name, self.bot, existing_forwards, self, node_info)
        else: # kvm
            view = KVM_PortForwardView(interaction.user.id, container_name, self.bot, existing_forwards, self, node_info)

        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    async def _other_callback(self, interaction: discord.Interaction, container_name: str):
        view = OtherActionsView(interaction.user.id, container_name, self, self.bot)
        await interaction.response.edit_message(view=view)

    async def _fix_ssh_callback(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer(ephemeral=True)

        vps_db_info = db.get_vps_by_container_name(container_name)
        if not vps_db_info:
            await interaction.followup.send(embed=_create_embed("Error", f"Could not find VPS {container_name} in the database."), ephemeral=True)
            return

        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            await interaction.followup.send(embed=_create_embed("Node Error", "Could not determine the node for this VPS."), ephemeral=True)
            return

        vps_type = vps_db_info.get('vps_type', 'lxc')
        endpoint = f"/{vps_type}/{ 'vm' if vps_type == 'kvm' else 'container'}/{container_name}/fix-ssh"

        await interaction.followup.send(embed=_create_embed("Processing", f"Attempting to fix SSH for {container_name}... This may take a moment.", 0xE5E6EB), ephemeral=True)

        result = await node_manager.api_request('POST', endpoint, node_info['url'], node_info['api_key'])

        if result and result.get("status") == "success":
            embed = _create_embed("Success", f"SSH password authentication has been re-enabled and port forwarding rules have been refreshed for {container_name}.", 0xE5E6EB)
        else:
            if result:
                error_message = result.get("message", "An unknown error occurred.")
            else:
                error_message = "API request failed or returned no response."
            embed = _create_embed("Failed", f"Could not fix SSH for {container_name}. Reason: {error_message}", 0x992D22)
        
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Manage(bot))