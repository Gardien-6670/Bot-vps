import discord
from discord import app_commands
from discord.ext import commands
from utils.database import db
from datetime import datetime, timedelta
import logging
import io

try:
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    logging.warning("matplotlib not available, graph features will be disabled")

class TransactionGraphs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="transaction_graph", description="View graphical statistics of transactions")
    @app_commands.describe(
        user="User to view stats for (optional)",
        days_back="Number of days to analyze (default: 30)",
        graph_type="Type of graph to generate"
    )
    @app_commands.choices(graph_type=[
        app_commands.Choice(name="Daily Activity", value="daily"),
        app_commands.Choice(name="By Type", value="by_type"),
        app_commands.Choice(name="Balance Over Time", value="balance"),
    ])
    async def transaction_graph(
        self,
        interaction: discord.Interaction,
        user: discord.User = None,
        days_back: int = 30,
        graph_type: str = "daily"
    ):
        """Generate graphical statistics of transactions."""
        await interaction.response.defer(ephemeral=True)
        
        if not MATPLOTLIB_AVAILABLE:
            await interaction.followup.send(
                "Graph feature is not available. Please install matplotlib: `pip install matplotlib`",
                ephemeral=True
            )
            return
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Get logs
        user_id = user.id if user else None
        logs = db.get_transaction_logs(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date,
            limit=10000,
            offset=0
        )
        
        if not logs:
            await interaction.followup.send("No transaction data available for the selected period.", ephemeral=True)
            return
        
        try:
            # Create figure
            fig, ax = plt.subplots(figsize=(12, 6))
            
            if graph_type == "daily":
                # Daily transaction count
                daily_counts = {}
                for log in logs:
                    created_at = log['created_at']
                    if isinstance(created_at, str):
                        created_at = datetime.fromisoformat(created_at)
                    date_key = created_at.date()
                    daily_counts[date_key] = daily_counts.get(date_key, 0) + 1
                
                dates = sorted(daily_counts.keys())
                counts = [daily_counts[d] for d in dates]
                
                ax.bar(dates, counts, color='#3498DB', alpha=0.7)
                ax.set_xlabel('Date')
                ax.set_ylabel('Number of Transactions')
                ax.set_title(f'Daily Transaction Activity - Last {days_back} Days')
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                
            elif graph_type == "by_type":
                # Transactions by type
                type_counts = {}
                type_amounts = {}
                
                for log in logs:
                    trans_type = log['transaction_type']
                    type_counts[trans_type] = type_counts.get(trans_type, 0) + 1
                    type_amounts[trans_type] = type_amounts.get(trans_type, 0) + log['amount']
                
                types = list(type_counts.keys())
                counts = [type_counts[t] for t in types]
                
                # Create bar chart
                colors = {
                    'credit_add': '#2ECC71',
                    'credit_remove': '#E74C3C',
                    'point_add': '#F39C12',
                    'point_remove': '#E67E22'
                }
                bar_colors = [colors.get(t, '#95A5A6') for t in types]
                
                bars = ax.bar(types, counts, color=bar_colors, alpha=0.7)
                
                # Add amount labels on bars
                for i, (bar, trans_type) in enumerate(zip(bars, types)):
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{type_amounts[trans_type]} total',
                           ha='center', va='bottom', fontsize=9)
                
                ax.set_xlabel('Transaction Type')
                ax.set_ylabel('Number of Transactions')
                ax.set_title(f'Transactions by Type - Last {days_back} Days')
                ax.grid(True, alpha=0.3, axis='y')
                plt.xticks(rotation=45)
                
            elif graph_type == "balance":
                # Balance over time
                if not user:
                    await interaction.followup.send(
                        "Balance over time graph requires a specific user. Please specify a user.",
                        ephemeral=True
                    )
                    plt.close(fig)
                    return
                
                # Sort logs by date
                sorted_logs = sorted(logs, key=lambda x: x['created_at'])
                
                dates = []
                balances = []
                
                for log in sorted_logs:
                    created_at = log['created_at']
                    if isinstance(created_at, str):
                        created_at = datetime.fromisoformat(created_at)
                    dates.append(created_at)
                    balances.append(log['balance_after'])
                
                ax.plot(dates, balances, marker='o', linestyle='-', linewidth=2, markersize=4, color='#3498DB')
                ax.fill_between(dates, balances, alpha=0.3, color='#3498DB')
                ax.set_xlabel('Date')
                ax.set_ylabel('Balance')
                ax.set_title(f'Balance Over Time - {user.display_name}')
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                
                # Format y-axis
                ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{int(x):,}'))
            
            plt.tight_layout()
            
            # Save to buffer
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            plt.close(fig)
            
            # Send graph
            file = discord.File(buffer, filename=f'transaction_graph_{graph_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png')
            
            embed = discord.Embed(
                title=f"📊 Transaction Graph - {graph_type.replace('_', ' ').title()}",
                description=f"Analysis of last {days_back} days",
                color=0x3498DB
            )
            if user:
                embed.set_footer(text=f"User: {user.display_name}")
            
            embed.set_image(url=f"attachment://{file.filename}")
            
            await interaction.followup.send(embed=embed, file=file, ephemeral=True)
            
        except Exception as e:
            logging.error(f"Error generating graph: {e}", exc_info=True)
            await interaction.followup.send(f"Error generating graph: {e}", ephemeral=True)
            if 'fig' in locals():
                plt.close(fig)

async def setup(bot):
    await bot.add_cog(TransactionGraphs(bot))
