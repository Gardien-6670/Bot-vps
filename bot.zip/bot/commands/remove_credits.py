import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db
from utils.transaction_notifications import notify_important_transaction
import logging

class RemoveCredits(commands.Cog):
 def __init__(self, bot: commands.Bot):
 self.bot = bot

 @commands.hybrid_command(name="remove_credits", description="Remove credits from a user")
 @app_commands.guild_only()
 @app_commands.describe(
 user="The user to remove credits from",
 amount="The amount of credits to remove",
 reason="Reason for removing credits (required)"
 )
 async def remove_credits(self, ctx: commands.Context, user: discord.User, amount: int, *, reason: str):
 AUTHORIZED_USER_ID = 1047760053509312642 # REPLACE THIS WITH THE AUTHORIZED USER ID

 if ctx.author.id not in [AUTHORIZED_USER_ID, 1286418351035388006]:
 await ctx.send("You do not have permission to use this command.", ephemeral=True)
 return

 if amount <= 0:
 await ctx.send("The amount must be positive.", ephemeral=True)
 return
 
 if not reason or len(reason.strip()) < 3:
 await ctx.send("Please provide a valid reason (at least 3 characters).", ephemeral=True)
 return

 try:
 # Get balance before
 balance_before = db.get_balance(user.id)
 
 if balance_before < amount:
 await ctx.send(
 f"User {user.mention} only has {balance_before} credits. Cannot remove {amount} credits.",
 ephemeral=True
 )
 return
 
 # Remove credits with reason
 db.remove_credits(user.id, amount, reason=f"Admin {ctx.author.name}: {reason}")
 
 # Get balance after
 new_balance = db.get_balance(user.id)
 
 # Send notification for important transactions
 await notify_important_transaction(
 self.bot,
 user.id,
 'credit_remove',
 amount,
 new_balance,
 f"Admin {ctx.author.name}: {reason}"
 )

 embed = discord.Embed(title="[OK] Credits Removed", color=0xE74C3C)
 embed.add_field(name="User", value=user.mention, inline=True)
 embed.add_field(name="Amount", value=f"-{amount}", inline=True)
 embed.add_field(name="Balance", value=f"{balance_before} → {new_balance}", inline=False)
 embed.add_field(name="Reason", value=reason, inline=False)
 embed.set_footer(text=f"Transaction logged • Admin: {ctx.author.name}")

 await ctx.send(embed=embed)
 
 # Notify user
 try:
 user_embed = discord.Embed(
 title=" Credits Removed from Your Account",
 description=f"An administrator has removed **{amount} credits** from your account.",
 color=0xE74C3C
 )
 user_embed.add_field(name="New Balance", value=f"{new_balance} credits", inline=True)
 user_embed.add_field(name="Reason", value=reason, inline=False)
 await user.send(embed=user_embed)
 except discord.Forbidden:
 logging.warning(f"Could not send credit notification to user {user.id} (DMs disabled)")
 
 except Exception as e:
 logging.error(f"Error removing credits: {e}", exc_info=True)
 await ctx.send(f"Error removing credits: {e}", ephemeral=True)

async def setup(bot: commands.Bot):
 await bot.add_cog(RemoveCredits(bot))
