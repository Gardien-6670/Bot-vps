"""
Configuration du Bot API Server
===============================

Configuration pour supporter plusieurs API nodes en parallèle.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# Configuration du serveur
SERVER_HOST = os.getenv('BOT_API_HOST', '0.0.0.0')
SERVER_PORT = int(os.getenv('BOT_API_PORT', '5001'))
DEBUG_MODE = os.getenv('BOT_API_DEBUG', 'False').lower() == 'true'

# Sécurité
API_SECRET_TOKEN = os.getenv('BOT_API_SECRET_TOKEN', 'change-me-in-production')

# Performance
WORKERS = int(os.getenv('BOT_API_WORKERS', '4'))  # Nombre de workers
THREADS_PER_WORKER = int(os.getenv('BOT_API_THREADS', '10'))  # Threads par worker
MAX_REQUESTS = int(os.getenv('BOT_API_MAX_REQUESTS', '1000'))  # Max requêtes par worker
TIMEOUT = int(os.getenv('BOT_API_TIMEOUT', '30'))  # Timeout en secondes

# Connection pooling MySQL
DB_POOL_SIZE = int(os.getenv('DB_POOL_SIZE', '20'))  # Taille du pool
DB_POOL_MAX_OVERFLOW = int(os.getenv('DB_POOL_MAX_OVERFLOW', '10'))  # Overflow max
DB_POOL_TIMEOUT = int(os.getenv('DB_POOL_TIMEOUT', '30'))  # Timeout pool
DB_POOL_RECYCLE = int(os.getenv('DB_POOL_RECYCLE', '3600'))  # Recycle connexions

# Rate limiting
RATE_LIMIT_ENABLED = os.getenv('RATE_LIMIT_ENABLED', 'True').lower() == 'true'
RATE_LIMIT_PER_MINUTE = int(os.getenv('RATE_LIMIT_PER_MINUTE', '100'))  # Par API node
RATE_LIMIT_BURST = int(os.getenv('RATE_LIMIT_BURST', '20'))  # Burst autorisé

# Cache Redis (optionnel)
REDIS_ENABLED = os.getenv('REDIS_ENABLED', 'False').lower() == 'true'
REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.getenv('REDIS_PORT', '6379'))
REDIS_DB = int(os.getenv('REDIS_DB', '0'))
REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', None)
CACHE_TTL = int(os.getenv('CACHE_TTL', '60'))  # TTL cache en secondes

# Queue système (optionnel)
QUEUE_ENABLED = os.getenv('QUEUE_ENABLED', 'False').lower() == 'true'
QUEUE_TYPE = os.getenv('QUEUE_TYPE', 'redis')  # redis ou rabbitmq
QUEUE_HOST = os.getenv('QUEUE_HOST', 'localhost')
QUEUE_PORT = int(os.getenv('QUEUE_PORT', '6379'))

# Monitoring
METRICS_ENABLED = os.getenv('METRICS_ENABLED', 'True').lower() == 'true'
METRICS_PORT = int(os.getenv('METRICS_PORT', '9090'))

# Logging
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = os.getenv('LOG_FILE', 'logs/bot_api_server.log')

# Health check
HEALTH_CHECK_INTERVAL = int(os.getenv('HEALTH_CHECK_INTERVAL', '30'))  # secondes

# API Nodes tracking
API_NODES_TRACKING = os.getenv('API_NODES_TRACKING', 'True').lower() == 'true'
API_NODE_TIMEOUT = int(os.getenv('API_NODE_TIMEOUT', '300'))  # Timeout inactivité
