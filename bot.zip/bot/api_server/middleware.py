"""
Middleware pour le Bot API Server
=================================

Middleware pour gérer la concurrence, le rate limiting, etc.
"""

from flask import request, jsonify, g
from functools import wraps
import time
import logging
from collections import defaultdict
from threading import Lock
import hashlib

logger = logging.getLogger(__name__)

# Rate limiting storage
rate_limit_storage = defaultdict(list)
rate_limit_lock = Lock()

# API nodes tracking
api_nodes = {}
api_nodes_lock = Lock()


def track_api_node():
    """Track les API nodes actifs"""
    try:
        # Identifier l'API node par son IP ou un header custom
        node_id = request.headers.get('X-API-Node-ID')
        if not node_id:
            # Fallback sur l'IP
            node_id = request.remote_addr
            
        with api_nodes_lock:
            if node_id not in api_nodes:
                api_nodes[node_id] = {
                    'first_seen': time.time(),
                    'last_seen': time.time(),
                    'request_count': 0,
                    'error_count': 0
                }
                logger.info(f"New API node registered: {node_id}")
            
            api_nodes[node_id]['last_seen'] = time.time()
            api_nodes[node_id]['request_count'] += 1
            
        g.api_node_id = node_id
        
    except Exception as e:
        logger.error(f"Error tracking API node: {e}")


def check_rate_limit(node_id: str, limit_per_minute: int, burst: int) -> bool:
    """
    Vérifie le rate limit pour un API node
    
    Args:
        node_id: ID du node
        limit_per_minute: Limite par minute
        burst: Burst autorisé
        
    Returns:
        True si autorisé
    """
    current_time = time.time()
    
    with rate_limit_lock:
        # Nettoyer les anciennes entrées (> 1 minute)
        rate_limit_storage[node_id] = [
            t for t in rate_limit_storage[node_id]
            if current_time - t < 60
        ]
        
        # Vérifier le nombre de requêtes
        request_count = len(rate_limit_storage[node_id])
        
        # Autoriser le burst
        if request_count < burst:
            rate_limit_storage[node_id].append(current_time)
            return True
            
        # Vérifier la limite par minute
        if request_count < limit_per_minute:
            rate_limit_storage[node_id].append(current_time)
            return True
            
        return False


def rate_limiter(limit_per_minute: int = 100, burst: int = 20):
    """
    Décorateur pour rate limiting
    
    Args:
        limit_per_minute: Limite par minute
        burst: Burst autorisé
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            node_id = getattr(g, 'api_node_id', request.remote_addr)
            
            if not check_rate_limit(node_id, limit_per_minute, burst):
                logger.warning(f"Rate limit exceeded for node {node_id}")
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'retry_after': 60
                }), 429
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def log_request():
    """Log les requêtes"""
    try:
        node_id = getattr(g, 'api_node_id', 'unknown')
        logger.info(f"Request from {node_id}: {request.method} {request.path}")
    except Exception as e:
        logger.error(f"Error logging request: {e}")


def log_response(response):
    """Log les réponses"""
    try:
        node_id = getattr(g, 'api_node_id', 'unknown')
        duration = time.time() - g.start_time if hasattr(g, 'start_time') else 0
        
        logger.info(
            f"Response to {node_id}: {response.status_code} "
            f"({duration:.3f}s)"
        )
        
        # Tracker les erreurs
        if response.status_code >= 400:
            with api_nodes_lock:
                if node_id in api_nodes:
                    api_nodes[node_id]['error_count'] += 1
                    
    except Exception as e:
        logger.error(f"Error logging response: {e}")
        
    return response


def before_request():
    """Hook avant chaque requête"""
    g.start_time = time.time()
    track_api_node()
    log_request()


def after_request(response):
    """Hook après chaque requête"""
    log_response(response)
    
    # Ajouter des headers CORS si nécessaire
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, X-API-Token, X-API-Node-ID'
    
    return response


def get_api_nodes_stats():
    """
    Récupère les statistiques des API nodes
    
    Returns:
        Dict avec les stats
    """
    current_time = time.time()
    
    with api_nodes_lock:
        stats = {
            'total_nodes': len(api_nodes),
            'active_nodes': 0,
            'nodes': []
        }
        
        for node_id, data in api_nodes.items():
            # Node actif si vu dans les 5 dernières minutes
            is_active = (current_time - data['last_seen']) < 300
            
            if is_active:
                stats['active_nodes'] += 1
                
            stats['nodes'].append({
                'node_id': node_id,
                'is_active': is_active,
                'first_seen': data['first_seen'],
                'last_seen': data['last_seen'],
                'request_count': data['request_count'],
                'error_count': data['error_count'],
                'error_rate': (
                    data['error_count'] / data['request_count'] * 100
                    if data['request_count'] > 0 else 0
                )
            })
            
        return stats


def cleanup_inactive_nodes(timeout: int = 300):
    """
    Nettoie les nodes inactifs
    
    Args:
        timeout: Timeout en secondes
    """
    current_time = time.time()
    
    with api_nodes_lock:
        inactive_nodes = [
            node_id for node_id, data in api_nodes.items()
            if (current_time - data['last_seen']) > timeout
        ]
        
        for node_id in inactive_nodes:
            logger.info(f"Removing inactive node: {node_id}")
            del api_nodes[node_id]
            
            # Nettoyer aussi le rate limiting
            with rate_limit_lock:
                if node_id in rate_limit_storage:
                    del rate_limit_storage[node_id]
