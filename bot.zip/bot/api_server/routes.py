"""
Routes complètes pour le Bot API Server
=======================================

Ce module contient toutes les routes API pour la communication Bot/API.
"""

from flask import Blueprint, request, jsonify
import logging

logger = logging.getLogger(__name__)

# Blueprint pour les routes
api_bp = Blueprint('api', __name__, url_prefix='/api/v1')

# Importer le décorateur d'authentification
from functools import wraps

def require_auth(f):
    """Décorateur pour vérifier l'authentification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from bot.api_server.server import verify_token
        token = request.headers.get('X-API-Token')
        
        if not token:
            return jsonify({'error': 'Missing authentication token'}), 401
            
        if not verify_token(token):
            return jsonify({'error': 'Invalid authentication token'}), 403
            
        return f(*args, **kwargs)
    return decorated_function


def get_db():
    """Récupère l'instance de la base de données"""
    from shared.database_wrapper import db
    return db


# ==========================================
# VPS Operations
# ==========================================

@api_bp.route('/vps/all', methods=['GET'])
@require_auth
def get_all_vps():
    """Récupère tous les VPS"""
    try:
        db = get_db()
        vps_list = db.get_all_vps()
        
        return jsonify({
            'success': True,
            'vps_list': vps_list,
            'count': len(vps_list)
        })
        
    except Exception as e:
        logger.error(f"Error getting all VPS: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/vps/<int:vps_id>/due-date', methods=['PUT'])
@require_auth
def set_vps_due_date(vps_id):
    """
    Définit la date d'échéance d'un VPS
    
    Body:
        due_date: Date d'échéance (ISO format)
    """
    try:
        data = request.get_json()
        
        if not data or 'due_date' not in data:
            return jsonify({'error': 'Missing due_date'}), 400
            
        from datetime import datetime
        due_date = datetime.fromisoformat(data['due_date'])
        
        db = get_db()
        success = db.set_vps_due_date(vps_id, due_date)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Due date updated successfully'
            })
        else:
            return jsonify({'error': 'Failed to update due date'}), 500
            
    except Exception as e:
        logger.error(f"Error setting due date: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/vps/suspended', methods=['GET'])
@require_auth
def get_suspended_vps():
    """Récupère tous les VPS suspendus"""
    try:
        db = get_db()
        all_vps = db.get_all_vps()
        suspended = [vps for vps in all_vps if vps.get('is_suspended')]
        
        return jsonify({
            'success': True,
            'vps_list': suspended,
            'count': len(suspended)
        })
        
    except Exception as e:
        logger.error(f"Error getting suspended VPS: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# User Operations
# ==========================================

@api_bp.route('/users/<int:user_id>', methods=['GET'])
@require_auth
def get_user(user_id):
    """Récupère un utilisateur"""
    try:
        db = get_db()
        user = db.get_user(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
            
        return jsonify({
            'success': True,
            'user': user
        })
        
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/users/<int:user_id>/vps-points', methods=['GET'])
@require_auth
def get_vps_points(user_id):
    """Récupère les points VPS d'un utilisateur"""
    try:
        db = get_db()
        points = db.get_vps_points(user_id)
        
        return jsonify({
            'success': True,
            'user_id': user_id,
            'vps_points': points
        })
        
    except Exception as e:
        logger.error(f"Error getting VPS points: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/users/<int:user_id>/vps-points', methods=['POST'])
@require_auth
def add_vps_points(user_id):
    """
    Ajoute des points VPS
    
    Body:
        points: Nombre de points à ajouter
    """
    try:
        data = request.get_json()
        
        if not data or 'points' not in data:
            return jsonify({'error': 'Missing points'}), 400
            
        db = get_db()
        success = db.add_vps_points(user_id, data['points'])
        
        if success:
            new_points = db.get_vps_points(user_id)
            return jsonify({
                'success': True,
                'message': 'VPS points updated successfully',
                'new_points': new_points
            })
        else:
            return jsonify({'error': 'Failed to update VPS points'}), 500
            
    except Exception as e:
        logger.error(f"Error updating VPS points: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/users/<int:user_id>/invites', methods=['GET'])
@require_auth
def get_invites(user_id):
    """Récupère les invitations d'un utilisateur"""
    try:
        db = get_db()
        invites = db.get_invites(user_id)
        
        return jsonify({
            'success': True,
            'user_id': user_id,
            'invites': invites
        })
        
    except Exception as e:
        logger.error(f"Error getting invites: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# Refund Operations
# ==========================================

@api_bp.route('/refund/process', methods=['POST'])
@require_auth
def process_refund():
    """
    Traite un remboursement
    
    Body:
        user_id: ID de l'utilisateur
        vps_info: Informations du VPS
        reason: Raison du remboursement
    """
    try:
        data = request.get_json()
        
        required = ['user_id', 'vps_info', 'reason']
        for field in required:
            if field not in data:
                return jsonify({'error': f'Missing {field}'}), 400
                
        from shared.helpers import process_refund
        db = get_db()
        
        success, message = process_refund(
            db,
            data['user_id'],
            data['vps_info'],
            data['reason']
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': message
            })
        else:
            return jsonify({'error': message}), 500
            
    except Exception as e:
        logger.error(f"Error processing refund: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# Batch Operations
# ==========================================

@api_bp.route('/vps/batch/create', methods=['POST'])
@require_auth
def batch_create_vps():
    """
    Crée plusieurs VPS en une seule requête
    
    Body:
        vps_list: Liste de VPS à créer
    """
    try:
        data = request.get_json()
        
        if not data or 'vps_list' not in data:
            return jsonify({'error': 'Missing vps_list'}), 400
            
        db = get_db()
        results = []
        
        for vps_data in data['vps_list']:
            try:
                vps_id = db.add_vps(**vps_data)
                results.append({
                    'success': True,
                    'vps_id': vps_id,
                    'container_name': vps_data.get('container_name')
                })
            except Exception as e:
                results.append({
                    'success': False,
                    'error': str(e),
                    'container_name': vps_data.get('container_name')
                })
                
        success_count = sum(1 for r in results if r['success'])
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results),
            'success_count': success_count,
            'failed_count': len(results) - success_count
        })
        
    except Exception as e:
        logger.error(f"Error in batch create: {e}")
        return jsonify({'error': str(e)}), 500


@api_bp.route('/vps/batch/delete', methods=['POST'])
@require_auth
def batch_delete_vps():
    """
    Supprime plusieurs VPS en une seule requête
    
    Body:
        vps_ids: Liste d'IDs de VPS à supprimer
    """
    try:
        data = request.get_json()
        
        if not data or 'vps_ids' not in data:
            return jsonify({'error': 'Missing vps_ids'}), 400
            
        db = get_db()
        results = []
        
        for vps_id in data['vps_ids']:
            try:
                success = db.delete_vps(vps_id)
                results.append({
                    'success': success,
                    'vps_id': vps_id
                })
            except Exception as e:
                results.append({
                    'success': False,
                    'error': str(e),
                    'vps_id': vps_id
                })
                
        success_count = sum(1 for r in results if r['success'])
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results),
            'success_count': success_count,
            'failed_count': len(results) - success_count
        })
        
    except Exception as e:
        logger.error(f"Error in batch delete: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# Statistics
# ==========================================

@api_bp.route('/stats/overview', methods=['GET'])
@require_auth
def get_stats_overview():
    """Récupère des statistiques globales"""
    try:
        db = get_db()
        all_vps = db.get_all_vps()
        
        stats = {
            'total_vps': len(all_vps),
            'active_vps': sum(1 for vps in all_vps if not vps.get('is_suspended')),
            'suspended_vps': sum(1 for vps in all_vps if vps.get('is_suspended')),
            'by_type': {},
            'by_node': {}
        }
        
        for vps in all_vps:
            vps_type = vps.get('vps_type', 'unknown')
            node = vps.get('node', 'unknown')
            
            stats['by_type'][vps_type] = stats['by_type'].get(vps_type, 0) + 1
            stats['by_node'][node] = stats['by_node'].get(node, 0) + 1
            
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        return jsonify({'error': str(e)}), 500
