"""
API Server interne du Bot
=========================

Ce module expose une API REST pour la communication entre les API nodes et le bot.
"""

from .server import app, start_server

__all__ = ['app', 'start_server']

__version__ = '1.0.0'
