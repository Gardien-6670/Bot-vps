"""
API Server interne du Bot - Version Multi-Serveurs
==================================================

Ce serveur expose une API REST pour permettre aux API nodes
de communiquer avec le bot et d'effectuer des opérations DB.

Supporte plusieurs API nodes en parallèle avec :
- Rate limiting par node
- Connection pooling
- Tracking des nodes actifs
- Métriques et monitoring
"""

from flask import Flask, request, jsonify, g
from functools import wraps
import os
import logging
import hmac
from datetime import datetime
import threading
import time

# Configuration
from .config import (
    API_SECRET_TOKEN, RATE_LIMIT_ENABLED, RATE_LIMIT_PER_MINUTE,
    RATE_LIMIT_BURST, API_NODES_TRACKING, API_NODE_TIMEOUT
)

# Middleware
from .middleware import (
    before_request, after_request, rate_limiter,
    get_api_nodes_stats, cleanup_inactive_nodes
)

logger = logging.getLogger(__name__)

app = Flask(__name__)

# Enregistrer les hooks
app.before_request(before_request)
app.after_request(after_request)

# Importer et enregistrer les routes supplémentaires
from .routes import api_bp
app.register_blueprint(api_bp)


def verify_token(token: str) -> bool:
    """
    Vérifie le token d'authentification
    
    Args:
        token: Token à vérifier
        
    Returns:
        True si valide
    """
    return hmac.compare_digest(token, API_SECRET_TOKEN)


def require_auth(f):
    """Décorateur pour vérifier l'authentification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get('X-API-Token')
        
        if not token:
            return jsonify({'error': 'Missing authentication token'}), 401
            
        if not verify_token(token):
            return jsonify({'error': 'Invalid authentication token'}), 403
            
        return f(*args, **kwargs)
    return decorated_function


def get_db():
    """Récupère l'instance de la base de données"""
    from shared.database_wrapper import db
    return db


@app.route('/health', methods=['GET'])
def health_check():
    """Endpoint de santé"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'service': 'bot-api-server',
        'version': '3.0'
    })


@app.route('/metrics', methods=['GET'])
@require_auth
def metrics():
    """Endpoint de métriques"""
    try:
        stats = get_api_nodes_stats()
        
        return jsonify({
            'success': True,
            'metrics': stats,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/nodes', methods=['GET'])
@require_auth
def get_nodes():
    """Liste les API nodes actifs"""
    try:
        stats = get_api_nodes_stats()
        
        return jsonify({
            'success': True,
            'nodes': stats['nodes'],
            'total': stats['total_nodes'],
            'active': stats['active_nodes']
        })
        
    except Exception as e:
        logger.error(f"Error getting nodes: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# VPS Operations (avec rate limiting)
# ==========================================

@app.route('/api/v1/vps/create', methods=['POST'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def create_vps():
    """
    Crée un nouveau VPS
    
    Body:
        user_id: ID de l'utilisateur
        container_name: Nom du conteneur
        node: Node
        vps_type: Type de VPS
        ... autres paramètres
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        required_fields = ['user_id', 'container_name', 'node', 'vps_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
                
        db = get_db()
        vps_id = db.add_vps(**data)
        
        return jsonify({
            'success': True,
            'vps_id': vps_id,
            'message': 'VPS created successfully'
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/<int:vps_id>', methods=['GET'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE * 2, burst=RATE_LIMIT_BURST * 2) if RATE_LIMIT_ENABLED else lambda f: f
def get_vps(vps_id):
    """Récupère un VPS par ID"""
    try:
        db = get_db()
        vps = db.get_vps(vps_id=vps_id)
        
        if not vps:
            return jsonify({'error': 'VPS not found'}), 404
            
        return jsonify({
            'success': True,
            'vps': vps
        })
        
    except Exception as e:
        logger.error(f"Error getting VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/<int:vps_id>', methods=['PUT'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def update_vps(vps_id):
    """
    Met à jour un VPS
    
    Body:
        Champs à mettre à jour
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        db = get_db()
        success = db.update_vps(vps_id, **data)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'VPS updated successfully'
            })
        else:
            return jsonify({'error': 'Failed to update VPS'}), 500
            
    except Exception as e:
        logger.error(f"Error updating VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/<int:vps_id>', methods=['DELETE'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def delete_vps(vps_id):
    """Supprime un VPS"""
    try:
        db = get_db()
        success = db.delete_vps(vps_id)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'VPS deleted successfully'
            })
        else:
            return jsonify({'error': 'Failed to delete VPS'}), 500
            
    except Exception as e:
        logger.error(f"Error deleting VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/by-container/<container_name>', methods=['GET'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE * 2, burst=RATE_LIMIT_BURST * 2) if RATE_LIMIT_ENABLED else lambda f: f
def get_vps_by_container(container_name):
    """Récupère un VPS par nom de conteneur"""
    try:
        db = get_db()
        vps = db.get_vps(container_name=container_name)
        
        if not vps:
            return jsonify({'error': 'VPS not found'}), 404
            
        return jsonify({
            'success': True,
            'vps': vps
        })
        
    except Exception as e:
        logger.error(f"Error getting VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/user/<int:user_id>', methods=['GET'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE * 2, burst=RATE_LIMIT_BURST * 2) if RATE_LIMIT_ENABLED else lambda f: f
def get_user_vps(user_id):
    """Récupère tous les VPS d'un utilisateur"""
    try:
        db = get_db()
        vps_list = db.get_user_vps(user_id)
        
        return jsonify({
            'success': True,
            'vps_list': vps_list,
            'count': len(vps_list)
        })
        
    except Exception as e:
        logger.error(f"Error getting user VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/suspend', methods=['POST'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def suspend_vps():
    """
    Suspend un VPS
    
    Body:
        container_name: Nom du conteneur
        reason: Raison de la suspension
    """
    try:
        data = request.get_json()
        
        if not data or 'container_name' not in data:
            return jsonify({'error': 'Missing container_name'}), 400
            
        db = get_db()
        success = db.suspend_vps(
            data['container_name'],
            data.get('reason', 'No reason provided')
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': 'VPS suspended successfully'
            })
        else:
            return jsonify({'error': 'Failed to suspend VPS'}), 500
            
    except Exception as e:
        logger.error(f"Error suspending VPS: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/vps/unsuspend', methods=['POST'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def unsuspend_vps():
    """
    Réactive un VPS
    
    Body:
        container_name: Nom du conteneur
    """
    try:
        data = request.get_json()
        
        if not data or 'container_name' not in data:
            return jsonify({'error': 'Missing container_name'}), 400
            
        db = get_db()
        success = db.unsuspend_vps(data['container_name'])
        
        if success:
            return jsonify({
                'success': True,
                'message': 'VPS unsuspended successfully'
            })
        else:
            return jsonify({'error': 'Failed to unsuspend VPS'}), 500
            
    except Exception as e:
        logger.error(f"Error unsuspending VPS: {e}")
        return jsonify({'error': str(e)}), 500


# ==========================================
# User Operations
# ==========================================

@app.route('/api/v1/users/<int:user_id>/balance', methods=['GET'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE * 2, burst=RATE_LIMIT_BURST * 2) if RATE_LIMIT_ENABLED else lambda f: f
def get_user_balance(user_id):
    """Récupère le solde d'un utilisateur"""
    try:
        db = get_db()
        balance = db.get_balance(user_id)
        
        return jsonify({
            'success': True,
            'user_id': user_id,
            'balance': balance
        })
        
    except Exception as e:
        logger.error(f"Error getting balance: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/users/<int:user_id>/credits', methods=['POST'])
@require_auth
@rate_limiter(limit_per_minute=RATE_LIMIT_PER_MINUTE, burst=RATE_LIMIT_BURST) if RATE_LIMIT_ENABLED else lambda f: f
def add_credits(user_id):
    """
    Ajoute/retire des crédits
    
    Body:
        amount: Montant (peut être négatif)
    """
    try:
        data = request.get_json()
        
        if not data or 'amount' not in data:
            return jsonify({'error': 'Missing amount'}), 400
            
        db = get_db()
        success = db.add_credits(user_id, data['amount'])
        
        if success:
            new_balance = db.get_balance(user_id)
            return jsonify({
                'success': True,
                'message': 'Credits updated successfully',
                'new_balance': new_balance
            })
        else:
            return jsonify({'error': 'Failed to update credits'}), 500
            
    except Exception as e:
        logger.error(f"Error updating credits: {e}")
        return jsonify({'error': str(e)}), 500


@app.errorhandler(404)
def not_found(error):
    """Handler pour 404"""
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    """Handler pour 500"""
    return jsonify({'error': 'Internal server error'}), 500


@app.errorhandler(429)
def rate_limit_error(error):
    """Handler pour 429 (rate limit)"""
    return jsonify({
        'error': 'Rate limit exceeded',
        'retry_after': 60
    }), 429


def cleanup_thread():
    """Thread pour nettoyer les nodes inactifs"""
    while True:
        try:
            time.sleep(60)  # Toutes les minutes
            cleanup_inactive_nodes(API_NODE_TIMEOUT)
        except Exception as e:
            logger.error(f"Error in cleanup thread: {e}")


def start_server(host='0.0.0.0', port=5001, debug=False):
    """
    Démarre le serveur API
    
    Args:
        host: Hôte d'écoute
        port: Port d'écoute
        debug: Mode debug
    """
    logger.info(f"Starting Bot API Server on {host}:{port}")
    logger.info(f"Rate limiting: {'enabled' if RATE_LIMIT_ENABLED else 'disabled'}")
    logger.info(f"API nodes tracking: {'enabled' if API_NODES_TRACKING else 'disabled'}")
    
    # Démarrer le thread de nettoyage
    if API_NODES_TRACKING:
        cleanup = threading.Thread(target=cleanup_thread, daemon=True)
        cleanup.start()
        logger.info("Cleanup thread started")
    
    # Démarrer le serveur avec threading
    app.run(host=host, port=port, debug=debug, threaded=True)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    start_server(debug=True)
