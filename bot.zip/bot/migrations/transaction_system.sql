-- Migration complete pour le systeme de logs de transactions
-- Compatible avec MySQL 9

USE vps;

CREATE TABLE IF NOT EXISTS transaction_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    balance_before INT NOT NULL,
    balance_after INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_user_id (user_id);
ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_transaction_type (transaction_type);
ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_created_at (created_at);

CREATE TABLE IF NOT EXISTS transaction_logs_archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    balance_before INT NOT NULL,
    balance_after INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP,
    archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE transaction_logs_archive ADD INDEX IF NOT EXISTS idx_user_id (user_id);
ALTER TABLE transaction_logs_archive ADD INDEX IF NOT EXISTS idx_archived_at (archived_at);

SELECT 'Transaction logging tables created successfully!' AS Status;
