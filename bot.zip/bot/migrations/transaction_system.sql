-- Migration complete pour le systeme de logs de transactions
-- Compatible avec toutes les versions de MySQL

USE vps;

-- Table principale pour les logs de transactions
CREATE TABLE IF NOT EXISTS transaction_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    balance_before INT NOT NULL,
    balance_after INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table d'archive pour les anciens logs
CREATE TABLE IF NOT EXISTS transaction_logs_archive (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    balance_before INT NOT NULL,
    balance_after INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP,
    archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ajouter les index (ignorer les erreurs si les index existent déjà)
-- Pour transaction_logs
CREATE INDEX idx_user_id ON transaction_logs(user_id);
CREATE INDEX idx_transaction_type ON transaction_logs(transaction_type);
CREATE INDEX idx_created_at ON transaction_logs(created_at);

-- Pour transaction_logs_archive
CREATE INDEX idx_user_id ON transaction_logs_archive(user_id);
CREATE INDEX idx_archived_at ON transaction_logs_archive(archived_at);

SELECT 'Transaction logging tables created successfully!' AS Status;
