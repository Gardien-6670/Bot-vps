-- Migration script to add dedicated_renewal_orders table
-- This table stores renewal orders for dedicated VPS
-- Compatible with MySQL 9

CREATE TABLE IF NOT EXISTS dedicated_renewal_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    container_name VARCHAR(255) NOT NULL,
    months INT NOT NULL,
    price_eur DECIMAL(10, 2) NOT NULL,
    track_id VARCHAR(255) UNIQUE NOT NULL,
    expiration_time DATETIME NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL
);

-- Add indexes for better performance (MySQL 9 syntax)
ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_track_id (track_id);
ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_status (status);
ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_user_id (user_id);
ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_container_name (container_name);

SELECT 'Table dedicated_renewal_orders created successfully!' AS Status;
