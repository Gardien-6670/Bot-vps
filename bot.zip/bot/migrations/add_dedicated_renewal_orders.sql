-- Migration script to add dedicated_renewal_orders table
-- This table stores renewal orders for dedicated VPS
-- Compatible with all MySQL versions

CREATE TABLE IF NOT EXISTS dedicated_renewal_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    container_name VARCHAR(255) NOT NULL,
    months INT NOT NULL,
    price_eur DECIMAL(10, 2) NOT NULL,
    track_id VARCHAR(255) UNIQUE NOT NULL,
    expiration_time DATETIME NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL
);

-- Add indexes (check if they exist first in your MySQL client)
-- If index already exists, these will fail silently

-- For MySQL 8.0.29+ and MariaDB 10.5+, you can use:
-- ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_track_id (track_id);
-- ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_status (status);
-- ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_user_id (user_id);
-- ALTER TABLE dedicated_renewal_orders ADD INDEX IF NOT EXISTS idx_container_name (container_name);

-- For older MySQL versions, check manually and create if needed:
-- SELECT COUNT(*) FROM information_schema.statistics 
-- WHERE table_schema = DATABASE() AND table_name = 'dedicated_renewal_orders' AND index_name = 'idx_track_id';
-- If result is 0, then run:

CREATE INDEX idx_track_id ON dedicated_renewal_orders(track_id);
CREATE INDEX idx_status ON dedicated_renewal_orders(status);
CREATE INDEX idx_user_id ON dedicated_renewal_orders(user_id);
CREATE INDEX idx_container_name ON dedicated_renewal_orders(container_name);

SELECT 'Table dedicated_renewal_orders created successfully!' AS Status;
