# Guide de Migration MySQL 9 et Configuration

Ce guide explique comment corriger tous les problèmes de base de données et de configuration pour le bot VPS.

## 📋 Problèmes Corrigés

### 1. Base de Données MySQL
- ✅ Tables manquantes créées
- ✅ Colonnes manquantes ajoutées
- ✅ Index optimisés pour MySQL 9
- ✅ Compatibilité MySQL 9 assurée

### 2. Configuration
- ✅ IDs Discord configurables via .env
- ✅ SSL optionnel pour les serveurs Flask
- ✅ Coroutine async corrigée dans main.py

## 🚀 Instructions d'Installation

### Étape 1: Appliquer la Migration SQL

Connectez-vous à votre serveur MySQL et exécutez le script de migration :

```bash
# Option 1: Depuis la ligne de commande
mysql -h 192.254.79.244 -P 8082 -u vps -p vps < /root/Bot-vps/bot/migrations/mysql9_migration.sql

# Option 2: Depuis MySQL CLI
mysql -h 192.254.79.244 -P 8082 -u vps -p
USE vps;
SOURCE /root/Bot-vps/bot/migrations/mysql9_migration.sql;
```

**Note:** Remplacez les paramètres de connexion par vos propres valeurs.

### Étape 2: Mettre à Jour le Fichier .env

1. Copiez le nouveau fichier .env.example :
```bash
cp /root/Bot-vps/.env.example /root/Bot-vps/.env.new
```

2. Éditez `/root/Bot-vps/.env` et ajoutez les nouvelles variables :

```bash
# ============================================================================
# DISCORD CHANNEL IDS - IMPORTANT: Mettez à jour avec vos nouveaux IDs
# ============================================================================
TOS_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI
PAID_PLANS_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI
PANEL_MAIN_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI
PANEL_AD_TIERS_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI
PANEL_DEDICATED_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI
PANEL_INVITE_PLANS_CHANNEL_ID=VOTRE_NOUVEAU_ID_ICI

# ============================================================================
# DISCORD ROLE IDS
# ============================================================================
EXEMPT_ROLE_1=VOTRE_ID_ICI
EXEMPT_ROLE_2=VOTRE_ID_ICI
BOOSTER_ROLE_ID=VOTRE_ID_ICI

# ============================================================================
# DISCORD USER IDS
# ============================================================================
ADMIN_WHITELIST=ID1,ID2,ID3

# ============================================================================
# SSL CONFIGURATION (Désactivé par défaut)
# ============================================================================
SSL_ENABLED=false
# SSL_CERT_PATH=/path/to/cert.pem
# SSL_KEY_PATH=/path/to/key.pem
```

### Étape 3: Obtenir les Nouveaux IDs Discord

#### Pour obtenir un ID de canal :
1. Activez le Mode Développeur dans Discord (Paramètres > Avancé > Mode Développeur)
2. Clic droit sur le canal → Copier l'identifiant

#### Pour obtenir un ID de rôle :
1. Paramètres du serveur → Rôles
2. Clic droit sur le rôle → Copier l'identifiant

#### Pour obtenir un ID d'utilisateur :
1. Clic droit sur l'utilisateur → Copier l'identifiant

### Étape 4: Redémarrer le Bot

```bash
cd /root/Bot-vps/bot
python3 main.py
```

## 🔍 Vérification

### Vérifier que les tables sont créées :

```sql
USE vps;
SHOW TABLES;

-- Vérifier les colonnes de la table vps
DESCRIBE vps;

-- Vérifier les colonnes de invited_members
DESCRIBE invited_members;
```

### Vérifier les logs du bot :

```bash
tail -f /root/Bot-vps/bot/bot.log
```

Vous devriez voir :
- ✅ Aucune erreur "Table doesn't exist"
- ✅ Aucune erreur "Unknown column"
- ✅ "VPS renewal tasks started" sans warning
- ✅ Flask servers démarrés (avec ou sans SSL selon config)

## 📝 Tables Créées par la Migration

1. **paid_plans_message** - Messages des plans payants
2. **transactions** - Transactions de crédits
3. **giveaways** - Giveaways actifs
4. **giveaway_participants** - Participants aux giveaways
5. **virustotal_daily_stats** - Statistiques VirusTotal
6. **tos_message** - Messages Terms of Service

## 🔧 Colonnes Ajoutées

### Table `vps` :
- `status` - Statut du VPS (active, suspended, etc.)
- `invite_plan_tier` - Tier du plan d'invitation
- `is_dedicated` - Indicateur de serveur dédié
- `plan_tier` - Tier du plan
- `suspended_at` - Date de suspension
- `attributed_to_user_id` - ID utilisateur attribué
- `attribution_end_date` - Date de fin d'attribution

### Table `invited_members` :
- `member_id` - ID du membre invité
- `inviter_id` - ID de l'inviteur
- `joined_at` - Date d'adhésion
- `left_at` - Date de départ
- `reward_given` - Récompense donnée (0/1)

## ⚠️ Problèmes Connus et Solutions

### Erreur: "Missing Access" lors de la synchronisation des commandes
**Solution:** Vérifiez que le bot a les permissions nécessaires dans le serveur Discord.

### Erreur: SSL Certificate not found
**Solution:** Désactivez SSL dans le .env :
```bash
SSL_ENABLED=false
```

### Erreur: Channel not found
**Solution:** Mettez à jour tous les IDs de canaux dans le .env avec les nouveaux IDs de votre serveur.

## 📞 Support

Si vous rencontrez des problèmes :
1. Vérifiez les logs : `tail -f /root/Bot-vps/bot/bot.log`
2. Vérifiez la connexion MySQL : `mysql -h HOST -P PORT -u USER -p`
3. Vérifiez que toutes les variables .env sont définies

## 🎯 Checklist de Déploiement

- [ ] Migration SQL appliquée avec succès
- [ ] Fichier .env mis à jour avec tous les nouveaux IDs
- [ ] SSL configuré (activé ou désactivé)
- [ ] Bot redémarré
- [ ] Aucune erreur dans les logs
- [ ] Commandes Discord synchronisées
- [ ] Serveurs Flask démarrés
- [ ] Tests de base effectués (création VPS, etc.)

## 📚 Fichiers Modifiés

1. `/root/Bot-vps/bot/main.py` - Correction de la coroutine async
2. `/root/Bot-vps/bot/utils/flask_earn_server.py` - SSL optionnel
3. `/root/Bot-vps/bot/utils/flask_ip_verify.py` - SSL optionnel
4. `/root/Bot-vps/.env.example` - Nouvelles variables
5. `/root/Bot-vps/bot/migrations/mysql9_migration.sql` - Script de migration

---

**Date de création:** 2026-02-01
**Version:** 1.0
**Compatibilité:** MySQL 9.x, Python 3.13, Discord.py 2.x
