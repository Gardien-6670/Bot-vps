#!/usr/bin/env python3
"""
Script de mise à jour du fichier .env avec les nouveaux IDs Discord
"""

import os
import sys

def update_env_file():
    """Met à jour le fichier .env avec les nouvelles variables"""
    
    env_path = "/root/Bot-vps/.env"
    
    if not os.path.exists(env_path):
        print(f"❌ Fichier {env_path} introuvable!")
        return False
    
    print("🔧 Mise à jour du fichier .env...")
    print()
    
    # Lire le fichier actuel
    with open(env_path, 'r') as f:
        content = f.read()
    
    # Variables à ajouter si elles n'existent pas
    new_vars = {
        # Discord Channel IDs
        "TOS_CHANNEL_ID": "1430625796073980070",
        "PAID_PLANS_CHANNEL_ID": "1338196704188698757",
        "PANEL_MAIN_CHANNEL_ID": "1447244265540554763",
        "PANEL_AD_TIERS_CHANNEL_ID": "1447244451306012682",
        "PANEL_DEDICATED_CHANNEL_ID": "1447244755430801521",
        "PANEL_INVITE_PLANS_CHANNEL_ID": "1449707721212432385",
        
        # Discord Role IDs
        "EXEMPT_ROLE_1": "1358004192416890903",
        "EXEMPT_ROLE_2": "1436388721086693567",
        "BOOSTER_ROLE_ID": "1436388721086693567",
        
        # Discord User IDs
        "ADMIN_WHITELIST": "1047760053509312642,1358004112049967206",
        
        # Discord Guild ID
        "DISCORD_GUILD_ID": "1337813607530102814",
        
        # SSL Configuration
        "SSL_ENABLED": "false",
        "SSL_CERT_PATH": "/etc/letsencrypt/live/earn-jupyterhive.duckdns.org/fullchain.pem",
        "SSL_KEY_PATH": "/etc/letsencrypt/live/earn-jupyterhive.duckdns.org/privkey.pem",
        
        # Flask Configuration
        "FLASK_EARN_PORT": "6028",
        "FLASK_IP_VERIFY_PORT": "6029",
        "FLASK_BIND_HOST": "0.0.0.0",
    }
    
    # Vérifier quelles variables manquent
    missing_vars = []
    for var_name in new_vars:
        if f"{var_name}=" not in content:
            missing_vars.append(var_name)
    
    if not missing_vars:
        print("✅ Toutes les variables sont déjà présentes dans le .env")
        return True
    
    print(f"📝 {len(missing_vars)} variable(s) manquante(s) détectée(s):")
    for var in missing_vars:
        print(f"   - {var}")
    print()
    
    # Demander confirmation
    response = input("Voulez-vous ajouter ces variables au .env? (o/N): ")
    if response.lower() != 'o':
        print("❌ Opération annulée")
        return False
    
    # Créer une sauvegarde
    backup_path = f"{env_path}.backup"
    with open(backup_path, 'w') as f:
        f.write(content)
    print(f"💾 Sauvegarde créée: {backup_path}")
    
    # Ajouter les variables manquantes
    additions = []
    additions.append("\n# ============================================================================")
    additions.append("# CONFIGURATION AJOUTÉE AUTOMATIQUEMENT")
    additions.append("# ============================================================================\n")
    
    # Grouper par catégorie
    categories = {
        "DISCORD CHANNEL IDS": ["TOS_CHANNEL_ID", "PAID_PLANS_CHANNEL_ID", "PANEL_MAIN_CHANNEL_ID", 
                                "PANEL_AD_TIERS_CHANNEL_ID", "PANEL_DEDICATED_CHANNEL_ID", 
                                "PANEL_INVITE_PLANS_CHANNEL_ID"],
        "DISCORD ROLE IDS": ["EXEMPT_ROLE_1", "EXEMPT_ROLE_2", "BOOSTER_ROLE_ID"],
        "DISCORD USER IDS": ["ADMIN_WHITELIST"],
        "DISCORD GUILD": ["DISCORD_GUILD_ID"],
        "SSL CONFIGURATION": ["SSL_ENABLED", "SSL_CERT_PATH", "SSL_KEY_PATH"],
        "FLASK CONFIGURATION": ["FLASK_EARN_PORT", "FLASK_IP_VERIFY_PORT", "FLASK_BIND_HOST"],
    }
    
    for category, vars_in_category in categories.items():
        category_vars = [v for v in vars_in_category if v in missing_vars]
        if category_vars:
            additions.append(f"\n# {category}")
            for var_name in category_vars:
                value = new_vars[var_name]
                additions.append(f'{var_name}="{value}"')
    
    # Écrire le fichier mis à jour
    with open(env_path, 'a') as f:
        f.write('\n'.join(additions))
    
    print(f"✅ {len(missing_vars)} variable(s) ajoutée(s) au .env")
    print()
    print("⚠️  IMPORTANT: Vérifiez et mettez à jour les IDs avec vos propres valeurs!")
    print(f"   Éditez le fichier: {env_path}")
    print()
    print("📋 Variables à vérifier:")
    print("   - Tous les IDs de canaux Discord (CHANNEL_ID)")
    print("   - Tous les IDs de rôles Discord (ROLE_ID)")
    print("   - Liste des admins (ADMIN_WHITELIST)")
    print("   - ID du serveur Discord (DISCORD_GUILD_ID)")
    print()
    
    return True

def main():
    print("=" * 70)
    print("SCRIPT DE MISE À JOUR DU FICHIER .ENV")
    print("=" * 70)
    print()
    
    if update_env_file():
        print("=" * 70)
        print("✅ MISE À JOUR TERMINÉE")
        print("=" * 70)
        print()
        print("Prochaines étapes:")
        print("1. Éditez /root/Bot-vps/.env et mettez à jour les IDs")
        print("2. Appliquez la migration SQL (voir README_MIGRATION.md)")
        print("3. Redémarrez le bot: python3 /root/Bot-vps/bot/main.py")
        return 0
    else:
        print("=" * 70)
        print("❌ MISE À JOUR ÉCHOUÉE")
        print("=" * 70)
        return 1

if __name__ == "__main__":
    sys.exit(main())
