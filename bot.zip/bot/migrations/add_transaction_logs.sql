-- Migration script to add transaction_logs table
-- This table stores all credit and VPS point transactions for audit purposes
-- Compatible with all MySQL versions

CREATE TABLE IF NOT EXISTS transaction_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL COMMENT 'Discord user ID',
    transaction_type VARCHAR(50) NOT NULL COMMENT 'credit_add, credit_remove, point_add, point_remove',
    amount INT NOT NULL COMMENT 'Amount of credits or points',
    balance_before INT NOT NULL COMMENT 'Balance before transaction',
    balance_after INT NOT NULL COMMENT 'Balance after transaction',
    reason TEXT COMMENT 'Reason for the transaction',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Transaction timestamp'
);

-- Add indexes (check if they exist first in your MySQL client)
-- For older MySQL versions, these CREATE INDEX statements will fail if index exists
-- You can ignore the errors or check manually first

CREATE INDEX idx_user_id ON transaction_logs(user_id);
CREATE INDEX idx_transaction_type ON transaction_logs(transaction_type);
CREATE INDEX idx_created_at ON transaction_logs(created_at);

SELECT 'Table transaction_logs created successfully!' AS Status;
