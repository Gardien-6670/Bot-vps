-- Migration script to add transaction_logs table
-- This table stores all credit and VPS point transactions for audit purposes
-- Compatible with MySQL 9

CREATE TABLE IF NOT EXISTS transaction_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL COMMENT 'credit_add, credit_remove, point_add, point_remove',
    amount INT NOT NULL,
    balance_before INT NOT NULL,
    balance_after INT NOT NULL,
    reason TEXT COMMENT 'Reason for the transaction',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for better performance (MySQL 9 syntax)
ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_user_id (user_id);
ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_transaction_type (transaction_type);
ALTER TABLE transaction_logs ADD INDEX IF NOT EXISTS idx_created_at (created_at);

SELECT 'Table transaction_logs created successfully!' AS Status;
