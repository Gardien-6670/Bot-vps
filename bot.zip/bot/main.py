import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytz
from discord.ui import View, Button
import secrets
from utils.flask_ip_verify import run_ip_verify_flask_app
from utils.auto_renew import start_vps_renewal_tasks
from utils import node_manager
from utils.flask_earn_server import run_flask_app
from threading import Thread
import aiohttp
import yaml
import logging
from utils.surveillance.command_logger import CommandLogger
from utils.surveillance import SurveillanceLXC, SurveillanceKVM, SurveillanceDedi
from utils.database import db
from datetime import datetime, timedelta
from dotenv import load_dotenv
import asyncio
from discord.ext import commands, tasks
import discord

load_dotenv(dotenv_path='.env')

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.invites = True
intents.presences = True

bot = commands.Bot(command_prefix='!', intents=intents)
bot.remove_command('help')

bot.surveillance_lxc_instance = None
bot.surveillance_kvm_instance = None
bot.surveillance_dedi_instance = None
bot.command_logger_instance = None


class WrongGuildError(commands.CheckFailure):
    pass


# Configure logging avec plus de détails

# Créer le logger root
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)

# Supprimer les handlers existants pour éviter les doublons
for handler in root_logger.handlers[:]:
    root_logger.removeHandler(handler)

# Handler pour fichier
file_handler = logging.FileHandler('bot.log', encoding='utf-8')
file_handler.setLevel(logging.INFO)
file_formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)

# Handler pour console (stdout)
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.INFO)
console_formatter = logging.Formatter(
    '%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)

# Ajouter les handlers
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# Configurer les loggers spécifiques
logging.getLogger('discord').setLevel(logging.WARNING)
logging.getLogger('discord.http').setLevel(logging.WARNING)
logging.getLogger('discord.gateway').setLevel(logging.WARNING)
logging.getLogger('werkzeug').setLevel(logging.WARNING)

# Logger de test
logging.info("=" * 70)
logging.info("LOGGING SYSTEM INITIALIZED")
logging.info("=" * 70)
print("=" * 70)
print("LOGGING SYSTEM INITIALIZED")
print("=" * 70)

# ============================================================================
# TASKS
# ============================================================================


@tasks.loop(hours=1)
async def check_invitation_rewards():
    await bot.wait_until_ready()
    logging.info("Running hourly invitation reward check...")

    five_days_ago = datetime.now() - timedelta(days=5)
    unrewarded_members = db.get_unrewarded_members(five_days_ago)

    for member_data in unrewarded_members:
        member_id = member_data['member_id']
        inviter_id = member_data['inviter_id']

        # Database operations should always happen if logic dictates
        db.add_credits(inviter_id, 5)
        db.mark_invite_reward_given(member_id)
        logging.info(
            f"Rewarding {inviter_id} with 5 credits for inviting {member_id}.")

        # Attempt to send DM, handle potential errors
        try:
            inviter = await bot.fetch_user(inviter_id)
            if inviter:
                embed = discord.Embed(
                    title="Invitation Reward",
                    description=f"You have received 5 credits for inviting a new member who has stayed for 5 days!",
                    color=discord.Color.green())
                await inviter.send(embed=embed)
        except discord.NotFound:
            logging.warning(
                f"Inviter {inviter_id} not found, could not send reward DM.")
        except discord.Forbidden:
            logging.warning(
                f"Cannot send reward DM to inviter {inviter_id}. DMs are disabled.")


@tasks.loop(hours=1)
async def check_unverified_vps_for_suspension():
    await bot.wait_until_ready()
    logging.info("Running hourly check for unverified VPS users (multi-stage)...")
    now_utc = datetime.now(pytz.utc)
    WARNING_INTERVAL_HOURS = 3
    MAX_WARNINGS = 3
    SUSPENSION_GRACE_DAYS = 7 # Days after suspension before deletion

    # Get all users who own a VPS
    users_with_vps_records = db.get_all_users_with_vps()

    for user_data_record in users_with_vps_records:
        user_id = user_data_record['user_id']
        
        user_ip_status = db.get_user_ip_status(user_id)
        if not user_ip_status:
            logging.warning(f"Could not retrieve IP status for user {user_id}. Skipping.")
            continue
            
        is_verified = user_ip_status['is_ip_verified']
        ip_warning_sent_at = user_ip_status['ip_warning_sent_at']
        ip_warning_count = user_ip_status['ip_warning_count']
        vps_suspension_date = user_ip_status['vps_suspension_date']

        # Clear state if user is now verified
        if is_verified:
            if ip_warning_sent_at or ip_warning_count > 0 or vps_suspension_date:
                logging.info(f"User {user_id} is now verified. Clearing previous IP warning/suspension states.")
                db.clear_ip_verification_state(user_id)
            continue # User is verified, nothing to do here

        # User is not IP verified, check if they have active VPS
        active_vps_list = db.get_user_active_vps(user_id)
        if not active_vps_list:
            # If they don't have active VPS, clear any previous warning timestamps or suspension dates
            if ip_warning_sent_at or ip_warning_count > 0 or vps_suspension_date:
                logging.info(f"User {user_id} has no active VPS. Clearing previous IP warning/suspension states.")
                db.clear_ip_verification_state(user_id)
            continue # User has no active VPS, no need to warn/suspend

        # Get user object for DM
        user = None
        try:
            user = await bot.fetch_user(user_id)
        except discord.NotFound:
            logging.warning(f"User {user_id} not found, cannot send DM for IP verification.")
            continue # Cannot send DM, skip this user for now
        except discord.HTTPException as e:
            logging.error(f"HTTPException when fetching user {user_id}: {e}")
            continue

        PUBLIC_VERIFY_HOST = os.getenv("PUBLIC_FLASK_HOST", "earn-jupyterhive.duckdns.org")
        VERIFY_PORT = 6029

        # Generate a fresh token for the link every time a warning is sent or checked, in
        # case the old one expired.
        token = secrets.token_urlsafe(32)
        expiration = now_utc + timedelta(hours=WARNING_INTERVAL_HOURS) # Token valid for warning interval
        db.set_ip_verification_token(user_id, token, expiration)
        verify_url = f"https://{PUBLIC_VERIFY_HOST}:{VERIFY_PORT}/verify/{user_id}/{token}"

        # --- DELETION LOGIC (highest priority if VPS is suspended) ---
        if vps_suspension_date:
            time_since_suspension = now_utc - vps_suspension_date
            if time_since_suspension >= timedelta(days=SUSPENSION_GRACE_DAYS):
                logging.warning(f"User {user_id} has not verified IP after {SUSPENSION_GRACE_DAYS} days of suspension. Deleting active VPS.")
                
                deletion_embed = discord.Embed(
                    title="VPS Deleted - IP Unverified!",
                    description=f"Your VPS has been permanently deleted because your IP address was not verified within {SUSPENSION_GRACE_DAYS} days of suspension. This action is irreversible.",
                    color=discord.Color.dark_red())
                deletion_embed.add_field(name="Reason", value="Failure to complete IP verification after multiple warnings and VPS suspension.")
                
                try:
                    await user.send(embed=deletion_embed)
                except discord.Forbidden:
                    logging.warning(f"Cannot send VPS deletion DM to user {user_id}. DMs are disabled.")
                
                for vps in active_vps_list:
                    container_name = vps['container_name']
                    vps_id = vps['id']
                    vps_type = vps.get('vps_type', 'lxc')

                    node_info = node_manager.get_node_for_vps(container_name)
                    if node_info:
                        try:
                            node_url, api_key = node_info['url'], node_info['api_key']
                            endpoint = f"/lxc/container/{container_name}/terminate" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/terminate"
                            await node_manager.api_request('POST', endpoint, node_url, api_key)
                            db.delete_vps(vps_id) # Remove from DB
                            logging.info(f"VPS {container_name} (ID: {vps_id}) terminated and deleted for user {user_id} due to unverified IP.")
                        except Exception as e:
                            logging.error(f"Failed to terminate/delete VPS {container_name} for user {user_id}: {e}")
                    else:
                        logging.error(f"Could not determine node for VPS {container_name}. Cannot terminate/delete.")
                
                db.clear_ip_verification_state(user_id) # Clear all states after deletion
                continue # Move to next user

        # --- SUSPENSION LOGIC ---
        # If VPS is not suspended yet and conditions for suspension are met
        if not vps_suspension_date and ip_warning_count >= MAX_WARNINGS:
            # Check if enough time has passed since the last warning to trigger suspension
            if not ip_warning_sent_at or (now_utc - ip_warning_sent_at) >= timedelta(hours=WARNING_INTERVAL_HOURS):
                logging.warning(f"User {user_id} has not verified IP after {MAX_WARNINGS} warnings. Suspending active VPS.")

                suspension_embed = discord.Embed(
                    title="VPS Suspended - IP Unverified!",
                    description=f"Your VPS has been suspended because your IP address was not verified after {MAX_WARNINGS} warnings. Your VPS will be deleted in {SUSPENSION_GRACE_DAYS} days if not verified.",
                    color=discord.Color.red())
                suspension_embed.add_field(
                    name="Action Required",
                    value=f"Please complete the IP verification process. Your VPS will be unsuspended automatically once verified. [Click here to verify your IP]({verify_url}) (Link valid for {WARNING_INTERVAL_HOURS} hours)")
                
                try:
                    await user.send(embed=suspension_embed, view=View().add_item(Button(label="Verify My IP", url=verify_url)))
                except discord.Forbidden:
                    logging.warning(f"Cannot send VPS suspension DM to user {user_id}. DMs are disabled.")
                
                for vps in active_vps_list:
                    container_name = vps['container_name']
                    vps_id = vps['id']
                    vps_type = vps.get('vps_type', 'lxc')

                    node_info = node_manager.get_node_for_vps(container_name)
                    if node_info:
                        try:
                            node_url, api_key = node_info['url'], node_info['api_key']
                            endpoint = f"/lxc/container/{container_name}/stop" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/stop"
                            await node_manager.api_request('POST', endpoint, node_url, api_key, data={"force": True})
                            db.suspend_vps(vps_id, reason='ip_unverified')
                            logging.info(f"VPS {container_name} (ID: {vps_id}) suspended for user {user_id} due to unverified IP.")
                        except Exception as e:
                            logging.error(f"Failed to stop/suspend VPS {container_name} for user {user_id}: {e}")
                    else:
                        logging.error(f"Could not determine node for VPS {container_name}. Cannot stop/suspend.")
                
                # Set suspension date and clear warning states
                db.update_user_ip_status(user_id, vps_suspension_date=now_utc)
                db.clear_ip_verification_state(user_id) # Clear warning count/timestamp as suspension takes over
                continue # Move to next user
            else:
                logging.info(f"User {user_id} reached max warnings, but not enough time elapsed since last warning for suspension.")
                continue # Wait for next interval

        # --- WARNING LOGIC ---
        # If VPS is not suspended and warnings are less than max allowed
        if not vps_suspension_date and ip_warning_count < MAX_WARNINGS:
            if not ip_warning_sent_at or (now_utc - ip_warning_sent_at) >= timedelta(hours=WARNING_INTERVAL_HOURS):
                new_warning_count = ip_warning_count + 1
                logging.info(f"User {user_id} (unverified IP) has active VPS. Sending warning {new_warning_count}/{MAX_WARNINGS}.")
                
                warning_embed = discord.Embed(
                    title="IP Verification Required - Action Needed!",
                    description=f"Our records show you have an active VPS but have not yet verified your IP address. This is a one-time security measure.",
                    color=discord.Color.orange())
                
                if new_warning_count <= MAX_WARNINGS:
                    warning_embed.add_field(
                        name="Important!",
                        value=f"This is warning {new_warning_count} of {MAX_WARNINGS}. Your VPS will be suspended in approximately {WARNING_INTERVAL_HOURS} hours if your IP is not verified. Please complete the verification process immediately.")
                    warning_embed.add_field(
                        name="Verification Link",
                        value=f"[Click here to verify your IP]({verify_url}) (Link valid for {WARNING_INTERVAL_HOURS} hours)")
                
                try:
                    await user.send(embed=warning_embed, view=View().add_item(Button(label="Verify My IP", url=verify_url)))
                except discord.Forbidden:
                    logging.warning(f"Cannot send IP verification warning DM to user {user_id}. DMs are disabled.")
                
                db.update_user_ip_status(user_id, ip_warning_sent_at=now_utc, ip_warning_count=new_warning_count)
                continue # Move to next user
            else:
                logging.info(f"User {user_id} (unverified IP) has active VPS. Warning {ip_warning_count}/{MAX_WARNINGS} already sent at {ip_warning_sent_at}. Waiting for next interval.")
                continue # Not enough time passed for next warning
        
        if vps_suspension_date:
            logging.info(f"User {user_id} (unverified IP) has suspended VPS since {vps_suspension_date}. Waiting for deletion or verification.")
        else:
            logging.info(f"User {user_id} (unverified IP) is in an unexpected state. ip_warning_count: {ip_warning_count}, vps_suspension_date: {vps_suspension_date}. This should ideally not happen if logic is correct.")



@tasks.loop(hours=12)
async def check_dedicated_vps_attributions():
    await bot.wait_until_ready()
    logging.info("Running dedicated VPS attribution check...")
    now = datetime.now()

    # Check for expiring attributions
    expiring_vps = db.get_expiring_dedicated_vps_attributions(days_ahead=2)
    for vps in expiring_vps:
        user_id = vps['attributed_to_user_id']
        container_name = vps['container_name']
        attribution_end_date = datetime.strptime(
            vps['attribution_end_date'],
            '%Y-%m-%d %H:%M:%S.%f') if isinstance(
            vps['attribution_end_date'],
            str) else vps['attribution_end_date']

        try:
            user = await bot.fetch_user(user_id)
            if user:
                embed = discord.Embed(
                    title="Dedicated Server Attribution Expiring Soon",
                    description=f"Your attribution for dedicated server `{container_name}` will expire on {
                        attribution_end_date.strftime('%Y-%m-%d %H:%M:%S')}. Please contact an admin if you wish to renew.",
                    color=discord.Color.orange())
                await user.send(embed=embed)
                logging.info(
                    f"Sent expiring attribution notice to user {user_id} for {container_name}.")
        except discord.NotFound:
            logging.warning(
                f"User {user_id} not found for expiring dedicated VPS {container_name}.")
        except discord.Forbidden:
            logging.warning(
                f"Cannot send expiring attribution DM to user {user_id} for {container_name}. DMs are disabled.")
        except Exception as e:
            logging.error(
                f"Error processing expiring dedicated VPS {container_name} for user {user_id}: {e}")

    # Check for expired attributions
    expired_vps = db.get_expired_dedicated_vps_attributions()
    for vps in expired_vps:
        user_id = vps['attributed_to_user_id']
        container_name = vps['container_name']

        db.update_dedicated_vps_attribution(container_name, None, None)
        logging.info(
            f"Dedicated server {container_name} attribution expired for user {user_id}. Server un-attributed.")

        try:
            user = await bot.fetch_user(user_id)
            if user:
                embed = discord.Embed(
                    title="Dedicated Server Attribution Expired",
                    description=f"Your attribution for dedicated server `{container_name}` has expired. The server is now unassigned.",
                    color=discord.Color.red())
                await user.send(embed=embed)
                logging.info(
                    f"Sent expired attribution notice to user {user_id} for {container_name}.")
        except discord.NotFound:
            logging.warning(
                f"User {user_id} not found for expired dedicated VPS {container_name}.")
        except discord.Forbidden:
            logging.warning(
                f"Cannot send expired attribution DM to user {user_id} for {container_name}. DMs are disabled.")
        except Exception as e:
            logging.error(
                f"Error processing expired dedicated VPS {container_name} for user {user_id}: {e}")
# ============================================================================
# BOT CHECKS & ERROR HANDLING
# ============================================================================


@bot.before_invoke
async def check_ip_verification(ctx):
    """Global check to ensure the user has verified their IP before running any command."""
    logging.info(
        f"[IP Check] Running for user: {
            ctx.author.id} | Command: {
            ctx.command.name if ctx.command else 'None'}")

    # The following line is commented out for testing purposes, so the owner can test the check.
    # In production, you may want to uncomment it to ensure the bot owner always has access.
    # if await bot.is_owner(ctx.author):
    #     logging.info(f"[IP Check] User {ctx.author.id} is owner. Bypassing.")
    #     return

    EXEMPT_ROLES = [1358004192416890903, 1436388721086693567]
    # Allow specific commands to bypass the check
    if ctx.command and ctx.command.name in [
            'verify_ip']:  # Add any other exempt commands here
        logging.info(
            f"[IP Check] Command '{
                ctx.command.name}' is exempt. Bypassing.")
        return

    # Bypass for users with exempted roles
    if ctx.guild and ctx.author.roles and any(
            role.id in EXEMPT_ROLES for role in ctx.author.roles):
        logging.info(
            f"[IP Check] User {
                ctx.author.id} has an exempted role. Bypassing IP verification.")
        return

    user_ip_status = db.get_user_ip_status(ctx.author.id)
    is_verified = user_ip_status['is_ip_verified'] if user_ip_status else False
    logging.info(
        f"[IP Check] User {
            ctx.author.id} verification status from DB: {is_verified}")

    if not is_verified:
        logging.info(
            f"[IP Check] User {
                ctx.author.id} is NOT verified. Initiating verification process.")
        token = secrets.token_urlsafe(32)
        expiration = datetime.now(pytz.utc) + timedelta(hours=1)
        db.set_ip_verification_token(ctx.author.id, token, expiration)

        PUBLIC_VERIFY_HOST = os.getenv(
            "PUBLIC_FLASK_HOST",
            "earn-jupyterhive.duckdns.org")
        VERIFY_PORT = 6029
        verify_url = f"https://{PUBLIC_VERIFY_HOST}:{VERIFY_PORT}/verify/{
            ctx.author.id}/{token}"

        embed = discord.Embed(
            title="Verification Required",
            description="To access bot commands, you must first verify your identity. This is a one-time security measure to prevent abuse.",
            color=discord.Color.orange())
        embed.add_field(
            name="Action Required",
            value=f"Click the button below to complete the verification. This link is valid for 1 hour.")

        view = View()
        view.add_item(Button(label="Verify My IP", url=verify_url))

        try:
            await ctx.author.send(embed=embed, view=view)
            if ctx.guild:
                await ctx.send("Please check your DMs to complete the required verification.", ephemeral=True)
        except discord.Forbidden:
            await ctx.send(f"{ctx.author.mention}, I couldn't send you a DM. Please enable DMs from server members to complete the verification.", ephemeral=True)

        raise commands.CheckFailure("User has not verified their IP address.")
    else:
        logging.info(
            f"[IP Check] User {
                ctx.author.id} is verified. Allowing command.")


@bot.check
async def is_in_correct_guild(ctx):
    if ctx.guild is None:
        raise WrongGuildError("Commands cannot be used in Direct Messages.")
    if ctx.guild.id != 1337813607530102814:
        raise WrongGuildError(
            "This bot can only be used in the official server.")
    return True


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.CheckFailure):
        logging.warning(
            f"CheckFailure for {
                ctx.author.name} on command '{
                ctx.command.name if ctx.command else 'unknown'}': {error}")
        # Silently ignore, as the check itself should have sent a message.
        return
    elif isinstance(error, WrongGuildError):
        await ctx.send(str(error))
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"You are missing a required argument: `{error.param.name}`. Please use `!help {ctx.command.name}` for more information.")
    elif isinstance(error, commands.CommandError):
        await ctx.send(f"An error occurred while executing the command: {error}")
    else:
        logging.error(f"An error occurred: {error}")

# ============================================================================
# BOT EVENTS
# ============================================================================


@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')

    # Load commands
    commands_dir = os.path.join(os.path.dirname(__file__), 'commands')
    for filename in os.listdir(commands_dir):
        if filename.endswith('.py') and filename not in ['tos.py', 'paid_plans.py']:
            try:
                await bot.load_extension(f'bot.commands.{filename[:-3]}')
                print(f'Loaded command: {filename[:-3]}')
            except Exception as e:
                print(f'Failed to load command: {filename[:-3]}')
                print(f'[ERROR] {e}')

    # Load utils cogs
    utils_dir = os.path.join(os.path.dirname(__file__), 'utils')
    for filename in os.listdir(utils_dir):
        if filename.endswith('.py') and not filename.startswith('__'):
            try:
                await bot.load_extension(f'bot.utils.{filename[:-3]}')
                print(f'Loaded util cog: {filename}')
            except commands.NoEntryPointError:
                pass  # Not a cog
            except Exception as e:
                print(f'Failed to load util cog {filename}: {e}')

    # Sync commands
    try:
        guild_id = 1337813607530102814
        guild = discord.Object(id=guild_id)
        await bot.tree.sync(guild=guild)
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(f"Error syncing commands: {e}")

    # Start payment and reward checks
    try:
        logging.info("Starting payment and reward checks...")
        if not check_invitation_rewards.is_running():
            check_invitation_rewards.start()
        if not check_dedicated_vps_attributions.is_running():
            check_dedicated_vps_attributions.start()
        logging.info("✅ Payment and reward checks started.")
    except Exception as e:
        logging.error(f"❌ Error starting payment and reward checks: {e}")
        import traceback
        logging.error(traceback.format_exc())

    # Update unassigned VPS nodes
    try:
        logging.info("Updating unassigned VPS nodes...")
        db.update_unassigned_vps_nodes('node1')
        logging.info("✅ Unassigned VPS nodes updated successfully")
    except Exception as e:
        logging.error(f"❌ Error updating unassigned VPS nodes: {e}")
        import traceback
        logging.error(traceback.format_exc())

    # Start Flask app for earning
    flask_thread = Thread(target=run_flask_app)
    flask_thread.daemon = True
    flask_thread.start()
    logging.info("Earn Flask server started in a separate thread.")

    # Start Flask app for IP verification
    ip_verify_flask_thread = Thread(target=run_ip_verify_flask_app)
    ip_verify_flask_thread.daemon = True
    ip_verify_flask_thread.start()
    logging.info("IP Verify Flask server started in a separate thread.")

    # Start auto-renewal task
    try:
        logging.info("Starting VPS renewal tasks...")
        await start_vps_renewal_tasks(bot)
        logging.info("✅ VPS renewal tasks started.")
    except Exception as e:
        logging.error(f"❌ Error starting VPS renewal tasks: {e}")

    # Start check for unverified VPS users
    try:
        logging.info("Starting unverified VPS suspension check...")
        check_unverified_vps_for_suspension.start()
        logging.info("✅ Unverified VPS suspension check started.")
    except Exception as e:
        logging.error(f"❌ Error starting unverified VPS suspension check: {e}")
        import traceback
        logging.error(traceback.format_exc())

    # ========================================================================
    # SURVEILLANCE - VERSION AMÉLIORÉE AVEC DIAGNOSTIC DÉTAILLÉ
    # ========================================================================

    print("\n" + "=" * 70)
    print("INITIALISATION DE LA SURVEILLANCE")
    print("=" * 70)
    logging.info("\n" + "=" * 70)
    logging.info("INITIALISATION DE LA SURVEILLANCE")
    logging.info("=" * 70)

    # Vérifier les prérequis
    groq_key = os.getenv("GROQ_API_KEY")
    if not groq_key:
        print("❌ GROQ_API_KEY manquante - Surveillance LXC DÉSACTIVÉE")
        print("   Action requise: Ajoutez GROQ_API_KEY dans votre fichier .env")
        logging.error("❌ GROQ_API_KEY manquante - Surveillance LXC DÉSACTIVÉE")
        logging.error(
            "   Action requise: Ajoutez GROQ_API_KEY dans votre fichier .env")
    else:
        print(f"✅ GROQ_API_KEY détectée ({groq_key[:10]}...)")
        logging.info(f"✅ GROQ_API_KEY détectée ({groq_key[:10]}...)")

    vt_key = os.getenv("VIRUSTOTAL_API_KEY")
    if vt_key:
        print(f"✅ VIRUSTOTAL_API_KEY détectée ({vt_key[:10]}...)")
        logging.info(f"✅ VIRUSTOTAL_API_KEY détectée ({vt_key[:10]}...)")
    else:
        print("⚠️  VIRUSTOTAL_API_KEY manquante - Scan de fichiers limité")
        logging.warning(
            "⚠️  VIRUSTOTAL_API_KEY manquante - Scan de fichiers limité")

    sys.stdout.flush()

    # Variables pour capturer les erreurs
    lxc_error = None
    kvm_error = None
    dedi_error = None

    # LXC Surveillance
    try:
        print("\n" + "-" * 70)
        print("📦 INITIALISATION LXC SURVEILLANCE")
        print("-" * 70)
        logging.info("\n" + "-" * 70)
        logging.info("📦 INITIALISATION LXC SURVEILLANCE")
        logging.info("-" * 70)

        print("Création de l'instance SurveillanceLXC...")
        bot.surveillance_lxc_instance = SurveillanceLXC(bot)
        print("✅ SurveillanceLXC instancié avec succès")
        logging.info("✅ SurveillanceLXC instancié avec succès")

        # Démarrer toutes les tâches une par une
        print("\n🚀 Démarrage des tâches LXC:")
        logging.info("\n🚀 Démarrage des tâches LXC:")
        sys.stdout.flush()

        logging.info("  [1/2] collect_metrics_task...")
        print("  [1/2] collect_metrics_task...")
        if not bot.surveillance_lxc_instance.collect_metrics_task.is_running():
            bot.surveillance_lxc_instance.collect_metrics_task.start()
            print("  ✅ collect_metrics_task démarré (intervalle: 1 min)")
            logging.info("  ✅ collect_metrics_task démarré (intervalle: 1 min)")
        else:
            print("  ⚠️  collect_metrics_task était déjà en cours d'exécution")
            logging.warning("  ⚠️  collect_metrics_task était déjà en cours d'exécution")
        
        logging.info("  [2/2] analyze_lxc_threats_task...")
        print("  [2/2] analyze_lxc_threats_task...")
        if not bot.surveillance_lxc_instance.analyze_lxc_threats_task.is_running():
            bot.surveillance_lxc_instance.analyze_lxc_threats_task.start()
            print("  ✅ analyze_lxc_threats_task démarré (intervalle: 30 min)")
            logging.info("  ✅ analyze_lxc_threats_task démarré (intervalle: 30 min)")
        else:
            print("  ⚠️  analyze_lxc_threats_task était déjà en cours d'exécution")
            logging.warning("  ⚠️  analyze_lxc_threats_task était déjà en cours d'exécution")

        # Vérifier que les tâches sont bien démarrées
        print("\n" + "=" * 70)
        print("✅ LXC SURVEILLANCE: TÂCHES ACTIVES")
        print("=" * 70)
        print("📋 Vérification des tâches:")
        collect_metrics_running = bot.surveillance_lxc_instance.collect_metrics_task.is_running()
        analyze_threats_running = bot.surveillance_lxc_instance.analyze_lxc_threats_task.is_running()

        print(
            f"   • collect_metrics_task: {
                '✅ RUNNING' if collect_metrics_running else '❌ NOT RUNNING'}")
        print(
            f"   • analyze_lxc_threats_task: {
                '✅ RUNNING' if analyze_threats_running else '❌ NOT RUNNING'}")
        print("=" * 70)
        sys.stdout.flush()
        logging.info("\n" + "=" * 70)
        logging.info("✅ LXC SURVEILLANCE: TÂCHES ACTIVES")
        logging.info("=" * 70)
        logging.info("📋 Tâches actives:")
        logging.info("   • collect_metrics_task (intervalle: 1 min)")
        logging.info("   • analyze_lxc_threats_task (intervalle: 30 min)")
        logging.info("=" * 70)

    except ValueError as e:
        lxc_error = {
            'type': 'ValueError',
            'message': str(e),
            'traceback': None,
            'cause': 'GROQ_API_KEY manquante ou invalide'
        }
        logging.error("\n" + "!" * 70)
        logging.error("❌ ERREUR CRITIQUE LXC: ValueError")
        logging.error("!" * 70)
        logging.error(f"Message: {e}")
        logging.error("Cause probable: GROQ_API_KEY manquante ou invalide")
        logging.error("Action requise:")
        logging.error("  1. Vérifiez votre fichier .env")
        logging.error("  2. Assurez-vous que GROQ_API_KEY=votre_clé")
        logging.error("  3. Redémarrez le bot")
        logging.error("!" * 70)

    except Exception as e:
        import traceback
        lxc_error = {
            'type': type(e).__name__,
            'message': str(e),
            'traceback': traceback.format_exc(),
            'cause': None
        }
        logging.error("\n" + "!" * 70)
        logging.error("❌ ERREUR INATTENDUE LXC")
        logging.error("!" * 70)
        logging.error(f"Type d'erreur: {type(e).__name__}")
        logging.error(f"Message: {e}")
        logging.error("\n📋 Stack trace complet:")
        for line in traceback.format_exc().split('\n'):
            logging.error(f"   {line}")
        logging.error("!" * 70)

    # KVM Surveillance
    try:
        print("\n" + "-" * 70)
        print("🖥️  INITIALISATION KVM SURVEILLANCE")
        print("-" * 70)
        logging.info("\n" + "-" * 70)
        logging.info("🖥️  INITIALISATION KVM SURVEILLANCE")
        logging.info("-" * 70)

        print("Création de l'instance SurveillanceKVM...")
        bot.surveillance_kvm_instance = SurveillanceKVM(bot)
        print("✅ SurveillanceKVM instancié")
        logging.info("✅ SurveillanceKVM instancié")

        print("\n🚀 Démarrage des tâches KVM:")
        logging.info("\n🚀 Démarrage des tâches KVM:")
        sys.stdout.flush()

        logging.info("  [1/1] check_kvm_for_threats...")
        print("  [1/1] check_kvm_for_threats...")
        if not bot.surveillance_kvm_instance.check_kvm_for_threats.is_running():
            bot.surveillance_kvm_instance.check_kvm_for_threats.start()
            print("  ✅ check_kvm_for_threats démarré (intervalle: 60 sec)")
            logging.info("  ✅ check_kvm_for_threats démarré (intervalle: 60 sec)")
        else:
            print("  ⚠️  check_kvm_for_threats était déjà en cours d'exécution")
            logging.warning("  ⚠️  check_kvm_for_threats était déjà en cours d'exécution")

        # Vérifier que les tâches sont bien démarrées
        print("\n" + "=" * 70)
        print("✅ KVM SURVEILLANCE: TÂCHES ACTIVES")
        print("=" * 70)
        print("📋 Vérification des tâches:")
        check_kvm_running = bot.surveillance_kvm_instance.check_kvm_for_threats.is_running()

        print(
            f"   • check_kvm_for_threats: {
                '✅ RUNNING' if check_kvm_running else '❌ NOT RUNNING'}")
        print("=" * 70)
        sys.stdout.flush()
        logging.info("\n" + "=" * 70)
        logging.info("✅ KVM SURVEILLANCE: TÂCHES ACTIVES")
        logging.info("=" * 70)
        logging.info("📋 Tâches actives:")
        logging.info("   • check_kvm_for_threats (intervalle: 60 sec)")
        logging.info("=" * 70)

    except ValueError as e:
        kvm_error = {
            'type': 'ValueError',
            'message': str(e),
            'traceback': None,
            'cause': 'GROQ_API_KEY manquante ou invalide'
        }
        logging.error(f"❌ KVM surveillance error (ValueError): {e}")
    except Exception as e:
        import traceback
        kvm_error = {
            'type': type(e).__name__,
            'message': str(e),
            'traceback': traceback.format_exc(),
            'cause': None
        }
        logging.error(f"❌ KVM surveillance error: {e}")
        logging.error(traceback.format_exc())

    # Dedicated Server Surveillance
    try:
        print("\n" + "-" * 70)
        print("🖧  INITIALISATION DEDICATED SERVER SURVEILLANCE")
        print("-" * 70)
        logging.info("\n" + "-" * 70)
        logging.info("🖧  INITIALISATION DEDICATED SERVER SURVEILLANCE")
        logging.info("-" * 70)

        print("Création de l'instance SurveillanceDedi...")
        bot.surveillance_dedi_instance = SurveillanceDedi(bot)
        print("✅ SurveillanceDedi instancié")
        logging.info("✅ SurveillanceDedi instancié")

        print("\n🚀 Démarrage des tâches Dedi:")
        logging.info("\n🚀 Démarrage des tâches Dedi:")
        sys.stdout.flush()

        logging.info("  [1/2] collect_metrics_task...")
        print("  [1/2] collect_metrics_task...")
        if not bot.surveillance_dedi_instance.collect_metrics_task.is_running():
            bot.surveillance_dedi_instance.collect_metrics_task.start()
            print("  ✅ collect_metrics_task démarré (intervalle: 1 min)")
            logging.info("  ✅ collect_metrics_task démarré (intervalle: 1 min)")
        else:
            print("  ⚠️  collect_metrics_task était déjà en cours d'exécution")
            logging.warning("  ⚠️  collect_metrics_task était déjà en cours d'exécution")
        
        logging.info("  [2/2] analyze_dedi_threats_task...")
        print("  [2/2] analyze_dedi_threats_task...")
        if not bot.surveillance_dedi_instance.analyze_dedi_threats_task.is_running():
            bot.surveillance_dedi_instance.analyze_dedi_threats_task.start()
            print("  ✅ analyze_dedi_threats_task démarré (intervalle: 30 min)")
            logging.info("  ✅ analyze_dedi_threats_task démarré (intervalle: 30 min)")
        else:
            print("  ⚠️  analyze_dedi_threats_task était déjà en cours d'exécution")
            logging.warning("  ⚠️  analyze_dedi_threats_task était déjà en cours d'exécution")

        # Vérifier que les tâches sont bien démarrées
        print("\n" + "=" * 70)
        print("✅ DEDICATED SERVER SURVEILLANCE: TÂCHES ACTIVES")
        print("=" * 70)
        print("📋 Vérification des tâches:")
        collect_metrics_running = bot.surveillance_dedi_instance.collect_metrics_task.is_running()
        analyze_threats_running = bot.surveillance_dedi_instance.analyze_dedi_threats_task.is_running()

        print(
            f"   • collect_metrics_task: {
                '✅ RUNNING' if collect_metrics_running else '❌ NOT RUNNING'}")
        print(
            f"   • analyze_dedi_threats_task: {
                '✅ RUNNING' if analyze_threats_running else '❌ NOT RUNNING'}")
        print("=" * 70)
        sys.stdout.flush()
        logging.info("\n" + "=" * 70)
        logging.info("✅ DEDICATED SERVER SURVEILLANCE: TÂCHES ACTIVES")
        logging.info("=" * 70)
        logging.info("📋 Tâches actives:")
        logging.info("   • collect_metrics_task (intervalle: 1 min)")
        logging.info("   • analyze_dedi_threats_task (intervalle: 30 min)")
        logging.info("=" * 70)

    except ValueError as e:
        dedi_error = {
            'type': 'ValueError',
            'message': str(e),
            'traceback': None,
            'cause': 'GROQ_API_KEY manquante ou invalide'
        }
        logging.error(f"❌ Dedi surveillance error (ValueError): {e}")
    except Exception as e:
        import traceback
        dedi_error = {
            'type': type(e).__name__,
            'message': str(e),
            'traceback': traceback.format_exc(),
            'cause': None
        }
        logging.error(f"❌ Dedi surveillance error: {e}")
        logging.error(traceback.format_exc())

    # Command Logger
    try:
        print("\n" + "-" * 70)
        print("📜 INITIALISATION COMMAND LOGGER")
        print("-" * 70)
        logging.info("\n" + "-" * 70)
        logging.info("📜 INITIALISATION COMMAND LOGGER")
        logging.info("-" * 70)
        bot.command_logger_instance = CommandLogger(bot)
        print("✅ CommandLogger instancié et démarré")
        logging.info("✅ CommandLogger instancié et démarré")
        print("-" * 70)
        logging.info("-" * 70)
    except Exception as e:
        logging.error(f"❌ Command logger error: {e}")
        logging.error(traceback.format_exc())

    # ========================================================================
    # RÉSUMÉ FINAL - MESSAGES SÉPARÉS POUR CHAQUE SYSTÈME
    # ========================================================================

    print("\n" + "=" * 70)
    print("📊 RÉSUMÉ FINAL DE LA SURVEILLANCE")
    print("=" * 70)
    logging.info("\n" + "=" * 70)
    logging.info("📊 RÉSUMÉ FINAL DE LA SURVEILLANCE")
    logging.info("=" * 70)

    # Message 1: LXC Surveillance
    print("\n" + "─" * 70)
    print("📦 SYSTÈME DE SURVEILLANCE LXC")
    print("─" * 70)
    logging.info("\n" + "─" * 70)
    logging.info("📦 SYSTÈME DE SURVEILLANCE LXC")
    logging.info("─" * 70)
    if bot.surveillance_lxc_instance and not lxc_error:
        print("✅ STATUT: ACTIF - Aucune erreur détectée")
        print("📋 Tâches actives (1):")
        print("   • monitor (surveillance globale)")
        logging.info("✅ STATUT: ACTIF - Aucune erreur détectée")
        logging.info("📋 Tâches actives (1):")
        logging.info("   • monitor (surveillance globale)")
    elif lxc_error:
        print("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        print(f"🔴 Type d'erreur: {lxc_error['type']}")
        print(f"🔴 Message: {lxc_error['message']}")
        logging.error("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        logging.error(f"🔴 Type d'erreur: {lxc_error['type']}")
        logging.error(f"🔴 Message: {lxc_error['message']}")
        if lxc_error.get('cause'):
            print(f"🔴 Cause probable: {lxc_error['cause']}")
            logging.error(f"🔴 Cause probable: {lxc_error['cause']}")
        if lxc_error.get('traceback'):
            print("🔴 Stack trace:")
            logging.error("🔴 Stack trace:")
            for line in lxc_error['traceback'].split('\n'):
                if line.strip():
                    print(f"   {line}")
                    logging.error(f"   {line}")
    else:
        print("⚠️  STATUT: NON INITIALISÉ")
        logging.warning("⚠️  STATUT: NON INITIALISÉ")
    print("─" * 70)
    logging.info("─" * 70)

    # Message 2: KVM Surveillance
    print("\n" + "─" * 70)
    print("🖥️  SYSTÈME DE SURVEILLANCE KVM")
    print("─" * 70)
    logging.info("\n" + "─" * 70)
    logging.info("🖥️  SYSTÈME DE SURVEILLANCE KVM")
    logging.info("─" * 70)
    if bot.surveillance_kvm_instance and not kvm_error:
        print("✅ STATUT: ACTIF - Aucune erreur détectée")
        print("📋 Tâches actives (1):")
        print("   • check_kvm_for_threats (détection de menaces)")
        logging.info("✅ STATUT: ACTIF - Aucune erreur détectée")
        logging.info("📋 Tâches actives (1):")
        logging.info("   • check_kvm_for_threats (détection de menaces)")
    elif kvm_error:
        print("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        print(f"🔴 Type d'erreur: {kvm_error['type']}")
        print(f"🔴 Message: {kvm_error['message']}")
        logging.error("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        logging.error(f"🔴 Type d'erreur: {kvm_error['type']}")
        logging.error(f"🔴 Message: {kvm_error['message']}")
        if kvm_error.get('cause'):
            print(f"🔴 Cause probable: {kvm_error['cause']}")
            logging.error(f"🔴 Cause probable: {kvm_error['cause']}")
        if kvm_error.get('traceback'):
            print("🔴 Stack trace:")
            logging.error("🔴 Stack trace:")
            for line in kvm_error['traceback'].split('\n'):
                if line.strip():
                    print(f"   {line}")
                    logging.error(f"   {line}")
    else:
        print("⚠️  STATUT: NON INITIALISÉ")
        logging.warning("⚠️  STATUT: NON INITIALISÉ")
    print("─" * 70)
    logging.info("─" * 70)

    # Message 3: Dedicated Server Surveillance
    print("\n" + "─" * 70)
    print("🖧  SYSTÈME DE SURVEILLANCE DEDICATED SERVER")
    print("─" * 70)
    logging.info("\n" + "─" * 70)
    logging.info("🖧  SYSTÈME DE SURVEILLANCE DEDICATED SERVER")
    logging.info("─" * 70)
    if bot.surveillance_dedi_instance and not dedi_error:
        print("✅ STATUT: ACTIF - Aucune erreur détectée")
        print("📋 Tâches actives (1):")
        print("   • check_dedi_for_threats (détection de menaces)")
        logging.info("✅ STATUT: ACTIF - Aucune erreur détectée")
        logging.info("📋 Tâches actives (1):")
        logging.info("   • check_dedi_for_threats (détection de menaces)")
    elif dedi_error:
        print("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        print(f"🔴 Type d'erreur: {dedi_error['type']}")
        print(f"🔴 Message: {dedi_error['message']}")
        logging.error("❌ STATUT: ÉCHEC - Erreur lors de l'initialisation")
        logging.error(f"🔴 Type d'erreur: {dedi_error['type']}")
        logging.error(f"🔴 Message: {dedi_error['message']}")
        if dedi_error.get('cause'):
            print(f"🔴 Cause probable: {dedi_error['cause']}")
            logging.error(f"🔴 Cause probable: {dedi_error['cause']}")
        if dedi_error.get('traceback'):
            print("🔴 Stack trace:")
            logging.error("🔴 Stack trace:")
            for line in dedi_error['traceback'].split('\n'):
                if line.strip():
                    print(f"   {line}")
                    logging.error(f"   {line}")
    else:
        print("⚠️  STATUT: NON INITIALISÉ")
        logging.warning("⚠️  STATUT: NON INITIALISÉ")
    print("─" * 70)
    logging.info("─" * 70)

    # Résumé global
    active_count = sum([
        1 if bot.surveillance_lxc_instance and not lxc_error else 0,
        1 if bot.surveillance_kvm_instance and not kvm_error else 0,
        1 if bot.surveillance_dedi_instance and not dedi_error else 0
    ])
    total_tasks = (1 if bot.surveillance_lxc_instance and not lxc_error else 0) + \
                  (1 if bot.surveillance_kvm_instance and not kvm_error else 0) + \
                  (1 if bot.surveillance_dedi_instance and not dedi_error else 0)

    print("\n" + "=" * 70)
    print(
        f"📈 RÉSULTAT GLOBAL: {active_count}/3 systèmes actifs ({total_tasks} tâches au total)")
    logging.info("\n" + "=" * 70)
    logging.info(
        f"📈 RÉSULTAT GLOBAL: {active_count}/3 systèmes actifs ({total_tasks} tâches au total)")

    if active_count == 3:
        print("🎉 TOUS LES SYSTÈMES DE SURVEILLANCE SONT OPÉRATIONNELS")
        logging.info("🎉 TOUS LES SYSTÈMES DE SURVEILLANCE SONT OPÉRATIONNELS")
    elif active_count > 0:
        print("⚠️  SURVEILLANCE PARTIELLE - Certains systèmes ont échoué (voir détails ci-dessus)")
        logging.warning(
            "⚠️  SURVEILLANCE PARTIELLE - Certains systèmes ont échoué (voir détails ci-dessus)")
    else:
        print("❌ AUCUN SYSTÈME DE SURVEILLANCE ACTIF - Vérifiez votre configuration")
        logging.error(
            "❌ AUCUN SYSTÈME DE SURVEILLANCE ACTIF - Vérifiez votre configuration")

    print("=" * 70 + "\n")
    logging.info("=" * 70 + "\n")

    # Send TOS embed (moved to END)
    await send_tos_embed(bot)

# ============================================================================
# TOS EMBED FUNCTION
# ============================================================================


async def send_tos_embed(bot):
    tos_path = os.path.join(
        os.path.dirname(__file__),
        'condition-utilisation',
        'tos.yaml')

    try:
        with open(tos_path, 'r', encoding='utf-8') as f:
            tos_data = yaml.safe_load(f)
        logging.info(f"Successfully loaded tos.yaml. Keys: {tos_data.keys()}")
    except FileNotFoundError:
        logging.error("TOS file not found during automatic sending.")
        return
    except yaml.YAMLError as e:
        logging.error(f"Error reading TOS file for automatic sending: {e}")
        return

    tos_content = tos_data.get('tos', {})

    embed = discord.Embed(
        title=tos_content.get('title', 'Terms of Service'),
        color=discord.Color.orange()
    )

    for section in tos_content.get('sections', []):
        embed.add_field(
            name=section.get('title'),
            value=section.get('content'),
            inline=False)

    legal_notice = tos_data.get('legal_notice', {})

    if legal_notice:
        legal_text = f"Address: {legal_notice.get('address', 'N/A')}\n"
        legal_text += f"Postal Code: {
            legal_notice.get(
                'postal_code', 'N/A')}\n"
        legal_text += f"City: {legal_notice.get('city', 'N/A')}\n"
        legal_text += f"Country: {legal_notice.get('country', 'N/A')}\n"
        legal_text += f"Contact Email: {
            legal_notice.get(
                'contact_email', 'N/A')}"
        embed.add_field(name="Legal Notice", value=legal_text, inline=False)

    user_id = 1047760053509312642
    try:
        user = await bot.fetch_user(user_id)
        if user:
            embed.set_footer(
                text=f"Provided by {
                    user.name}",
                icon_url=user.avatar.url if user.avatar else None)
    except Exception as e:
        logging.warning(f"Could not fetch user {user_id} for footer: {e}")

    target_channel_id = 1430625796073980070
    target_channel = bot.get_channel(target_channel_id)

    if target_channel:
        stored_message_id, stored_channel_id = db.get_tos_message_id()

        if stored_message_id and stored_channel_id == target_channel_id:
            try:
                message = await target_channel.fetch_message(stored_message_id)
                await message.edit(embed=embed)
                logging.info(
                    f"TOS embed updated in channel {
                        target_channel.id}")
            except discord.NotFound:
                logging.warning(
                    f"Stored TOS message {stored_message_id} not found. Sending new message.")
                new_message = await target_channel.send(embed=embed)
                db.save_tos_message_id(new_message.id, target_channel_id)
                logging.info(
                    f"New TOS embed sent in channel {
                        target_channel.id}")
            except discord.Forbidden:
                logging.error(
                    f"Cannot edit message in channel {
                        target_channel.id}. Permissions issue.")
        else:
            new_message = await target_channel.send(embed=embed)
            db.save_tos_message_id(new_message.id, target_channel_id)
            logging.info(f"New TOS embed sent in channel {target_channel.id}")
    else:
        logging.error(
            f"Channel {target_channel_id} not found during automatic sending.")

# ============================================================================
# RUN BOT
# ============================================================================

TOKEN = os.getenv("DISCORD_TOKEN")
if TOKEN is None:
    raise ValueError("DISCORD_TOKEN environment variable not set.")

bot.run(TOKEN)
