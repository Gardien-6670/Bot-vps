import subprocess
import time
import logging
import uuid
import re
import yaml
import secrets
import string
import random
import sys
import os
from utils.database import db
import asyncio
import json
import socket
from typing import Optional

logging.basicConfig(level=logging.INFO)

class LazySemaphore:
    def __init__(self, value):
        self._value = value
        self._semaphore = None
        self._loop = None

    async def _get_semaphore(self):
        current_loop = asyncio.get_running_loop()
        if self._semaphore is None or self._loop is not current_loop:
            self._semaphore = asyncio.Semaphore(self._value)
            self._loop = current_loop
        return self._semaphore

    async def __aenter__(self):
        semaphore = await self._get_semaphore()
        return await semaphore.__aenter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._semaphore:
            return await self._semaphore.__aexit__(exc_type, exc_val, exc_tb)

LXC_CMD_SEMAPHORE = LazySemaphore(4)

def generate_password(length=30):
    """Generates a secure random password"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def is_port_in_use(port):
    """Checks if a port is already in use on the system"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('0.0.0.0', port))
            return False
    except OSError:
        return True

async def get_available_ssh_port():
    """Finds an available SSH port between 9000 and 10000 by checking the DB and the system"""
    used_ports = db.get_all_ssh_ports()
    
    port_range = list(range(9000, 10001))
    random.shuffle(port_range)

    for port in port_range:
        # First, check in the vps table (main SSH ports)
        if port in used_ports:
            continue
        
        # Second, check the custom port forwards table
        if db.get_port_forward_by_external_port(port, 'tcp'):
            continue

        # Then, check if the port is actually free on the system
        if not is_port_in_use(port):
            logging.info(f"Found available port: {port}")
            return port
            
    logging.error("No available ports found in range 9000-10000")
    return None

async def setup_storage():
    """Configure le pool de stockage btrfs pour les conteneurs si nécessaire"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "storage", "list", "--format", "csv",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        if "default" in stdout.decode():
            logging.info("Pool de stockage déjà configuré")
            return True
            
        logging.info("Création du pool de stockage btrfs...")
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "storage", "create", "default", "btrfs",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                # Fallback vers dir si btrfs échoue
                logging.warning(f"Échec avec btrfs: {stderr.decode()}")
                logging.info("Tentative avec dir...")
                async with LXC_CMD_SEMAPHORE:
                    proc = await asyncio.create_subprocess_exec(
                        "lxc", "storage", "create", "default", "dir",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    _, stderr = await proc.communicate()
                    if proc.returncode != 0:
                        raise subprocess.CalledProcessError(proc.returncode or 1, "lxc storage create", stderr=stderr)
                logging.info("Pool de stockage créé (type: dir)")
            else:
                logging.info("Pool de stockage créé (type: btrfs)")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Échec de la configuration du stockage: {e.stderr.decode()}")
        return False

async def wait_for_network(container_name, timeout=120):
    """Waits for the container to have a network connection"""
    start = time.time()
    attempt = 0
    last_ip = None
    
    while time.time() - start < timeout:
        attempt += 1
        try:
            # First, check if container has an IP address
            container_ip = await get_container_ip(container_name)
            if not container_ip:
                logging.debug(f"Attempt {attempt}: No IP address yet for {container_name}, waiting...")
                await asyncio.sleep(3)
                continue
            
            # If we got an IP, remember it
            if container_ip != last_ip:
                logging.info(f"Container {container_name} has IP: {container_ip}")
                last_ip = container_ip
            
            # Check if we have a default route (more reliable than ping)
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "ip", "route", "show", "default",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
                if proc.returncode == 0 and stdout.decode().strip():
                    logging.info(f"Default route found for {container_name}")
                    # Try a simple connectivity test (ping gateway or DNS)
                    # But don't fail if ping fails - having IP and route is enough
                    try:
                        async with LXC_CMD_SEMAPHORE:
                            ping_proc = await asyncio.create_subprocess_exec(
                                "lxc", "exec", container_name, "--", "ping", "-c", "1", "-W", "2", "8.8.8.8",
                                stdout=asyncio.subprocess.DEVNULL,
                                stderr=asyncio.subprocess.DEVNULL
                            )
                            await asyncio.wait_for(ping_proc.wait(), timeout=5)
                            if ping_proc.returncode == 0:
                                logging.info(f"Network fully ready for {container_name} (IP: {container_ip}, ping successful)")
                                return True
                            else:
                                # IP and route exist, but ping failed - this is acceptable
                                logging.info(f"Network ready for {container_name} (IP: {container_ip}, route exists, ping may be blocked)")
                                return True
                    except:
                        # If ping fails but we have IP and route, consider network ready
                        logging.info(f"Network ready for {container_name} (IP: {container_ip}, route exists)")
                        return True
                else:
                    logging.debug(f"Attempt {attempt}: No default route yet for {container_name}")
        except asyncio.TimeoutError:
            logging.debug(f"Attempt {attempt}: Timeout checking network on {container_name}")
        except Exception as e:
            logging.debug(f"Attempt {attempt}: Error checking network for {container_name}: {e}")
        
        await asyncio.sleep(3)
    
    # If we have an IP but no route after timeout, still consider it partially ready
    if last_ip:
        logging.warning(f"Network partially ready for {container_name} (IP: {last_ip} but no route/default gateway after {timeout}s)")
        # Return True anyway - having an IP is better than nothing
        return True
    
    logging.warning(f"Network timeout for {container_name} after {timeout}s ({attempt} attempts)")
    return False

async def wait_for_ip_address(container_name, timeout=90):
    """Waits for the container to get an IP address using lxc query (no network scan)"""
    start = time.time()
    attempt = 0
    while time.time() - start < timeout:
        attempt += 1
        try:
            # Method 1: Using 'lxc query' (most efficient, no network scan)
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "query", f"/1.0/instances/{container_name}",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await proc.communicate()
            
            if proc.returncode == 0:
                try:
                    import json
                    data = json.loads(stdout.decode())
                    state = data.get('state', {})
                    network = state.get('network', {})
                    for iface_name, iface_data in network.items():
                        if iface_name != 'lo':  # Skip loopback
                            addresses = iface_data.get('addresses', [])
                            for addr in addresses:
                                ip = addr.get('address', '')
                                if ip and not ip.startswith('127.') and ':' not in ip:  # IPv4 only
                                    logging.info(f"Found IP {ip} for {container_name} using lxc query (attempt {attempt})")
                                    return ip
                except (json.JSONDecodeError, KeyError) as e:
                    logging.debug(f"Failed to parse lxc query response: {e}")
            
            # Fallback Method 2: Using 'lxc list' with JSON format
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "list", container_name, "--format", "json",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await proc.communicate()
            
            if proc.returncode == 0:
                try:
                    import json
                    data = json.loads(stdout.decode())
                    if data and len(data) > 0:
                        state = data[0].get('state', {})
                        network = state.get('network', {})
                        for iface_name, iface_data in network.items():
                            if iface_name != 'lo':
                                addresses = iface_data.get('addresses', [])
                                for addr in addresses:
                                    ip = addr.get('address', '')
                                    if ip and not ip.startswith('127.') and ':' not in ip:
                                        logging.info(f"Found IP {ip} for {container_name} using lxc list (attempt {attempt})")
                                        return ip
                except (json.JSONDecodeError, KeyError, IndexError) as e:
                    logging.debug(f"Failed to parse lxc list response: {e}")
            
            logging.warning(f"Attempt {attempt}: No IP address found for {container_name}. Waiting...")
            
        except Exception as e:
            logging.warning(f"Attempt {attempt}: Error getting IP for {container_name}: {e}")
        
        await asyncio.sleep(3)
    
    logging.error(f"No IP address found for {container_name} after {timeout}s")
    return None

async def get_container_ip(container_name):
    """Gets the container IP address"""
    try:
        # Method 1: Using 'ip -4 a show eth0'
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "ip", "-4", "a", "show", "eth0",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        
        if proc.returncode == 0:
            output = stdout.decode()
            match = re.search(r"inet\s+([0-9.]+)/", output)
            if match:
                ip = match.group(1)
                if ip and not ip.startswith("127."):
                    logging.info(f"Found IP {ip} for {container_name} using ip a")
                    return ip
        
        # Method 2: Using 'hostname -I'
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "hostname", "-I",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        
        if proc.returncode == 0:
            ips = stdout.decode().strip().split()
            for ip in ips:
                if ip and not ip.startswith("127.") and ":" not in ip:  # Exclude localhost and IPv6
                    logging.info(f"Found IP {ip} for {container_name} using hostname -I")
                    return ip

        # Method 3: lxc list
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", container_name, "--format", "csv", "-c", "4",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        if proc.returncode == 0:
            ip_output = stdout.decode().strip()
            match = re.search(r'([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)', ip_output)
            if match:
                ip = match.group(1)
                if ip and not ip.startswith("127."):
                    logging.info(f"Found IP {ip} for {container_name} using lxc list")
                    return ip

    except Exception as e:
        logging.warning(f"Error getting IP for {container_name}: {e}")
    
    logging.warning(f"Could not find IP for {container_name}")
    return None

async def check_ipv6_disabled(container_name):
    """Vérifie si IPv6 est déjà désactivé dans le conteneur"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "sysctl", "-n", "net.ipv6.conf.all.disable_ipv6",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        return stdout.decode().strip() == "1"
    except Exception:
        return False

async def _get_cpu_assignment(cpu_request):
    """Determines CPU core assignment based on request and current load"""
    CORE_POOL_SIZE = 5
    
    if cpu_request > 1:
        num_cores = min(cpu_request, CORE_POOL_SIZE)
        core_list = list(range(num_cores))
        return ",".join(map(str, core_list))

    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", "--format", "yaml",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(proc.returncode or 1, "lxc list", stderr=stderr)

        containers = yaml.safe_load(stdout)
        core_counts = {i: 0 for i in range(CORE_POOL_SIZE)}
        
        if containers:
            for container in containers:
                config = container.get('config', {})
                cpu_limit = config.get('limits.cpu')
                
                if cpu_limit and cpu_limit.isdigit():
                    core = int(cpu_limit)
                    if core in core_counts:
                        core_counts[core] += 1
        
            if cpu_request == 1:
                return "1"
    except (subprocess.CalledProcessError, FileNotFoundError, yaml.YAMLError) as e:
        logging.error(f"Failed to determine CPU core assignment: {e}. Defaulting to core 0.")
        return "0"

async def create_lxc_container(user_id, username, cpu, ram, disk, progress_callback=None):
    """
    Creates an LXC container with OpenSSH access
    Returns: (container_name, ssh_connection_string, ssh_port, ssh_password)
    """
    sanitized_username = re.sub(r'[^a-z0-9-]', '', username.lower().replace(" ", "-"))
    container_name = f"{sanitized_username}-{user_id}-{str(uuid.uuid4())[:8]}"
    
    if progress_callback:
        await progress_callback(5, "Initialisation de la création du conteneur...")
    
    if not await setup_storage():
        logging.error("Échec de la configuration du pool de stockage")
        if progress_callback:
            await progress_callback(0, "Échec: Configuration du stockage échouée")
        return None, None, None, None
    
    # Trouver un port SSH disponible (vérifie DB + système)
    ssh_port = await get_available_ssh_port()
    if not ssh_port:
        logging.error("No available SSH ports in range 9000-10000")
        if progress_callback:
            await progress_callback(0, "Failed: No available SSH ports")
        return None, None, None, None
    
    # Générer un mot de passe
    ssh_password = generate_password()
    
    try:
        logging.info(f"Creating container {container_name} for user {user_id}")
        logging.info(f"Resources: {cpu} CPU, {ram}GB RAM, {disk}GB disk")
        logging.info(f"SSH Port: {ssh_port}")
        
        if progress_callback:
            await progress_callback(10, "Configuring CPU assignment...")
        
        cpu_assignment = await _get_cpu_assignment(cpu)
        logging.info(f"Assigning container to CPU core(s): {cpu_assignment}")

        # Create container from Debian 13 image
        if progress_callback:
            await progress_callback(15, "Creating container from Debian 13 image...")
        async with LXC_CMD_SEMAPHORE:
            launch_cmd = ["lxc", "launch", "debian-13-base", container_name, "--storage", "bot-storage"]
            proc = await asyncio.create_subprocess_exec(*launch_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                # Si l'image n'existe pas, essayer de la télécharger
                logging.warning(f"Image debian-13-base not found, downloading...")
                async with LXC_CMD_SEMAPHORE:
                    download_cmd = ["lxc", "image", "copy", "images:debian/trixie/amd64", "local:", "--alias", "debian-13-base"]
                    proc = await asyncio.create_subprocess_exec(*download_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                    await proc.communicate()
                # Réessayer la création
                async with LXC_CMD_SEMAPHORE:
                    proc = await asyncio.create_subprocess_exec(*launch_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                    _, stderr = await proc.communicate()
                    if proc.returncode != 0:
                        raise subprocess.CalledProcessError(proc.returncode or 1, launch_cmd, stderr=stderr)
        logging.info(f"Container {container_name} created from Debian 13 image")

        if progress_callback:
            await progress_callback(25, "Configuring network interface...")

        # Check if eth0 already exists before adding
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "show", container_name,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        devices = yaml.safe_load(stdout.decode()) if stdout else {}
        
        if 'eth0' not in devices:
            # Add network interface
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "config", "device", "add", container_name, "eth0", "nic", 
                    "name=eth0", "network=lxdbr0",
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                )
                _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.warning(f"Failed to add eth0 device: {stderr.decode().strip()}")
            else:
                logging.info(f"eth0 device added to {container_name}")
        else:
            logging.info(f"eth0 already exists for {container_name}")

        # Apply resource limits
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.cpu", str(cpu_assignment), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            ram_in_mb = int(ram * 1000)
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.memory", f"{ram_in_mb}MB", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "security.nesting", "false", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "security.privileged", "false", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "set", container_name, "limits.processes", "500", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            logging.info(f"Resource limits configured for {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set resource limits: {e.stderr.decode()}")
            raise

        if progress_callback:
            await progress_callback(35, "Starting container...")

        # Start container
        async with LXC_CMD_SEMAPHORE:
            start_cmd = ["lxc", "start", container_name]
            proc = await asyncio.create_subprocess_exec(*start_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, start_cmd)
        logging.info(f"Container {container_name} started")

        # Wait for container to fully boot
        logging.info(f"Waiting for {container_name} to fully initialize...")
        if progress_callback:
            await progress_callback(40, "Waiting for container to boot...")
        await asyncio.sleep(10)
        
        # Verify network interface is present
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "show", container_name,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        devices_check = yaml.safe_load(stdout.decode()) if stdout else {}
        if 'eth0' not in devices_check:
            error_msg = f"Network interface eth0 not found for {container_name}"
            logging.error(error_msg)
            if progress_callback:
                await progress_callback(0, error_msg)
            raise Exception(error_msg)
        logging.info(f"Network interface eth0 verified for {container_name}")

        # Apply disk quota
        if progress_callback:
            await progress_callback(45, "Applying disk quota...")
        try:
            disk_in_mb = int(disk * 1000) + 300
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "config", "device", "set", container_name, "root", "size", f"{disk_in_mb}MB", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            logging.info(f"Disk quota of {disk_in_mb}MB set for {container_name}")
        except subprocess.CalledProcessError as e:
            logging.error(f"Failed to set disk quota: {e.stderr.decode()}")
            raise

        # Wait for network - but be more lenient if we have an IP
        if progress_callback:
            await progress_callback(50, "Waiting for network connection...")
        
        # First, wait for IP address (this is critical)
        container_ip = await wait_for_ip_address(container_name, timeout=90)
        if not container_ip:
            error_msg = f"Failed to obtain IP address for {container_name}"
            logging.error(error_msg)
            if progress_callback:
                await progress_callback(0, error_msg)
            raise Exception(error_msg)
        
        logging.info(f"Container {container_name} has IP: {container_ip}")
        
        # Now try to verify network connectivity (but don't fail if ping is blocked)
        network_ready = await wait_for_network(container_name, timeout=60)
        if not network_ready:
            # If we have an IP but network check failed, log warning but continue
            # The container might still work for SSH even if external ping is blocked
            logging.warning(f"Network connectivity check failed for {container_name}, but IP exists ({container_ip}). Continuing anyway...")
            if progress_callback:
                await progress_callback(52, f"Network IP obtained ({container_ip}), connectivity check inconclusive but continuing...")

        # Vérifier si IPv6 est déjà désactivé
        if progress_callback:
            await progress_callback(55, "Configuring network settings...")
        ipv6_already_disabled = await check_ipv6_disabled(container_name)
        
        if not ipv6_already_disabled:
            logging.info(f"Disabling IPv6 for {container_name}")
            # Configure DNS
            async with LXC_CMD_SEMAPHORE:
                dns_cmd = """
rm -f /etc/resolv.conf
echo "nameserver 1.1.1.1" > /etc/resolv.conf
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
"""
                proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", dns_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await asyncio.wait_for(proc.communicate(), timeout=10)

            # Configure hostname
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", f"echo '{container_name}' > /etc/hostname", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await asyncio.wait_for(proc.communicate(), timeout=10)
            
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", f"sed -i 's/127.0.1.1.*/127.0.1.1\t{container_name}/' /etc/hosts", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await asyncio.wait_for(proc.communicate(), timeout=10)

            # Disable IPv6
            async with LXC_CMD_SEMAPHORE:
                ipv6_disable_cmd = """
cat >> /etc/sysctl.conf << 'EOF'
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
EOF
sysctl -w net.ipv6.conf.all.disable_ipv6=1
sysctl -w net.ipv6.conf.default.disable_ipv6=1
sysctl -w net.ipv6.conf.lo.disable_ipv6=1
echo 'Acquire::ForceIPv4 "true";' > /etc/apt/apt.conf.d/99force-ipv4
echo 'precedence ::ffff:0:0/96  100' >> /etc/gai.conf
systemctl disable systemd-resolved 2>/dev/null || true
systemctl stop systemd-resolved 2>/dev/null || true
"""
                proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", ipv6_disable_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                await proc.communicate()
            
            # Restart network to apply changes
            logging.info(f"Restarting network for {container_name}")
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "bash", "-c",
                    "systemctl restart networking 2>/dev/null || service networking restart 2>/dev/null || true",
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                )
                await proc.communicate()
            
            await asyncio.sleep(5)
            
            if not await wait_for_network(container_name):
                raise Exception(f"Network timeout after configuration for {container_name}")
        else:
            logging.info(f"IPv6 already disabled for {container_name}, skipping configuration")

        # IP address should already be obtained above, just verify it's still there
        if progress_callback:
            await progress_callback(60, "Verifying IP address...")
        
        # Re-check IP to make sure it's still valid after network config
        container_ip = await get_container_ip(container_name)
        if not container_ip:
            # Try waiting again if we lost it
            logging.warning(f"IP address lost after network config, re-obtaining...")
            container_ip = await wait_for_ip_address(container_name, timeout=30)
            if not container_ip:
                error_msg = f"Failed to obtain IP for {container_name}"
                logging.error(error_msg)
                if progress_callback:
                    await progress_callback(0, error_msg)
                raise Exception(error_msg)
        
        logging.info(f"Confirmed IP address for {container_name}: {container_ip}")

        # Install essential packages and configure OpenSSH
        logging.info(f"Installing essential packages in {container_name}...")
        if progress_callback:
            await progress_callback(70, "Installing essential packages and OpenSSH...")
        
        # Install openssh-server and other essential packages
        async with LXC_CMD_SEMAPHORE:
            install_packages_cmd = """
# Update package lists
DEBIAN_FRONTEND=noninteractive apt-get update -y

# Install essential packages
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    openssh-server \
    curl \
    wget \
    nano \
    vim \
    net-tools \
    iputils-ping \
    dnsutils \
    htop \
    sudo \
    ca-certificates \
    gnupg \
    lsb-release

# Enable and start SSH
systemctl enable ssh
systemctl start ssh

echo "Essential packages installed successfully"
"""
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", install_packages_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, "install ssh", stderr=stderr)

        # Configure SSH to allow password authentication
        if progress_callback:
            await progress_callback(80, "Configuring SSH...")
        async with LXC_CMD_SEMAPHORE:
            ssh_config_cmd = """
# Remove conflicting cloud-init config file from the template image
rm -f /etc/ssh/sshd_config.d/60-cloudimg-settings.conf

# Create a dedicated configuration file to ensure correct settings
mkdir -p /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/99-enable-password.conf << 'EOF'
PasswordAuthentication yes
PermitRootLogin yes
PubkeyAuthentication yes
EOF

# Restart SSH service to apply changes
systemctl restart ssh || systemctl restart sshd || service ssh restart
"""
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", ssh_config_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()

        # Set root password
        if progress_callback:
            await progress_callback(85, "Setting root password...")
        async with LXC_CMD_SEMAPHORE:
            set_password_cmd = f"echo 'root:{ssh_password}' | chpasswd"
            proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "bash", "-c", set_password_cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, "set password")

        # Add port forwarding for SSH avec vérification finale du port
        if progress_callback:
            await progress_callback(90, "Setting up SSH port forwarding...")
        device_name = f"sshproxy{ssh_port}"
        
        # Double vérification que le port est toujours libre avant d'ajouter le proxy
        if is_port_in_use(ssh_port):
            logging.error(f"Port {ssh_port} became occupied before adding proxy, finding new port...")
            ssh_port = await get_available_ssh_port()
            if not ssh_port:
                raise Exception("No available SSH ports after retry")
            device_name = f"sshproxy{ssh_port}"
        
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "add", container_name, device_name, "proxy",
                f"listen=tcp:0.0.0.0:{ssh_port}",
                f"connect=tcp:{container_ip}:22",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to add SSH proxy: {stderr.decode()}")
                raise subprocess.CalledProcessError(proc.returncode or 1, "add ssh proxy", stderr=stderr)

        
        domain = os.getenv("NODE_DOMAIN", "jupyterhive.duckdns.org")
        ssh_connection = f"ssh root@{domain} -p {ssh_port}"
        
        if progress_callback:
            await progress_callback(95, "Finalizing container setup...")
        
        logging.info(f"Container {container_name} created successfully")
        logging.info(f"Container IP: {container_ip}")
        logging.info(f"SSH: {ssh_connection}")
        logging.info(f"Password: {ssh_password}")

        if progress_callback:
            await progress_callback(95, "Container created, finalizing setup...")

        return container_name, ssh_connection, ssh_port, ssh_password

    except Exception as e:
        logging.error(f"Error creating container {container_name}: {str(e)}")
        import traceback
        logging.error(traceback.format_exc())
        if progress_callback:
            await progress_callback(0, f"Error: {str(e)}")
        await cleanup_container(container_name)
        return None, None, None, None

async def cleanup_container(container_name):
    """Deletes a container in case of error"""
    try:
        logging.info(f"Cleaning up container {container_name}")
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "delete", container_name, "--force",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await asyncio.wait_for(proc.communicate(), timeout=30)
        logging.info(f"Container {container_name} deleted")
    except Exception as e:
        logging.error(f"Failed to cleanup {container_name}: {e}")

async def delete_container(container_name):
    """Gracefully deletes a container"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", container_name, "--format", "csv", "-c", "n",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await proc.communicate()
        if container_name not in stdout.decode():
            logging.info(f"Container {container_name} does not exist.")
            return True

        # Clean up port forwarding entries from the database
        port_forwards = db.get_port_forwards_for_container(container_name)
        if port_forwards:
            logging.info(f"Removing {len(port_forwards)} port forward database entries for {container_name}")
            for forward in port_forwards:
                db.remove_port_forward_entry(forward['device_name'])

        # Force stop the container before deleting
        stop_status = await stop_container(container_name, force=True)
        if stop_status is False:
            logging.warning(f"Failed to stop container {container_name} before deletion, but proceeding with delete anyway.")

        await asyncio.sleep(2)
        
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "delete", container_name, "--force",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, "lxc delete", stderr=stderr)
        logging.info(f"Container {container_name} deleted successfully")
        # Run cleanup script
        run_port_cleanup()
        return True
    except Exception as e:
        logging.error(f"Error deleting {container_name}: {e}")
        return False

async def regenerate_ssh_link(container_name):
    """Regenerates the SSH connection string for a given container."""
    vps_info = db.get_vps_by_container_name(container_name)
    if vps_info and vps_info['ssh_port']:
        ssh_port = vps_info['ssh_port']
        ssh_connection = f"ssh root@jupyterhive.duckdns.org -p {ssh_port}"
        return ssh_connection
    return None

async def reinstall_container(old_container_name, progress_callback=None):
    """Reinstalls an LXC container"""
    try:
        if progress_callback:
            await progress_callback(5, "Fetching VPS information...")
            await asyncio.sleep(2)
        
        # Try to get VPS info from database first
        vps_info = db.get_vps_by_container_name(old_container_name)
        
        # If not in DB, try to get specs from the actual LXC container
        if not vps_info:
            logging.warning(f"VPS info not found in DB for {old_container_name}, fetching from LXC container...")
            
            # Extract user_id and username from container name format: {username}-{user_id}-{uuid}
            parts = old_container_name.rsplit('-', 1)
            if len(parts) < 2:
                logging.error(f"Could not extract info from {old_container_name}")
                if progress_callback:
                    await progress_callback(0, "Failed: Invalid container name format.")
                return None, None, None, None
            
            name_without_uuid = parts[0]
            parts2 = name_without_uuid.rsplit('-', 1)
            if len(parts2) < 2:
                logging.error(f"Could not extract user_id from {old_container_name}")
                if progress_callback:
                    await progress_callback(0, "Failed: Could not extract user information.")
                return None, None, None, None
            
            username = parts2[0]
            try:
                user_id = int(parts2[1])
            except ValueError:
                logging.error(f"Could not parse user_id from {old_container_name}")
                if progress_callback:
                    await progress_callback(0, "Failed: Could not parse user information.")
                return None, None, None, None
            
            # Get specs from lxc query
            try:
                async with LXC_CMD_SEMAPHORE:
                    proc = await asyncio.create_subprocess_exec(
                        "lxc", "query", f"/1.0/instances/{old_container_name}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await proc.communicate()
                
                if proc.returncode == 0:
                    import json
                    data = json.loads(stdout.decode())
                    config = data.get('config', {})
                    
                    # Extract CPU count
                    cpu_limit = config.get('limits.cpu', '1')
                    try:
                        cpu = int(cpu_limit)
                    except ValueError:
                        cpu = 1
                    
                    # Extract RAM in GB
                    ram_limit = config.get('limits.memory', '1GB')
                    try:
                        if ram_limit.endswith('GB'):
                            ram = float(ram_limit.replace('GB', ''))
                        elif ram_limit.endswith('MB'):
                            ram = float(ram_limit.replace('MB', '')) / 1024
                        else:
                            ram = 1.0
                    except ValueError:
                        ram = 1.0
                    
                    # Try to get disk from root device
                    devices = data.get('devices', {})
                    root_device = devices.get('root', {})
                    disk_size = root_device.get('size', '10GB')
                    try:
                        if disk_size.endswith('GB'):
                            disk = float(disk_size.replace('GB', ''))
                        elif disk_size.endswith('MB'):
                            disk = float(disk_size.replace('MB', '')) / 1024
                        else:
                            disk = 10
                    except ValueError:
                        disk = 10
                    
                    logging.info(f"Extracted specs from container: {cpu}C, {ram}GB RAM, {disk}GB disk")
                else:
                    logging.warning(f"Could not query container {old_container_name}, using defaults")
                    cpu = 1
                    ram = 1.0
                    disk = 10
            except Exception as e:
                logging.warning(f"Error querying container specs: {e}, using defaults")
                cpu = 1
                ram = 1.0
                disk = 10
        else:
            user_id = vps_info['user_id']
            username = vps_info['username'] or f"user-{user_id}"
            cpu = vps_info['cpu']
            ram = vps_info['ram']
            disk = vps_info['disk']

        if progress_callback:
            await progress_callback(15, f"Deleting old container {old_container_name}...")

        if not await delete_container(old_container_name):
            if progress_callback:
                await progress_callback(0, "Failed: Could not delete old container.")
            return None, None, None, None
        
        if progress_callback:
            await progress_callback(25, "Removing old VPS entry from database...")
        
        db.delete_vps_by_container_name(old_container_name)

        if progress_callback:
            await progress_callback(30, "Creating new container...")
        
        new_container_name, ssh_connection, ssh_port, ssh_password = await create_lxc_container(user_id, username, cpu, ram, disk, progress_callback=progress_callback)

        if new_container_name:
            logging.info(f"Container reinstalled as {new_container_name}")
            if progress_callback:
                await progress_callback(100, f"Reinstallation complete: {new_container_name}")
            # Run cleanup script
            run_port_cleanup()
            return new_container_name, ssh_connection, ssh_port, ssh_password
        else:
            if progress_callback:
                await progress_callback(0, "Failed: Could not create new container.")
            return None, None, None, None

    except Exception as e:
        logging.error(f"Error during reinstall: {str(e)}")
        if progress_callback:
            await progress_callback(0, f"Reinstallation failed: {str(e)}")
        return None, None, None, None

async def list_user_containers(user_id):
    """Lists all containers for a user"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", "--format", "csv", "-c", "n",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await proc.communicate()
        all_containers = stdout.decode().strip().split('\n')
        return [c for c in all_containers if f"-{user_id}-" in c]
    except Exception as e:
        logging.error(f"Error listing containers: {e}")
        return []

async def get_container_info(container_name):
    """Retrieves container information with full state data using native Ubuntu tools."""
    try:
        # Get IP address
        ipv4 = await get_container_ip(container_name)

        # Check if container exists and get basic status
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", container_name, "--format", "csv", "-c", "s",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            logging.error(f"Container {container_name} not found: {stderr.decode().strip()}")
            return None
        
        status_raw = stdout.decode().strip().upper()
        status = 'stopped' if 'STOPPED' in status_raw else 'running' if 'RUNNING' in status_raw else 'unknown'
        
        # Initialize info structure
        info = {
            'status': status,
            'Status': status.capitalize(),
            'ipv4': ipv4,
            'state': {
                'memory': {'usage': 0, 'usage_peak': 0},
                'disk': {'root': {'usage': 0}},
                'uptime': 0,
                'cpu_usage': 0,
                'network': {}
            }
        }

        # If container is not running, return basic info
        if status != 'running':
            logging.info(f"Container {container_name} is {status}, returning basic info")
            return info

        # Get uptime using native tools
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "cat", "/proc/uptime",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                uptime_seconds = float(stdout.decode().split()[0])
                info['state']['uptime'] = int(uptime_seconds)
                logging.info(f"Uptime for {container_name}: {uptime_seconds}s")
        except Exception as e:
            logging.warning(f"Could not get uptime for {container_name}: {e}")

        # Get memory usage using /proc/meminfo
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "cat", "/proc/meminfo",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                meminfo = stdout.decode()
                mem_total = 0
                mem_available = 0
                
                for line in meminfo.split('\n'):
                    if line.startswith('MemTotal:'):
                        mem_total = int(line.split()[1]) * 1024  # Convert kB to bytes
                    elif line.startswith('MemAvailable:'):
                        mem_available = int(line.split()[1]) * 1024
                
                mem_used = mem_total - mem_available
                info['state']['memory']['usage'] = mem_used
                info['state']['memory']['total'] = mem_total
                logging.info(f"Memory for {container_name}: {mem_used}/{mem_total} bytes")
        except Exception as e:
            logging.warning(f"Could not get memory info for {container_name}: {e}")

        # Get disk usage using lxc info
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "info", container_name,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                output = stdout.decode()
                # Regex to find "Disk usage: root: XXXMiB" or "Disk usage: root: XXXGiB"
                match = re.search(r"Disk usage:\s+root:\s+([\d.]+)([MGT]iB)", output)
                if match:
                    value = float(match.group(1))
                    unit = match.group(2)
                    
                    disk_used_bytes = 0
                    if unit == "MiB":
                        disk_used_bytes = int(value * 1024 * 1024)
                    elif unit == "GiB":
                        disk_used_bytes = int(value * 1024 * 1024 * 1024)
                    elif unit == "TiB":
                        disk_used_bytes = int(value * 1024 * 1024 * 1024 * 1024)
                    
                    info['state']['disk']['root']['usage'] = disk_used_bytes
                    # lxc info doesn't directly provide total disk size in this format, set to 0 or fetch separately if needed
                    info['state']['disk']['root']['total'] = 0 
                    logging.info(f"Disk for {container_name}: {disk_used_bytes} bytes")
        except Exception as e:
            logging.warning(f"Could not get disk info for {container_name}: {e}")

        # Get CPU usage using /proc/stat (last 1 second average)
        try:
            async with LXC_CMD_SEMAPHORE:
                # First reading
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "cat", "/proc/stat",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout1, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                await asyncio.sleep(1)  # Wait 1 second
                
                # Second reading
                async with LXC_CMD_SEMAPHORE:
                    proc = await asyncio.create_subprocess_exec(
                        "lxc", "exec", container_name, "--", "cat", "/proc/stat",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout2, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
                
                if proc.returncode == 0:
                    def parse_cpu_line(line):
                        parts = line.split()
                        if parts[0].startswith('cpu') and parts[0] != 'cpu':
                            return None  # Skip individual cores, only use 'cpu' total
                        if parts[0] == 'cpu':
                            # user, nice, system, idle, iowait, irq, softirq, steal
                            values = [int(x) for x in parts[1:8]]
                            total = sum(values)
                            idle = values[3]
                            return total, idle
                        return None
                    
                    cpu1 = parse_cpu_line(stdout1.decode().split('\n')[0])
                    cpu2 = parse_cpu_line(stdout2.decode().split('\n')[0])
                    
                    if cpu1 and cpu2:
                        total_diff = cpu2[0] - cpu1[0]
                        idle_diff = cpu2[1] - cpu1[1]
                        
                        if total_diff > 0:
                            cpu_usage_percent = 100 * (total_diff - idle_diff) / total_diff
                            info['state']['cpu_usage'] = round(cpu_usage_percent, 2)
                            logging.info(f"CPU usage for {container_name}: {cpu_usage_percent}%")
        except Exception as e:
            logging.warning(f"Could not get CPU usage for {container_name}: {e}")

        # Get network statistics using /proc/net/dev
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "cat", "/proc/net/dev",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                lines = stdout.decode().split('\n')
                for line in lines:
                    if 'eth0:' in line:
                        parts = line.split()
                        if len(parts) >= 10:
                            info['state']['network']['eth0'] = {
                                'bytes_received': int(parts[1]),
                                'bytes_sent': int(parts[9])
                            }
                            logging.info(f"Network for {container_name}: RX={parts[1]}, TX={parts[9]}")
                        break
        except Exception as e:
            logging.warning(f"Could not get network info for {container_name}: {e}")

        # Get load average
        try:
            async with LXC_CMD_SEMAPHORE:
                proc = await asyncio.create_subprocess_exec(
                    "lxc", "exec", container_name, "--", "cat", "/proc/loadavg",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            
            if proc.returncode == 0:
                loadavg = stdout.decode().split()
                if len(loadavg) >= 3:
                    info['state']['loadavg'] = {
                        '1min': float(loadavg[0]),
                        '5min': float(loadavg[1]),
                        '15min': float(loadavg[2])
                    }
                    logging.info(f"Load average for {container_name}: {loadavg[0]}, {loadavg[1]}, {loadavg[2]}")
        except Exception as e:
            logging.warning(f"Could not get load average for {container_name}: {e}")

        return info
        
    except Exception as e:
        logging.error(f"Error getting info for {container_name}: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return None

async def get_container_config(container_name):
    """Retrieves container configuration in YAML format"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "show", container_name,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.error(f"lxc config show command failed for {container_name} with stderr: {stderr.decode().strip()}")
            return None
        return yaml.safe_load(stdout.decode())
    except Exception as e:
        logging.error(f"Error getting config for {container_name}: {e}")
        return None

async def is_container_running(container_name):
    """Checks if a container is running."""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "list", container_name, "--format", "csv", "-c", "s",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.warning(f"Could not get status for {container_name}: {stderr.decode().strip()}")
            return False
        return "RUNNING" in stdout.decode().strip().upper()
    except Exception as e:
        logging.error(f"Exception checking status for {container_name}: {e}")
        return False


async def execute_command(container_name: str, command: list, timeout: int = 60) -> dict:
    """Executes a command inside a container and returns its output."""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            
            return {
                "stdout": stdout.decode('utf-8', errors='ignore'),
                "stderr": stderr.decode('utf-8', errors='ignore'),
                "returncode": proc.returncode
            }
            
    except asyncio.TimeoutError:
        logging.error(f"Timeout executing command in {container_name}: {' '.join(command)}")
        # Process might not be assigned if create_subprocess_exec fails partially
        if 'proc' in locals():
            try:
                proc.kill()
                await proc.wait()
            except ProcessLookupError:
                pass # Process already finished
        return {"error": "Command timed out", "stdout": "", "stderr": "Timeout", "returncode": -1}
    except Exception as e:
        logging.error(f"Error executing command in {container_name}: {e}")
        return {"error": str(e), "stdout": "", "stderr": str(e), "returncode": -1}


async def get_file_content(container_name: str, filepath: str, size_limit: Optional[int] = None) -> Optional[bytes]:
    """Reads the content of a file from within a container."""
    command = []
    if size_limit and isinstance(size_limit, int) and size_limit > 0:
        command = ["head", "-c", str(size_limit), filepath]
    else:
        command = ["cat", filepath]
    
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
            
            if proc.returncode != 0:
                logging.error(f"Error reading file {filepath} from {container_name}: {stderr.decode()}")
                return None
            
            return stdout
            
    except Exception as e:
        logging.error(f"Error getting file content from {container_name}: {e}")
        return None


async def pause_container(container_name):
    """Pauses an LXC container"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec("lxc", "pause", container_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
        if proc.returncode == 0:
            logging.info(f"Container {container_name} paused.")
            return True
        else:
            logging.error(f"Failed to pause container {container_name}.")
            return False
    except Exception as e:
        logging.error(f"Failed to pause container: {e}")
        return False

async def stop_container(container_name, force=False):
    """Stops an LXC container"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec("lxc", "list", container_name, "--format", "csv", "-c", "s", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            status_result, _ = await proc.communicate()
        if "STOPPED" in status_result.decode().strip().upper():
            logging.info(f"Container {container_name} already stopped.")
            return None

        cmd = ["lxc", "stop", container_name]
        if force:
            cmd.append("--force")

        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"lxc stop command failed for {container_name} with stderr: {stderr.decode()}")
                return False
        logging.info(f"Container {container_name} stopped.")
        return True
    except Exception as e:
        logging.error(f"Failed to stop container: {e}")
        return False

async def start_container(container_name):
    """Starts an LXC container"""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec("lxc", "list", container_name, "--format", "csv", "-c", "s", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            status_result, _ = await proc.communicate()
        if "RUNNING" in status_result.decode().strip().upper():
            logging.info(f"Container {container_name} already running.")
            return None

        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec("lxc", "start", container_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
        
        if not await wait_for_network(container_name):
            logging.error(f"Network timeout after starting {container_name}")
            return False

        return True
    except Exception as e:
        logging.error(f"Failed to start container: {e}")
        return False

def list_port_forwards(container_name):
    """Lists existing port forwarding rules"""
    try:
        forwards_db = db.get_port_forwards_for_container(container_name)
        return [f"{f['external_port']}/{f['protocol']} -> {f['internal_port']}" for f in forwards_db]
    except Exception as e:
        logging.error(f"Error listing port forwards: {e}")
        return []

async def add_port_forward(container_name, port):
    """Adds a port forwarding rule"""
    try:
        # Vérifier si le port est déjà utilisé dans la DB
        if db.get_port_forward_by_external_port(int(port), 'tcp'):
            logging.error(f"Port {port} is already in use in database.")
            return False
        
        # Vérifier si le port est réellement libre sur le système
        if is_port_in_use(int(port)):
            logging.error(f"Port {port} is already in use on the system.")
            return False

        # Get container IP using the new function
        container_ip = await wait_for_ip_address(container_name, timeout=30)
        
        if not container_ip:
            logging.error(f"Could not find IP address for {container_name}.")
            return False

        device_name = f"proxy{port}"
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "add", container_name, device_name, "proxy",
                f"listen=tcp:0.0.0.0:{port}", f"connect=tcp:{container_ip}:{port}",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to add proxy device for port {port} on {container_name}: {stderr.decode()}")
                return False
        
        db.add_port_forward_entry(container_name, int(port), int(port), 'tcp', device_name)
        logging.info(f"Successfully forwarded port {port} to {container_ip}:{port} for {container_name}.")
        return True
    except Exception as e:
        logging.error(f"An unexpected error occurred while adding port forward for {container_name}: {e}")
        return False

async def delete_port_forward(container_name, port):
    """Deletes a port forwarding rule"""
    try:
        forward_entry = db.get_port_forward_by_external_port(port, 'tcp')
        if not forward_entry or forward_entry['container_name'] != container_name:
            return False
        
        device_name = forward_entry['device_name']
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "device", "remove", container_name, device_name,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        db.remove_port_forward_entry(device_name)
        return True
    except Exception as e:
        logging.error(f"Error deleting port forward: {e}")
        return False

async def get_active_container_count():
    """Returns the number of running containers."""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_shell(
                'lxc list --format=json',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode == 0:
            lxc_list = json.loads(stdout)
            return sum(1 for c in lxc_list if c['status'] == 'Running')
        else:
            logging.error(f"lxc list command failed with stderr: {stderr.decode()}")
            return None
    except (json.JSONDecodeError, KeyError, FileNotFoundError) as e:
        logging.error(f"Error getting active container count: {e}")
        return None

async def get_total_container_count():
    """Returns the total number of LXC containers, regardless of status."""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_shell(
                'lxc list --format=json',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode == 0:
            lxc_list = json.loads(stdout)
            return len(lxc_list)
        else:
            logging.error(f"lxc list command failed with stderr: {stderr.decode()}")
            return None
    except (json.JSONDecodeError, KeyError, FileNotFoundError) as e:
        logging.error(f"Error getting total container count: {e}")
        return None

async def enable_ssh_password_auth(container_name: str) -> bool:
    """
    Ensures SSH password authentication is enabled in the container and refreshes port forwarding.
    """
    try:
        if not await is_container_running(container_name):
            logging.info(f"Starting container {container_name} to fix SSH...")
            await start_container(container_name)
            await asyncio.sleep(8) # Wait for boot

        if not await is_container_running(container_name):
            logging.error(f"Container {container_name} did not start correctly.")
            return False

        logging.info(f"Configuring SSH for password authentication in {container_name}...")

        async with LXC_CMD_SEMAPHORE:
            ssh_fix_script = """
# Create the sshd_config.d directory if it doesn't exist
mkdir -p /etc/ssh/sshd_config.d

# Create a dedicated configuration file
cat > /etc/ssh/sshd_config.d/99-enable-password.conf << 'SSHEOF'
# Enable password authentication
PasswordAuthentication yes
PermitRootLogin yes
PubkeyAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
SSHEOF

# Also modify the main file for safety
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config

# Ensure the directives exist if they were missing
grep -q "^PasswordAuthentication" /etc/ssh/sshd_config || echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config
grep -q "^PermitRootLogin" /etc/ssh/sshd_config || echo "PermitRootLogin yes" >> /etc/ssh/sshd_config

# Restart SSH
systemctl restart ssh || systemctl restart sshd || service ssh restart
"""
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", container_name, "--", "bash", "-c", ssh_fix_script,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()

        if proc.returncode != 0:
            logging.error(f"Failed to execute SSH fix script in {container_name}: {stderr.decode()}")
        else:
            logging.info(f"SSH password authentication enabled for {container_name}. Output: {stdout.decode()}")

        # Refresh port forwarding
        logging.info(f"Refreshing port forwarding for {container_name}...")
        container_ip = await get_container_ip(container_name)
        if not container_ip:
            logging.error(f"Could not get IP for {container_name} to refresh port forwards.")
        else:
            # Refresh SSH port forward
            vps_info = db.get_vps_by_container_name(container_name)
            if vps_info and vps_info.get('ssh_port'):
                ssh_port = vps_info['ssh_port']
                device_name = f"sshproxy{ssh_port}"
                try:
                    async with LXC_CMD_SEMAPHORE:
                        remove_proc = await asyncio.create_subprocess_exec("lxc", "config", "device", "remove", container_name, device_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                        await remove_proc.communicate()
                    async with LXC_CMD_SEMAPHORE:
                        add_proc = await asyncio.create_subprocess_exec(
                            "lxc", "config", "device", "add", container_name, device_name, "proxy",
                            f"listen=tcp:0.0.0.0:{ssh_port}",
                            f"connect=tcp:{container_ip}:22",
                            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                        )
                        await add_proc.communicate()
                    logging.info(f"Refreshed SSH proxy for {container_name} to IP {container_ip}")
                except Exception as e:
                    logging.warning(f"Could not refresh SSH proxy device {device_name} for {container_name}: {e}")

            # Refresh custom port forwards
            custom_ports = db.get_port_forwards_for_container(container_name)
            for port_info in custom_ports:
                port = port_info['external_port']
                device_name = port_info['device_name']
                try:
                    async with LXC_CMD_SEMAPHORE:
                        remove_proc = await asyncio.create_subprocess_exec("lxc", "config", "device", "remove", container_name, device_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                        await remove_proc.communicate()
                    async with LXC_CMD_SEMAPHORE:
                        add_proc = await asyncio.create_subprocess_exec(
                            "lxc", "config", "device", "add", container_name, device_name, "proxy",
                            f"listen=tcp:0.0.0.0:{port}", f"connect=tcp:{container_ip}:{port}",
                            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                        )
                        await add_proc.communicate()
                    logging.info(f"Refreshed custom port proxy for {container_name} on port {port} to IP {container_ip}")
                except Exception as e:
                    logging.warning(f"Could not refresh custom proxy device {device_name} for {container_name}: {e}")
        return True

    except Exception as e:
        logging.error(f"Error enabling SSH password auth or refreshing ports for {container_name}: {e}")
        return False


def run_port_cleanup():
    """Runs the port cleanup script in the background."""
    try:
        logging.info("Starting port cleanup script...")
        subprocess.Popen(
            [sys.executable, "utils/port-delete.py"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        logging.info("Port cleanup script started in background.")
        return True
    except Exception as e:
        logging.error(f"Failed to start port cleanup script: {e}")
        return False

async def set_cpu_limit(container_name: str, cpu_limit: int):
    """Sets the CPU limit for a container."""
    try:
        async with LXC_CMD_SEMAPHORE:
            proc = await asyncio.create_subprocess_exec(
                "lxc", "config", "set", container_name, "limits.cpu", str(cpu_limit),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to set CPU limit for {container_name}: {stderr.decode()}")
                return False
        logging.info(f"CPU limit for {container_name} set to {cpu_limit}.")
        return True
    except Exception as e:
        logging.error(f"Error setting CPU limit for {container_name}: {e}")
        return False