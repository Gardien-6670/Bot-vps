import subprocess
import time
import logging
import uuid
import re
import secrets
import string
import random
import sys
import os
from utils.database import db
import asyncio
import socket
import xml.etree.ElementTree as ET
import threading
import time

logging.basicConfig(level=logging.INFO)

# A lock to protect access to the _semaphores dictionary from multiple threads
_SEMAPHORE_LOCK = threading.Lock()
_LOOP_SEMAPHORES = {}
_IP_CACHE = {}  # Cache local pour les IPs (vm_name -> (ip, timestamp))
_IP_CACHE_TTL = 60  # Cache valide 60 secondes

def get_kvm_semaphore():
    """
    Gets or creates an asyncio.Semaphore for the current event loop.
    This makes the semaphore safe to use across different threads that run their own event loops.
    """
    loop = asyncio.get_running_loop()
    
    # Fast path: check if we already have a semaphore for this loop without locking
    if loop in _LOOP_SEMAPHORES:
        return _LOOP_SEMAPHORES[loop]
    
    # Slow path: acquire the thread-safe lock and check again (double-checked locking)
    with _SEMAPHORE_LOCK:
        if loop not in _LOOP_SEMAPHORES:
            _LOOP_SEMAPHORES[loop] = asyncio.Semaphore(4)
        return _LOOP_SEMAPHORES[loop]

def generate_password(length=30):
    """Generates a secure random password"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def is_port_in_use(port):
    """Checks if a port is already in use on the system"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('0.0.0.0', port))
            return False
    except OSError:
        return True

async def get_available_ssh_port():
    """Finds an available SSH port between 9000 and 10000 by checking the DB and the system"""
    used_ports = db.get_all_ssh_ports()
    
    port_range = list(range(9000, 10001))
    random.shuffle(port_range)

    for port in port_range:
        # First, check in the vps table (main SSH ports)
        if port in used_ports:
            continue
        
        # Second, check the custom port forwards table
        if db.get_port_forward_by_external_port(port, 'tcp'):
            continue

        # Then, check if the port is actually free on the system
        if not is_port_in_use(port):
            logging.info(f"Found available port: {port}")
            return port
            
    logging.error("No available ports found in range 9000-10000")
    return None

async def wait_for_vm_ip(vm_name, timeout=120):
    """Waits for the VM to get an IP address"""
    start = time.time()
    attempt = 0
    while time.time() - start < timeout:
        attempt += 1
        try:
            async with get_kvm_semaphore():
                proc = await asyncio.create_subprocess_exec(
                    "sudo", "virsh", "domifaddr", vm_name,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await proc.communicate()
            
            if proc.returncode == 0:
                output = stdout.decode()
                # Parse output to find IPv4 address
                match = re.search(r'(\d+\.\d+\.\d+\.\d+)/\d+', output)
                if match:
                    ip = match.group(1)
                    if ip and not ip.startswith("127."):
                        logging.info(f"Found IP {ip} for {vm_name} (attempt {attempt})")
                        return ip
            
            # After 15 attempts, try fallback method
            if attempt == 15:
                logging.info(f"Attempt 15 reached for {vm_name}. Trying fallback method with virsh dumpxml...")
                try:
                    async with get_kvm_semaphore():
                        proc_xml = await asyncio.create_subprocess_exec(
                            "sudo", "virsh", "dumpxml", vm_name,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE
                        )
                        stdout_xml, stderr_xml = await asyncio.wait_for(proc_xml.communicate(), timeout=10.0)
                    
                    if proc_xml.returncode == 0:
                        xml_output = stdout_xml.decode()
                        # Look for MAC address in XML
                        mac_match = re.search(r"<mac address='([a-f0-9:]+)'", xml_output)
                        if mac_match:
                            mac_addr = mac_match.group(1)
                            logging.info(f"Found MAC address {mac_addr} for {vm_name}. Checking for IP...")
                            
                            # Method 1: Check DHCP leases file
                            ip_found = None
                            leases_paths = [
                                "/var/lib/libvirt/dnsmasq/default.leases",
                                "/var/lib/dnsmasq/dnsmasq.leases",
                                "/var/lib/misc/dnsmasq.leases"
                            ]
                            
                            for leases_path in leases_paths:
                                try:
                                    async with get_kvm_semaphore():
                                        proc_leases = await asyncio.create_subprocess_exec(
                                            "sudo", "grep", mac_addr, leases_path,
                                            stdout=asyncio.subprocess.PIPE,
                                            stderr=asyncio.subprocess.PIPE
                                        )
                                        stdout_leases, _ = await asyncio.wait_for(proc_leases.communicate(), timeout=5.0)
                                    
                                    if proc_leases.returncode == 0:
                                        lease_line = stdout_leases.decode().strip()
                                        # Format: timestamp mac_address ip_address hostname client_id
                                        lease_parts = lease_line.split()
                                        if len(lease_parts) >= 3:
                                            ip = lease_parts[2]
                                            if ip and not ip.startswith("127."):
                                                logging.info(f"Found IP {ip} from DHCP leases ({leases_path}) for {vm_name}")
                                                ip_found = ip
                                                break
                                except Exception as e:
                                    logging.debug(f"DHCP leases check failed for {leases_path}: {e}")
                            
                            # Method 2: Check ARP table if DHCP leases failed
                            if not ip_found:
                                logging.info(f"DHCP leases failed, trying ARP table for MAC {mac_addr}...")
                                try:
                                    async with get_kvm_semaphore():
                                        proc_arp = await asyncio.create_subprocess_exec(
                                            "sudo", "arp", "-n",
                                            stdout=asyncio.subprocess.PIPE,
                                            stderr=asyncio.subprocess.PIPE
                                        )
                                        stdout_arp, _ = await asyncio.wait_for(proc_arp.communicate(), timeout=5.0)
                                    
                                    if proc_arp.returncode == 0:
                                        arp_output = stdout_arp.decode()
                                        for line in arp_output.split('\n'):
                                            if mac_addr.lower() in line.lower():
                                                # Format: IP HWtype HWaddress Flags Mask Iface
                                                arp_parts = line.split()
                                                if len(arp_parts) >= 1:
                                                    ip = arp_parts[0]
                                                    if ip and not ip.startswith("127."):
                                                        logging.info(f"Found IP {ip} from ARP table for {vm_name}")
                                                        ip_found = ip
                                                        break
                                except Exception as e:
                                    logging.warning(f"ARP table check failed: {e}")
                            
                            # Method 3: Check virsh network list as last resort
                            if not ip_found:
                                logging.info(f"ARP failed, trying virsh net-dumpxml...")
                                try:
                                    async with get_kvm_semaphore():
                                        proc_net = await asyncio.create_subprocess_exec(
                                            "sudo", "virsh", "net-dumpxml", "default",
                                            stdout=asyncio.subprocess.PIPE,
                                            stderr=asyncio.subprocess.PIPE
                                        )
                                        stdout_net, _ = await asyncio.wait_for(proc_net.communicate(), timeout=5.0)
                                    
                                    if proc_net.returncode == 0:
                                        # Try to get DHCP range from network XML
                                        net_output = stdout_net.decode()
                                        dhcp_match = re.search(r"<ip address='([0-9.]+)'", net_output)
                                        if dhcp_match:
                                            network_ip = dhcp_match.group(1)
                                            # The VM IP should be in the same subnet
                                            logging.info(f"Network IP detected: {network_ip}, VM may be getting its IP...")
                                except Exception as e:
                                    logging.warning(f"Network XML check failed: {e}")
                            
                            if ip_found:
                                return ip_found
                except Exception as e:
                    logging.warning(f"Fallback method failed: {e}")
            
            logging.warning(f"Attempt {attempt}: No IP address found for {vm_name}. Waiting...")
            
        except Exception as e:
            logging.warning(f"Attempt {attempt}: Error getting IP for {vm_name}: {e}")
        
        await asyncio.sleep(3)
    
    logging.error(f"No IP address found for {vm_name} after {timeout}s")
    return None

async def get_vm_ip(vm_name):
    """Gets the VM IP address and caches it in memory and DB"""
    # Check local cache first
    if vm_name in _IP_CACHE:
        ip, timestamp = _IP_CACHE[vm_name]
        if time.time() - timestamp < _IP_CACHE_TTL:
            logging.info(f"Using cached IP {ip} for {vm_name}")
            return ip
        else:
            del _IP_CACHE[vm_name]  # Cache expired
    
    proc = None
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "domifaddr", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15.0)
        
        if proc.returncode == 0:
            output = stdout.decode()
            match = re.search(r'(\d+\.\d+\.\d+\.\d+)/\d+', output)
            if match:
                ip = match.group(1)
                if ip and not ip.startswith("127."):
                    logging.info(f"Found IP {ip} for {vm_name}")
                    
                    # Cache in memory
                    _IP_CACHE[vm_name] = (ip, time.time())
                    
                    # Update database with the found IP
                    try:
                        vps_info = db.get_vps_by_container_name(vm_name)
                        if vps_info:
                            db._execute_query(
                                "UPDATE vps SET ip_address = ? WHERE container_name = ?",
                                (ip, vm_name)
                            )
                            logging.info(f"Cached IP {ip} for {vm_name} in database")
                    except Exception as e:
                        logging.warning(f"Failed to cache IP in database: {e}")
                    
                    return ip
    except asyncio.TimeoutError:
        logging.warning(f"Timeout getting IP for {vm_name}")
        if proc and proc.returncode is None:
            try:
                proc.kill()
                await proc.wait()
            except ProcessLookupError:
                pass
    except Exception as e:
        logging.warning(f"Error getting IP for {vm_name}: {e}")
    
    logging.warning(f"Could not find IP for {vm_name}")
    return None

async def get_vm_ip_via_ssh(vm_name, ssh_host, ssh_port, ssh_password):
    """
    Gets the VM IP by connecting via SSH and running 'hostname -I'.
    Updates the database with the discovered IP for caching.
    Returns the IP address or None if it fails.
    """
    try:
        # Build SSH command to get IP
        cmd = [
            "sshpass", "-p", ssh_password, "ssh",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "ConnectTimeout=10",
            "-p", str(ssh_port),
            f"root@{ssh_host}",
            "hostname -I | awk '{print $1}'"
        ]
        
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15.0)
            if proc.returncode == 0:
                ip = stdout.decode().strip().split()[0] if stdout else None
                if ip and re.match(r'^\d+\.\d+\.\d+\.\d+$', ip) and not ip.startswith("127."):
                    logging.info(f"Found IP {ip} for {vm_name} via SSH")
                    
                    # Update database with the discovered IP
                    try:
                        vps_info = db.get_vps_by_container_name(vm_name)
                        if vps_info:
                            db._execute_query(
                                "UPDATE vps SET ip_address = ? WHERE container_name = ?",
                                (ip, vm_name)
                            )
                            logging.info(f"Cached IP {ip} for {vm_name} in database")
                    except Exception as e:
                        logging.warning(f"Failed to cache IP in database: {e}")
                    
                    return ip
            else:
                logging.warning(f"SSH command failed for {vm_name}: {stderr.decode().strip()}")
        except asyncio.TimeoutError:
            logging.warning(f"Timeout getting IP via SSH for {vm_name}")
            if proc.returncode is None:
                try:
                    proc.kill()
                    await proc.wait()
                except ProcessLookupError:
                    pass
    except Exception as e:
        logging.warning(f"Error getting IP via SSH for {vm_name}: {e}")
    
    logging.warning(f"Could not get IP via SSH for {vm_name}")
    return None

async def create_kvm_vm(user_id, username, cpu, ram, disk, progress_callback=None, vm_name=None):
    """
    Creates a KVM VM with OpenSSH access and a dedicated surveillance user.
    Returns: (vm_name, ssh_connection_string, ssh_port, ssh_password, vm_ip, surveillance_user, surveillance_password)
    """
    sanitized_username = re.sub(r'[^a-z0-9-]', '', username.lower().replace(" ", "-"))
    
    # If vm_name not provided, use the short naming pattern: username-vm_number
    if not vm_name:
        vm_name = f"{sanitized_username}-1"  # Default to -1 if not provided
    
    if progress_callback:
        await progress_callback(5, "Initializing VM creation...")
    
    # Find available SSH port
    ssh_port = await get_available_ssh_port()
    if not ssh_port:
        logging.error("No available SSH ports in range 9000-10000")
        if progress_callback:
            await progress_callback(0, "Failed: No available SSH ports")
        return None, None, None, None, None, None, None
    
    # IMPORTANT: Nettoie les règles orphelines pour ce port
    await cleanup_orphaned_rules(ssh_port)
    
    # Generate passwords
    ssh_password = generate_password()
    surveillance_password = generate_password()
    surveillance_user = "gemini-surveillance"
    
    try:
        logging.info(f"Creating VM {vm_name} for user {user_id}")
        logging.info(f"Resources: {cpu} CPU, {ram}GB RAM, {disk}GB disk")
        logging.info(f"SSH Port: {ssh_port}")
        
        if progress_callback:
            await progress_callback(10, "Preparing VM configuration...")
        
        # Convert GB to MB for RAM
        ram_mb = int(ram * 1024)
        disk_size = f"{int(disk)}G"
        
        # Create disk image
        if progress_callback:
            await progress_callback(15, "Creating disk image...")
        async with get_kvm_semaphore():
            disk_path = f"/var/lib/libvirt/images/{vm_name}.qcow2"
            
            # Remove existing disk if it exists
            try:
                remove_disk_cmd = ["sudo", "rm", "-f", disk_path]
                proc = await asyncio.create_subprocess_exec(
                    *remove_disk_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                await proc.communicate()
            except Exception as e:
                logging.warning(f"Could not remove existing disk {disk_path}: {e}")
            
            create_disk_cmd = [
                "sudo", "qemu-img", "create", "-f", "qcow2",
                "-b", "/var/lib/libvirt/images/debian-13-base.qcow2",
                "-F", "qcow2", disk_path, disk_size
            ]
            proc = await asyncio.create_subprocess_exec(
                *create_disk_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, create_disk_cmd, stderr=stderr)
        logging.info(f"Disk created for {vm_name}")
        
        if progress_callback:
            await progress_callback(25, "Creating cloud-init configuration...")
        
        # Create user-data file with surveillance user
        user_data = f"""#cloud-config
hostname: {vm_name}
manage_etc_hosts: true
ssh_pwauth: true
disable_root: false

users:
  - name: root
    lock_passwd: false
    plain_text_passwd: '{ssh_password}'
    shell: /bin/bash
  - name: ubuntu
    lock_passwd: false
    plain_text_passwd: '{ssh_password}'
    sudo: ALL=(ALL) NOPASSWD:ALL
    groups: users, admin, sudo
    shell: /bin/bash
  - name: {surveillance_user}
    lock_passwd: false
    plain_text_passwd: '{surveillance_password}'
    sudo: ALL=(ALL) NOPASSWD:ALL
    groups: users, admin, sudo
    shell: /bin/bash

chpasswd:
  expire: False
  list: |
    root:{ssh_password}
    ubuntu:{ssh_password}
    {surveillance_user}:{surveillance_password}

package_update: true
package_upgrade: false
packages:
  - openssh-server
  - curl
  - wget
  - nano
  - vim
  - net-tools
  - iputils-ping
  - dnsutils
  - htop
  - sudo
  - ca-certificates
  - gnupg
  - lsb-release

write_files:
  - path: /etc/ssh/sshd_config.d/99-cloud-init.conf
    content: |
      PasswordAuthentication yes
      PermitRootLogin yes
      PubkeyAuthentication yes
      ChallengeResponseAuthentication no
      UsePAM yes
    permissions: '0644'
  - path: /etc/sudoers.d/99-surveillance
    content: "{surveillance_user} ALL=(ALL) NOPASSWD:ALL"
    permissions: '0440'

runcmd:
  - sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - systemctl restart sshd || systemctl restart ssh
  - echo "Surveillance user and SSH configured." > /var/log/cloud-init-surveillance.log

final_message: "VM {vm_name} is ready. SSH should be available."
"""
        
        async with get_kvm_semaphore():
            user_data_path = f"/tmp/{vm_name}-user-data"
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c", f"cat > {user_data_path} << 'EOF'\n{user_data}\nEOF",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Create meta-data file
        async with get_kvm_semaphore():
            meta_data = f"""instance-id: {vm_name}
local-hostname: {vm_name}
"""
            meta_data_path = f"/tmp/{vm_name}-meta-data"
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c", f"cat > {meta_data_path} << 'EOF'\n{meta_data}\nEOF",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        if progress_callback:
            await progress_callback(35, "Generating cloud-init ISO...")
        
        # Generate cloud-init ISO
        async with get_kvm_semaphore():
            iso_path = f"/var/lib/libvirt/images/{vm_name}-cloud.iso"
            create_iso_cmd = [
                "sudo", "cloud-localds", iso_path, user_data_path, meta_data_path
            ]
            proc = await asyncio.create_subprocess_exec(
                *create_iso_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, create_iso_cmd, stderr=stderr)
        logging.info(f"Cloud-init ISO created for {vm_name}")
        
        if progress_callback:
            await progress_callback(45, "Configuring network...")
        
        # Ensure default network is active
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "net-start", "default",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "net-autostart", "default",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        if progress_callback:
            await progress_callback(50, "Creating and starting VM...")
        
        # Create and start VM
        async with get_kvm_semaphore():
            virt_install_cmd = [
                "sudo", "virt-install",
                "--name", vm_name,
                "--memory", str(ram_mb),
                "--vcpus", str(cpu),
                "--cpu", "host-model",
                "--disk", f"path={disk_path},format=qcow2",
                "--disk", f"path={iso_path},device=cdrom",
                "--os-variant", "debian12",
                "--network", "network=default",
                "--graphics", "none",
                "--noautoconsole",
                "--import",
                "--boot", "hd,cdrom"
            ]
            proc = await asyncio.create_subprocess_exec(
                *virt_install_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"virt-install for {vm_name} failed with stderr: {stderr.decode()}")
                raise subprocess.CalledProcessError(proc.returncode or 1, virt_install_cmd, stderr=stderr)
        logging.info(f"VM {vm_name} created and started")
        
        if progress_callback:
            await progress_callback(60, "Waiting for VM to boot and get IP address...")
        
        # Wait for VM to boot and get IP
        logging.info(f"Waiting for {vm_name} to get IP address...")
        await asyncio.sleep(15)
        
        if progress_callback:
            await progress_callback(70, "Obtaining IP address...")
        
        vm_ip = await wait_for_vm_ip(vm_name, timeout=300)
        if not vm_ip:
            error_msg = f"Failed to obtain IP for {vm_name}"
            logging.error(error_msg)
            if progress_callback:
                await progress_callback(0, error_msg)
            raise Exception("Could not obtain VM IP address")
        
        if progress_callback:
            await progress_callback(80, "Waiting for cloud-init to complete SSH configuration...")
        
        # Wait additional time for cloud-init to complete
        logging.info("Waiting for cloud-init to complete SSH configuration...")
        await asyncio.sleep(45)  # Augmenté pour être sûr que cloud-init a terminé
        
        if progress_callback:
            await progress_callback(90, "Setting up SSH port forwarding...")
        
        # Add port forwarding for SSH using iptables
        if vm_ip and vm_ip not in ['127.0.0.1', '::1']:
            try:
                await setup_ssh_port_forward(vm_ip, ssh_port)
            except Exception as e:
                logging.warning(f"Failed to setup SSH port forward, will use default domain: {e}")
        
        domain = os.getenv("NODE_DOMAIN", "jupyterhive.duckdns.org")
        ssh_connection = f"ssh root@{domain} -p {ssh_port}"
        
        if progress_callback:
            await progress_callback(95, "Finalizing VM setup...")
        
        logging.info(f"VM {vm_name} created successfully")
        logging.info(f"VM IP: {vm_ip}")
        logging.info(f"SSH: {ssh_connection}")
        logging.info(f"Password: {ssh_password}")
        
        # Clean up temporary files
        async with get_kvm_semaphore():
            await asyncio.create_subprocess_exec("sudo", "rm", "-f", user_data_path, meta_data_path)
        
        if progress_callback:
            await progress_callback(100, "VM creation complete!")
        
        return vm_name, ssh_connection, ssh_port, ssh_password, vm_ip, surveillance_user, surveillance_password
        
    except Exception as e:
        logging.error(f"Error creating VM {vm_name}: {str(e)}")
        import traceback
        logging.error(traceback.format_exc())
        if progress_callback:
            await progress_callback(0, f"Error: {str(e)}")
        await cleanup_vm(vm_name)
        return None, None, None, None, None, None, None

async def setup_ssh_port_forward(vm_ip, ssh_port):
    """Sets up iptables port forwarding for SSH"""
    try:
        # Add INPUT rule
        async with get_kvm_semaphore():
            input_cmd = [
                "sudo", "iptables", "-I", "INPUT", "1",
                "-p", "tcp", "--dport", str(ssh_port),
                "-j", "ACCEPT"
            ]
            proc = await asyncio.create_subprocess_exec(
                *input_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Add PREROUTING rule for external access
        async with get_kvm_semaphore():
            prerouting_cmd = [
                "sudo", "iptables", "-t", "nat", "-A", "PREROUTING",
                "-p", "tcp", "--dport", str(ssh_port),
                "-j", "DNAT", "--to-destination", f"{vm_ip}:22"
            ]
            proc = await asyncio.create_subprocess_exec(
                *prerouting_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Add OUTPUT rule for local access
        async with get_kvm_semaphore():
            output_cmd = [
                "sudo", "iptables", "-t", "nat", "-A", "OUTPUT",
                "-p", "tcp", "--dport", str(ssh_port),
                "-j", "DNAT", "--to-destination", f"{vm_ip}:22"
            ]
            proc = await asyncio.create_subprocess_exec(
                *output_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # IMPORTANT: Add to LIBVIRT_FWI instead of FORWARD to bypass libvirt restrictions
        async with get_kvm_semaphore():
            forward_cmd = [
                "sudo", "iptables", "-I", "LIBVIRT_FWI", "1",
                "-p", "tcp", "-d", vm_ip, "--dport", "22",
                "-j", "ACCEPT"
            ]
            proc = await asyncio.create_subprocess_exec(
                *forward_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Add POSTROUTING masquerade
        async with get_kvm_semaphore():
            masquerade_cmd = [
                "sudo", "iptables", "-t", "nat", "-A", "POSTROUTING",
                "-p", "tcp", "-d", vm_ip, "--dport", "22",
                "-j", "MASQUERADE"
            ]
            proc = await asyncio.create_subprocess_exec(
                *masquerade_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        logging.info(f"Port forwarding configured: {ssh_port} -> {vm_ip}:22")
        await save_iptables_rules()
    except Exception as e:
        logging.error(f"Error setting up port forward: {e}")
        raise

async def remove_ssh_port_forward(vm_ip, ssh_port):
    """Removes iptables port forwarding rules - Enhanced cleanup"""
    try:
        # Remove INPUT rule (try without IP first, then with IP)
        for _ in range(3):  # Try multiple times in case of duplicates
            async with get_kvm_semaphore():
                proc = await asyncio.create_subprocess_exec(
                    "sudo", "iptables", "-D", "INPUT",
                    "-p", "tcp", "--dport", str(ssh_port),
                    "-j", "ACCEPT",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                await proc.communicate()
        
        # Remove PREROUTING rules - try with and without IP
        if vm_ip:
            for _ in range(3):
                async with get_kvm_semaphore():
                    proc = await asyncio.create_subprocess_exec(
                        "sudo", "iptables", "-t", "nat", "-D", "PREROUTING",
                        "-p", "tcp", "--dport", str(ssh_port),
                        "-j", "DNAT", "--to-destination", f"{vm_ip}:22",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    await proc.communicate()
        
        # Fallback: Remove ALL rules for this port (without IP specification)
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                f"iptables -t nat -S PREROUTING | grep 'dpt:{ssh_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Remove OUTPUT rules
        if vm_ip:
            for _ in range(3):
                async with get_kvm_semaphore():
                    proc = await asyncio.create_subprocess_exec(
                        "sudo", "iptables", "-t", "nat", "-D", "OUTPUT",
                        "-p", "tcp", "--dport", str(ssh_port),
                        "-j", "DNAT", "--to-destination", f"{vm_ip}:22",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    await proc.communicate()
        
        # Fallback: Remove ALL OUTPUT rules for this port
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                f"iptables -t nat -S OUTPUT | grep 'dpt:{ssh_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Remove from LIBVIRT_FWI
        if vm_ip:
            for _ in range(3):
                async with get_kvm_semaphore():
                    proc = await asyncio.create_subprocess_exec(
                        "sudo", "iptables", "-D", "LIBVIRT_FWI",
                        "-p", "tcp", "-d", vm_ip, "--dport", "22",
                        "-j", "ACCEPT",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    await proc.communicate()
        
        # Fallback: Remove ALL LIBVIRT_FWI rules for SSH to any IP
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                "iptables -S LIBVIRT_FWI | grep 'tcp dpt:22' | sed 's/-A/-D/' | while read rule; do iptables $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Remove POSTROUTING rules
        if vm_ip:
            for _ in range(3):
                async with get_kvm_semaphore():
                    proc = await asyncio.create_subprocess_exec(
                        "sudo", "iptables", "-t", "nat", "-D", "POSTROUTING",
                        "-p", "tcp", "-d", vm_ip, "--dport", "22",
                        "-j", "MASQUERADE",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    await proc.communicate()
        
        # Fallback: Remove ALL POSTROUTING rules for SSH
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                "iptables -t nat -S POSTROUTING | grep 'tcp dpt:22' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        logging.info(f"Port forwarding removed for port {ssh_port}")
        await save_iptables_rules()
    except Exception as e:
        logging.warning(f"Error removing port forward: {e}")


async def cleanup_orphaned_rules(ssh_port):
    """
    Nettoie toutes les règles orphelines pour un port donné
    Utile avant de recréer une VM avec le même port
    """
    try:
        logging.info(f"Cleaning up orphaned rules for port {ssh_port}")
        
        # Clean INPUT
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                f"iptables -S INPUT | grep 'dpt:{ssh_port}' | sed 's/-A/-D/' | while read rule; do iptables $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Clean PREROUTING
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                f"iptables -t nat -S PREROUTING | grep 'dpt:{ssh_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        # Clean OUTPUT
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c",
                f"iptables -t nat -S OUTPUT | grep 'dpt:{ssh_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        logging.info(f"Orphaned rules cleaned for port {ssh_port}")
        await save_iptables_rules()
        
    except Exception as e:
        logging.error(f"Error cleaning orphaned rules: {e}")

async def save_iptables_rules():
    """Saves current iptables rules to make them persistent."""
    try:
        # Tentative 1: netfilter-persistent (Debian/Ubuntu)
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "netfilter-persistent", "save",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode == 0:
            logging.info("iptables rules saved successfully with netfilter-persistent.")
            return
        
        # Tentative 2: iptables-save + restore service (universelle)
        logging.warning("netfilter-persistent not available, using iptables-save...")
        
        # Sauvegarder les règles
        async with get_kvm_semaphore():
            proc_save = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c", "iptables-save > /etc/iptables/rules.v4 && ip6tables-save > /etc/iptables/rules.v6",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout_save, stderr_save = await proc_save.communicate()
        
        if proc_save.returncode != 0:
            logging.error(f"Failed to save iptables rules: {stderr_save.decode()}")
            return
        
        logging.info("iptables rules saved to /etc/iptables/rules.v4 and rules.v6.")
        
        # Activer le service de restauration iptables au démarrage (Debian/Ubuntu)
        async with get_kvm_semaphore():
            proc_service = await asyncio.create_subprocess_exec(
                "sudo", "bash", "-c", "systemctl enable netfilter-persistent 2>/dev/null || systemctl enable iptables-restore 2>/dev/null || true",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc_service.communicate()
        
        logging.info("iptables restore service enabled for boot persistence.")
        
    except Exception as e:
        logging.error(f"Error saving iptables rules: {e}")

async def cleanup_vm(vm_name):
    """Deletes a VM in case of error"""
    try:
        logging.info(f"Cleaning up VM {vm_name}")
        vm_ip = await get_vm_ip(vm_name)
        vps_info = db.get_vps_by_container_name(vm_name)
        if vps_info and vm_ip:
            await remove_ssh_port_forward(vm_ip, vps_info['ssh_port'])
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "destroy", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "undefine", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        async with get_kvm_semaphore():
            disk_path = f"/var/lib/libvirt/images/{vm_name}.qcow2"
            iso_path = f"/var/lib/libvirt/images/{vm_name}-cloud.iso"
            proc = await asyncio.create_subprocess_exec(
                "sudo", "rm", "-f", disk_path, iso_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        logging.info(f"VM {vm_name} cleaned up")
    except Exception as e:
        logging.error(f"Failed to cleanup {vm_name}: {e}")

async def delete_vm(vm_name):
    """Gracefully deletes a VM"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "list", "--all", "--name",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        if vm_name not in stdout.decode():
            logging.info(f"VM {vm_name} does not exist.")
            return True
        
        vps_info = db.get_vps_by_container_name(vm_name)
        vm_ip = vps_info.get('ip_address') if vps_info else None
        
        await stop_vm(vm_name, force=True)
        await asyncio.sleep(2)
        
        custom_ports = db.get_port_forwards_for_container(vm_name)
        if custom_ports:
            logging.info(f"Deleting {len(custom_ports)} custom port forwards for {vm_name}.")
            for port_info in custom_ports:
                await delete_port_forward_vm(vm_name, port_info['external_port'])

        if vps_info and vm_ip:
            await remove_ssh_port_forward(vm_ip, vps_info['ssh_port'])
        elif vps_info:
            logging.warning(f"IP address not found in database for {vm_name}. Attempting to remove port forward by port number only.")
            await remove_ssh_port_forward(None, vps_info['ssh_port'])
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "undefine", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, "virsh undefine", stderr=stderr)
        
        async with get_kvm_semaphore():
            disk_path = f"/var/lib/libvirt/images/{vm_name}.qcow2"
            iso_path = f"/var/lib/libvirt/images/{vm_name}-cloud.iso"
            proc = await asyncio.create_subprocess_exec(
                "sudo", "rm", "-f", disk_path, iso_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        
        logging.info(f"VM {vm_name} deleted successfully")
        run_port_cleanup()
        return True
    except Exception as e:
        logging.error(f"Error deleting {vm_name}: {e}")
        return False

async def stop_vm(vm_name, force=False):
    """Stops a KVM VM"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "domstate", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        state = stdout.decode().strip().lower()
        
        if "shut off" in state:
            logging.info(f"VM {vm_name} already stopped.")
            return None
        
        cmd = ["sudo", "virsh", "shutdown" if not force else "destroy", vm_name]
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"virsh stop command failed for {vm_name}: {stderr.decode()}")
                return False
        
        logging.info(f"VM {vm_name} stopped.")
        return True
    except Exception as e:
        logging.error(f"Failed to stop VM: {e}")
        return False

async def start_vm(vm_name):
    """Starts a KVM VM"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "domstate", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        state = stdout.decode().strip().lower()
        
        if "running" in state:
            logging.info(f"VM {vm_name} already running.")
            return None
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "start", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise subprocess.CalledProcessError(proc.returncode or 1, "virsh start", stderr=stderr)
        
        logging.info(f"VM {vm_name} started.")
        return True
    except Exception as e:
        logging.error(f"Failed to start VM: {e}")
        return False

async def is_vm_running(vm_name):
    """Checks if a VM is running"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "domstate", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.warning(f"Could not get state for {vm_name}: {stderr.decode().strip()}")
            return False
        return "running" in stdout.decode().strip().lower()
    except Exception as e:
        logging.error(f"Exception checking status for {vm_name}: {e}")
        return False

async def get_vm_info(vm_name):
    """Retrieves VM information"""
    dominfo_proc, domstats_proc = None, None
    try:
        # Lancer les commandes en parallèle
        async with get_kvm_semaphore():
            dominfo_proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "dominfo", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
        async with get_kvm_semaphore():
            domstats_proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "domstats", vm_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

        # Attendre les résultats avec des timeouts
        try:
            stdout_info, stderr_info = await asyncio.wait_for(dominfo_proc.communicate(), timeout=15.0)
            if dominfo_proc.returncode != 0:
                logging.error(f"virsh dominfo failed for {vm_name}: {stderr_info.decode().strip()}")
                return None
        except asyncio.TimeoutError:
            logging.error(f"Timeout getting dominfo for {vm_name}")
            if dominfo_proc and dominfo_proc.returncode is None:
                dominfo_proc.kill()
            return None

        try:
            stdout_stats, _ = await asyncio.wait_for(domstats_proc.communicate(), timeout=15.0)
        except asyncio.TimeoutError:
            logging.warning(f"Timeout getting domstats for {vm_name}")
            if domstats_proc and domstats_proc.returncode is None:
                domstats_proc.kill()
            stdout_stats = b'' # Continuer sans les statistiques

        info = {}
        # Parser dominfo
        if stdout_info:
            for line in stdout_info.decode().split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    info[key.strip()] = value.strip()

        # Extraire la RAM depuis dominfo
        max_mem_str = info.get('Max memory', '0 KiB')
        try:
            max_mem_kib = int(re.search(r'(\d+)', max_mem_str).group(1))
            info['ram_gb'] = round(max_mem_kib / 1024 / 1024, 2)
        except (ValueError, AttributeError):
            info['ram_gb'] = 0.0

        # Obtenir l'IP
        vm_ip = await get_vm_ip(vm_name)
        info['ipv4'] = vm_ip
        info['status'] = info.get('State', 'unknown').lower()
        
        # Parser domstats
        if stdout_stats:
            for line in stdout_stats.decode().split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    info[key.strip()] = value.strip()
        
        return info
        
    except Exception as e:
        logging.error(f"Error getting info for {vm_name}: {e}")
        # S'assurer que les processus sont terminés
        for proc in [dominfo_proc, domstats_proc]:
            if proc and proc.returncode is None:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
        return None

async def list_user_vms(user_id):
    """Lists all VMs for a user"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "list", "--all", "--name",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        all_vms = stdout.decode().strip().split('\n')
        return [vm for vm in all_vms if vm and f"-{user_id}-" in vm]
    except Exception as e:
        logging.error(f"Error listing VMs: {e}")
        return []

async def add_port_forward_vm(vm_name, external_port, internal_port):
    """Adds a port forwarding rule for a VM - FIXED VERSION"""
    try:
        external_port = int(external_port)
        internal_port = int(internal_port)
        
        if not (1024 <= external_port <= 65535):
            logging.error(f"External port {external_port} out of valid range (1024-65535)")
            return False
            
        if not (1 <= internal_port <= 65535):
            logging.error(f"Internal port {internal_port} out of valid range (1-65535)")
            return False
        
        if not await is_vm_running(vm_name):
            logging.error(f"VM {vm_name} is not running")
            return False
        
        existing_forward = db.get_port_forward_by_external_port(external_port, 'tcp')
        if existing_forward:
            logging.error(f"Port {external_port} is already forwarded to {existing_forward['container_name']}")
            return False
        
        if is_port_in_use(external_port):
            logging.error(f"Port {external_port} is already in use on the system")
            return False
        
        vm_ip = await get_vm_ip(vm_name)
        if not vm_ip:
            logging.warning(f"IP not immediately available, waiting...")
            await asyncio.sleep(3)
            vm_ip = await get_vm_ip(vm_name)
            
        if not vm_ip:
            logging.error(f"Could not find IP address for {vm_name}")
            return False
        
        logging.info(f"Adding port forward: external={external_port} -> {vm_ip}:{internal_port}")
        
        async with get_kvm_semaphore():
            input_cmd = [
                "sudo", "iptables", "-I", "INPUT", "1",
                "-p", "tcp", "--dport", str(external_port),
                "-j", "ACCEPT"
            ]
            proc = await asyncio.create_subprocess_exec(
                *input_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to add INPUT rule: {stderr.decode()}")
                return False
        logging.info("✓ INPUT rule added")
        
        async with get_kvm_semaphore():
            prerouting_cmd = [
                "sudo", "iptables", "-t", "nat", "-I", "PREROUTING", "1",
                "-p", "tcp", "--dport", str(external_port),
                "-j", "DNAT", "--to-destination", f"{vm_ip}:{internal_port}"
            ]
            proc = await asyncio.create_subprocess_exec(
                *prerouting_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to add PREROUTING rule: {stderr.decode()}")
                async with get_kvm_semaphore():
                    await asyncio.create_subprocess_exec(
                        "sudo", "iptables", "-D", "INPUT",
                        "-p", "tcp", "--dport", str(external_port),
                        "-j", "ACCEPT"
                    )
                return False
        logging.info("✓ PREROUTING rule added")
        
        async with get_kvm_semaphore():
            output_cmd = [
                "sudo", "iptables", "-t", "nat", "-I", "OUTPUT", "1",
                "-p", "tcp", "--dport", str(external_port),
                "-j", "DNAT", "--to-destination", f"{vm_ip}:{internal_port}"
            ]
            proc = await asyncio.create_subprocess_exec(
                *output_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        logging.info("✓ OUTPUT rule added")
        
        async with get_kvm_semaphore():
            forward_cmd = [
                "sudo", "iptables", "-I", "LIBVIRT_FWI", "1",
                "-p", "tcp", "-d", vm_ip, "--dport", str(internal_port),
                "-j", "ACCEPT"
            ]
            proc = await asyncio.create_subprocess_exec(
                *forward_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logging.error(f"Failed to add LIBVIRT_FWI rule: {stderr.decode()}")
            else:
                logging.info("✓ LIBVIRT_FWI rule added")
        
        async with get_kvm_semaphore():
            masquerade_cmd = [
                "sudo", "iptables", "-t", "nat", "-A", "POSTROUTING",
                "-p", "tcp", "-d", vm_ip, "--dport", str(internal_port),
                "-j", "MASQUERADE"
            ]
            proc = await asyncio.create_subprocess_exec(
                *masquerade_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        logging.info("✓ POSTROUTING rule added")
        
        async with get_kvm_semaphore():
            forward_backup_cmd = [
                "sudo", "iptables", "-I", "FORWARD", "1",
                "-p", "tcp", "-d", vm_ip, "--dport", str(internal_port),
                "-j", "ACCEPT"
            ]
            proc = await asyncio.create_subprocess_exec(
                *forward_backup_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
        logging.info("✓ FORWARD backup rule added")
        
        device_name = f"port{external_port}"
        db.add_port_forward_entry(vm_name, external_port, internal_port, 'tcp', device_name)
        logging.info(f"✓ Database entry created: {device_name}")
        
        await save_iptables_rules()
        logging.info("✓ iptables rules saved")
        
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "iptables", "-t", "nat", "-L", "PREROUTING", "-n", "-v",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
        if str(external_port) in stdout.decode():
            logging.info(f"✓ Verified: Port forwarding {external_port} -> {vm_ip}:{internal_port} is active")
        else:
            logging.warning(f"⚠ Warning: Could not verify rule in iptables output")
        
        return True
        
    except ValueError as e:
        logging.error(f"Invalid port number: {e}")
        return False
    except Exception as e:
        logging.error(f"Error adding port forward: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False

async def delete_port_forward_vm(vm_name, external_port):
    """Deletes a port forwarding rule for a VM - FIXED VERSION"""
    try:
        external_port = int(external_port)
        
        forward_entry = db.get_port_forward_by_external_port(external_port, 'tcp')
        if not forward_entry or forward_entry['container_name'] != vm_name:
            logging.error(f"Port forward entry not found or doesn't belong to {vm_name}")
            return False
        
        internal_port = forward_entry['internal_port']
        vm_ip = await get_vm_ip(vm_name)
        
        if not vm_ip:
            logging.warning(f"VM IP not found, attempting cleanup by port only")
        
        rules_to_remove = [
            ["sudo", "iptables", "-D", "INPUT", "-p", "tcp", "--dport", str(external_port), "-j", "ACCEPT"],
            ["sudo", "iptables", "-t", "nat", "-D", "PREROUTING", "-p", "tcp", "--dport", str(external_port), 
             "-j", "DNAT", "--to-destination", f"{vm_ip}:{internal_port}"] if vm_ip else None,
            ["sudo", "iptables", "-t", "nat", "-D", "OUTPUT", "-p", "tcp", "--dport", str(external_port), 
             "-j", "DNAT", "--to-destination", f"{vm_ip}:{internal_port}"] if vm_ip else None,
            ["sudo", "iptables", "-D", "LIBVIRT_FWI", "-p", "tcp", "-d", vm_ip, 
             "--dport", str(internal_port), "-j", "ACCEPT"] if vm_ip else None,
            ["sudo", "iptables", "-D", "FORWARD", "-p", "tcp", "-d", vm_ip, 
             "--dport", str(internal_port), "-j", "ACCEPT"] if vm_ip else None,
            ["sudo", "iptables", "-t", "nat", "-D", "POSTROUTING", "-p", "tcp", "-d", vm_ip, 
             "--dport", str(internal_port), "-j", "MASQUERADE"] if vm_ip else None,
        ]
        
        for rule in rules_to_remove:
            if rule is None:
                continue
            for _ in range(3):
                async with get_kvm_semaphore():
                    proc = await asyncio.create_subprocess_exec(
                        *rule,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await proc.communicate()
                if proc.returncode != 0:
                    break
        
        cleanup_commands = [
            f"iptables -t nat -S PREROUTING | grep 'dpt:{external_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
            f"iptables -t nat -S OUTPUT | grep 'dpt:{external_port}' | sed 's/-A/-D/' | while read rule; do iptables -t nat $rule 2>/dev/null; done",
            f"iptables -S INPUT | grep 'dpt:{external_port}' | sed 's/-A/-D/' | while read rule; do iptables $rule 2>/dev/null; done",
        ]
        
        for cmd in cleanup_commands:
            async with get_kvm_semaphore():
                proc = await asyncio.create_subprocess_exec(
                    "sudo", "bash", "-c", cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                await proc.communicate()
        
        device_name = forward_entry['device_name']
        db.remove_port_forward_entry(device_name)
        
        await save_iptables_rules()
        
        logging.info(f"Port forwarding removed: {external_port} -> {internal_port}")
        return True
        
    except Exception as e:
        logging.error(f"Error deleting port forward: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False

def list_port_forwards_vm(vm_name):
    """Lists existing port forwarding rules for a VM"""
    try:
        forwards_db = db.get_port_forwards_for_container(vm_name)
        return [f"{f['external_port']}/{f['protocol']} -> {f['internal_port']}" for f in forwards_db]
    except Exception as e:
        logging.error(f"Error listing port forwards: {e}")
        return []

async def reinstall_vm(old_vm_name, progress_callback=None):
    """Reinstalls a KVM VM"""
    try:
        if progress_callback:
            await progress_callback(5, "Fetching VM information...")
            await asyncio.sleep(2)

        vps_info = db.get_vps_by_container_name(old_vm_name)
        if not vps_info:
            logging.error(f"VPS info not found for {old_vm_name}")
            if progress_callback:
                await progress_callback(0, "Failed: VPS information not found.")
            return None, None, None, None, None

        user_id = vps_info['user_id']
        username = vps_info['username'] or f"user-{user_id}"
        cpu = vps_info['cpu']
        ram = vps_info['ram']
        disk = vps_info['disk']

        if progress_callback:
            await progress_callback(15, f"Deleting old VM {old_vm_name}...")

        if not await delete_vm(old_vm_name):
            if progress_callback:
                await progress_callback(0, "Failed: Could not delete old VM.")
            return None, None, None, None, None

        if progress_callback:
            await progress_callback(25, "Removing old VPS entry from database...")

        db.delete_vps_by_container_name(old_vm_name)

        if progress_callback:
            await progress_callback(30, "Creating new VM...")

        new_vm_name, ssh_connection, ssh_port, ssh_password, vm_ip, _, _ = await create_kvm_vm(user_id, username, cpu, ram, disk, progress_callback=progress_callback)

        if new_vm_name:
            logging.info(f"VM reinstalled as {new_vm_name}")
            if progress_callback:
                await progress_callback(100, f"Reinstallation complete: {new_vm_name}")
            run_port_cleanup()
            return new_vm_name, ssh_connection, ssh_port, ssh_password, vm_ip
        else:
            if progress_callback:
                await progress_callback(0, "Failed: Could not create new VM.")
            return None, None, None, None, None

    except Exception as e:
        logging.error(f"Error during reinstall: {str(e)}")
        if progress_callback:
            await progress_callback(0, f"Reinstallation failed: {str(e)}")
        return None, None, None, None, None

async def regenerate_ssh_link_vm(vm_name):
    """Regenerates the SSH connection string for a VM"""
    vps_info = db.get_vps_by_container_name(vm_name)
    if vps_info and vps_info['ssh_port']:
        ssh_port = vps_info['ssh_port']
        ssh_connection = f"ssh root@jupyterhive.duckdns.org -p {ssh_port}"
        return ssh_connection
    return None

async def get_active_vm_count():
    """Returns the number of running VMs"""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "list", "--state-running", "--name",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode == 0:
            vms = [vm for vm in stdout.decode().strip().split('\n') if vm]
            return len(vms)
        else:
            logging.error(f"virsh list command failed: {stderr.decode()}")
            return None
    except Exception as e:
        logging.error(f"Error getting active VM count: {e}")
        return None

async def get_total_vm_count():
    """Returns the total number of KVM VMs, regardless of status."""
    try:
        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                "sudo", "virsh", "list", "--all", "--name",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
        if proc.returncode == 0:
            vms = [vm for vm in stdout.decode().strip().split('\n') if vm]
            return len(vms)
        else:
            logging.error(f"virsh list --all command failed: {stderr.decode()}")
            return None
    except Exception as e:
        logging.error(f"Error getting total VM count: {e}")
        return None

async def enable_ssh_password_auth_vm(vm_name: str) -> bool:
    """
    Ensures SSH password authentication is enabled in the VM and re-applies port forwarding.
    """
    try:
        if not await is_vm_running(vm_name):
            logging.info(f"Starting VM {vm_name} to fix SSH...")
            await start_vm(vm_name)
            await asyncio.sleep(20) # Wait for boot

        vps_info = db.get_vps_by_container_name(vm_name)
        if not vps_info:
            logging.error(f"Could not find VPS info for {vm_name} in database.")
            return False

        ssh_port = vps_info.get('ssh_port')
        ssh_password = vps_info.get('ssh_password')
        vm_ip = vps_info.get('ip_address') or await get_vm_ip(vm_name)

        if not all([ssh_port, ssh_password, vm_ip]):
            logging.error(f"Missing SSH credentials for {vm_name}.")
            return False

        logging.info(f"Configuring SSH for password authentication in {vm_name}...")

        ssh_fix_script = """
set -e
mkdir -p /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/99-enable-password.conf << 'SSHEOF'
PasswordAuthentication yes
PermitRootLogin yes
PubkeyAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
SSHEOF
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
grep -q "^PasswordAuthentication" /etc/ssh/sshd_config || echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config
grep -q "^PermitRootLogin" /etc/ssh/sshd_config || echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
systemctl restart ssh || systemctl restart sshd || service ssh restart
"""

        process_env = os.environ.copy()
        process_env["SSHPASS"] = ssh_password

        ssh_command = [
            "sshpass", "-e",
            "ssh",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "ConnectTimeout=20",
            "-p", str(ssh_port),
            f"root@{vm_ip}",
            "bash", "-c", ssh_fix_script
        ]

        async with get_kvm_semaphore():
            proc = await asyncio.create_subprocess_exec(
                *ssh_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=process_env
            )

            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=60.0)

        if proc.returncode != 0:
            logging.error(f"Failed to execute SSH fix script in {vm_name}: {stderr.decode()}")
        else:
            logging.info(f"SSH password authentication enabled for {vm_name}. Output: {stdout.decode()}")

        # Re-apply port forwarding rules
        logging.info(f"Re-applying port forwarding rules for {vm_name}...")
        
        if vm_ip and ssh_port:
            await remove_ssh_port_forward(vm_ip, ssh_port) # Clean old rules first
            await setup_ssh_port_forward(vm_ip, ssh_port)
            logging.info(f"Re-applied SSH port forward for {vm_name} ({ssh_port} -> {vm_ip}:22)")

        custom_ports = db.get_port_forwards_for_container(vm_name)
        if custom_ports:
            logging.info(f"Re-applying {len(custom_ports)} custom port forwards for {vm_name}.")
            for port_info in custom_ports:
                external_port = port_info['external_port']
                internal_port = port_info['internal_port']
                await delete_port_forward_vm(vm_name, external_port) # Clean old rules
                await add_port_forward_vm(vm_name, external_port, internal_port)
                logging.info(f"Re-applied custom port forward for {vm_name} ({external_port} -> {internal_port})")

        return True

    except Exception as e:
        logging.error(f"Error enabling SSH password auth or reapplying ports for {vm_name}: {e}")
        return False

def run_port_cleanup():
    """Runs the port cleanup script in the background."""
    try:
        logging.info("Starting port cleanup script...")
        subprocess.Popen(
            [sys.executable, "utils/port-delete.py"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        logging.info("Port cleanup script started in background.")
        return True
    except Exception as e:
        logging.error(f"Failed to start port cleanup script: {e}")
        return False