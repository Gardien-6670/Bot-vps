import asyncio
from typing import Dict, Optional

class ProgressTracker:
    """Simple progress tracker for async operations"""
    
    def __init__(self):
        self._operations: Dict[str, dict] = {}
    
    async def start_operation(self, operation_id: str, operation_type: str):
        """Start tracking a new operation"""
        self._operations[operation_id] = {
            "type": operation_type,
            "percentage": 0,
            "message": "Starting...",
            "status": "in_progress",
            "completed": False
        }
    
    async def update_progress(self, operation_id: str, percentage: int, message: str):
        """Update progress of an operation"""
        if operation_id in self._operations:
            self._operations[operation_id]["percentage"] = percentage
            self._operations[operation_id]["message"] = message
    
    async def complete_operation(self, operation_id: str, result: dict | None = None):
        """Mark operation as complete"""
        if operation_id in self._operations:
            self._operations[operation_id]["status"] = "completed"
            self._operations[operation_id]["percentage"] = 100
            self._operations[operation_id]["completed"] = True
            self._operations[operation_id]["message"] = "Operation completed successfully"
            if result is not None:
                # Attach result payload for consumers
                self._operations[operation_id]["result"] = result
    
    async def fail_operation(self, operation_id: str, error_message: str = "Operation failed"):
        """Mark operation as failed"""
        if operation_id in self._operations:
            self._operations[operation_id]["status"] = "failed"
            self._operations[operation_id]["completed"] = True  # Mark as completed so bot knows it's done
            self._operations[operation_id]["message"] = error_message
    
    async def get_operation_status(self, operation_id: str) -> Optional[dict]:
        """Coroutine to return the operation status (async-friendly)"""
        return self._operations.get(operation_id)
    
    def get_progress_sync(self, operation_id: str) -> Optional[dict]:
        """Get progress of an operation (synchronous)"""
        return self._operations.get(operation_id)
    
    def get_all_operations(self) -> Dict[str, dict]:
        """Get all operations"""
        return self._operations.copy()
    
    def clear_operation(self, operation_id: str):
        """Remove an operation from tracking"""
        if operation_id in self._operations:
            del self._operations[operation_id]


# Global instance
progress_tracker = ProgressTracker()
