import asyncio
import logging
import re
import subprocess
import json
import sys
import os

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.database import db

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

async def run_command(command):
    """Runs a shell command and returns its stdout."""
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            logging.error(f"Command failed: {command}\nStderr: {stderr.decode().strip()}")
            return None
        return stdout.decode().strip()
    except Exception as e:
        logging.error(f"Exception running command {command}: {e}")
        return None

async def get_all_kvm_vm_ips():
    """Gets all running KVM VMs and their IP addresses."""
    logging.info("Fetching KVM VM IPs...")
    vm_ips = {}
    vm_list_output = await run_command("sudo virsh list --state-running --name")
    if not vm_list_output:
        logging.warning("Could not list running KVM VMs.")
        return vm_ips

    running_vms = [vm for vm in vm_list_output.split('\n') if vm]
    logging.info(f"Found running KVM VMs: {running_vms}")

    for vm_name in running_vms:
        ip_output = await run_command(f"sudo virsh domifaddr {vm_name}")
        if ip_output:
            match = re.search(r'(\d+\.\d+\.\d+\.\d+)/\d+', ip_output)
            if match:
                ip = match.group(1)
                if ip and not ip.startswith("127."):
                    vm_ips[vm_name] = ip
                    logging.info(f"Found IP {ip} for KVM VM {vm_name}")
    return vm_ips

async def get_all_lxc_container_ips():
    """Gets all running LXC containers and their IP addresses."""
    logging.info("Fetching LXC container IPs...")
    container_ips = {}
    lxc_list_output = await run_command("lxc list --format=json")
    if not lxc_list_output:
        logging.warning("Could not list LXC containers.")
        return container_ips

    try:
        containers = json.loads(lxc_list_output)
        for container in containers:
            if container['status'].lower() == 'running':
                container_name = container['name']
                if 'state' in container and container['state'] and 'network' in container['state'] and container['state']['network']:
                    for iface, net_info in container['state']['network'].items():
                        if 'addresses' in net_info:
                            for addr in net_info['addresses']:
                                if addr['family'] == 'inet' and not addr['address'].startswith('127.'):
                                    container_ips[container_name] = addr['address']
                                    logging.info(f"Found IP {addr['address']} for LXC container {container_name}")
                                    break
                        if container_name in container_ips:
                            break
    except json.JSONDecodeError as e:
        logging.error(f"Failed to parse LXC list JSON: {e}")

    return container_ips

async def update_or_remove_iptables_rule(port, old_ip, new_ip=None):
    """
    Met à jour une règle iptables existante vers une nouvelle IP,
    ou la supprime si new_ip est None.
    """
    if new_ip:
        logging.info(f"Updating iptables rules for port {port}: {old_ip} -> {new_ip}")
    else:
        logging.info(f"Removing iptables rules for port {port} with IP {old_ip}")
    
    tables_chains = [
        ("nat", "PREROUTING"),
        ("nat", "OUTPUT"),
        ("nat", "POSTROUTING"),
        ("filter", "INPUT"),
        ("filter", "LIBVIRT_FWI")
    ]
    
    for table, chain in tables_chains:
        # Lister les règles avec leurs numéros
        list_cmd = f"sudo iptables -t {table} -L {chain} -n --line-numbers 2>/dev/null"
        rules_output = await run_command(list_cmd)
        
        if not rules_output:
            continue
        
        lines_to_process = []
        for line in rules_output.split('\n'):
            # Chercher les règles contenant le port et l'ancienne IP
            if f"dpt:{port}" in line or f"--dport {port}" in line:
                if old_ip in line or (chain == "INPUT" and "ACCEPT" in line):
                    match = re.match(r'^(\d+)', line.strip())
                    if match:
                        lines_to_process.append(int(match.group(1)))
        
        # Traiter les règles en ordre inverse pour ne pas décaler les numéros
        for line_num in sorted(lines_to_process, reverse=True):
            if new_ip:
                # Récupérer la règle complète pour la modifier
                get_rule_cmd = f"sudo iptables -t {table} -S {chain} | sed -n '{line_num}p'"
                rule_str = await run_command(get_rule_cmd)
                
                if rule_str:
                    # Remplacer l'ancienne IP par la nouvelle
                    new_rule = rule_str.replace(old_ip, new_ip).replace('-A', '-I')
                    
                    # Supprimer l'ancienne règle
                    delete_cmd = f"sudo iptables -t {table} -D {chain} {line_num}"
                    await run_command(delete_cmd)
                    
                    # Ajouter la nouvelle règle
                    insert_cmd = new_rule.replace('-I', '-A')  # Utiliser -A pour ajouter à la fin
                    await run_command(f"sudo {insert_cmd}")
                    logging.info(f"Updated rule in {table}/{chain}: {old_ip} -> {new_ip}")
            else:
                # Supprimer la règle
                delete_cmd = f"sudo iptables -t {table} -D {chain} {line_num}"
                await run_command(delete_cmd)
                logging.info(f"Deleted rule #{line_num} in {table}/{chain}")
    
    # Sauvegarder les règles
    await run_command("sudo netfilter-persistent save")

async def cleanup_orphaned_and_duplicate_rules(active_ips_map):
    """
    Nettoie ou met à jour les règles iptables orphelines et dupliquées.
    Si une IP active existe pour un port, réutilise la règle.
    Sinon, supprime la règle.
    """
    logging.info("Cleaning up orphaned and duplicate iptables rules...")
    
    if not active_ips_map:
        logging.warning("No active KVM or LXC IPs found. Skipping cleanup.")
        return
    
    active_ips_set = set(active_ips_map.values())
    
    # Parser toutes les règles PREROUTING (port forwarding principal)
    rules_output = await run_command("sudo iptables -t nat -L PREROUTING -n --line-numbers")
    if not rules_output:
        logging.warning("Could not list PREROUTING rules.")
        return
    
    rules = rules_output.strip().split('\n')
    if len(rules) < 3:
        logging.info("No rules found in nat/PREROUTING.")
        return
    
    rules = rules[2:]  # Skip header lines
    
    # Grouper les règles par port
    rules_by_port = {}
    rule_pattern = re.compile(r'^(\d+)\s+.*?\s*DNAT\s+tcp\s+.*\s+tcp\s+dpt:(\d+)\s+to:([\d\.:]+)')
    
    for rule_line in rules:
        match = rule_pattern.search(rule_line.strip())
        if match:
            line_num = int(match.group(1))
            port = int(match.group(2))
            dest_ip = match.group(3).split(':')[0]
            
            if port not in rules_by_port:
                rules_by_port[port] = []
            rules_by_port[port].append({
                'line': line_num,
                'port': port,
                'ip': dest_ip,
                'rule_str': rule_line.strip()
            })
    
    # Traiter chaque port
    for port, port_rules in rules_by_port.items():
        active_rules = [r for r in port_rules if r['ip'] in active_ips_set]
        orphaned_rules = [r for r in port_rules if r['ip'] not in active_ips_set]
        
        if orphaned_rules:
            if active_rules:
                # Cas 1: Il y a des règles actives ET orphelines
                # -> Supprimer les orphelines, garder les actives
                logging.info(f"Port {port}: Found {len(orphaned_rules)} orphaned rules (keeping {len(active_rules)} active)")
                for rule in orphaned_rules:
                    await update_or_remove_iptables_rule(port, rule['ip'], new_ip=None)
            else:
                # Cas 2: Toutes les règles sont orphelines
                # -> Chercher une IP active à réutiliser ou supprimer
                logging.warning(f"Port {port}: All {len(orphaned_rules)} rules are orphaned")
                
                # Essayer de trouver une IP active à réutiliser
                if active_ips_map:
                    # Prendre la première IP active disponible
                    new_ip = list(active_ips_map.values())[0]
                    old_ip = orphaned_rules[0]['ip']
                    
                    logging.info(f"Port {port}: Reassigning orphaned rule to active IP {new_ip}")
                    await update_or_remove_iptables_rule(port, old_ip, new_ip=new_ip)
                    
                    # Supprimer les autres règles orphelines dupliquées
                    for rule in orphaned_rules[1:]:
                        await update_or_remove_iptables_rule(port, rule['ip'], new_ip=None)
                else:
                    # Aucune IP active, supprimer toutes les règles
                    for rule in orphaned_rules:
                        await update_or_remove_iptables_rule(port, rule['ip'], new_ip=None)
        
        # Gérer les duplicatas dans les règles actives
        if len(active_rules) > 1:
            logging.warning(f"Port {port}: Found {len(active_rules)} duplicate active rules, keeping only one")
            active_rules.sort(key=lambda r: r['line'])
            
            # Garder la première, supprimer les autres
            for rule in active_rules[1:]:
                await update_or_remove_iptables_rule(port, rule['ip'], new_ip=None)

async def cleanup_orphaned_lxc_proxies(active_containers):
    """Removes LXC proxy devices for non-existent containers."""
    logging.info("Cleaning up orphaned LXC proxy devices from database...")
    
    all_forwards = db.get_all_port_forwards()
    if not all_forwards:
        logging.info("No port forwards found in the database.")
        return

    active_container_names = set(active_containers.keys())

    for forward in all_forwards:
        container_name = forward['container_name']
        vps = db.get_vps_by_container_name(container_name)

        if not vps or vps.get('vps_type') != 'lxc':
            continue

        if container_name not in active_container_names:
            logging.warning(f"Found orphaned LXC proxy device in DB for non-existent/stopped container {container_name}. Removing entry.")
            db.remove_port_forward_entry(forward['device_name'])

async def delete_port_rules(port):
    """
    Supprime toutes les règles iptables pour un port donné.
    Version améliorée pour un nettoyage complet.
    """
    logging.info(f"Deleting ALL iptables rules for port {port}...")
    
    tables_chains = [
        ("nat", "PREROUTING"),
        ("nat", "OUTPUT"),
        ("nat", "POSTROUTING"),
        ("filter", "INPUT"),
        ("filter", "LIBVIRT_FWI")
    ]
    
    for table, chain in tables_chains:
        # Méthode robuste: lister et supprimer ligne par ligne
        while True:
            list_cmd = f"sudo iptables -t {table} -L {chain} -n --line-numbers 2>/dev/null | grep 'dpt:{port}'"
            rules_output = await run_command(list_cmd)
            
            if not rules_output:
                break
            
            # Prendre la première règle trouvée
            match = re.match(r'^(\d+)', rules_output.strip())
            if match:
                line_num = match.group(1)
                delete_cmd = f"sudo iptables -t {table} -D {chain} {line_num}"
                await run_command(delete_cmd)
                logging.info(f"Deleted rule #{line_num} for port {port} in {table}/{chain}")
            else:
                break
    
    logging.info("Saving updated iptables rules...")
    await run_command("sudo netfilter-persistent save")
    logging.info(f"All rules for port {port} deleted and saved.")

async def main():
    """Main function to run the cleanup process."""
    logging.info("Starting orphaned port cleanup job...")
    
    # Get active IPs and container names
    kvm_ips_map = await get_all_kvm_vm_ips()
    lxc_ips_map = await get_all_lxc_container_ips()
    
    # Combiner les deux maps
    all_active_ips_map = {**kvm_ips_map, **lxc_ips_map}
    
    # Cleanup iptables rules (update orphaned to active IPs or remove)
    await cleanup_orphaned_and_duplicate_rules(all_active_ips_map)
    
    # Cleanup LXC proxy devices from DB if container is gone
    await cleanup_orphaned_lxc_proxies(lxc_ips_map)
    
    logging.info("Orphaned port cleanup job finished.")

if __name__ == "__main__":
    # Add get_all_port_forwards to Database class if not present
    if not hasattr(db, 'get_all_port_forwards'):
        def get_all_port_forwards(self):
            results = self._execute("SELECT * FROM port_forwards", fetchall=True)
            return results if results else []
        db.get_all_port_forwards = get_all_port_forwards.__get__(db)

    if len(sys.argv) > 1:
        # Mode manuel: supprimer toutes les règles pour un port spécifique
        try:
            port_to_delete = int(sys.argv[1])
            asyncio.run(delete_port_rules(port_to_delete))
        except ValueError:
            logging.error("Invalid port number provided. Please provide an integer.")
            sys.exit(1)
    else:
        # Mode automatique: cleanup intelligent
        asyncio.run(main())