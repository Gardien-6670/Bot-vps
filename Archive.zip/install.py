#!/usr/bin/env python3
"""
Script principal d'installation automatique du système bot-vps
Remplace install_all.sh et tous les scripts shell
Peut s'exécuter avec ou sans le dossier api/
"""

import sys
import os
from pathlib import Path
import subprocess

# Ajouter le répertoire parent au PYTHONPATH
sys.path.insert(0, str(Path(__file__).parent))

# Fonctions de logging basiques (au cas où api.installer n'est pas disponible)
def basic_log_info(msg):
    print(f"[INFO] {msg}")

def basic_log_warn(msg):
    print(f"[WARN] {msg}")

def basic_log_error(msg):
    print(f"[ERROR] {msg}")

def basic_log_step(msg):
    print(f"[ÉTAPE] {msg}")

def basic_check_root():
    return os.geteuid() == 0

def basic_update_apt_cache():
    try:
        subprocess.run(['apt-get', 'update'], check=True, capture_output=True)
        return True
    except:
        return False

def basic_install_package(package):
    try:
        subprocess.run(['apt-get', 'install', '-y', package], check=True, capture_output=True)
        return True
    except:
        return False

def basic_create_env_file():
    """Crée un fichier .env basique"""
    env_file = Path(__file__).parent / '.env'
    if env_file.exists():
        basic_log_info("✓ Fichier .env existe déjà")
        return True
    
    try:
        env_content = """# Configuration Bot Discord
DISCORD_TOKEN=votre_token_discord
DISCORD_GUILD_ID=votre_guild_id

# Configuration Base de Données
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=votre_mot_de_passe
DB_NAME=vps

# Configuration API (si installation complète)
API_PORT=5000
API_HOST=0.0.0.0
"""
        env_file.write_text(env_content)
        basic_log_info("✓ Fichier .env créé")
        return True
    except Exception as e:
        basic_log_error(f"Échec de la création du .env: {e}")
        return False

# Essayer d'importer les modules de l'API (optionnel)
try:
    from api.installer import (
        log_info, log_warn, log_error, log_step,
        check_root, create_env_file, install_package, update_apt_cache
    )
    from api.installer.system_setup import setup_system
    from api.installer.image_setup import setup_images
    from api.installer.system_check import check_system
    API_AVAILABLE = True
except ImportError:
    # Utiliser les fonctions basiques si api/ n'est pas disponible
    log_info = basic_log_info
    log_warn = basic_log_warn
    log_error = basic_log_error
    log_step = basic_log_step
    check_root = basic_check_root
    create_env_file = basic_create_env_file
    install_package = basic_install_package
    update_apt_cache = basic_update_apt_cache
    API_AVAILABLE = False
    basic_log_warn("⚠️  Module api.installer non disponible, fonctionnalités limitées")


def show_menu():
    """Affiche le menu de sélection du type d'installation"""
    print()
    print("[1m" + "=" * 60 + "[0m")
    print("[1m" + " " * 15 + "MENU D'INSTALLATION" + " " * 27 + "[0m")
    print("[1m" + "=" * 60 + "[0m")
    print()
    print("[1mChoisissez le type d'installation :[0m")
    print()
    print("[92m  1.[0m Installation [1mCOMPLÈTE[0m")
    print("     • LXD + KVM + Images")
    print("     • Configuration réseau et stockage")
    print("     • Service systemd")
    print("     • Dépendances Python (API + Bot)")
    print()
    print("[93m  2.[0m Installation [1mBOT DISCORD UNIQUEMENT[0m")
    print("     • Dépendances Python du bot")
    print("     • Configuration .env")
    print("     • Pas de LXD/KVM")
    print()
    print("[91m  3.[0m Quitter")
    print()
    print("[1m" + "=" * 60 + "[0m")
    print()
    
    while True:
        try:
            choice = input("[1mVotre choix (1-3) :[0m ").strip()
            if choice in ['1', '2', '3']:
                return choice
            else:
                print("[91m⚠️  Choix invalide. Veuillez entrer 1, 2 ou 3.[0m")
        except (EOFError, KeyboardInterrupt):
            print()
            log_warn("Installation annulée par l'utilisateur")
            sys.exit(1)


def install_bot_dependencies_only():
    """Installe uniquement les dépendances du bot Discord"""
    print()
    print("=" * 60)
    print("[1mInstallation des Dépendances du Bot Discord[0m")
    print("=" * 60)
    print()
    
    project_root = Path(__file__).parent
    
    # Étape 1: Paquets système de base
    log_step("1/3 - Installation des paquets système de base...")
    print()
    
    base_packages = [
        'python3',
        'python3-pip',
        'python3-venv',
        'git',
        'curl',
        'wget'
    ]
    
    if not update_apt_cache():
        log_error("Échec de la mise à jour du cache apt")
        return False
    
    for package in base_packages:
        if not install_package(package):
            log_warn(f"Échec de l'installation de {package}, continuation...")
    
    log_info("✓ Paquets de base installés")
    print()
    
    # Étape 2: Dépendances Python
    log_step("2/3 - Installation des dépendances Python du bot...")
    print()
    
    venv_path = project_root / 'venv'
    requirements_file = project_root / 'requirements.txt'
    
    if not requirements_file.exists():
        log_error(f"Fichier {requirements_file} non trouvé")
        return False
    
    try:
        # Créer l'environnement virtuel
        if not venv_path.exists():
            log_info("Création de l'environnement virtuel...")
            os.system(f'python3 -m venv {venv_path}')
        
        # Installer les dépendances
        pip_path = venv_path / 'bin' / 'pip'
        log_info("Installation des dépendances Python...")
        
        os.system(f'{pip_path} install --upgrade pip')
        os.system(f'{pip_path} install -r {requirements_file}')
        
        log_info("✓ Dépendances Python installées")
    except Exception as e:
        log_error(f"Échec de l'installation des dépendances: {e}")
        return False
    
    print()
    
    # Étape 3: Configuration .env
    log_step("3/3 - Configuration du fichier .env...")
    print()
    
    if create_env_file():
        log_info("✓ Fichier .env configuré")
        log_warn("⚠️  N'oubliez pas d'éditer le fichier .env avec vos valeurs!")
    else:
        log_warn("Configuration du fichier .env échouée")
    
    print()
    print("=" * 60)
    print("[92m✓ Installation du bot terminée avec succès![0m")
    print("=" * 60)
    print()
    
    log_info("Composants installés:")
    print("  ✓ Paquets système de base (Python, pip, venv)")
    print("  ✓ Dépendances Python du bot")
    print("  ✓ Configuration .env")
    print()
    
    log_warn("⚠️  IMPORTANT: Actions requises")
    print()
    print("1. Éditez le fichier .env:")
    print("   nano .env")
    print()
    print("2. Démarrez le bot:")
    print("   cd bot")
    print("   python3 main.py")
    print()
    
    return True


def main():
    """Installation complète automatique"""
    
    print("=" * 60)
    print("Installation Automatique")
    print("Bot VPS - Système Autonome v2.0")
    print("=" * 60)
    
    # Vérifier les privilèges root
    if not check_root():
        log_error("Ce script doit être exécuté en tant que root (sudo)")
        print()
        print("Utilisation:")
        print("  sudo python3 install.py")
        sys.exit(1)
    
    # Afficher le menu et obtenir le choix
    choice = show_menu()
    
    if choice == '3':
        log_info("👋 Installation annulée")
        sys.exit(0)
    
    if choice == '2':
        # Installation bot uniquement
        if install_bot_dependencies_only():
            sys.exit(0)
        else:
            log_error("Échec de l'installation du bot")
            sys.exit(1)
    
    # Si choice == '1', continuer avec l'installation complète
    if not API_AVAILABLE:
        log_error("❌ Le dossier api/ est requis pour l'installation complète")
        log_error("Veuillez vous assurer que le dossier api/ existe")
        log_info("Ou choisissez l'option 2 (Bot Discord uniquement)")
        sys.exit(1)
    
    print()
    print("=" * 60)
    print("[1mInstallation Complète[0m")
    print("=" * 60)
    print()
    
    # ÉTAPE 1: Installation du système
    log_step("1/5 - Installation du système (LXD, KVM, dépendances)...")
    print()
    
    if not setup_system():
        log_error("Échec de l'installation du système")
        sys.exit(1)
    
    print()
    print("=" * 60)
    print()
    
    # ÉTAPE 2: Configuration des images
    log_step("2/5 - Configuration des images Debian 13...")
    print()
    
    if not setup_images():
        log_warn("Configuration des images échouée, mais continuation possible")
        log_info("Les images seront téléchargées automatiquement lors de la première utilisation")
    
    print()
    print("=" * 60)
    print()
    
    # ÉTAPE 3: Configuration du fichier .env
    log_step("3/5 - Configuration du fichier .env...")
    print()
    
    if create_env_file():
        log_info("✓ Fichier .env configuré")
        log_warn("⚠️  N'oubliez pas d'éditer le fichier .env avec vos valeurs!")
    else:
        log_warn("Configuration du fichier .env échouée")
    
    print()
    print("=" * 60)
    print()
    
    # ÉTAPE 4: Vérification du système
    log_step("4/5 - Vérification du système...")
    print()
    
    check_result = check_system()
    
    print()
    print("=" * 60)
    print()
    
    # ÉTAPE 5: Instructions finales
    log_step("5/5 - Configuration terminée")
    print()
    
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 15 + "Installation Terminée! ✓" + " " * 20 + "║")
    print("╚" + "=" * 58 + "╝")
    print()
    
    log_info("Composants installés:")
    print("  ✓ Paquets système (Python, snapd, etc.)")
    print("  ✓ LXD (via snap)")
    print("  ✓ KVM/QEMU")
    print("  ✓ Réseau LXD (lxdbr0)")
    print("  ✓ Stockage btrfs (default) ou dir en fallback")
    print("  ✓ Images Debian 13 (LXD et KVM)")
    print("  ✓ Dépendances Python")
    print("  ✓ Service systemd")
    print("  ✓ Configuration .env")
    print()
    
    log_warn("⚠️  IMPORTANT: Actions requises")
    print()
    print("1. Déconnectez-vous et reconnectez-vous")
    print("   (pour que les groupes lxd/libvirt prennent effet)")
    print()
    print("2. Éditez le fichier .env:")
    print("   nano .env")
    print()
    print("3. Démarrez l'API:")
    print("   sudo systemctl start bot-vps-api")
    print()
    print("4. Vérifiez les logs:")
    print("   sudo journalctl -u bot-vps-api -f")
    print()
    
    log_info("Commandes utiles:")
    print()
    print("  # Démarrer l'API")
    print("  sudo systemctl start bot-vps-api")
    print()
    print("  # Arrêter l'API")
    print("  sudo systemctl stop bot-vps-api")
    print()
    print("  # Voir les logs")
    print("  sudo journalctl -u bot-vps-api -f")
    print()
    print("  # Vérifier le système")
    print("  sudo python3 -m installer.system_check")
    print()
    print("  # Mettre à jour les images")
    print("  sudo python3 -m installer.image_setup")
    print()
    
    print("=" * 60)
    log_info("Installation terminée avec succès! 🎉")
    print("=" * 60)
    print()
    
    sys.exit(0 if check_result == 0 else 0)  # Toujours retourner 0 si installation réussie


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print()
        log_warn("Installation interrompue par l'utilisateur")
        sys.exit(1)
    except Exception as e:
        print()
        log_error(f"Erreur inattendue: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
