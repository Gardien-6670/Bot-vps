from bot.utils.database import db
from datetime import datetime, timedelta
import asyncio
import logging
import discord
from bot.utils import node_manager
from discord.ext import tasks
from bot.commands.plans import LXC_AD_TIERS # Import tier definitions

async def auto_renew_suspended_vps(bot: discord.Client):
    """
    Automatically renews suspended VPS if the user has enough credits or vps points.
    """
    all_vps = db.get_all_vps()
    suspended_vps = [vps for vps in all_vps if vps['is_suspended'] and (vps.get('suspension_reason') == 'suspended_for_non_payment' or vps.get('is_suspended') == 1)]

    for vps in suspended_vps:
        user_id = vps['user_id']
        vps_id = vps['id']
        container_name = vps['container_name']
        current_due_date = vps['due_date']
        
        is_free_tier = (vps.get('plan_tier') and vps['plan_tier'] != '') or \
                       (vps.get('invite_plan_tier') and vps['invite_plan_tier'] != '')

        renewed = False
        if is_free_tier:
            # FREE TIER (suspended): Use VPS points with dynamic cost
            plan_tier = vps.get('plan_tier')
            cost_vps_points = 1  # Default cost
            if plan_tier and plan_tier in LXC_AD_TIERS:
                cost_vps_points = LXC_AD_TIERS[plan_tier].get('ads_required', 1)
            
            user_vps_points = db.get_vps_points(user_id)
            if user_vps_points >= cost_vps_points:
                db.consume_vps_points(user_id, cost_vps_points)
                db.set_vps_due_date(vps_id, current_due_date + timedelta(days=1))
                db.unsuspend_vps(container_name)
                logging.info(f"Suspended FREE VPS {container_name} for user {user_id} has been automatically renewed for 1 day using {cost_vps_points} vps points.")
                renewed = True
        else:
            # PAID TIER (suspended): Use credits
            cost_credits = vps['cost_credits']
            balance = db.get_balance(user_id)
            if balance >= cost_credits:
                db.add_credits(user_id, -cost_credits) # Use add_credits for consistency
                db.set_vps_due_date(vps_id, current_due_date + timedelta(days=30))
                db.unsuspend_vps(container_name)
                logging.info(f"Suspended PAID VPS {container_name} for user {user_id} has been automatically renewed for 30 days using {cost_credits} credits.")
                renewed = True

        if renewed:
            # Skip dedicated servers - they don't use node API
            if vps.get('is_dedicated'):
                logging.info(f"VPS {container_name} (dedicated) renewed but not restarted via API.")
                continue
            
            # Start container via API
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                logging.error(f"Could not determine node for VPS {container_name}. Cannot start.")
                continue
            
            node_url, api_key = node_info['url'], node_info['api_key']
            vps_type = vps.get('vps_type', 'lxc')
            endpoint = f"/lxc/container/{container_name}/start" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/start"

            try:
                result = await node_manager.api_request('POST', endpoint, node_url, api_key)
                if result and result.get("status") == "success":
                    logging.info(f"VPS {container_name} for user {user_id} has been started after renewal.")
                else:
                    logging.error(f"Failed to start container {container_name} via API")
            except Exception as e:
                logging.error(f"Error starting VPS {container_name}: {e}")

@tasks.loop(hours=24)
async def check_vps_payments(bot: discord.Client):
    logging.info("Running daily VPS payment check for all active VPS...")
    all_vps = db.get_all_vps()
    now = datetime.now()

    for vps in all_vps:
        # This task only handles active (not suspended) VPS
        if vps.get('is_suspended'):
            continue

        if isinstance(vps['due_date'], str):
            due_date = datetime.fromisoformat(vps['due_date'])
        else:
            due_date = vps['due_date']
        
        # If not overdue, skip
        if now <= due_date:
            continue

        # From here, the active VPS is overdue and needs renewal or suspension
        user_id = vps['user_id']
        vps_id = vps['id']
        container_name = vps['container_name']

        user = None
        try:
            user = await bot.fetch_user(user_id)
        except discord.NotFound:
            logging.warning(f"User {user_id} not found, cannot send DM.")
        
        # Differentiate between free and paid tiers
        is_free_tier = (vps.get('plan_tier') and vps['plan_tier'] != '') or \
                       (vps.get('invite_plan_tier') and vps['invite_plan_tier'] != '')

        if is_free_tier:
            # --- Free Tier Renewal Logic with Dynamic Cost ---
            plan_tier = vps.get('plan_tier')
            cost_vps_points = 1  # Default cost
            if plan_tier and plan_tier in LXC_AD_TIERS:
                cost_vps_points = LXC_AD_TIERS[plan_tier].get('ads_required', 1)

            renewal_days = 1
            user_vps_points = db.get_vps_points(user_id)

            if user_vps_points >= cost_vps_points:
                db.consume_vps_points(user_id, cost_vps_points)
                db.set_vps_due_date(vps_id, due_date + timedelta(days=renewal_days))
                logging.info(f"Active FREE VPS {container_name} for user {user_id} renewed for {renewal_days} day using {cost_vps_points} VPS points.")
            else:
                # Not enough points, suspend
                db.suspend_vps(vps_id, reason='suspended_for_non_payment')
                logging.info(f"Active FREE VPS {container_name} for user {user_id} suspended due to insufficient VPS points ({user_vps_points}/{cost_vps_points}).")
                
                # Stop container via API
                node_info = node_manager.get_node_for_vps(container_name)
                if node_info:
                    node_url, api_key = node_info['url'], node_info['api_key']
                    vps_type = vps.get('vps_type', 'lxc')
                    endpoint = f"/lxc/container/{container_name}/stop" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/stop"
                    await node_manager.api_request('POST', endpoint, node_url, api_key, data={"force": True})
                
                if user:
                    embed = discord.Embed(
                        title="Free VPS Suspended",
                        description=f"Your free VPS `{container_name}` has been suspended because you do not have enough VPS Points to cover the daily renewal cost ({cost_vps_points} point/day).",
                        color=discord.Color.orange()
                    )
                    embed.add_field(name="Action Required", value="Please earn more VPS Points to reactivate your VPS. It will be automatically reactivated once you have sufficient points.")
                    try:
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send free VPS suspension DM to user {user_id}.")

        else: # Paid Tier
            # --- Paid Tier Renewal Logic ---
            cost_credits = vps['cost_credits']
            user_balance = db.get_balance(user_id)
            renewal_days = 30 

            if user_balance >= cost_credits:
                db.add_credits(user_id, -cost_credits) # Use add_credits for consistency
                db.set_vps_due_date(vps_id, due_date + timedelta(days=renewal_days))
                logging.info(f"Active PAID VPS {container_name} for user {user_id} has been renewed for {renewal_days} days.")
                if user:
                    try:
                        embed = discord.Embed(
                            title="Automatic VPS Renewal", 
                            description=f"Your VPS `{container_name}` has been automatically renewed for one more month. {cost_credits} credits have been deducted from your balance.", 
                            color=discord.Color.green()
                        )
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send paid renewal DM to user {user_id}.")
            else:
                # Not enough credits, suspend
                db.suspend_vps(vps_id, reason='suspended_for_non_payment')
                logging.info(f"Active PAID VPS {container_name} for user {user_id} is overdue and has been suspended.")
                
                # Stop container via API
                node_info = node_manager.get_node_for_vps(container_name)
                if node_info:
                    node_url, api_key = node_info['url'], node_info['api_key']
                    vps_type = vps.get('vps_type', 'lxc')
                    endpoint = f"/lxc/container/{container_name}/stop" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/stop"
                    await node_manager.api_request('POST', endpoint, node_url, api_key, data={"force": True})

                if user:
                    delete_timestamp = int((now + timedelta(days=2)).timestamp())
                    embed = discord.Embed(
                        title="VPS Payment Overdue",
                        description=f"Your VPS `{container_name}` has been suspended due to non-payment. You do not have enough credits ({user_balance}) to renew it for {cost_credits} credits.",
                        color=discord.Color.orange()
                    )
                    embed.add_field(
                        name="Deletion Date",
                        value=f"Your VPS will be permanently deleted <t:{delete_timestamp}:R> if not renewed.",
                        inline=False
                    )
                    try:
                        await user.send(embed=embed)
                    except discord.Forbidden:
                        logging.warning(f"Cannot send overdue DM to user {user_id}.")
                
                # This part handles the final deletion, it should be outside the active/overdue logic
                # For now, we let the suspended vps logic handle it. A better approach would be to have a separate cleanup task.
                # The existing logic for deletion was tied to the `status == 'overdue'` which is no longer set.
                # Let's keep it simple and focus on the renewal fix. The suspended vps task will handle reactivation.


async def start_vps_renewal_tasks(bot: discord.Client):
    """
    Starts the background tasks for VPS renewal.
    """
    @tasks.loop(minutes=2)
    async def auto_renewal_loop():
        try:
            await auto_renew_suspended_vps(bot)
        except Exception as e:
            logging.error(f"An error occurred in the auto-renewal task: {e}")

    @auto_renewal_loop.before_loop
    async def before_auto_renewal():
        await bot.wait_until_ready()
        logging.info("Auto-renewal task ready")

    @tasks.loop(hours=24)
    async def check_vps_payments_loop():
        try:
            await check_vps_payments(bot)
        except Exception as e:
            logging.error(f"An error occurred in the vps payment check task: {e}")

    @check_vps_payments_loop.before_loop
    async def before_check_payments():
        await bot.wait_until_ready()
        logging.info("VPS payment check task ready")

    auto_renewal_loop.start()
    check_vps_payments_loop.start()
