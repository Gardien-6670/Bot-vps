import logging
import asyncio
from datetime import datetime, timedelta
from bot.utils.database import db
import discord
import os
from . import node_manager

logger = logging.getLogger(__name__)

async def try_renew_vps(bot, user_id):
    """
    Tente de renouveler automatiquement les VPS en retard de paiement
    
    Args:
        bot: Instance du bot Discord
        user_id: ID de l'utilisateur
    """
    try:
        user_vps = db.get_user_vps(user_id)
        user_balance = db.get_balance(user_id)
        
        # Récupérer l'utilisateur Discord (optionnel pour les notifications)
        user = None
        try:
            user = await bot.fetch_user(user_id)
        except discord.NotFound:
            logger.warning(f"Discord user {user_id} not found")
        except Exception as e:
            logger.error(f"Error fetching Discord user {user_id}: {e}")
        
        # Parcourir tous les VPS de l'utilisateur
        if not user_vps:
            return

        for vps in user_vps:
            if vps['status'] == 'overdue':
                cost = vps['cost_credits']
                container_name = vps['container_name']
                
                # Vérifier si l'utilisateur a assez de crédits
                if user_balance >= cost:
                    # Débiter les crédits
                    db.add_credits(user_id, -cost)
                    user_balance -= cost
                    
                    # Mettre à jour la date d'échéance
                    db.update_vps_due_date(vps['id'])
                    
                    # Démarrer le conteneur via l'API
                    node_info = node_manager.get_node_for_vps(container_name)
                    if not node_info:
                        logger.error(f"Could not determine node for VPS {container_name}. Cannot start.")
                        continue
                    node_url, api_key = node_info['url'], node_info['api_key']

                    response = await node_manager.api_request(
                        "POST", 
                        f"/lxc/container/{container_name}/start",
                        node_url, api_key
                    )
                    
                    if response and response.get("status") == "success":
                        logger.info(f"Overdue VPS {container_name} for user {user_id} renewed and started")
                        
                        # Envoyer une notification à l'utilisateur
                        if user:
                            try:
                                embed = discord.Embed(
                                    title="VPS Renewed",
                                    description=f"Your overdue VPS `{container_name}` has been automatically renewed and is now starting.",
                                    color=discord.Color.green()
                                )
                                embed.add_field(name="Cost", value=f"{cost} credits", inline=True)
                                embed.add_field(name="Remaining Balance", value=f"{user_balance} credits", inline=True)
                                embed.timestamp = datetime.utcnow()
                                await user.send(embed=embed)
                            except discord.Forbidden:
                                logger.warning(f"Cannot send DM to user {user_id} (DMs disabled)")
                            except Exception as e:
                                logger.error(f"Error sending renewal notification to {user_id}: {e}")
                    else:
                        logger.error(f"Failed to start container {container_name}: {response}")
                else:
                    # Pas assez de crédits, envoyer une alerte
                    logger.warning(f"User {user_id} has insufficient credits for VPS {container_name} (needs {cost}, has {user_balance})")
                    
                    if user:
                        try:
                            embed = discord.Embed(
                                title="Insufficient Credits",
                                description=f"Your VPS `{container_name}` is overdue but you don't have enough credits for renewal.",
                                color=discord.Color.red()
                            )
                            embed.add_field(name="Required", value=f"{cost} credits", inline=True)
                            embed.add_field(name="Your Balance", value=f"{user_balance} credits", inline=True)
                            embed.add_field(name="Action Required", value="Please add credits to renew your VPS.", inline=False)
                            embed.timestamp = datetime.utcnow()
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            logger.warning(f"Cannot send DM to user {user_id} (DMs disabled)")
                        except Exception as e:
                            logger.error(f"Error sending insufficient credits notification to {user_id}: {e}")
    
    except Exception as e:
        logger.error(f"Error in try_renew_vps for user {user_id}: {e}")


async def check_all_vps_renewals(bot):
    """
    Vérifie tous les VPS pour les renouvellements automatiques
    Fonction à appeler périodiquement (par exemple, toutes les heures)
    
    Args:
        bot: Instance du bot Discord
    """
    try:
        logger.info("Starting VPS renewal check...")
        
        # Récupérer tous les utilisateurs avec des VPS
        users_with_vps = db.get_all_users_with_vps()
        
        if not users_with_vps:
            logger.info("No users with VPS found to check.")
            return

        renewal_count = 0
        for user_row in users_with_vps:
            user_id = user_row.get('user_id')
            if not user_id:
                continue
            try:
                await try_renew_vps(bot, user_id)
                renewal_count += 1
            except Exception as e:
                logger.error(f"Error checking renewals for user {user_id}: {e}")
        
        logger.info(f"VPS renewal check completed. Processed {renewal_count} users.")
    
    except Exception as e:
        logger.error(f"Error in check_all_vps_renewals: {e}")


async def check_expiring_vps(bot, days_before=3):
    """
    Vérifie les VPS qui vont expirer bientôt et envoie des notifications
    
    Args:
        bot: Instance du bot Discord
        days_before: Nombre de jours avant expiration pour envoyer l'alerte
    """
    try:
        logger.info(f"Checking for VPS expiring in {days_before} days...")
        
        expiring_vps = db.get_expiring_vps(days_before)
        if not expiring_vps:
            return
        
        for vps_info in expiring_vps:
            user_id = vps_info['user_id']
            container_name = vps_info['container_name']
            due_date = vps_info['due_date']
            cost = vps_info['cost_credits']
            
            try:
                user = await bot.fetch_user(user_id)
                user_balance = db.get_balance(user_id)
                
                # Calculer les jours restants
                days_remaining = (due_date - datetime.now()).days
                
                embed = discord.Embed(
                    title="VPS Expiration Warning",
                    description=f"Your VPS `{container_name}` will expire soon!",
                    color=discord.Color.orange()
                )
                embed.add_field(name="Days Remaining", value=f"{days_remaining} days", inline=True)
                embed.add_field(name="Renewal Cost", value=f"{cost} credits", inline=True)
                embed.add_field(name="Your Balance", value=f"{user_balance} credits", inline=True)
                
                if user_balance < cost:
                    embed.add_field(
                        name="Action Required",
                        value="You don't have enough credits for automatic renewal. Please add credits to avoid service interruption.",
                        inline=False
                    )
                else:
                    embed.add_field(
                        name="Auto-Renewal",
                        value="You have sufficient credits. Your VPS will be automatically renewed.",
                        inline=False
                    )
                
                embed.timestamp = datetime.utcnow()
                await user.send(embed=embed)
                
                logger.info(f"Sent expiration warning to user {user_id} for VPS {container_name}")
            
            except discord.NotFound:
                logger.warning(f"Discord user {user_id} not found")
            except discord.Forbidden:
                logger.warning(f"Cannot send DM to user {user_id} (DMs disabled)")
            except Exception as e:
                logger.error(f"Error sending expiration warning to user {user_id}: {e}")
    
    except Exception as e:
        logger.error(f"Error in check_expiring_vps: {e}")


async def suspend_expired_vps(bot):
    """
    Suspend les VPS qui ont dépassé leur date d'échéance et n'ont pas été renouvelés
    Fait des requêtes à l'API pour arrêter les conteneurs
    """
    try:
        logger.info("Checking for expired VPS to suspend...")
        
        expired_vps = db.get_expired_vps()
        
        if not expired_vps:
            return
        
        suspended_count = 0
        for vps_info in expired_vps:
            user_id = vps_info['user_id']
            container_name = vps_info['container_name']
            vps_id = vps_info['id']
            
            try:
                # Arrêter le conteneur via l'API
                node_info = node_manager.get_node_for_vps(container_name)
                if not node_info:
                    logger.error(f"Could not determine node for VPS {container_name}. Cannot suspend.")
                    continue
                node_url, api_key = node_info['url'], node_info['api_key']

                response = await node_manager.api_request(
                    "POST",
                    f"/lxc/container/{container_name}/stop",
                    node_url, api_key,
                    data={"force": True}
                )
                
                if response and response.get("status") == "success":
                    # Mettre à jour le statut en base de données
                    db.update_vps_status(vps_id, 'overdue')
                    
                    logger.info(f"Suspended expired VPS {container_name} for user {user_id}")
                    
                    # Notifier l'utilisateur
                    try:
                        user = await bot.fetch_user(user_id)
                        user_balance = db.get_balance(user_id)
                        
                        embed = discord.Embed(
                            title="VPS Suspended",
                            description=f"Your VPS `{container_name}` has been suspended due to non-payment.",
                            color=discord.Color.red()
                        )
                        embed.add_field(
                            name="What happened?",
                            value="Your VPS expired and could not be automatically renewed.",
                            inline=False
                        )
                        embed.add_field(
                            name="Your Balance",
                            value=f"{user_balance} credits",
                            inline=True
                        )
                        embed.add_field(
                            name="How to restore?",
                            value="Add credits to your account. Your VPS will be automatically restored when you have sufficient balance.",
                            inline=False
                        )
                        embed.timestamp = datetime.utcnow()
                        await user.send(embed=embed)
                    
                    except discord.NotFound:
                        logger.warning(f"Discord user {user_id} not found")
                    except discord.Forbidden:
                        logger.warning(f"Cannot send DM to user {user_id} (DMs disabled)")
                    except Exception as e:
                        logger.error(f"Error sending suspension notification to user {user_id}: {e}")
                    
                    suspended_count += 1
                else:
                    logger.error(f"Failed to stop container {container_name} via API: {response}")
            
            except Exception as e:
                logger.error(f"Error suspending VPS {container_name}: {e}")
        
        logger.info(f"Suspended {suspended_count} expired VPS.")
    
    except Exception as e:
        logger.error(f"Error in suspend_expired_vps: {e}")


# Fonction pour démarrer les tâches de billing périodiques
async def start_billing_tasks(bot):
    """
    Démarre les tâches de billing périodiques
    À appeler au démarrage du bot
    
    Args:
        bot: Instance du bot Discord
    """
    logger.info("Starting billing background tasks...")
    
    async def renewal_loop():
        """Boucle de renouvellement automatique (toutes les heures)"""
        while True:
            try:
                await check_all_vps_renewals(bot)
                await asyncio.sleep(3600)  # Toutes les heures
            except Exception as e:
                logger.error(f"Error in renewal loop: {e}")
                await asyncio.sleep(60)  # Réessayer après 1 minute en cas d'erreur
    
    async def expiration_check_loop():
        """Boucle de vérification des expirations (une fois par jour)"""
        while True:
            try:
                await check_expiring_vps(bot, days_before=3)
                await asyncio.sleep(86400)  # Une fois par jour
            except Exception as e:
                logger.error(f"Error in expiration check loop: {e}")
                await asyncio.sleep(3600)  # Réessayer après 1 heure en cas d'erreur
    
    async def suspension_loop():
        """Boucle de suspension des VPS expirés (toutes les heures)"""
        while True:
            try:
                await suspend_expired_vps(bot)
                await asyncio.sleep(3600)  # Toutes les heures
            except Exception as e:
                logger.error(f"Error in suspension loop: {e}")
                await asyncio.sleep(60)  # Réessayer après 1 minute en cas d'erreur
    
    # Lancer les tâches en arrière-plan
    asyncio.create_task(renewal_loop())
    asyncio.create_task(expiration_check_loop())
    asyncio.create_task(suspension_loop())
    
    logger.info("Billing background tasks started successfully")