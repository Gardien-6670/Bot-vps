import asyncio
import os
import google.generativeai as genai
from google.api_core import exceptions as google_exceptions
from discord.ext import tasks
from dotenv import load_dotenv
from bot.utils.database import db
import logging
import time
import json
import discord
from discord.ui import View, Button
import aiohttp
import re
from bot.utils import node_manager
import random
import traceback
from typing import Dict, List, Optional, Any
from datetime import datetime

load_dotenv()

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class PerMinuteRateLimiter:
    """Thread-safe rate limiter with semaphore"""
    def __init__(self, requests_per_minute: int):
        self.max_requests = requests_per_minute
        self.time_window = 60
        self.request_timestamps = []
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            while True:
                now = time.time()
                self.request_timestamps = [
                    ts for ts in self.request_timestamps 
                    if now - ts < self.time_window
                ]

                if len(self.request_timestamps) < self.max_requests:
                    self.request_timestamps.append(now)
                    break
                else:
                    oldest_request_time = self.request_timestamps[0]
                    time_to_wait = self.time_window - (now - oldest_request_time)
                    logger.info(f"Rate limit reached. Waiting for {time_to_wait:.2f} seconds.")
                    await asyncio.sleep(time_to_wait + 0.1)


class SurveillanceKVM:
    """Enhanced KVM VM surveillance system with improved security and performance"""
    
    def __init__(self, bot):
        self.bot = bot
        self.virustotal_api_key = os.getenv('VIRUSTOTAL_API_KEY')
        self.scan_semaphore = asyncio.Semaphore(3)  # Limit concurrent scans
        self.admin_user_id = 1047760053509312642
        
        # Initialize Gemini AI
        gemini_api_key = os.getenv("GEMINI_API_KEY")
        if not gemini_api_key:
            raise ValueError("GEMINI_API_KEY not found in .env file")
        
        genai.configure(api_key=gemini_api_key)
        self.primary_model = genai.GenerativeModel('gemini-2.5-pro')
        self.fallback_model = genai.GenerativeModel('gemini-2.5-flash-lite')
        self.fallback2_model = genai.GenerativeModel('gemini-2.0-flash-lite')
        self.primary_limiter = PerMinuteRateLimiter(20)
        self.fallback_limiter = PerMinuteRateLimiter(30)
        self.fallback2_limiter = PerMinuteRateLimiter(30)
        
        # Metrics tracking
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'false_positives': 0,
            'api_calls': 0
        }
        
        logger.info("=" * 70)
        logger.info("[KVM] SurveillanceKVM initialized")
        logger.info(f"[KVM] Bot instance: {self.bot}")
        logger.info(f"[KVM] VirusTotal API Key: {'Configured' if self.virustotal_api_key else 'NOT CONFIGURED'}")
        logger.info("[KVM] Gemini AI models configured")
        logger.info("=" * 70)

    @tasks.loop(hours=24)
    async def scan_kvm_filesystem(self):
        """Scan all KVM VMs for suspicious files and check with VirusTotal"""
        logger.info("[KVM] Starting filesystem scan for all KVM VMs")
        try:
            all_vps = db.get_all_vps()
            kvm_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'kvm']
            logger.info(f"[KVM] Found {len(kvm_vps)} KVM VMs to scan")
            
            for vps in kvm_vps:
                vm_name = vps['container_name']
                logger.debug(f"[KVM] Processing VM: {vm_name}")
                node_info = node_manager.get_node_for_vps(vm_name)
                if not node_info:
                    logger.warning(f"[KVM] No node found for VM: {vm_name}")
                    continue
                node_url, api_key = node_info['url'], node_info['api_key']
                try:
                    logger.info(f"[KVM] Scanning filesystem for {vm_name}")
                    await self.scan_filesystem_kvm(vm_name, node_url, api_key)
                    logger.info(f"[KVM] Successfully scanned {vm_name}")
                except Exception as e:
                    logger.error(f"[KVM] Error scanning filesystem for {vm_name}: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"[KVM] Error in scan_kvm_filesystem: {e}", exc_info=True)

    async def scan_filesystem_kvm(self, vm_name, node_url, api_key):
        """Scan filesystem of a KVM VM and check files with VirusTotal"""
        # 1. List suspicious files (example: /tmp, /var/tmp, /dev/shm)
        suspicious_paths = ['/tmp', '/var/tmp', '/dev/shm']
        files_to_scan = []
        for path in suspicious_paths:
            try:
                result = await node_manager.api_request('POST', f"/kvm/vm/{vm_name}/exec", node_url, api_key, data={"command": f"find {path} -type f -size -10M | head -n 20"})
                if result and result.get('output'):
                    files_to_scan += [f for f in result['output'].splitlines() if f.strip()]
            except Exception as e:
                logger.error(f"Error listing files in {path} for {vm_name}: {e}")
        # 2. For each file, get hash
        for filepath in files_to_scan:
            try:
                hash_result = await node_manager.api_request('POST', f"/kvm/vm/{vm_name}/exec", node_url, api_key, data={"command": f"sha256sum {filepath} | awk '{{print $1}}'"})
                file_hash = hash_result.get('output', '').strip() if hash_result else None
                if not file_hash or len(file_hash) != 64:
                    continue
                # 3. Query VirusTotal
                vt_result = await self.query_virustotal(file_hash)
                # 4. Save result in DB
                scan_data = {
                    'filepath': filepath,
                    'hash': file_hash,
                    'threat_level': vt_result.get('threat_level', 0) if vt_result else 0,
                    'detection_ratio': vt_result.get('detection_ratio') if vt_result else None,
                    'vt_positives': vt_result.get('positives') if vt_result else None,
                    'vt_total': vt_result.get('total') if vt_result else None,
                    'suspicious': vt_result.get('suspicious', False) if vt_result else False,
                    'official': False,
                    'quarantined': False,
                    'ai_decision': vt_result.get('ai_decision') if vt_result else None
                }
                db.save_file_scan_result(file_hash, scan_data)
            except Exception as e:
                logger.error(f"Error scanning file {filepath} in {vm_name}: {e}")

    async def query_virustotal(self, file_hash):
        if not self.virustotal_api_key:
            return None
        url = f"https://www.virustotal.com/api/v3/files/{file_hash}"
        headers = {"x-apikey": self.virustotal_api_key}
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    stats = data.get('data', {}).get('attributes', {}).get('last_analysis_stats', {})
                    positives = stats.get('malicious', 0)
                    total = sum(stats.values())
                    detection_ratio = f"{positives}/{total}" if total else None
                    return {
                        'threat_level': int(positives * 100 / total) if total else 0,
                        'detection_ratio': detection_ratio,
                        'positives': positives,
                        'total': total,
                        'suspicious': positives > 0,
                        'ai_decision': None
                    }
                return None

    async def _call_gemini_with_fallback(
        self, 
        prompt: str, 
        timeout: int = 60,
        use_primary_first: bool = True
    ) -> Optional[str]:
        """Call Gemini API with automatic fallback to flash-lite on quota errors (429)"""
        try:
            if use_primary_first:
                await self.primary_limiter.acquire()
                model = self.primary_model
                model_name = "gemini-2.5-pro"
            else:
                await self.fallback_limiter.acquire()
                model = self.fallback_model
                model_name = "gemini-2.5-flash-lite"
            
            response = await asyncio.wait_for(
                model.generate_content_async(prompt),
                timeout=timeout
            )
            
            if not response or not response.text:
                raise ValueError("Empty response from AI")
            
            return response.text.strip()
        
        except google_exceptions.ResourceExhausted as e:
            # Quota exceeded (429) - switch to fallback
            error_msg = str(e).lower()
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logger.warning(
                        f"[KVM] Gemini quota exceeded on {model_name}, switching to fallback model. "
                        f"Error: {str(e)[:200]}"
                    )
                    # Retry with first fallback
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logger.info("[KVM] Successfully used fallback model (gemini-2.5-flash-lite)")
                            return response.text.strip()
                    except google_exceptions.ResourceExhausted as fallback_e:
                        logger.warning(f"[KVM] First fallback also hit quota limit, trying second fallback (gemini-2.0-flash-lite)")
                        try:
                            await self.fallback2_limiter.acquire()
                            response = await asyncio.wait_for(
                                self.fallback2_model.generate_content_async(prompt),
                                timeout=timeout
                            )
                            if response and response.text:
                                logger.info("[KVM] Successfully used second fallback model (gemini-2.0-flash-lite)")
                                return response.text.strip()
                        except Exception as fallback2_e:
                            logger.error(f"[KVM] Second fallback model also failed: {fallback2_e}")
                            return None
                    except Exception as fallback_e:
                        logger.error(f"[KVM] Fallback model also failed: {fallback_e}")
                        return None
                else:
                    logger.error(f"[KVM] Fallback model also hit quota limit: {e}")
                    return None
            else:
                # Other ResourceExhausted error, try fallback anyway
                if use_primary_first:
                    logger.warning(f"[KVM] Resource exhausted on {model_name}, trying fallback...")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            return response.text.strip()
                    except Exception:
                        pass
                return None
        
        except asyncio.TimeoutError:
            logger.error(f"[KVM] Timeout calling Gemini API ({model_name})")
            return None
        
        except Exception as e:
            error_msg = str(e).lower()
            # Check if it's a quota/429 error in the message
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logger.warning(f"[KVM] Quota error detected, switching to fallback: {e}")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logger.info("[KVM] Successfully used fallback model after quota error")
                            return response.text.strip()
                    except Exception:
                        pass
            logger.error(f"[KVM] Error calling Gemini API ({model_name}): {e}")
            return None

    @tasks.loop(minutes=5)
    async def check_kvm_for_mining(self):
        logger.info("=" * 70)
        logger.info("[KVM] 🔍 check_kvm_for_mining: EXECUTING NOW")
        logger.info(f"[KVM] Timestamp: {datetime.now().isoformat()}")
        logger.info(f"[KVM] Bot instance available: {self.bot is not None}")
        logger.info("=" * 70)
        
        try:
            logger.info("[KVM] Starting mining check on all KVM VMs...")
            all_vps = db.get_all_vps()
            logger.info(f"[KVM] Total VPS in database: {len(all_vps)}")
            # Filter KVM VMs - handle None/NULL values
            kvm_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'kvm']
            logger.info(f"[KVM] Found {len(kvm_vps)} KVM VMs to check")

            processes_to_analyze = {}
            vps_map = {}
            high_risk_vms = []
            any_suspicion_vms = []

            for vps in kvm_vps:
                vm_name = vps['container_name']
                logger.debug(f"[KVM] Processing VM: {vm_name}")

                if db.is_vps_suspended(vm_name):
                    logger.info(f"[KVM] Skipping suspended KVM {vm_name}")
                    continue

                node_info = node_manager.get_node_for_vps(vm_name)
                if not node_info:
                    logger.error(f"[KVM] Could not determine node for KVM {vm_name}. Skipping surveillance.")
                    continue
                node_url, api_key = node_info['url'], node_info['api_key']

                status_endpoint = f"/kvm/vm/{vm_name}/status"
                process_endpoint = f"/kvm/vm/{vm_name}/processes"

                status_result = await node_manager.api_request('GET', status_endpoint, node_url, api_key)
                if not status_result or not status_result.get('running'):
                    logger.info(f"[KVM] Skipping non-running KVM {vm_name}")
                    continue

                process_result = await node_manager.api_request('GET', process_endpoint, node_url, api_key)
                if process_result and process_result.get('processes'):
                    processes_text = process_result.get('processes', '')
                    
                    # Convert list of dicts to string if needed
                    if isinstance(processes_text, list):
                        processes_text = '\n'.join([
                            str(p) if isinstance(p, str) else str(p.get('cmd', '')) 
                            for p in processes_text
                        ])
                    
                    if self._is_only_monitoring_activity(processes_text):
                        logger.info(f"[KVM] Skipping KVM {vm_name} - only monitoring SSH activity detected")
                        if vps['suspicion_count'] > 0:
                            logger.info(f"[KVM] Resetting suspicion count for {vm_name} (monitoring only)")
                            db.reset_suspicion_count(vm_name)
                            db.clear_suspicion_logs(vm_name)
                        continue

                    processes_to_analyze[vm_name] = processes_text
                    vps_map[vm_name] = vps

                    if vps['suspicion_count'] >= 1:
                        any_suspicion_vms.append(vm_name)
                        if vps['suspicion_count'] >= 2:
                            high_risk_vms.append(vm_name)
                            logger.info(f"[KVM] KVM {vm_name} is HIGH RISK (suspicion count: {vps['suspicion_count']})")

            if not processes_to_analyze:
                logger.info("[KVM] No running KVM VMs to analyze.")
                logger.info("[KVM] KVM mining check finished.")
                return

            try:
                logger.info(f"[KVM] Starting analysis of {len(processes_to_analyze)} VMs (high_risk: {len(high_risk_vms)}, any_suspicion: {len(any_suspicion_vms)})")
                analysis_results = await self.analyze_all_vms(
                    processes_to_analyze,
                    use_pro_model=(len(any_suspicion_vms) > 0),
                    high_risk_vms=high_risk_vms
                )

                if not analysis_results:
                    logger.warning("[KVM] Did not receive valid analysis from Gemini.")
                    logger.info("[KVM] KVM mining check finished.")
                    return

                logger.info(f"[KVM] Analysis complete. Processing results...")
                for vm_name, result in analysis_results.items():
                    vps = vps_map.get(vm_name)
                    if not vps:
                        continue

                    if result == 'MINING':
                        logger.warning(f"[KVM] 🚨 Suspicious activity detected in KVM {vm_name}")
                        process_list = processes_to_analyze.get(vm_name, "")
                        db.add_suspicion_log(vm_name, process_list)
                        new_count = db.increment_suspicion_count(vm_name)
                        if new_count >= 3:
                            logger.warning(f"[KVM] ⚠️ Mining confirmed in KVM {vm_name} after {new_count} detections. SUSPENDING.")
                            reason = await self.get_suspension_reason(vm_name)
                            await self.handle_mining_detection(vps, reason)
                            self.metrics['threats_detected'] += 1
                        else:
                            logger.info(f"[KVM] KVM {vm_name} suspicion count is now {new_count}. Notifying admin.")
                            reason = f"Suspicion count: {new_count}. Process list:\n```\n{process_list[:900]}\n```"
                            await self.notify_admin_of_suspicion(vps, reason)
                    elif result == 'CLEAN':
                        if vps['suspicion_count'] > 0:
                            logger.info(f"[KVM] ✅ KVM {vm_name} is clean. Resetting suspicion count.")
                            db.reset_suspicion_count(vm_name)
                            db.clear_suspicion_logs(vm_name)
                            self.metrics['false_positives'] += 1

            except Exception as e:
                logger.error(f"[KVM] An error occurred during bulk KVM analysis: {e}", exc_info=True)

            logger.info("[KVM] KVM mining check finished.")
            new_interval = random.randint(1, 5)
            logger.info(f"[KVM] Next check in {new_interval} minutes")
            self.check_kvm_for_mining.change_interval(minutes=new_interval)
        
        except Exception as e:
            logger.error(f"[KVM] Critical error in check_kvm_for_mining: {e}", exc_info=True)
            new_interval = random.randint(1, 5)
            logger.info(f"Next KVM scan in {new_interval} minutes (after error).")
            self.check_kvm_for_mining.change_interval(minutes=new_interval)

    def _is_only_monitoring_activity(self, processes_text) -> bool:
        if not processes_text:
            return False
        
        # Convert list to string if needed
        if isinstance(processes_text, list):
            processes_text = '\n'.join(processes_text)
        
        processes_lower = processes_text.lower()
        sshd_count = processes_lower.count('sshd:')
        has_host_connection = '192.168.122.1' in processes_text
        max_cpu = 0.0
        cpu_intensive_count = 0
        
        for line in processes_text.split('\n'):
            parts = line.strip().split()
            if len(parts) > 0 and parts[0].replace('.', '', 1).isdigit():
                try:
                    cpu = float(parts[0])
                    max_cpu = max(max_cpu, cpu)
                    if cpu > 10.0:
                        cpu_intensive_count += 1
                except ValueError:
                    continue
        
        suspicious_keywords = ['xmrig', 'miner', 'stratum', 'cpuminer', 'nanominer', 'ethminer']
        has_suspicious = any(keyword in processes_lower for keyword in suspicious_keywords)
        suspicious_paths = ['/tmp/', '/dev/shm/', '/var/tmp/', '/.cache/']
        has_suspicious_path = any(path in processes_lower for path in suspicious_paths)
        
        if (sshd_count >= 1 and sshd_count <= 4 and 
            has_host_connection and 
            max_cpu < 12.0 and 
            cpu_intensive_count <= 3 and
            not has_suspicious and 
            not has_suspicious_path):
            
            normal_keywords = ['systemd', 'snapd', 'unattended', 'journald', 'networkd', 'init', 'kworker']
            has_normal_activity = any(keyword in processes_lower for keyword in normal_keywords)
            
            if has_normal_activity:
                logger.info(f"Detected monitoring-only activity: max_cpu={max_cpu}%, sshd_count={sshd_count}, from_host={has_host_connection}")
                return True
        
        return False

    def _prefilter_process_list(self, text: str) -> str:
        if not text:
            return ""

        lines = text.splitlines()
        filtered_lines = []
        for line in lines:
            if re.search(r'sshd:\s+\S+@notty', line, re.IGNORECASE):
                continue
            
            if re.search(r'^\s*\d+\.\d+\s+\d+\.\d+\s+\d+\s+\w+\s+sshd:', line, re.IGNORECASE):
                parts = line.strip().split()
                if len(parts) >= 5:
                    try:
                        cpu = float(parts[0])
                        if cpu < 15 and 'notty' in line.lower():
                            continue
                    except ValueError:
                        pass
            
            if line.strip() == "" or re.match(r"^===+", line.strip()):
                continue
                
            filtered_lines.append(line)
        
        max_chars = 48_000
        joined = "\n".join(filtered_lines).strip()
        if len(joined) > max_chars:
            joined = joined[:max_chars] + "\n[TRUNCATED]"
        return joined

    async def analyze_all_vms(self, processes_dict, use_pro_model=False, high_risk_vms=None):
        if high_risk_vms is None:
            high_risk_vms = []

        filtered_processes = {k: self._prefilter_process_list(v) for k, v in processes_dict.items()}
        json_input = json.dumps(filtered_processes, indent=2)
        risk_note = ""
        if high_risk_vms:
            risk_note = f"\n\n**CRITICAL**: The following VMs require EXTRA CAREFUL analysis: {', '.join(high_risk_vms)}"

        prompt = f"""
        You are a cybersecurity AI specialized in detecting cryptocurrency mining activity in KVM virtual machines.
        Analyze the following JSON object. The keys are VM names, and the values are their respective Linux process lists.
        Each value contains the output of "ps -eo %cpu,%mem,pid,user,args --sort=-%cpu" and "ss -tunp".
        Your task: For each instance, decide whether it is **CLEAN** or **MINING**.

        ### CONTEXT
        - These are KVM VMs with CPU limits around 90-100%.
        - Miners often maintain high CPU usage near the limit (70-90-100%).
        - Miners disguise as system processes or hide in temporary directories.
        - All monitoring SSH connections (`sshd: root@gemini-surveillance` from 192.168.122.1) are pre-filtered and should be ignored.
        - All monitoring SSH connections (`sshd: gemini-surveillance`) are pre-filtered and should be ignored.

        ### STRONG INDICATORS OF MINING
        1. **Sustained high CPU usage** (70%).
        2. **Suspicious binary paths**: `/tmp`, `/var/tmp`, `/dev/shm`, `/run/`, `/sys/fs/cgroup`, `/root/.cache/`.
        3. **Masqueraded system processes** with abnormal CPU or paths.
        4. **Known miner software or flags**: `xmrig`, `cpuminer`, `-o stratum+tcp://`.
        5. **Unusual users**: `nobody`, `systemd-coredump`, `upd`, `sys`, `svc`, `miner`.
        6. **Network connections** to pool ports: `3333`, `5555`, `7777`.

        ### NORMAL BEHAVIOR TO IGNORE
        - **SSH and Monitoring**: `sshd: root@notty`, any `sshd` from `192.168.122.1`.
        - **System Management**: `systemd`, `journald`, `cron`, `qemu-ga`.
        - **Package Management**: `apt`, `dpkg`, `unattended-upgrade`, `snapd`. These can use 5-15% CPU temporarily.

        ### CLASSIFICATION RULES
        - Output `"MINING"` for two or more strong indicators, or one very clear indicator.
        - Output `"CLEAN"` otherwise.
        - **BE CONSERVATIVE**. Avoid false positives from system updates or SSH monitoring.
        - Be more strict for high-risk VMs.{risk_note}

        ### INPUT JSON
        {json_input}

        ### OUTPUT (JSON ONLY, NO MARKDOWN)
        """

        async def make_api_call(model, model_name):
            logger.info(f"Using {model_name} for KVM analysis...")
            self.metrics['api_calls'] += 1
            response = await asyncio.wait_for(model.generate_content_async(prompt), timeout=180)
            
            if not response or not response.text:
                raise ValueError("Empty response from API")
            
            text = response.text.strip()
            
            # Remove markdown formatting
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            # Extract JSON object
            start = text.find('{')
            end = text.rfind('}') + 1
            
            if start == -1 or end == 0:
                raise ValueError(f"No JSON object found in response: {text[:200]}")
            
            json_text = text[start:end]
            result = json.loads(json_text)
            
            # Validate result format
            if not isinstance(result, dict):
                raise ValueError("Response is not a dictionary")
            
            for vm, classification in result.items():
                if classification not in ['MINING', 'CLEAN']:
                    logger.warning(f"Invalid classification for {vm}: {classification}")
                    result[vm] = 'CLEAN'  # Default to safe
            
            return result

        # Try primary model first if high risk
        try:
            if use_pro_model and high_risk_vms:
                await self.primary_limiter.acquire()
                return await make_api_call(
                    self.primary_model, 
                    "gemini-2.5-pro (HIGH RISK KVM SCAN)"
                )
            else:
                await self.fallback_limiter.acquire()
                return await make_api_call(
                    self.fallback_model, 
                    "gemini-2.5-flash-lite (KVM)"
                )
        
        except (asyncio.TimeoutError, google_exceptions.ResourceExhausted,
                json.JSONDecodeError, ValueError) as e:
            error_msg = str(e).lower()
            is_quota_error = (
                isinstance(e, google_exceptions.ResourceExhausted) or
                "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg
            )
            
            if is_quota_error:
                logger.warning(f"[KVM] Quota exceeded (429) on primary model, switching to fallback: {e}")
            else:
                logger.warning(f"Primary KVM analysis failed: {type(e).__name__}: {e}")
            
            # Retry with first fallback model
            try:
                if use_pro_model or is_quota_error:
                    await self.fallback_limiter.acquire()
                    return await make_api_call(
                        self.fallback_model, 
                        "gemini-2.5-flash-lite (KVM FALLBACK)"
                    )
                else:
                    await self.primary_limiter.acquire()
                    return await make_api_call(
                        self.primary_model, 
                        "gemini-2.5-pro (KVM FALLBACK)"
                    )
            except (asyncio.TimeoutError, google_exceptions.ResourceExhausted,
                    json.JSONDecodeError, ValueError) as fallback_e:
                error_msg_2 = str(fallback_e).lower()
                is_quota_error_2 = (
                    isinstance(fallback_e, google_exceptions.ResourceExhausted) or
                    "429" in error_msg_2 or "quota" in error_msg_2 or "exceeded" in error_msg_2
                )
                
                if is_quota_error_2:
                    logger.warning(f"[KVM] First fallback also hit quota limit, trying second fallback: {fallback_e}")
                
                # Try second fallback model
                try:
                    await self.fallback2_limiter.acquire()
                    return await make_api_call(
                        self.fallback2_model, 
                        "gemini-2.0-flash-lite (KVM FALLBACK2)"
                    )
                except Exception as fallback2_e:
                    logger.error(f"All three models failed for KVM analysis: {fallback2_e}\n{traceback.format_exc()}")
                    return None
        
        except Exception as e:
            # Catch any other exception and check for quota errors
            error_msg = str(e).lower()
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                logger.warning(f"[KVM] Quota error detected in exception, switching to fallback: {e}")
                try:
                    await self.fallback_limiter.acquire()
                    return await make_api_call(
                        self.fallback_model, 
                        "gemini-2.5-flash-lite (KVM FALLBACK)"
                    )
                except Exception as fallback_e:
                    error_msg_2 = str(fallback_e).lower()
                    if "429" in error_msg_2 or "quota" in error_msg_2 or "exceeded" in error_msg_2:
                        logger.warning(f"[KVM] First fallback also hit quota limit, trying second fallback: {fallback_e}")
                        try:
                            await self.fallback2_limiter.acquire()
                            return await make_api_call(
                                self.fallback2_model, 
                                "gemini-2.0-flash-lite (KVM FALLBACK2)"
                            )
                        except Exception as fallback2_e:
                            logger.error(f"All three models failed for KVM analysis: {fallback2_e}")
                            return None
                    else:
                        logger.error(f"Fallback model also failed: {fallback_e}")
                        return None
            else:
                logger.error(f"Unexpected error in KVM analysis: {e}\n{traceback.format_exc()}")
                return None

    async def get_suspension_reason(self, vm_name):
        logs = db.get_suspicion_logs(vm_name, limit=3)
        if not logs:
            return "No process logs found."
        formatted_logs = ""
        for i, log in enumerate(reversed(logs)):
            formatted_logs += f"---" + "-" * 10 + f" Detection {i+1} ---" + f"\n{log['process_list']}\n\n"
        prompt = f"""
        You are a cybersecurity analyst.
        The following three process lists were flagged as suspicious for cryptocurrency mining from the same KVM VM, at 5-minute intervals.
        Summarize in a few bullet points why these processes are suspicious.
        Focus on the process names, CPU usage, and any patterns you observe across the detections.
        Be concise and clear.

        {formatted_logs}
        """
        result = await self._call_gemini_with_fallback(prompt, timeout=60, use_primary_first=True)
        if result:
            return result
        
        # Fallback message if both models fail
        return "Analysis unavailable. Manual review recommended."

    async def notify_admin_of_suspicion(self, vps, reason="Suspicious activity detected."):
        """Send suspicion notification to admin"""
        vm_name = vps['container_name']
        user_id = vps['user_id']
        
        try:
            admin = await self.bot.fetch_user(self.admin_user_id)
            
            embed = discord.Embed(
                title="⚠️ SUSPICIOUS ACTIVITY (KVM)",
                description=f"VM: `{vm_name}`\nUser: `{user_id}`\n\n⚠️ Not suspended yet - requires confirmation",
                color=discord.Color.yellow(),
                timestamp=discord.utils.utcnow()
            )
            
            # Truncate reason if too long
            if len(reason) > 1024:
                reason = reason[:1020] + "..."
            
            embed.add_field(name="Analysis", value=reason, inline=False)
            embed.set_footer(text=f"Suspicion Count: {vps.get('suspicion_count', 0)}")
            
            await admin.send(embed=embed)
            
        except discord.Forbidden:
            logger.error(f"Cannot send DM to admin {self.admin_user_id}")
        except Exception as e:
            logger.error(f"Failed to notify admin: {e}")

    async def handle_mining_detection(self, vps, reason="No specific reason provided."):
        """Handle confirmed mining detection with improved error handling"""
        vm_name = vps['container_name']
        user_id = vps['user_id']

        node_info = node_manager.get_node_for_vps(vm_name)
        if not node_info:
            logger.error(f"Cannot suspend {vm_name}: No node information")
            return

        try:
            # Stop VM
            node_url, api_key = node_info['url'], node_info['api_key']
            await node_manager.api_request(
                'POST', 
                f"/kvm/vm/{vm_name}/stop", 
                node_url, 
                api_key, 
                data={"force": True}
            )
            
            # Update database
            db.suspend_vps(vm_name)
            
            logger.critical(f"KVM VM {vm_name} suspended for mining")
            
            # Notify admin
            try:
                admin = await self.bot.fetch_user(self.admin_user_id)
                
                embed = discord.Embed(
                    title="🚨 MINING DETECTED & SUSPENDED (KVM)",
                    description=f"**VM:** `{vm_name}`\n**User:** `{user_id}`\n\n✅ Automatically suspended",
                    color=discord.Color.red(),
                    timestamp=discord.utils.utcnow()
                )
                
                if len(reason) > 1024:
                    reason = reason[:1020] + "..."
                
                embed.add_field(name="AI Analysis", value=reason, inline=False)
                
                view = UnsuspendView(vm_name, user_id, self.bot, 'kvm')
                await admin.send(embed=embed, view=view)
                
            except Exception as e:
                logger.error(f"Failed to notify admin: {e}")
            
            # Notify user
            try:
                user = await self.bot.fetch_user(user_id)
                await user.send(
                    f"🚨 **VM Suspended**\n\n"
                    f"Your VM `{vm_name}` has been suspended for "
                    f"suspected cryptocurrency mining activity.\n\n"
                    f"If you believe this is an error, please contact support."
                )
            except Exception as e:
                logger.error(f"Failed to notify user {user_id}: {e}")
        
        except Exception as e:
            logger.error(f"Error handling mining detection for {vm_name}: {e}\n{traceback.format_exc()}")

    @check_kvm_for_mining.before_loop
    async def before_check(self):
        logger.info("[KVM] check_kvm_for_mining: Waiting for bot to be ready...")
        logger.info(f"[KVM] Bot instance check: {self.bot is not None}")
        logger.info(f"[KVM] Bot type: {type(self.bot)}")
        
        if self.bot is None:
            logger.error("[KVM] CRITICAL: Bot is None! Cannot wait_until_ready()")
            return
        
        try:
            await self.bot.wait_until_ready()
            logger.info("[KVM] ✅ check_kvm_for_mining: Bot ready, task will start in 5 minutes")
        except Exception as e:
            logger.error(f"[KVM] Error waiting for bot ready: {e}", exc_info=True)


class UnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=None)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Unsuspend", style=discord.ButtonStyle.danger)
    async def unsuspend_button(self, interaction: discord.Interaction, button: Button):
        entity_type = "Container" if self.vps_type == 'lxc' else "VM"
        confirm_view = ConfirmUnsuspendView(self.container_name, self.user_id, self.bot, self.vps_type)
        embed = discord.Embed(
            title=f"⚠️ Confirm Unsuspend {entity_type}",
            description=f"Are you sure you want to unsuspend `{self.container_name}`?",
            color=discord.Color.orange()
        )
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)


class ConfirmUnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Yes, Unsuspend", style=discord.ButtonStyle.success)
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        entity_type = "Container" if self.vps_type == 'lxc' else "VM"
        try:
            db.unsuspend_vps(self.container_name)
            db.reset_suspicion_count(self.container_name)
            db.clear_suspicion_logs(self.container_name)

            node_info = node_manager.get_node_for_vps(self.container_name)
            if not node_info:
                await interaction.followup.send(f"Failed to unsuspend: Could not determine node for {self.container_name}.", ephemeral=True)
                return
            node_url, api_key = node_info['url'], node_info['api_key']

            if self.vps_type == 'lxc':
                await node_manager.api_request('POST', f"/lxc/container/{self.container_name}/resume", node_url, api_key)
            elif self.vps_type == 'kvm':
                await node_manager.api_request('POST', f"/kvm/vm/{self.container_name}/start", node_url, api_key)
            success_embed = discord.Embed(title="✅ Unsuspended", description=f"{entity_type} `{self.container_name}` unsuspended.", color=discord.Color.green())
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            try:
                user = await self.bot.fetch_user(self.user_id)
                await user.send(f"✅ Your {entity_type.lower()} (`{self.container_name}`) has been unsuspended.")
            except Exception as e:
                logger.error(f"Failed to notify user about unsuspension: {e}")
            for item in self.children:
                item.disabled = True
            if interaction.message:
                await interaction.message.edit(view=self)
        except Exception as e:
            logger.error(f"Failed to unsuspend {self.container_name}: {e}")
            await interaction.followup.send(f"Failed to unsuspend: {e}", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)


class AntiDDoSMonitorKVM:
    """Monitor KVM VM network traffic for DDoS detection"""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        self.threshold_mbps = 40
        self.violation_count = {}
        self.suspension_threshold = 2
        self.traffic_history = {}
        self.max_history_age = 300
        
    async def check_vm_traffic(self, vm_name: str, tx_bytes: int, previous_tx_bytes: int) -> bool:
        """Check if KVM VM traffic exceeds threshold"""
        try:
            current_time = time.time()
            bytes_delta = tx_bytes - previous_tx_bytes
            
            if vm_name not in self.traffic_history:
                self.traffic_history[vm_name] = []
            
            self.traffic_history[vm_name].append((current_time, bytes_delta))
            self.traffic_history[vm_name] = [
                (ts, bytes_) for ts, bytes_ in self.traffic_history[vm_name]
                if current_time - ts < self.max_history_age
            ]
            
            sixty_sec_ago = current_time - 60
            recent_traffic = [bytes_ for ts, bytes_ in self.traffic_history[vm_name] if ts > sixty_sec_ago]
            
            if recent_traffic:
                avg_bytes_per_sec = sum(recent_traffic) / 60
                avg_mbps = (avg_bytes_per_sec * 8) / (1024 * 1024)
                
                if avg_mbps > self.threshold_mbps:
                    if vm_name not in self.violation_count:
                        self.violation_count[vm_name] = 0
                    
                    self.violation_count[vm_name] += 1
                    logger.warning(f"🔴 DDoS Alert KVM {vm_name}: {avg_mbps:.2f} MB/s (violation #{self.violation_count[vm_name]})")
                    
                    await self._notify_founder_kvm(vm_name, avg_mbps, self.violation_count[vm_name])
                    
                    if self.violation_count[vm_name] >= self.suspension_threshold:
                        logger.error(f"🛑 Suspending KVM {vm_name} after {self.suspension_threshold} violations")
                        await self._suspend_vm(vm_name)
                        return True
                else:
                    if vm_name in self.violation_count and self.violation_count[vm_name] > 0:
                        self.violation_count[vm_name] = 0
                        logger.info(f"✅ {vm_name} traffic normalized")
            
            return False
        except Exception as e:
            logger.error(f"Error checking KVM traffic for {vm_name}: {e}")
            return False
    
    async def _notify_founder_kvm(self, vm_name: str, mbps: float, violation_num: int):
        """Notify founder about KVM DDoS detection"""
        try:
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="⚠️ KVM DDoS Detection Alert",
                description=f"Excessive traffic detected on VM",
                color=discord.Color.red()
            )
            embed.add_field(name="VM", value=vm_name, inline=False)
            embed.add_field(name="Traffic", value=f"{mbps:.2f} MB/s", inline=True)
            embed.add_field(name="Violation", value=f"{violation_num}/2", inline=True)
            embed.set_footer(text=f"Timestamp: {datetime.now().isoformat()}")
            
            await user.send(embed=embed)
            logger.info(f"Founder notified about {vm_name} KVM DDoS alert")
        except Exception as e:
            logger.error(f"Failed to notify founder about KVM: {e}")
    
    async def _suspend_vm(self, vm_name: str):
        """Suspend KVM VM due to DDoS activity"""
        try:
            db.update_vps_status(vm_name, "suspended")
            
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="🛑 KVM Suspended",
                description=f"VM suspended due to DDoS activity",
                color=discord.Color.dark_red()
            )
            embed.add_field(name="VM", value=vm_name, inline=False)
            embed.add_field(name="Reason", value="Exceeded DDoS threshold (2+ violations)", inline=False)
            embed.set_footer(text=f"Timestamp: {datetime.now().isoformat()}")
            
            await user.send(embed=embed)
            logger.error(f"KVM {vm_name} suspended by anti-DDoS system")
        except Exception as e:
            logger.error(f"Failed to suspend KVM VM: {e}")
