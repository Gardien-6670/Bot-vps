import asyncio
import hashlib
import os
import google.generativeai as genai
from google.api_core import exceptions as google_exceptions
from discord.ext import tasks
from dotenv import load_dotenv
from bot.utils.database import db
import logging
import time
import json
import discord
from discord.ui import View, Button
import aiohttp
import re
from bot.utils import node_manager
import random
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
import traceback

load_dotenv()


class PerMinuteRateLimiter:
    """Thread-safe rate limiter with semaphore"""
    def __init__(self, requests_per_minute: int):
        self.max_requests = requests_per_minute
        self.time_window = 60
        self.request_timestamps = []
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            while True:
                now = time.time()
                self.request_timestamps = [
                    ts for ts in self.request_timestamps 
                    if now - ts < self.time_window
                ]

                if len(self.request_timestamps) < self.max_requests:
                    self.request_timestamps.append(now)
                    break
                else:
                    oldest_request_time = self.request_timestamps[0]
                    time_to_wait = self.time_window - (now - oldest_request_time)
                    logging.info(f"Rate limit reached. Waiting for {time_to_wait:.2f} seconds.")
                    await asyncio.sleep(time_to_wait + 0.1)


class SurveillanceLXC:
    """Enhanced LXC container surveillance system with improved security and performance"""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        # Initialize Gemini AI
        gemini_api_key = os.getenv("GEMINI_API_KEY")
        if not gemini_api_key:
            raise ValueError("GEMINI_API_KEY not found in .env file")
        
        genai.configure(api_key=gemini_api_key)
        self.primary_model = genai.GenerativeModel('gemini-2.5-pro')
        self.fallback_model = genai.GenerativeModel('gemini-2.5-flash-lite')
        self.fallback2_model = genai.GenerativeModel('gemini-2.0-flash-lite')
        self.primary_limiter = PerMinuteRateLimiter(20)
        self.fallback_limiter = PerMinuteRateLimiter(30)
        self.fallback2_limiter = PerMinuteRateLimiter(30)
        
        # VirusTotal configuration with improved key management
        self.virustotal_api_key_data: List[Dict[str, Any]] = []
        self._initialize_virustotal_keys()
        self.vt_key_index = 0  # For round-robin fallback
        self.vt_semaphore = asyncio.Semaphore(3)  # Limit concurrent VT requests
        
        # Security monitoring thresholds - BALANCED
        self.official_hashes = {}
        self.DISK_IO_THRESHOLD = 500 * 1024 * 1024  # 500 MB in 5 min (increased)
        self.CPU_THRESHOLD = 90
        self.NETWORK_THRESHOLD = 50 * 1024 * 1024
        self.NETWORK_IO_THRESHOLD_5MIN = 10 * 1024 * 1024 * 1024  # 10 GB in 5 min (reduced)
        
        # History tracking with cleanup
        self.network_stats_history = {}
        self.disk_stats_history = {}
        self.last_cleanup = time.time()
        
        # Performance optimization
        self.scan_semaphore = asyncio.Semaphore(5)  # Max 5 concurrent container scans
        
        # Metrics tracking
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'false_positives': 0,
            'api_calls': 0
        }

    @staticmethod
    def _get_virustotal_key_hash(api_key: str) -> str:
        """Generate full SHA256 hash of VirusTotal API key for database storage"""
        return hashlib.sha256(api_key.encode()).hexdigest()

    async def _call_gemini_with_fallback(
        self, 
        prompt: str, 
        timeout: int = 60,
        use_primary_first: bool = True
    ) -> Optional[str]:
        """Call Gemini API with automatic fallback to flash-lite on quota errors (429)"""
        try:
            if use_primary_first:
                await self.primary_limiter.acquire()
                model = self.primary_model
                model_name = "gemini-2.5-pro"
            else:
                await self.fallback_limiter.acquire()
                model = self.fallback_model
                model_name = "gemini-2.5-flash-lite"
            
            response = await asyncio.wait_for(
                model.generate_content_async(prompt),
                timeout=timeout
            )
            
            if not response or not response.text:
                raise ValueError("Empty response from AI")
            
            return response.text.strip()
        
        except google_exceptions.ResourceExhausted as e:
            # Quota exceeded (429) - switch to fallback
            error_msg = str(e).lower()
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logging.warning(
                        f"Gemini quota exceeded on {model_name}, switching to fallback model. "
                        f"Error: {str(e)[:200]}"
                    )
                    # Retry with first fallback
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logging.info("Successfully used fallback model (gemini-2.5-flash-lite)")
                            return response.text.strip()
                    except google_exceptions.ResourceExhausted as fallback_e:
                        logging.warning(f"First fallback also hit quota limit, trying second fallback (gemini-2.0-flash-lite)")
                        try:
                            await self.fallback2_limiter.acquire()
                            response = await asyncio.wait_for(
                                self.fallback2_model.generate_content_async(prompt),
                                timeout=timeout
                            )
                            if response and response.text:
                                logging.info("Successfully used second fallback model (gemini-2.0-flash-lite)")
                                return response.text.strip()
                        except Exception as fallback2_e:
                            logging.error(f"Second fallback model also failed: {fallback2_e}")
                            return None
                    except Exception as fallback_e:
                        logging.error(f"Fallback model also failed: {fallback_e}")
                        return None
                else:
                    logging.error(f"Fallback model also hit quota limit: {e}")
                    return None
            else:
                # Other ResourceExhausted error, try fallback anyway
                if use_primary_first:
                    logging.warning(f"Resource exhausted on {model_name}, trying fallback...")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            return response.text.strip()
                    except Exception:
                        pass
                return None
        
        except asyncio.TimeoutError:
            logging.error(f"Timeout calling Gemini API ({model_name})")
            return None
        
        except Exception as e:
            error_msg = str(e).lower()
            # Check if it's a quota/429 error in the message
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logging.warning(f"Quota error detected, switching to fallback: {e}")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logging.info("Successfully used fallback model after quota error")
                            return response.text.strip()
                    except Exception:
                        pass
            logging.error(f"Error calling Gemini API ({model_name}): {e}")
            return None

    def _initialize_virustotal_keys(self):
        """Initialize VirusTotal API keys with improved error handling"""
        vt_keys_from_env = []
        
        primary_vt_key = os.getenv('VIRUSTOTAL_API_KEY')
        if primary_vt_key:
            vt_keys_from_env.append(primary_vt_key)
            logging.info(f"[VT] Primary VirusTotal key loaded")
        
        for i in range(1, 11):
            additional_key = os.getenv(f'VIRUSTOTAL_API_KEY_{i}')
            if additional_key:
                vt_keys_from_env.append(additional_key)
                logging.info(f"[VT] Additional VirusTotal key {i} loaded")

        if not vt_keys_from_env:
            logging.warning("[VT] No VIRUSTOTAL_API_KEY found in .env. File scanning with VirusTotal will be disabled.")
            return
        
        logging.info(f"[VT] Initialized {len(vt_keys_from_env)} VirusTotal API key(s)")

        today_date = datetime.now().date()
        today_str = today_date.strftime('%Y-%m-%d')

        for vt_key in vt_keys_from_env:
            try:
                # Generate full hash for database operations
                key_hash_full = self._get_virustotal_key_hash(vt_key)
                daily_count = db.get_virustotal_daily_requests(today_str, key_hash_full)
                self.virustotal_api_key_data.append({
                    'key': vt_key,
                    'key_hash': key_hash_full,  # Store full hash for DB operations
                    'per_minute_limiter': PerMinuteRateLimiter(4),
                    'daily_request_count': daily_count,
                    'last_reset_date': today_date,
                    'consecutive_errors': 0  # Track errors per key
                })
                # Obfuscate key in logs (first 8 chars for readability)
                key_hash_short = key_hash_full[:8]
                logging.info(f"VirusTotal key {key_hash_short} loaded. Daily requests: {daily_count}/500")
            except Exception as e:
                logging.error(f"Failed to initialize VT key: {e}")
        
        # Log load balancing summary
        if self.virustotal_api_key_data:
            total_requests = sum(k['daily_request_count'] for k in self.virustotal_api_key_data)
            avg_requests = total_requests / len(self.virustotal_api_key_data)
            logging.info(
                f"[VT] Load balancing: {len(self.virustotal_api_key_data)} key(s) available. "
                f"Total requests today: {total_requests}, Average per key: {avg_requests:.1f}/500"
            )

    async def _cleanup_old_stats(self):
        """Clean up old statistics to prevent memory leaks"""
        now = time.time()
        if now - self.last_cleanup < 3600:  # Cleanup every hour
            return
        
        cutoff_time = now - 7200  # Keep last 2 hours
        
        # Clean network stats
        to_remove = [
            name for name, stats in self.network_stats_history.items()
            if stats['time'] < cutoff_time
        ]
        for name in to_remove:
            del self.network_stats_history[name]
        
        # Clean disk stats
        to_remove = [
            name for name, stats in self.disk_stats_history.items()
            if stats['time'] < cutoff_time
        ]
        for name in to_remove:
            del self.disk_stats_history[name]
        
        self.last_cleanup = now
        logging.info(f"Stats cleanup completed. Removed {len(to_remove)} old entries.")

    def _sanitize_filepath(self, filepath: str) -> Optional[str]:
        """Validate and sanitize file paths to prevent path traversal"""
        if not filepath:
            return None
        
        # Remove null bytes and control characters
        filepath = filepath.replace('\0', '')
        
        # Check for path traversal attempts
        if '..' in filepath or filepath.startswith('~'):
            logging.warning(f"Potential path traversal attempt detected: {filepath}")
            return None
        
        # Ensure absolute path
        if not filepath.startswith('/'):
            return None
        
        # Blacklist dangerous paths
        dangerous_paths = ['/dev/', '/proc/', '/sys/']
        if any(filepath.startswith(p) for p in dangerous_paths):
            return None
        
        return filepath

    @tasks.loop(minutes=5)
    async def check_lxc_for_mining(self):
        """Enhanced mining detection with better error handling"""
        print("\n" + "=" * 60)
        print("[TASK] 🔍 check_lxc_for_mining: EXECUTING NOW")
        print("=" * 60)
        logging.info("=" * 60)
        logging.info("[TASK] 🔍 check_lxc_for_mining: EXECUTING NOW")
        logging.info("=" * 60)
        logging.info("Starting mining check on all LXC containers...")
        await self._cleanup_old_stats()

        try:
            all_vps = db.get_all_vps()
            logging.info(f"Total VPS in database: {len(all_vps)}")
            # Filter LXC containers - handle None/NULL values by defaulting to 'lxc'
            lxc_vps = [vps for vps in all_vps if (vps.get('vps_type') or 'lxc') == 'lxc']
            logging.info(f"Found {len(lxc_vps)} LXC containers to check")

            processes_to_analyze = {}
            vps_map = {}
            high_risk_containers = []
            any_suspicion_containers = []

            # Collect process data from all containers
            for vps in lxc_vps:
                container_name = vps['container_name']
                logging.info(f"Checking LXC container: {container_name}")

                if db.is_vps_suspended(container_name):
                    logging.info(f"Skipping suspended LXC {container_name}")
                    continue

                node_info = node_manager.get_node_for_vps(container_name)
                if not node_info:
                    logging.error(f"No node found for LXC {container_name}")
                    continue

                logging.info(f"Node found for {container_name}, checking status")

                try:
                    # Use dedicated status endpoint for more reliable checking
                    if not await self.is_container_running(container_name):
                        logging.info(f"LXC {container_name} is not running")
                        continue

                    logging.info(f"LXC {container_name} is running, getting process list")

                    process_result = await self.execute_command_in_container(
                        container_name,
                        ["ps", "-eo", "%cpu,%mem,pid,user,args", "--sort=-%cpu"],
                        timeout=30
                    )

                    if process_result and process_result.get('stdout'):
                        processes_text = process_result.get('stdout', '')
                        logging.info(f"Got process list for {container_name} ({len(processes_text)} chars)")

                        # Skip if only monitoring activity
                        if self._is_only_monitoring_activity(processes_text):
                            logging.info(f"LXC {container_name} - only monitoring activity, skipping analysis")
                            if vps['suspicion_count'] > 0:
                                db.reset_suspicion_count(container_name)
                                db.clear_suspicion_logs(container_name)
                            continue

                        logging.info(f"Adding {container_name} to analysis queue")
                        processes_to_analyze[container_name] = processes_text
                        vps_map[container_name] = vps

                        if vps['suspicion_count'] >= 1:
                            any_suspicion_containers.append(container_name)
                            if vps['suspicion_count'] >= 2:
                                high_risk_containers.append(container_name)
                                logging.warning(f"HIGH RISK: {container_name} (suspicion: {vps['suspicion_count']})")

                    else:
                        logging.warning(f"Failed to get process list for {container_name}: {process_result}")

                except Exception as e:
                    logging.error(f"Error checking {container_name}: {e}")
                    continue

            if not processes_to_analyze:
                logging.info("No running LXC containers to analyze.")
                return

            # Analyze all containers in batch
            analysis_results = await self.analyze_all_containers_for_mining(
                processes_to_analyze,
                use_pro_model=(len(any_suspicion_containers) > 0),
                high_risk_containers=high_risk_containers
            )

            if not analysis_results:
                logging.warning("No valid analysis results from Gemini")
                return

            # Process results
            for container_name, result in analysis_results.items():
                vps = vps_map.get(container_name)
                if not vps:
                    continue

                try:
                    if result == 'MINING':
                        await self._handle_mining_suspicion(container_name, vps, processes_to_analyze.get(container_name, ""))
                    elif result == 'CLEAN':
                        await self._handle_clean_container(container_name, vps)
                except Exception as e:
                    logging.error(f"Error processing result for {container_name}: {e}")

        except Exception as e:
            logging.error(f"Error in mining check loop: {e}\n{traceback.format_exc()}")
        finally:
            # Randomize next interval
            new_interval = random.randint(3, 7)
            self.check_lxc_for_mining.change_interval(minutes=new_interval)
            logging.info(f"Next LXC scan in {new_interval} minutes.")
            logging.info("Mining check loop completed")

    async def _handle_mining_suspicion(self, container_name: str, vps: dict, process_list: str):
        """Handle detected mining activity"""
        logging.warning(f"Suspicious activity detected in LXC {container_name}")
        db.add_suspicion_log(container_name, process_list)
        new_count = db.increment_suspicion_count(container_name)
        
        if new_count >= 3:
            logging.critical(f"MINING CONFIRMED in {container_name} after {new_count} detections")
            reason = await self.get_suspension_reason(container_name)
            await self.handle_mining_detection(vps, reason)
            self.metrics['threats_detected'] += 1
        else:
            logging.info(f"LXC {container_name} suspicion count: {new_count}")
            reason = f"Suspicion count: {new_count}\nProcess list:\n```\n{process_list[:900]}\n```"
            await self.notify_admin_of_suspicion(vps, reason)

    async def _handle_clean_container(self, container_name: str, vps: dict):
        """Handle clean container verification"""
        if vps['suspicion_count'] > 0:
            logging.info(f"LXC {container_name} verified clean. Resetting suspicion.")
            db.reset_suspicion_count(container_name)
            db.clear_suspicion_logs(container_name)

    def _is_only_monitoring_activity(self, processes_text: str) -> bool:
        """Enhanced detection of monitoring-only activity"""
        if not processes_text:
            return False
        
        processes_lower = processes_text.lower()
        
        # Count SSH connections
        sshd_count = processes_lower.count('sshd:')
        has_host_connection = '192.168.122.1' in processes_text
        
        # Analyze CPU usage
        max_cpu = 0.0
        cpu_intensive_count = 0
        total_cpu = 0.0
        process_count = 0
        
        for line in processes_text.split('\n')[1:]:  # Skip header
            parts = line.strip().split(None, 4)
            if len(parts) >= 1 and parts[0].replace('.', '', 1).isdigit():
                try:
                    cpu = float(parts[0])
                    max_cpu = max(max_cpu, cpu)
                    total_cpu += cpu
                    process_count += 1
                    if cpu > 15.0:
                        cpu_intensive_count += 1
                except ValueError:
                    continue
        
        avg_cpu = total_cpu / process_count if process_count > 0 else 0
        
        # Check for suspicious indicators
        suspicious_keywords = [
            'xmrig', 'miner', 'stratum', 'cpuminer', 'nanominer', 
            'ethminer', 'ccminer', 'sgminer', 'nicehash'
        ]
        has_suspicious = any(keyword in processes_lower for keyword in suspicious_keywords)
        
        suspicious_paths = [
            '/tmp/', '/var/tmp/', '/dev/shm/', '/run/', 
            '/sys/fs/cgroup/', '/root/.cache/', '/.local/'
        ]
        has_suspicious_path = any(path in processes_lower for path in suspicious_paths)
        
        # Enhanced detection logic
        is_monitoring_only = (
            1 <= sshd_count <= 5 and
            has_host_connection and
            max_cpu < 20.0 and
            avg_cpu < 5.0 and
            cpu_intensive_count <= 2 and
            not has_suspicious and
            not has_suspicious_path
        )
        
        if is_monitoring_only:
            # Verify normal system processes
            normal_keywords = [
                'systemd', 'snapd', 'unattended', 'journald', 
                'networkd', 'init', 'kworker', 'cron'
            ]
            has_normal = any(keyword in processes_lower for keyword in normal_keywords)
            
            if has_normal:
                logging.debug(
                    f"Monitoring-only activity: max_cpu={max_cpu:.1f}%, "
                    f"avg_cpu={avg_cpu:.1f}%, sshd={sshd_count}"
                )
                return True
        
        return False

    def _prefilter_process_list(self, text: str) -> str:
        """Enhanced process list filtering with better edge case handling"""
        if not text:
            return ""

        lines = text.splitlines()
        filtered_lines = []
        
        for line in lines:
            # Skip empty lines
            if not line.strip():
                continue
            
            # Skip SSH notty connections with low CPU
            if re.search(r'sshd:\s+\S+@notty', line, re.IGNORECASE):
                parts = line.strip().split()
                if len(parts) >= 1:
                    try:
                        cpu = float(parts[0])
                        if cpu < 10:
                            continue
                    except (ValueError, IndexError):
                        pass
            
            # Skip separator lines
            if re.match(r"^[=\-]+$", line.strip()):
                continue
            
            filtered_lines.append(line)
        
        # Limit total size
        max_chars = 45000
        joined = "\n".join(filtered_lines).strip()
        
        if len(joined) > max_chars:
            joined = joined[:max_chars] + "\n[TRUNCATED - Content exceeded limit]"
        
        return joined

    async def analyze_all_containers_for_mining(
        self, 
        processes_dict: Dict[str, str], 
        use_pro_model: bool = False, 
        high_risk_containers: Optional[List[str]] = None
    ) -> Optional[Dict[str, str]]:
        """Enhanced AI analysis with better error handling and retry logic"""
        
        if high_risk_containers is None:
            high_risk_containers = []

        # Prefilter all process lists
        filtered_processes = {
            k: self._prefilter_process_list(v) 
            for k, v in processes_dict.items()
        }
        
        json_input = json.dumps(filtered_processes, indent=2)
        
        risk_note = ""
        if high_risk_containers:
            risk_note = (
                f"\n\n**CRITICAL ATTENTION REQUIRED**: "
                f"These containers have previous violations: {', '.join(high_risk_containers)}"
            )

        prompt = f"""You are an advanced cybersecurity AI specialized in cryptocurrency mining detection in LXC containers.

TASK: Analyze the following JSON object containing container process lists and classify each as CLEAN or MINING.

CONTEXT:
- LXC containers with CPU limits of 25-40%
- Miners maintain sustained high CPU near the limit (15-30%)
- Miners disguise as system processes or hide in temporary directories
- SSH monitoring connections from 192.168.122.1 are pre-filtered

STRONG MINING INDICATORS:
1. Sustained high CPU (15-50%) from single process
2. Suspicious binary paths: /tmp, /var/tmp, /dev/shm, /run, /sys/fs/cgroup, /root/.cache
3. Masqueraded system processes with abnormal behavior
4. Known miner software: xmrig, cpuminer, nanominer, ethminer, ccminer
5. Mining pool connections: stratum+tcp, -o pool, --url
6. Unusual users: nobody, systemd-coredump, upd, sys, svc, miner
7. Network connections to ports: 3333, 4444, 5555, 7777, 8333, 9999

NORMAL BEHAVIOR (IGNORE):
- SSH connections (sshd: root@notty from 192.168.122.1)
- System management: systemd, journald, cron, dbus
- Package management: apt, dpkg, unattended-upgrade (5-20% CPU temporarily)
- Standard utilities: ps, top, htop, bash, sh

CLASSIFICATION RULES:
- MINING: Two or more strong indicators, OR one very clear indicator
- CLEAN: Otherwise
- BE CONSERVATIVE: Avoid false positives from legitimate system activity
- HIGH RISK containers require extra scrutiny{risk_note}

INPUT JSON:
{json_input}

OUTPUT: JSON object only, no markdown. Format:
{{
  "container-name": "MINING" or "CLEAN",
  ...
}}
"""

        async def make_api_call(model, model_name: str) -> Dict[str, str]:
            """Make API call with improved error handling"""
            logging.info(f"Using {model_name} for LXC analysis...")
            self.metrics['api_calls'] += 1
            
            response = await asyncio.wait_for(
                model.generate_content_async(prompt), 
                timeout=180
            )
            
            if not response or not response.text:
                raise ValueError("Empty response from API")
            
            text = response.text.strip()
            
            # Remove markdown formatting
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            # Extract JSON object
            start = text.find('{')
            end = text.rfind('}') + 1
            
            if start == -1 or end == 0:
                raise ValueError(f"No JSON object found in response: {text[:200]}")
            
            json_text = text[start:end]
            result = json.loads(json_text)
            
            # Validate result format
            if not isinstance(result, dict):
                raise ValueError("Response is not a dictionary")
            
            for container, classification in result.items():
                if classification not in ['MINING', 'CLEAN']:
                    logging.warning(f"Invalid classification for {container}: {classification}")
                    result[container] = 'CLEAN'  # Default to safe
            
            return result

        # Try primary model first if high risk
        try:
            if use_pro_model and high_risk_containers:
                await self.primary_limiter.acquire()
                return await make_api_call(
                    self.primary_model, 
                    "gemini-2.5-pro (HIGH RISK)"
                )
            else:
                await self.fallback_limiter.acquire()
                return await make_api_call(
                    self.fallback_model, 
                    "gemini-2.5-flash-lite"
                )
        
        except (asyncio.TimeoutError, google_exceptions.ResourceExhausted, 
                json.JSONDecodeError, ValueError) as e:
            error_msg = str(e).lower()
            is_quota_error = (
                isinstance(e, google_exceptions.ResourceExhausted) or
                "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg
            )
            
            if is_quota_error:
                logging.warning(f"Quota exceeded (429), switching to fallback: {e}")
            else:
                logging.warning(f"Primary analysis failed: {type(e).__name__}: {e}")
            
            # Retry with first fallback model
            try:
                if use_pro_model or is_quota_error:
                    await self.fallback_limiter.acquire()
                    return await make_api_call(
                        self.fallback_model, 
                        "gemini-2.5-flash-lite (FALLBACK)"
                    )
                else:
                    await self.primary_limiter.acquire()
                    return await make_api_call(
                        self.primary_model, 
                        "gemini-2.5-pro (FALLBACK)"
                    )
            except (asyncio.TimeoutError, google_exceptions.ResourceExhausted,
                    json.JSONDecodeError, ValueError) as fallback_e:
                error_msg_2 = str(fallback_e).lower()
                is_quota_error_2 = (
                    isinstance(fallback_e, google_exceptions.ResourceExhausted) or
                    "429" in error_msg_2 or "quota" in error_msg_2 or "exceeded" in error_msg_2
                )
                
                if is_quota_error_2:
                    logging.warning(f"First fallback also hit quota limit, trying second fallback: {fallback_e}")
                
                # Try second fallback model
                try:
                    await self.fallback2_limiter.acquire()
                    return await make_api_call(
                        self.fallback2_model, 
                        "gemini-2.0-flash-lite (FALLBACK2)"
                    )
                except Exception as fallback2_e:
                    logging.error(f"All three models failed: {fallback2_e}\n{traceback.format_exc()}")
                    return None
        
        except Exception as e:
            logging.error(f"Unexpected error in analysis: {e}\n{traceback.format_exc()}")
            return None

    async def get_suspension_reason(self, container_name: str) -> str:
        """Generate AI-powered suspension reason with retry logic"""
        logs = db.get_suspicion_logs(container_name, limit=3)
        
        if not logs:
            return "No process logs available for analysis."
        
        formatted_logs = "\n\n".join([
            f"=== Detection {i+1} ===\n{log['process_list'][:1500]}"
            for i, log in enumerate(reversed(logs))
        ])
        
        prompt = f"""You are a cybersecurity analyst. Analyze these three process snapshots from an LXC container, taken at 5-minute intervals, that were flagged for cryptocurrency mining.

Provide a concise summary (3-5 bullet points) explaining:
- What processes indicate mining activity
- CPU usage patterns observed
- Any disguising/evasion techniques detected

Process Snapshots:
{formatted_logs}

Response format:
• [Key observation 1]
• [Key observation 2]
• [Key observation 3]
"""
        
        result = await self._call_gemini_with_fallback(prompt, timeout=60, use_primary_first=True)
        if result:
            return result
        
        # Fallback message if both models fail
        return "Analysis unavailable. Manual review recommended."

    async def notify_admin_of_suspicion(self, vps: dict, reason: str = "Suspicious activity detected."):
        """Send suspicion notification to admin"""
        container_name = vps['container_name']
        user_id = vps['user_id']
        
        try:
            admin = await self.bot.fetch_user(self.admin_user_id)
            
            embed = discord.Embed(
                title="⚠️ SUSPICIOUS ACTIVITY (LXC)",
                description=f"Container: `{container_name}`\nUser: `{user_id}`\n\n⚠️ Not suspended yet - requires confirmation",
                color=discord.Color.yellow(),
                timestamp=discord.utils.utcnow()
            )
            
            # Truncate reason if too long
            if len(reason) > 1024:
                reason = reason[:1020] + "..."
            
            embed.add_field(name="Analysis", value=reason, inline=False)
            embed.set_footer(text=f"Suspicion Count: {vps.get('suspicion_count', 0)}")
            
            await admin.send(embed=embed)
            
        except discord.Forbidden:
            logging.error(f"Cannot send DM to admin {self.admin_user_id}")
        except Exception as e:
            logging.error(f"Failed to notify admin: {e}")

    async def handle_mining_detection(self, vps: dict, reason: str = "No specific reason provided."):
        """Handle confirmed mining detection with improved error handling"""
        container_name = vps['container_name']
        user_id = vps['user_id']

        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            logging.error(f"Cannot suspend {container_name}: No node information")
            return

        try:
            # Pause container
            node_url, api_key = node_info['url'], node_info['api_key']
            await node_manager.api_request(
                'POST', 
                f"/lxc/container/{container_name}/pause", 
                node_url, 
                api_key
            )
            
            # Update database
            db.suspend_vps(container_name)
            
            logging.critical(f"Container {container_name} suspended for mining")
            
            # Notify admin
            try:
                admin = await self.bot.fetch_user(self.admin_user_id)
                
                embed = discord.Embed(
                    title="🚨 MINING DETECTED & SUSPENDED (LXC)",
                    description=f"**Container:** `{container_name}`\n**User:** `{user_id}`\n\n✅ Automatically suspended",
                    color=discord.Color.red(),
                    timestamp=discord.utils.utcnow()
                )
                
                if len(reason) > 1024:
                    reason = reason[:1020] + "..."
                
                embed.add_field(name="AI Analysis", value=reason, inline=False)
                
                view = UnsuspendView(container_name, user_id, self.bot, 'lxc')
                await admin.send(embed=embed, view=view)
                
            except Exception as e:
                logging.error(f"Failed to notify admin: {e}")
            
            # Notify user
            try:
                user = await self.bot.fetch_user(user_id)
                await user.send(
                    f"🚨 **Container Suspended**\n\n"
                    f"Your container `{container_name}` has been suspended for "
                    f"suspected cryptocurrency mining activity.\n\n"
                    f"If you believe this is an error, please contact support."
                )
            except Exception as e:
                logging.error(f"Failed to notify user {user_id}: {e}")
        
        except Exception as e:
            logging.error(f"Error handling mining detection for {container_name}: {e}\n{traceback.format_exc()}")

    @tasks.loop(minutes=5)
    async def monitor_lxc_network(self):
        """Monitor network usage across all LXC containers"""
        logging.info("=" * 60)
        logging.info("[TASK] 📊 monitor_lxc_network: EXECUTING NOW")
        logging.info("=" * 60)
        logging.info("Starting network monitoring...")
        
        try:
            all_vps = db.get_all_vps()
            # Filter LXC containers - handle None/NULL values by defaulting to 'lxc'
            lxc_vps = [vps for vps in all_vps if (vps.get('vps_type') or 'lxc') == 'lxc']

            high_usage_containers = []

            for vps in lxc_vps:
                container_name = vps['container_name']

                if db.is_vps_suspended(container_name):
                    continue

                try:
                    # Use dedicated status endpoint for more reliable checking
                    if not await self.is_container_running(container_name):
                        continue
                    
                    command = "cat /sys/class/net/eth0/statistics/rx_bytes /sys/class/net/eth0/statistics/tx_bytes"
                    result = await self.execute_command_in_container(
                        container_name, 
                        ["bash", "-c", command],
                        timeout=10
                    )

                    if result and result.get('stdout') and result.get('returncode') == 0:
                        lines = result.get('stdout').strip().split('\n')
                        if len(lines) < 2:
                            continue
                        
                        rx_bytes = int(lines[0])
                        tx_bytes = int(lines[1])
                        current_time = time.time()

                        if container_name in self.network_stats_history:
                            last_stats = self.network_stats_history[container_name]
                            time_delta = current_time - last_stats['time']
                            
                            if time_delta > 0:
                                total_bytes = (rx_bytes - last_stats['rx']) + (tx_bytes - last_stats['tx'])
                                
                                # Check threshold
                                if total_bytes > self.NETWORK_IO_THRESHOLD_5MIN:
                                    gb_used = total_bytes / (1024**3)
                                    high_usage_containers.append({
                                        "container_name": container_name,
                                        "usage_gb": round(gb_used, 2),
                                        "user_id": vps.get('user_id'),
                                        "time_window": round(time_delta / 60, 1)
                                    })
                                    logging.warning(f"High network usage in {container_name}: {gb_used:.2f} GB")

                        self.network_stats_history[container_name] = {
                            'rx': rx_bytes,
                            'tx': tx_bytes,
                            'time': current_time
                        }
                        
                        # Check anti-DDoS protection
                        if hasattr(self, 'antiddos'):
                            prev_tx = last_stats.get('tx', tx_bytes) if container_name in self.network_stats_history else tx_bytes
                            is_suspended = await self.antiddos.check_container_traffic(
                                container_name, 
                                tx_bytes, 
                                prev_tx
                            )
                            if is_suspended:
                                logging.critical(f"🛑 {container_name} suspended by anti-DDoS")
                                await self.handle_network_suspension(container_name, "DDoS activity detected")
                
                except (ValueError, IndexError) as e:
                    logging.debug(f"Could not parse network stats for {container_name}: {e}")
                except Exception as e:
                    logging.error(f"Error monitoring network for {container_name}: {e}")
            
            # Analyze high usage containers
            if high_usage_containers:
                logging.warning(f"Found {len(high_usage_containers)} containers with high network usage")
                suspension_decisions = await self.analyze_network_abuse(high_usage_containers)
                
                if suspension_decisions:
                    for decision in suspension_decisions:
                        if decision.get('suspend'):
                            container_name = decision['container_name']
                            reason = decision.get('reason', 'High network usage detected by AI.')
                            logging.critical(f"Suspending {container_name} for network abuse")
                            await self.handle_network_suspension(container_name, reason)

        except Exception as e:
            logging.error(f"Error in network monitoring loop: {e}\n{traceback.format_exc()}")
        finally:
            logging.info("Network monitoring completed")

    async def analyze_network_abuse(self, high_usage_data: List[Dict]) -> Optional[List[Dict]]:
        """Use AI to analyze network abuse patterns"""
        
        json_input = json.dumps(high_usage_data, indent=2)

        prompt = f"""You are a cybersecurity AI analyzing network abuse in VPS containers.

CONTEXT:
- Threshold for alert: {self.NETWORK_IO_THRESHOLD_5MIN / (1024**3):.1f} GB in 5 minutes
- This level is highly anomalous and often indicates:
  * DDoS attack participation
  * Large-scale file sharing/torrenting
  * Data exfiltration
  * Proxy/VPN abuse
- Normal VPS usage should NEVER reach this threshold

TASK:
Analyze each container and decide if suspension is warranted.

SUSPENSION CRITERIA:
- Usage > 15 GB: Almost certainly requires suspension
- Usage 10-15 GB: Likely abuse, suspend unless legitimate reason evident
- Multiple containers from same user: Coordinated attack pattern
- Consider time window and rate of transfer

INPUT DATA:
{json_input}

OUTPUT FORMAT (JSON only, no markdown):
[
  {{
    "container_name": "name",
    "suspend": true,
    "reason": "Brief explanation (e.g., 'Extreme usage of 18.2 GB in 5 min indicates DDoS or file sharing abuse')"
  }},
  ...
]
"""

        try:
            text = await self._call_gemini_with_fallback(prompt, timeout=120, use_primary_first=True)
            if not text:
                raise ValueError("Empty response from AI")
            
            text = text.strip()
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            start = text.find('[')
            end = text.rfind(']') + 1
            
            if start == -1 or end == 0:
                raise ValueError("No JSON array in response")
            
            json_text = text[start:end]
            result = json.loads(json_text)
            
            # Validate format
            if not isinstance(result, list):
                raise ValueError("Response is not an array")
            
            return result

        except (asyncio.TimeoutError, json.JSONDecodeError, ValueError) as e:
            logging.error(f"Network abuse analysis failed: {e}")
            # Default to suspension for safety
            return [{
                "container_name": c["container_name"], 
                "suspend": True, 
                "reason": f"AI analysis failed ({type(e).__name__}), suspending as precaution due to {c['usage_gb']} GB usage."
            } for c in high_usage_data]
        
        except Exception as e:
            logging.error(f"Unexpected error in network abuse analysis: {e}\n{traceback.format_exc()}")
            return None

    async def handle_network_suspension(self, container_name: str, reason: str):
        """Handle container suspension due to network abuse"""
        vps = db.get_vps_by_container_name(container_name)
        if not vps:
            logging.error(f"VPS not found for {container_name}")
            return

        user_id = vps['user_id']
        
        try:
            await self.suspend_container(container_name)
            
            # Notify admin
            admin = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="🚨 NETWORK ABUSE DETECTED (LXC)",
                description=f"**Container:** `{container_name}`\n**User:** `{user_id}`\n\n✅ Suspended for excessive network usage",
                color=discord.Color.red(),
                timestamp=discord.utils.utcnow()
            )
            
            if len(reason) > 1024:
                reason = reason[:1020] + "..."
            
            embed.add_field(name="AI Analysis", value=reason, inline=False)
            view = UnsuspendView(container_name, user_id, self.bot, 'lxc')
            await admin.send(embed=embed, view=view)
            
        except Exception as e:
            logging.error(f"Error sending network abuse notification: {e}")
            
        try:
            user = await self.bot.fetch_user(user_id)
            await user.send(
                f"🚨 **Container Suspended**\n\n"
                f"Your container `{container_name}` has been suspended for excessive network usage.\n\n"
                f"Please contact support if you believe this is an error."
            )
        except Exception as e:
            logging.error(f"Failed to notify user {user_id}: {e}")

    @tasks.loop(minutes=5)
    async def monitor_lxc_disk_io(self):
        """Monitor disk I/O across all LXC containers"""
        logging.info("=" * 60)
        logging.info("[TASK] 💾 monitor_lxc_disk_io: EXECUTING NOW")
        logging.info("=" * 60)
        logging.info("Starting disk I/O monitoring...")
        
        try:
            all_vps = db.get_all_vps()
            # Filter LXC containers - handle None/NULL values by defaulting to 'lxc'
            lxc_vps = [vps for vps in all_vps if (vps.get('vps_type') or 'lxc') == 'lxc']
            logging.info(f"Disk I/O monitoring: Found {len(lxc_vps)} LXC containers to check")

            high_usage_containers = []

            for vps in lxc_vps:
                container_name = vps['container_name']

                if db.is_vps_suspended(container_name):
                    continue

                try:
                    # Use dedicated status endpoint for more reliable checking
                    if not await self.is_container_running(container_name):
                        continue
                    
                    # Note: The API doesn't provide read/write bytes directly, only usage
                    # We'll need to track I/O differently or use a different method
                    read_bytes = 0  # Not available from get_container_info
                    write_bytes = 0  # Not available from get_container_info
                    current_time = time.time()

                    if container_name in self.disk_stats_history:
                        last_stats = self.disk_stats_history[container_name]
                        time_delta = current_time - last_stats['time']
                        
                        if time_delta > 0:
                            total_bytes = (read_bytes - last_stats['read']) + (write_bytes - last_stats['write'])
                            
                            if total_bytes > self.DISK_IO_THRESHOLD:
                                gb_used = total_bytes / (1024**3)
                                high_usage_containers.append({
                                    "container_name": container_name,
                                    "usage_gb": round(gb_used, 2),
                                    "user_id": vps.get('user_id'),
                                    "time_window": round(time_delta / 60, 1)
                                })
                                logging.warning(f"High disk I/O in {container_name}: {gb_used:.2f} GB")

                    self.disk_stats_history[container_name] = {
                        'read': read_bytes,
                        'write': write_bytes,
                        'time': current_time
                    }
                
                except (ValueError, KeyError) as e:
                    logging.debug(f"Could not parse disk stats for {container_name}: {e}")
                except Exception as e:
                    logging.error(f"Error monitoring disk for {container_name}: {e}")
            
            # Analyze high usage containers
            if high_usage_containers:
                logging.warning(f"Found {len(high_usage_containers)} containers with high disk I/O")
                suspension_decisions = await self.analyze_disk_abuse(high_usage_containers)
                
                if suspension_decisions:
                    for decision in suspension_decisions:
                        if decision.get('suspend'):
                            container_name = decision['container_name']
                            reason = decision.get('reason', 'High disk I/O detected by AI.')
                            logging.critical(f"Suspending {container_name} for disk abuse")
                            await self.handle_disk_suspension(container_name, reason)

        except Exception as e:
            logging.error(f"Error in disk I/O monitoring loop: {e}\n{traceback.format_exc()}")
        finally:
            logging.info("Disk I/O monitoring completed")

    async def analyze_disk_abuse(self, high_usage_data: List[Dict]) -> Optional[List[Dict]]:
        """Use AI to analyze disk abuse patterns"""
        
        json_input = json.dumps(high_usage_data, indent=2)

        prompt = f"""You are a cybersecurity AI analyzing disk I/O abuse in VPS containers.

CONTEXT:
- Threshold for alert: {self.DISK_IO_THRESHOLD / (1024**3):.1f} GB in 5 minutes
- This level indicates potential:
  * Ransomware encryption activity
  * Log bombing attacks
  * I/O bomb (fork bomb variant)
  * Filesystem stress testing
  * Large file operations abuse
- Normal operations should not trigger this threshold

TASK:
Analyze each container and decide if suspension is warranted.

SUSPENSION CRITERIA:
- Usage > 1 GB: Likely requires suspension
- Usage 0.5-1 GB: Investigate further, suspend if pattern continues
- Consider if this could be legitimate backup/restore operation
- Prioritize system stability and other users' performance

INPUT DATA:
{json_input}

OUTPUT FORMAT (JSON only, no markdown):
[
  {{
    "container_name": "name",
    "suspend": true,
    "reason": "Brief explanation (e.g., 'Extreme I/O of 1.2 GB suggests ransomware or I/O bomb')"
  }},
  ...
]
"""

        try:
            text = await self._call_gemini_with_fallback(prompt, timeout=120, use_primary_first=True)
            if not text:
                raise ValueError("Empty response from AI")
            
            text = text.strip()
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            start = text.find('[')
            end = text.rfind(']') + 1
            
            if start == -1 or end == 0:
                raise ValueError("No JSON array in response")
            
            json_text = text[start:end]
            result = json.loads(json_text)
            
            if not isinstance(result, list):
                raise ValueError("Response is not an array")
            
            return result

        except (asyncio.TimeoutError, json.JSONDecodeError, ValueError) as e:
            logging.error(f"Disk abuse analysis failed: {e}")
            return [{
                "container_name": c["container_name"], 
                "suspend": True, 
                "reason": f"AI analysis failed ({type(e).__name__}), suspending as precaution due to {c['usage_gb']} GB I/O."
            } for c in high_usage_data]
        
        except Exception as e:
            logging.error(f"Unexpected error in disk abuse analysis: {e}\n{traceback.format_exc()}")
            return None

    async def handle_disk_suspension(self, container_name: str, reason: str):
        """Handle container suspension due to disk I/O abuse"""
        vps = db.get_vps_by_container_name(container_name)
        if not vps:
            logging.error(f"VPS not found for {container_name}")
            return

        user_id = vps['user_id']
        
        try:
            await self.suspend_container(container_name)
            
            admin = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="🚨 DISK I/O ABUSE DETECTED (LXC)",
                description=f"**Container:** `{container_name}`\n**User:** `{user_id}`\n\n✅ Suspended for excessive disk I/O",
                color=discord.Color.red(),
                timestamp=discord.utils.utcnow()
            )
            
            if len(reason) > 1024:
                reason = reason[:1020] + "..."
            
            embed.add_field(name="AI Analysis", value=reason, inline=False)
            view = UnsuspendView(container_name, user_id, self.bot, 'lxc')
            await admin.send(embed=embed, view=view)
            
        except Exception as e:
            logging.error(f"Error sending disk abuse notification: {e}")
            
        try:
            user = await self.bot.fetch_user(user_id)
            await user.send(
                f"🚨 **Container Suspended**\n\n"
                f"Your container `{container_name}` has been suspended for excessive disk I/O.\n\n"
                f"Please contact support if you believe this is an error."
            )
        except Exception as e:
            logging.error(f"Failed to notify user {user_id}: {e}")

    @monitor_lxc_disk_io.before_loop
    async def before_monitor_lxc_disk_io(self):
        print("[TASK] monitor_lxc_disk_io: Waiting for bot to be ready...")
        logging.info("[TASK] monitor_lxc_disk_io: Waiting for bot to be ready...")
        await self.bot.wait_until_ready()
        print("[TASK] ✅ monitor_lxc_disk_io: Bot ready, task will start in 5 minutes")
        logging.info("[TASK] ✅ monitor_lxc_disk_io: Bot ready, task will start in 5 minutes")

    @monitor_lxc_network.before_loop
    async def before_monitor_lxc_network(self):
        print("[TASK] monitor_lxc_network: Waiting for bot to be ready...")
        logging.info("[TASK] monitor_lxc_network: Waiting for bot to be ready...")
        await self.bot.wait_until_ready()
        print("[TASK] ✅ monitor_lxc_network: Bot ready, task will start in 5 minutes")
        logging.info("[TASK] ✅ monitor_lxc_network: Bot ready, task will start in 5 minutes")

    @check_lxc_for_mining.before_loop
    async def before_check(self):
        print("[TASK] check_lxc_for_mining: Waiting for bot to be ready...")
        logging.info("[TASK] check_lxc_for_mining: Waiting for bot to be ready...")
        await self.bot.wait_until_ready()
        print("[TASK] ✅ check_lxc_for_mining: Bot ready, task will start in 5 minutes")
        logging.info("[TASK] ✅ check_lxc_for_mining: Bot ready, task will start in 5 minutes")
        
    @tasks.loop(hours=24)
    async def security_scan_loop(self):
        """Main security scanning loop - runs every 24 hours"""
        logging.info("=" * 60)
        logging.info("STARTING DAILY SECURITY SCAN")
        logging.info("=" * 60)
        
        try:
            all_vps = db.get_all_vps()
            # Filter LXC containers - handle None/NULL values by defaulting to 'lxc'
            lxc_vps = [vps for vps in all_vps if (vps.get('vps_type') or 'lxc') == 'lxc']
            logging.info(f"Security scan: Found {len(lxc_vps)} LXC containers to scan")
            
            total = len(lxc_vps)
            scanned = 0
            errors = 0
            
            for vps in lxc_vps:
                # Skip non-LXC containers (handle None/NULL values)
                if vps.get('vps_type') and vps.get('vps_type') != 'lxc':
                    continue

                container_name = vps['container_name']
                
                if vps.get('is_suspended'):
                    logging.info(f"Skipping suspended container: {container_name}")
                    continue
                
                try:
                    async with self.scan_semaphore:
                        await self.scan_container(container_name)
                        scanned += 1
                        
                        if scanned % 5 == 0:
                            logging.info(f"Progress: {scanned}/{total} containers scanned")
                
                except Exception as e:
                    errors += 1
                    logging.error(f"Error scanning {container_name}: {e}")
            
            logging.info("=" * 60)
            logging.info(f"SECURITY SCAN COMPLETED: {scanned} scanned, {errors} errors")
            logging.info(f"Metrics - Scans: {self.metrics['scans_completed']}, Threats: {self.metrics['threats_detected']}")
            logging.info("=" * 60)
            
        except Exception as e:
            logging.error(f"Critical error in security scan loop: {e}\n{traceback.format_exc()}")

    @security_scan_loop.before_loop
    async def before_security_scan(self):
        print("[TASK] security_scan_loop: Waiting for bot to be ready...")
        logging.info("[TASK] security_scan_loop: Waiting for bot to be ready...")
        await self.bot.wait_until_ready()
        print("[TASK] ✅ security_scan_loop: Bot ready, task will start in 24 hours")
        logging.info("[TASK] ✅ security_scan_loop: Bot ready, task will start in 24 hours")

    async def scan_container(self, container_name: str):
        """Comprehensive container security scan with improved efficiency"""
        logging.info(f"Starting security scan: {container_name}")
        
        try:
            # Use dedicated status endpoint for more reliable checking
            if not await self.is_container_running(container_name):
                logging.info(f"Container {container_name} not running, skipping scan")
                return
            
            # Get full container info for other checks
            status_result = await self.get_container_info(container_name)

            # Run checks in parallel
            abuse_task = self.check_resource_abuse(container_name)
            process_task = self.check_processes(container_name)
            network_task = self.check_network_connections(container_name)
            
            # Filesystem scan is heavy, run it separately
            abuse_detected, suspicious_processes, suspicious_connections = await asyncio.gather(
                abuse_task, process_task, network_task, return_exceptions=True
            )
            
            # Handle exceptions
            if isinstance(abuse_detected, Exception):
                logging.error(f"Resource abuse check failed: {abuse_detected}")
                abuse_detected = {}
            
            if isinstance(suspicious_processes, Exception):
                logging.error(f"Process check failed: {suspicious_processes}")
                suspicious_processes = []
            
            if isinstance(suspicious_connections, Exception):
                logging.error(f"Network check failed: {suspicious_connections}")
                suspicious_connections = []
            
            # Filesystem scan (slow)
            logging.info(f"[SCAN] Starting filesystem scan for {container_name}...")
            suspicious_files = await self.scan_filesystem(container_name)
            logging.info(f"[SCAN] Filesystem scan complete: {len(suspicious_files)} suspicious files found")
            
            # Calculate threat level
            if abuse_detected or suspicious_files or suspicious_processes or suspicious_connections:
                await self.handle_security_threat(
                    container_name,
                    abuse_detected,
                    suspicious_files,
                    suspicious_processes,
                    suspicious_connections
                )
            else:
                logging.info(f"Container {container_name} passed security scan")
            
            self.metrics['scans_completed'] += 1
            
        except Exception as e:
            logging.error(f"Error in scan_container for {container_name}: {e}\n{traceback.format_exc()}")

    async def check_resource_abuse(self, container_name: str) -> Dict:
        """Check for resource abuse with improved error handling"""
        abuse = {
            'cpu_abuse': False, 
            'disk_abuse': False, 
            'network_abuse': False, 
            'details': {}
        }
        
        try:
            info = await self.get_container_info(container_name)
            if not info or 'state' not in info or not info['state']:
                return abuse
            
            cpu_usage = info['state'].get('cpu_usage', 0)
            if cpu_usage > self.CPU_THRESHOLD:
                abuse['cpu_abuse'] = True
                abuse['details']['cpu'] = f"{cpu_usage}%"
                logging.warning(f"CPU abuse detected in {container_name}: {cpu_usage}%")
            
        except Exception as e:
            logging.error(f"Error checking resource abuse for {container_name}: {e}")
        
        return abuse

    async def load_official_hashes_for_container(self, container_name: str) -> bool:
        """Load official package hashes - SIMPLIFIED and CACHED"""
        try:
            logging.info(f"Building hash database for {container_name}...")
            
            # Use dpkg to get installed packages
            dpkg_command = r"""
            dpkg -l | awk '/^ii/ {print $2}' | head -100 | while read pkg; do
                dpkg -L "$pkg" 2>/dev/null | while read file; do
                    if [ -f "$file" ] && [ -r "$file" ]; then
                        sha256sum "$file" 2>/dev/null | awk '{print $1}'
                    fi
                done
            done | sort -u
            """
            
            result = await self.execute_command_in_container(
                container_name, 
                ["bash", "-c", dpkg_command],
                timeout=600  # 10 minutes
            )
            
            if result and result.get('returncode') == 0 and result.get('stdout'):
                hashes = result['stdout'].strip().split('\n')
                valid_hashes = [h for h in hashes if h and len(h) == 64]
                
                for hash_value in valid_hashes:
                    self.official_hashes[hash_value] = True
                
                logging.info(f"Loaded {len(valid_hashes)} official hashes for {container_name}")
                return True
            else:
                logging.warning(f"Failed to load hashes for {container_name}")
                return False
                
        except asyncio.TimeoutError:
            logging.error(f"Timeout loading hashes for {container_name}")
            return False
        except Exception as e:
            logging.error(f"Error loading hashes for {container_name}: {e}")
            return False

    async def should_skip_official_file(self, container_name: str, file_hash: str) -> bool:
        """Check if file is from official package"""
        if not self.official_hashes:
            cache_loaded = await self.load_official_hashes_from_cache(container_name)
            if not cache_loaded:
                success = await self.load_official_hashes_for_container(container_name)
                if success:
                    await self.save_official_hashes_to_cache(container_name)
        
        return file_hash in self.official_hashes

    async def load_official_hashes_from_cache(self, container_name: str) -> bool:
        """Load hashes from cache with improved path handling"""
        try:
            cache_dir = Path("/tmp/vps_hashes")
            cache_dir.mkdir(exist_ok=True)
            
            cache_file = cache_dir / f"{container_name}.json"
            
            if cache_file.exists():
                cache_age = time.time() - cache_file.stat().st_mtime
                
                if cache_age < 7 * 24 * 3600:  # 7 days
                    with open(cache_file, 'r') as f:
                        cache_data = json.load(f)
                        self.official_hashes = {h: True for h in cache_data}
                        logging.info(f"Loaded {len(self.official_hashes)} hashes from cache")
                        return True
                else:
                    logging.info(f"Cache for {container_name} expired, will rebuild")
                    cache_file.unlink()
        
        except Exception as e:
            logging.error(f"Error loading cache: {e}")
        
        return False

    async def save_official_hashes_to_cache(self, container_name: str):
        """Save hashes to cache with error handling"""
        try:
            cache_dir = Path("/tmp/vps_hashes")
            cache_dir.mkdir(exist_ok=True)
            
            cache_file = cache_dir / f"{container_name}.json"
            
            with open(cache_file, 'w') as f:
                json.dump(list(self.official_hashes.keys()), f)
            
            logging.info(f"Saved hash cache for {container_name}")
        
        except Exception as e:
            logging.error(f"Error saving cache: {e}")

    async def is_known_safe_file(self, container_name: str, filepath: str, file_hash: str) -> bool:
        """Comprehensive safe file detection"""
        # Check hash database
        if file_hash in self.official_hashes:
            return True
        
        # Safe directories
        safe_paths = [
            '/usr/share/doc/', '/usr/share/man/', '/usr/share/locale/',
            '/usr/share/info/', '/var/lib/dpkg/', '/var/cache/apt/',
            '/boot/', '/lib/modules/', '/usr/share/icons/',
            '/usr/share/fonts/', '/usr/share/pixmaps/'
        ]
        
        if any(filepath.startswith(path) for path in safe_paths):
            return True
        
        # Safe extensions in system directories
        safe_extensions = [
            '.txt', '.md', '.rst', '.log', '.conf', '.cfg', 
            '.ini', '.yml', '.yaml', '.json', '.xml', '.html', 
            '.css', '.js', '.py', '.sh', '.service'
        ]
        
        if any(filepath.endswith(ext) for ext in safe_extensions):
            system_dirs = ['/etc/', '/usr/share/', '/usr/lib/', '/lib/']
            if any(filepath.startswith(d) for d in system_dirs):
                return True
        
        return False

    async def scan_filesystem(self, container_name: str) -> List[Dict]:
        """Scan filesystem for suspicious files with improved efficiency"""
        logging.info(f"[FS] Starting filesystem scan for {container_name}")
        suspicious = []
        
        # Check if VirusTotal is available
        if not self.virustotal_api_key_data:
            logging.warning(f"[FS] No VirusTotal keys available - filesystem scan will be limited")
        
        try:
            # Load hash cache
            logging.info(f"[FS] Loading official hashes cache for {container_name}...")
            await self.load_official_hashes_from_cache(container_name)
            if not self.official_hashes:
                logging.info(f"[FS] Building hash database for {container_name} (may take 5-10 minutes)...")
                success = await self.load_official_hashes_for_container(container_name)
                if success:
                    await self.save_official_hashes_to_cache(container_name)
                    logging.info(f"[FS] Hash database built successfully for {container_name}")
            else:
                logging.info(f"[FS] Loaded {len(self.official_hashes)} official hashes from cache")
        
        except Exception as e:
            logging.error(f"[FS] Error loading hashes: {e}\n{traceback.format_exc()}")
        
        try:
            # Find unmanaged files in high-risk directories
            scan_command = r"""
            find /home /tmp /var/tmp /root /opt -type f -mtime -7 2>/dev/null | head -500 | while read file; do
                if ! dpkg -S "$file" >/dev/null 2>&1; then
                    echo "$file"
                fi
            done
            """
            
            result = await self.execute_command_in_container(
                container_name, 
                ["bash", "-c", scan_command],
                timeout=300
            )

            if not result or result.get('returncode') != 0:
                logging.warning(f"Filesystem scan failed for {container_name}, using fallback")
                return await self.fallback_scan_filesystem(container_name)

            files_to_scan = [
                f.strip() for f in result.get('stdout', '').strip().split('\n') 
                if f.strip()
            ]
            
            logging.info(f"[FS] Found {len(files_to_scan)} unmanaged files in {container_name}")
            
            if len(files_to_scan) == 0:
                logging.info(f"[FS] No files to scan in {container_name}")
                return suspicious

            scanned_count = 0
            skipped_count = 0
            
            # Limit scans to prevent API quota exhaustion
            files_to_process = files_to_scan[:100]  # Reduced from 200
            logging.info(f"[FS] Processing {len(files_to_process)} files (limited from {len(files_to_scan)})")
            
            for filepath in files_to_process:
                filepath = self._sanitize_filepath(filepath)
                if not filepath:
                    continue
                
                file_hash = await self.get_file_hash(container_name, filepath)
                if not file_hash:
                    continue
                
                # Skip known safe files
                if await self.is_known_safe_file(container_name, filepath, file_hash):
                    skipped_count += 1
                    continue
                
                # Analyze file
                logging.info(f"[FS] Analyzing file {scanned_count + 1}/{min(len(files_to_scan), 100)}: {filepath}")
                file_info = await self.analyze_file(container_name, filepath)
                if file_info and file_info.get('suspicious'):
                    suspicious.append(file_info)
                    security_score = file_info.get('threat_level', 50)
                    malicious_pct = file_info.get('malicious_percentage', 100 - security_score)
                    logging.warning(
                        f"[FS] Suspicious file found: {filepath} "
                        f"(security: {security_score}/100, {malicious_pct}% malicious)"
                    )
                elif file_info:
                    logging.debug(f"[FS] File analyzed but not suspicious: {filepath}")
                
                scanned_count += 1
                
                # Rate limit VT requests
                if scanned_count % 10 == 0:
                    logging.info(f"[FS] Progress: {scanned_count} files scanned, {skipped_count} skipped, {len(suspicious)} suspicious")
                    await asyncio.sleep(2)
            
            logging.info(
                f"Filesystem scan complete for {container_name}: "
                f"{scanned_count} scanned, {skipped_count} skipped, "
                f"{len(suspicious)} suspicious"
            )
            
        except Exception as e:
            logging.error(f"Error in filesystem scan for {container_name}: {e}\n{traceback.format_exc()}")
        
        return suspicious

    async def fallback_scan_filesystem(self, container_name: str) -> List[Dict]:
        """Simple fallback filesystem scan"""
        logging.warning(f"Using fallback scan for {container_name}")
        suspicious = []
        
        try:
            # Find recently modified files in suspicious locations
            command = [
                "find", "/home", "/tmp", "/var/tmp", "/root", 
                "-mtime", "-1", "-type", "f"
            ]
            
            result = await self.execute_command_in_container(
                container_name, 
                command,
                timeout=60
            )
            
            if not result or not result.get('stdout'):
                return suspicious
            
            files = result.get('stdout', '').strip().split('\n')
            
            for filepath in files[:50]:  # Limit to 50 files
                filepath = self._sanitize_filepath(filepath)
                if not filepath:
                    continue
                
                file_info = await self.analyze_file(container_name, filepath)
                if file_info and file_info.get('suspicious'):
                    suspicious.append(file_info)
        
        except Exception as e:
            logging.error(f"Error in fallback scan: {e}")
        
        return suspicious

    async def analyze_file(self, container_name: str, filepath: str) -> Optional[Dict]:
        """Analyze file for threats with caching and rate limiting"""
        try:
            logging.debug(f"[ANALYZE] Starting analysis for {filepath}")
            file_hash = await self.get_file_hash(container_name, filepath)
            if not file_hash:
                logging.debug(f"[ANALYZE] Could not get hash for {filepath}")
                return None
            
            # Check cache first
            cached_result = db.get_file_scan_result(file_hash)
            if cached_result:
                logging.debug(f"[ANALYZE] Using cached result for {filepath} (suspicious: {cached_result.get('suspicious')})")
                return cached_result if cached_result.get('suspicious') else None
            
            # Skip if known safe
            if await self.is_known_safe_file(container_name, filepath, file_hash):
                logging.debug(f"[ANALYZE] File is known safe: {filepath}")
                db.save_file_scan_result(file_hash, {
                    'hash': file_hash,
                    'filepath': filepath,
                    'threat_level': 0,
                    'suspicious': False,
                    'official': True
                })
                return None

            # Scan with VirusTotal (rate limited)
            logging.info(f"[ANALYZE] Scanning {filepath} with VirusTotal...")
            async with self.vt_semaphore:
                vt_result = await self.scan_with_virustotal(file_hash, container_name, filepath)
            
            if not vt_result:
                logging.warning(f"[ANALYZE] VirusTotal scan returned no result for {filepath}")
                return None
            
            threat_level = vt_result['threat_level']  # Now represents security score: 100=safe, 0=dangerous
            malicious_percentage = vt_result.get('malicious_percentage', 100 - threat_level)
            
            result = {
                'hash': file_hash,
                'filepath': filepath,
                'threat_level': threat_level,  # Security score: 100=safe, 0=dangerous
                'detection_ratio': vt_result['detection_ratio'],
                'suspicious': threat_level < 50,  # Inverted: low security score = suspicious
                'official': False,
                'vt_positives': vt_result['positives'],
                'vt_total': vt_result['total'],
                'malicious_percentage': malicious_percentage
            }
            
            # Handle based on security score (inverted logic: low score = dangerous)
            if threat_level < 30:
                # Very dangerous (security score < 30 means >70% malicious) - quarantine immediately
                await self.quarantine_file(container_name, filepath, file_hash, threat_level)
                result['quarantined'] = True
                logging.critical(
                    f"High threat file quarantined: {filepath} "
                    f"(security score: {threat_level}/100, {malicious_percentage}% malicious)"
                )
            
            elif 30 <= threat_level < 50:
                # Dangerous (security score 30-50 means 50-70% malicious) - AI assessment
                ai_decision = await self.ai_threat_assessment(container_name, filepath, result)
                result['ai_decision'] = ai_decision
                
                if ai_decision and ai_decision.get('quarantine', False):
                    await self.quarantine_file(container_name, filepath, file_hash, threat_level)
                    result['quarantined'] = True
                    logging.warning(f"AI recommended quarantine: {filepath} (security score: {threat_level}/100)")
            
            # Cache result
            db.save_file_scan_result(file_hash, result)
            
            return result if result['suspicious'] else None
            
        except Exception as e:
            logging.error(f"Error analyzing {filepath} in {container_name}: {e}")
            return None

    async def get_file_hash(self, container_name: str, filepath: str) -> Optional[str]:
        """Calculate SHA256 hash with improved error handling"""
        try:
            result = await self.execute_command_in_container(
                container_name, 
                ["sha256sum", filepath],
                timeout=10
            )
            
            if result and result.get('returncode') == 0 and result.get('stdout'):
                hash_value = result['stdout'].split()[0]
                
                # Validate hash format
                if len(hash_value) == 64 and all(c in '0123456789abcdef' for c in hash_value):
                    return hash_value
            
            return None
        
        except asyncio.TimeoutError:
            logging.debug(f"Timeout hashing {filepath}")
            return None
        except Exception as e:
            logging.debug(f"Could not hash {filepath}: {e}")
            return None

    async def _get_next_virustotal_api_key_data(self) -> Optional[Dict[str, Any]]:
        """Get next available VirusTotal API key with load balancing across all keys"""
        if not self.virustotal_api_key_data:
            return None
        
        today_date = datetime.now().date()
        today_str = today_date.strftime('%Y-%m-%d')
        
        # First, update all keys' daily counts from database if needed
        available_keys = []
        for key_data in self.virustotal_api_key_data:
            # Reset daily counter if new day - reload from database
            if key_data['last_reset_date'] != today_date:
                key_hash_full = key_data.get('key_hash', self._get_virustotal_key_hash(key_data['key']))
                # Reload count from database for the new day
                daily_count = db.get_virustotal_daily_requests(today_str, key_hash_full)
                key_hash_short = key_hash_full[:8]
                logging.info(
                    f"Resetting VT key {key_hash_short}. "
                    f"Old count: {key_data['daily_request_count']}, "
                    f"New day count from DB: {daily_count}"
                )
                key_data['daily_request_count'] = daily_count
                key_data['last_reset_date'] = today_date
                key_data['consecutive_errors'] = 0
            
            # Check if key is available (500 requests/day limit as per VirusTotal API)
            if key_data['daily_request_count'] < 500 and key_data['consecutive_errors'] < 5:
                available_keys.append(key_data)
        
        if not available_keys:
            logging.error("All VirusTotal API keys exhausted or have too many errors")
            return None
        
        # Load balancing: Select the key with the least requests used today
        # This ensures even distribution across all available keys
        selected_key = min(available_keys, key=lambda k: k['daily_request_count'])
        
        # Update round-robin index for fallback scenarios
        try:
            self.vt_key_index = self.virustotal_api_key_data.index(selected_key)
        except ValueError:
            pass
        
        key_hash_short = selected_key.get('key_hash', self._get_virustotal_key_hash(selected_key['key']))[:8]
        logging.debug(
            f"Selected VT key {key_hash_short} with {selected_key['daily_request_count']}/500 requests used. "
            f"Available keys: {len(available_keys)}/{len(self.virustotal_api_key_data)}"
        )
        
        return selected_key

    async def scan_with_virustotal(
        self, 
        file_hash: str, 
        container_name: str, 
        filepath: str
    ) -> Optional[Dict]:
        """Scan file with VirusTotal API with improved error handling"""
        logging.info(f"[VT] Scanning file: {filepath} (hash: {file_hash[:16]}...) in {container_name}")
        
        key_data = await self._get_next_virustotal_api_key_data()
        
        if not key_data or not key_data.get('per_minute_limiter'):
            logging.warning(f"[VT] No VT API key available for {file_hash}. Total keys: {len(self.virustotal_api_key_data)}")
            return None
        
        virustotal_api_key = key_data['key']
        per_minute_limiter = key_data['per_minute_limiter']

        try:
            await per_minute_limiter.acquire()

            url = f"https://www.virustotal.com/api/v3/files/{file_hash}"
            headers = {"x-apikey": virustotal_api_key}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=15) as response:
                    # Increment counter after successful request
                    if response.status in [200, 404]:  # Count both successful lookups and not found
                        key_data['daily_request_count'] += 1
                        key_hash_full = key_data.get('key_hash', self._get_virustotal_key_hash(virustotal_api_key))
                        db.increment_virustotal_daily_requests(
                            datetime.now().strftime('%Y-%m-%d'), 
                            key_hash_full
                        )

                    logging.debug(f"[VT] Response status: {response.status} for {filepath}")

                    if response.status == 200:
                        data = await response.json()
                        
                        if not data or 'data' not in data:
                            logging.error(f"[VT] Invalid VT response for {file_hash}")
                            return None
                        
                        attributes = data['data'].get('attributes', {})
                        stats = attributes.get('last_analysis_stats', {})
                        
                        positives = stats.get('malicious', 0)
                        total = sum(stats.values())
                        
                        # Calculate security score: 100 = safe, 0 = very dangerous
                        # If 78/100 detect as malicious, security score = 100 - 78 = 22 (low = dangerous)
                        malicious_percentage = int((positives / total) * 100) if total > 0 else 0
                        security_score = 100 - malicious_percentage  # Inverted: high = safe, low = dangerous
                        
                        key_data['consecutive_errors'] = 0  # Reset on success
                        
                        logging.info(
                            f"[VT] Scan result for {filepath}: {positives}/{total} detections "
                            f"(malicious: {malicious_percentage}%, security score: {security_score}/100)"
                        )
                        
                        return {
                            'positives': positives, 
                            'total': total, 
                            'detection_ratio': f"{positives}/{total}", 
                            'threat_level': security_score,  # Now represents security: 100=safe, 0=dangerous
                            'malicious_percentage': malicious_percentage  # Keep original for reference
                        }
                    
                    elif response.status == 404:
                        # File not in VT database - try uploading
                        logging.info(f"[VT] File not in database, uploading {filepath} to VT...")
                        return await self.upload_to_virustotal(container_name, filepath, file_hash)
                    
                    elif response.status == 429:
                        logging.warning(f"[VT] Rate limit hit for key (daily: {key_data['daily_request_count']})")
                        key_data['consecutive_errors'] += 1
                        return None
                    
                    else:
                        logging.warning(f"[VT] API returned {response.status} for {file_hash}")
                        key_data['consecutive_errors'] += 1
                        return None
        
        except asyncio.TimeoutError:
            logging.error(f"VT scan timeout for {file_hash}")
            key_data['consecutive_errors'] += 1
            return None
        
        except Exception as e:
            logging.error(f"VT scan error for {file_hash}: {e}")
            key_data['consecutive_errors'] += 1
            return None

    async def upload_to_virustotal(
        self, 
        container_name: str, 
        filepath: str, 
        file_hash: str
    ) -> Optional[Dict]:
        """Upload file to VirusTotal with size limits"""
        key_data = await self._get_next_virustotal_api_key_data()

        if not key_data or not key_data.get('per_minute_limiter'):
            logging.warning(f"No VT key available for uploading {filepath}")
            return None

        virustotal_api_key = key_data['key']
        per_minute_limiter = key_data['per_minute_limiter']

        try:
            # Get file content (limit to 32 MB for VT API)
            file_content = await self.get_file_content_from_container(
                container_name, 
                filepath, 
                32 * 1024 * 1024
            )

            if file_content is None:
                logging.error(f"Failed to get file content for {filepath}")
                return None
            
            # Check file size
            if len(file_content) > 32 * 1024 * 1024:
                logging.warning(f"File {filepath} too large for VT upload ({len(file_content)} bytes)")
                return None

            await per_minute_limiter.acquire()

            url = "https://www.virustotal.com/api/v3/files"
            headers = {"x-apikey": virustotal_api_key}

            async with aiohttp.ClientSession() as session:
                data = aiohttp.FormData()
                data.add_field(
                    'file', 
                    file_content, 
                    filename=os.path.basename(filepath)
                )
                
                async with session.post(url, headers=headers, data=data, timeout=120) as response:
                    # Increment counter after successful upload
                    if response.status == 200:
                        key_data['daily_request_count'] += 1
                        key_hash_full = key_data.get('key_hash', self._get_virustotal_key_hash(virustotal_api_key))
                        db.increment_virustotal_daily_requests(
                            datetime.now().strftime('%Y-%m-%d'), 
                            key_hash_full
                        )

                    if response.status == 200:
                        logging.info(f"File {filepath} uploaded to VT, waiting for analysis...")
                        await asyncio.sleep(90)  # Wait for analysis
                        return await self.scan_with_virustotal(file_hash, container_name, filepath)
                    else:
                        logging.warning(f"VT upload failed with status {response.status}")
                        return None
        
        except asyncio.TimeoutError:
            logging.error(f"VT upload timeout for {filepath}")
            return None
        except Exception as e:
            logging.error(f"Error uploading {filepath} to VT: {e}")
            return None

    async def ai_threat_assessment(
        self, 
        container_name: str, 
        filepath: str, 
        scan_result: Dict
    ) -> Dict:
        """Use AI to assess medium-threat files"""
        try:
            file_content = await self.get_file_content_from_container(
                container_name, 
                filepath, 
                8192  # First 8KB
            )
            
            content_preview = "Binary file or unreadable"
            if file_content:
                try:
                    content_preview = file_content.decode('utf-8', errors='ignore')[:2000]
                except:
                    content_preview = "Binary content"
            
            security_score = scan_result.get('threat_level', 50)
            malicious_pct = scan_result.get('malicious_percentage', 100 - security_score)
            
            prompt = f"""You are a cybersecurity analyst. Assess if this file should be quarantined.

**File Details:**
- Path: {filepath}
- Container: {container_name}
- Security Score: {security_score}/100 ({malicious_pct}% detected as malicious)
- VirusTotal: {scan_result['detection_ratio']} detections

**Content Preview:**
```
{content_preview}
```

**Context:**
- This file has moderate threat indicators (50-70%)
- Could be a false positive or legitimate security tool
- Consider: location, content, detection ratio

**Decision Required:**
Should this file be quarantined?

**Response Format (JSON only):**
{{
  "quarantine": true/false,
  "reason": "Brief explanation",
  "confidence": 0-100
}}
"""

            text = await self._call_gemini_with_fallback(prompt, timeout=45, use_primary_first=True)
            if not text:
                raise ValueError("Empty AI response")
            
            text = text.strip()
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            result = json.loads(text)
            
            # Validate response
            if 'quarantine' not in result:
                result['quarantine'] = True  # Default to safe
            
            return result
        
        except Exception as e:
            logging.error(f"AI assessment error for {filepath}: {e}")
            return {
                'quarantine': True, 
                'reason': 'AI assessment failed, defaulting to quarantine for safety', 
                'confidence': 50
            }

    async def quarantine_file(
        self, 
        container_name: str, 
        filepath: str, 
        file_hash: str, 
        threat_level: int
    ):
        """Quarantine suspicious file with improved safety"""
        try:
            quarantine_dir = "/var/quarantine"
            
            # Create quarantine directory with restricted permissions
            await self.execute_command_in_container(
                container_name, 
                ["mkdir", "-p", quarantine_dir]
            )
            
            await self.execute_command_in_container(
                container_name, 
                ["chmod", "700", quarantine_dir]
            )
            
            # Generate unique quarantine filename
            filename = os.path.basename(filepath)
            timestamp = int(time.time())
            quarantine_path = f"{quarantine_dir}/{filename}_{timestamp}.quarantined"
            
            # Move file to quarantine
            result = await self.execute_command_in_container(
                container_name, 
                ["mv", filepath, quarantine_path]
            )
            
            if result and result.get('returncode') == 0:
                # Remove execute permissions
                await self.execute_command_in_container(
                    container_name, 
                    ["chmod", "000", quarantine_path]
                )
                
                logging.warning(f"File quarantined: {filepath} -> {quarantine_path}")
                db.log_quarantine(container_name, filepath, quarantine_path, file_hash, threat_level)
            else:
                logging.error(f"Failed to quarantine {filepath}")
        
        except Exception as e:
            logging.error(f"Error quarantining {filepath}: {e}")

    async def check_processes(self, container_name: str) -> List[Dict]:
        """Check for suspicious processes with improved detection"""
        suspicious = []
        
        try:
            result = await self.execute_command_in_container(
                container_name, 
                ["ps", "aux"],
                timeout=10
            )
            
            if not result or result.get('returncode') != 0:
                return suspicious
            
            processes = result.get('stdout', '').strip().split('\n')[1:]  # Skip header
            
            # Suspicious patterns
            suspicious_patterns = [
                'xmrig', 'cpuminer', 'minerd', 'ddos', 'flood', 
                'scanner', 'masscan', 'nmap', 'zmap', 'nikto',
                'sqlmap', 'metasploit', 'meterpreter', 'payload'
            ]
            
            for process_line in processes:
                parts = process_line.split(None, 10)
                if len(parts) < 11:
                    continue
                
                try:
                    cpu = float(parts[2])
                    mem = float(parts[3])
                    user = parts[0]
                    command = parts[10]
                    
                    # Check for suspicious patterns
                    if any(p in command.lower() for p in suspicious_patterns):
                        suspicious.append({
                            'command': command[:200],
                            'cpu': cpu,
                            'mem': mem,
                            'user': user,
                            'reason': 'Matches known malware/attack tool pattern'
                        })
                    
                    # Check for high CPU with suspicious characteristics
                    elif cpu > 80:
                        # Check if from unusual user
                        unusual_users = ['nobody', 'systemd-coredump', 'upd', 'sys']
                        if user in unusual_users:
                            suspicious.append({
                                'command': command[:200],
                                'cpu': cpu,
                                'mem': mem,
                                'user': user,
                                'reason': f'High CPU ({cpu}%) from unusual user "{user}"'
                            })
                
                except (ValueError, IndexError):
                    continue
        
        except Exception as e:
            logging.error(f"Error checking processes for {container_name}: {e}")
        
        return suspicious

    async def check_network_connections(self, container_name: str) -> List[Dict]:
        """Check for suspicious network connections"""
        suspicious = []
        
        try:
            # Try ss first (more modern)
            result = await self.execute_command_in_container(
                container_name, 
                ["ss", "-tunp"],
                timeout=10
            )
            
            # Fallback to netstat if ss not available
            if not result or result.get('returncode') != 0:
                result = await self.execute_command_in_container(
                    container_name, 
                    ["netstat", "-tunp"],
                    timeout=10
                )
            
            # If both fail, skip
            if not result or result.get('returncode') != 0:
                logging.debug(f"Network tools unavailable in {container_name}")
                return suspicious
            
            connections = result.get('stdout', '').strip().split('\n')
            
            # Known mining pool and malicious ports
            suspicious_ports = [
                3333, 4444, 5555, 6666, 7777, 8333, 9999,
                14444, 45560, 1337, 31337
            ]
            
            for conn in connections:
                if 'ESTABLISHED' in conn or 'ESTAB' in conn:
                    try:
                        parts = conn.split()
                        if len(parts) < 5:
                            continue
                        
                        # Parse remote address
                        remote = parts[4] if 'netstat' in str(result.get('command', '')) else parts[5]
                        
                        if ':' in remote:
                            port_str = remote.split(':')[-1]
                            try:
                                port = int(port_str)
                                
                                if port in suspicious_ports:
                                    suspicious.append({
                                        'remote': remote,
                                        'port': port,
                                        'reason': f'Connection to known malicious port {port}'
                                    })
                            except ValueError:
                                continue
                    
                    except (IndexError, ValueError):
                        continue
        
        except Exception as e:
            logging.debug(f"Error checking network for {container_name}: {e}")
        
        return suspicious

    async def handle_security_threat(
        self, 
        container_name: str, 
        abuse: Dict, 
        files: List[Dict], 
        processes: List[Dict], 
        connections: List[Dict]
    ):
        """Handle detected security threats with risk-based response"""
        logging.warning(f"Security threat detected in {container_name}")
        
        # Calculate threat score (0 = safe, 100 = very dangerous)
        # This is the inverse of security score for consistency with existing logic
        threat_score = 0
        
        # Add file threat scores (low security score = high threat)
        if files:
            # Average security scores of suspicious files (inverted: low security = high threat)
            # threat_level now represents security: 100=safe, 0=dangerous
            # So we convert to threat: 0=safe, 100=dangerous
            file_threats = []
            files_with_score = 0
            for f in files:
                security_score = f.get('threat_level')
                if security_score is not None:
                    # Convert security score to threat: 100 - security_score
                    # Example: security_score=22 (low=safe) -> threat=78 (high=dangerous)
                    file_threat = 100 - security_score
                    file_threats.append(file_threat)
                    files_with_score += 1
            
            if file_threats:
                avg_file_threat = sum(file_threats) / len(file_threats)
                # Use the average threat, but ensure minimum contribution for suspicious files
                file_contribution = max(avg_file_threat, 30)  # Minimum 30 if files are detected
                threat_score += min(file_contribution, 50)  # Cap file contribution at 50
                logging.info(
                    f"File threats calculated: {file_threats}, avg: {avg_file_threat:.1f}, "
                    f"contribution: {min(file_contribution, 50)} (from {files_with_score} files with scores)"
                )
            else:
                # Fallback: if no threat_level, assume medium threat (50) for each file
                threat_score += min(len(files) * 25, 50)  # 25 points per file, max 50 total
                logging.warning(
                    f"No threat_level in {len(files)} suspicious file(s), using fallback: "
                    f"{min(len(files) * 25, 50)} points"
                )
        
        threat_score += len(processes) * 15
        threat_score += len(connections) * 10
        
        if abuse.get('cpu_abuse'):
            threat_score += 20
        if abuse.get('disk_abuse'):
            threat_score += 15
        if abuse.get('network_abuse'):
            threat_score += 15
        
        # Only set minimum score if there are actual suspicious items
        # Don't force a minimum if everything is clean (false positives)
        has_real_threats = (
            (files and any(f.get('threat_level') is not None or f.get('suspicious') for f in files)) or
            (processes and len(processes) > 0) or
            (connections and len(connections) > 0) or
            abuse.get('cpu_abuse') or 
            abuse.get('disk_abuse') or 
            abuse.get('network_abuse')
        )
        
        if has_real_threats and threat_score == 0:
            # If we have threats but score is 0, set minimum to ensure detection
            threat_score = 10
        
        # Cap at 100
        threat_score = min(threat_score, 100)
        
        logging.info(
            f"Calculated threat_score for {container_name}: {threat_score}/100 "
            f"(files: {len(files)}, processes: {len(processes)}, connections: {len(connections)}, "
            f"abuse: {bool(abuse.get('cpu_abuse') or abuse.get('disk_abuse') or abuse.get('network_abuse'))})"
        )
        
        # Log to database
        threat_data = {
            'abuse': abuse,
            'files': files[:5],  # Limit data size
            'processes': processes[:5],
            'connections': connections[:5]
        }
        
        db.log_security_threat(container_name, threat_score, json.dumps(threat_data))
        
        vps = db.get_vps_by_container_name(container_name)
        if not vps:
            logging.error(f"VPS not found for {container_name}")
            return
        
        # Risk-based response - only act if threat_score is significant
        if threat_score == 0:
            # No real threat detected, just log for monitoring
            logging.info(f"No significant threat in {container_name} (score: 0/100). Skipping alert.")
            return
        
        if threat_score >= 80:
            # Critical - suspend immediately
            logging.critical(f"CRITICAL THREAT in {container_name} (score: {threat_score})")
            await self.suspend_container(container_name)
            await self.notify_admins(vps, "CRITICAL", threat_score, abuse, files, processes, connections)
            self.metrics['threats_detected'] += 1
        
        elif threat_score >= 50:
            # High - increment suspicion
            new_count = db.increment_suspicion_count(container_name)
            
            if new_count >= 3:
                logging.warning(f"Suspending {container_name} after {new_count} violations (score: {threat_score})")
                await self.suspend_container(container_name)
            
            await self.notify_admins(vps, "HIGH", threat_score, abuse, files, processes, connections)
            self.metrics['threats_detected'] += 1
        
        elif threat_score >= 10:
            # Medium - notify only (minimum threshold to avoid false positives)
            await self.notify_admins(vps, "MEDIUM", threat_score, abuse, files, processes, connections)
        else:
            # Very low threat score (< 10) - log but don't alert
            logging.info(
                f"Low threat detected in {container_name} (score: {threat_score}/100). "
                f"Logged but not alerting to avoid false positives."
            )

    async def suspend_container(self, container_name: str):
        """Suspend container with improved error handling"""
        try:
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                logging.error(f"Cannot suspend {container_name}: No node info")
                return
            
            node_url, api_key = node_info['url'], node_info['api_key']
            
            # Stop container
            await node_manager.api_request(
                'POST', 
                f"/lxc/container/{container_name}/stop", 
                node_url, 
                api_key
            )
            
            # Update database
            db.suspend_vps(container_name)
            
            logging.warning(f"Container {container_name} suspended successfully")
        
        except Exception as e:
            logging.error(f"Error suspending {container_name}: {e}")
            
    async def notify_admins(
        self, 
        vps: dict, 
        severity: str, 
        score: int, 
        abuse: Dict, 
        files: List[Dict], 
        procs: List[Dict], 
        conns: List[Dict]
    ):
        """Send security notification to administrators"""
        try:
            admin = await self.bot.fetch_user(self.admin_user_id)
            
            color_map = {
                'CRITICAL': discord.Color.dark_red(),
                'HIGH': discord.Color.red(),
                'MEDIUM': discord.Color.orange()
            }
            
            embed = discord.Embed(
                title=f"🚨 Security Alert - {severity}",
                description=(
                    f"**Container:** `{vps['container_name']}`\n"
                    f"**User:** `{vps['user_id']}`\n"
                    f"**Threat Score:** {score}/100"
                ),
                color=color_map.get(severity, discord.Color.red()),
                timestamp=discord.utils.utcnow()
            )
            
            # Add details
            if abuse.get('details'):
                details_str = json.dumps(abuse['details'], indent=2)
                embed.add_field(
                    name="Resource Abuse", 
                    value=f"```json\n{details_str[:500]}\n```", 
                    inline=False
                )
            
            if files:
                file_summary = f"{len(files)} suspicious files detected"
                if files:
                    top_file = files[0]
                    security_score = top_file.get('threat_level', 50)  # Security score: 100=safe, 0=dangerous
                    malicious_pct = top_file.get('malicious_percentage', 100 - security_score)
                    file_summary += (
                        f"\n• {top_file.get('filepath', 'unknown')} "
                        f"(security: {security_score}/100, {malicious_pct}% malicious)"
                    )
                embed.add_field(name="Files", value=file_summary, inline=False)
            
            if procs:
                proc_summary = f"{len(procs)} suspicious processes"
                if procs:
                    top_proc = procs[0]
                    proc_summary += f"\n• {top_proc.get('command', 'unknown')[:100]}"
                embed.add_field(name="Processes", value=proc_summary, inline=False)
            
            if conns:
                conn_summary = f"{len(conns)} suspicious connections"
                if conns:
                    top_conn = conns[0]
                    conn_summary += f"\n• {top_conn.get('remote', 'unknown')} (port {top_conn.get('port', 0)})"
                embed.add_field(name="Connections", value=conn_summary, inline=False)
            
            embed.set_footer(text=f"Suspicion Count: {vps.get('suspicion_count', 0)}")
            
            view = None
            if vps.get('is_suspended'):
                view = UnsuspendView(vps['container_name'], vps['user_id'], self.bot, 'lxc')
            
            await admin.send(embed=embed, view=view)
            
        except discord.Forbidden:
            logging.error(f"Cannot send DM to admin {self.admin_user_id}")
        except Exception as e:
            logging.error(f"Failed to send security alert: {e}")

    async def is_container_running(self, container_name: str) -> bool:
        """Check if container is running (info endpoint)"""
        try:
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                return False
            
            # Use /info endpoint like manage.py does (line 868)
            vps_info_raw = await node_manager.api_request(
                'GET', 
                f"/lxc/container/{container_name}/info", 
                node_info['url'], 
                node_info['api_key']
            )
            # Check status exactly like manage.py does (line 871)
            return vps_info_raw and vps_info_raw.get('status') == 'running'
        except Exception as e:
            logging.error(f"Error checking status for {container_name}: {e}")
            return False

    async def get_container_info(self, container_name: str) -> Optional[Dict]:
        """Get container information from node API"""
        try:
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                return None
            
            return await node_manager.api_request(
                'GET', 
                f"/lxc/container/{container_name}/info", 
                node_info['url'], 
                node_info['api_key']
            )
        except Exception as e:
            logging.error(f"Error getting info for {container_name}: {e}")
            return None

    async def execute_command_in_container(
        self,
        container_name: str,
        command: list,
        timeout: int = 600
    ) -> dict:
        """Execute command in container with timeout"""
        try:
            logging.info(f"Executing command in {container_name}: {' '.join(command)}")
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                logging.error(f"No node info for command execution in {container_name}")
                return {}

            result = await node_manager.api_request(
                'POST',
                f"/lxc/container/{container_name}/exec",
                node_info['url'],
                node_info['api_key'],
                data={"command": command},
                timeout_seconds=timeout
            )
            logging.info(f"Command result for {container_name}: returncode={result.get('returncode')}, stdout_len={len(result.get('stdout', ''))}")
            return result
        except asyncio.TimeoutError:
            logging.error(f"Command timeout in {container_name}: {' '.join(command)}")
            return {'returncode': 1, 'error': 'timeout'}
        except Exception as e:
            logging.error(f"Error executing command in {container_name}: {e}")
            return {}
        
    async def get_file_content_from_container(
        self, 
        container_name: str, 
        filepath: str, 
        size_limit: Optional[int] = None
    ) -> Optional[bytes]:
        """Get file content from container with size limit"""
        try:
            node_info = node_manager.get_node_for_vps(container_name)
            if not node_info:
                return None
            
            # Sanitize filepath
            filepath = self._sanitize_filepath(filepath)
            if not filepath:
                return None
            
            params = {"path": filepath}
            if size_limit:
                params["size"] = size_limit

            headers = {'Authorization': f'Bearer {node_info["api_key"]}'}
            
            async with aiohttp.ClientSession() as session:
                url = f'{node_info["url"]}/lxc/container/{container_name}/file'
                
                async with session.get(url, params=params, headers=headers, timeout=30) as response:
                    if response.status == 200:
                        return await response.read()
                    else:
                        logging.debug(f"Failed to get file {filepath}: HTTP {response.status}")
                        return None
        
        except asyncio.TimeoutError:
            logging.error(f"Timeout getting file {filepath} from {container_name}")
            return None
        except Exception as e:
            logging.error(f"Error getting file {filepath}: {e}")
            return None


class UnsuspendView(View):
    """Discord view for unsuspending containers"""
    
    def __init__(self, container_name: str, user_id: int, bot, vps_type: str):
        super().__init__(timeout=None)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Unsuspend", style=discord.ButtonStyle.danger)
    async def unsuspend_button(self, interaction: discord.Interaction, button: Button):
        """Handle unsuspend button click"""
        entity_type = "Container" if self.vps_type == 'lxc' else "VM"
        
        confirm_view = ConfirmUnsuspendView(
            self.container_name, 
            self.user_id, 
            self.bot, 
            self.vps_type
        )
        
        embed = discord.Embed(
            title=f"⚠️ Confirm Unsuspend {entity_type}",
            description=f"Are you sure you want to unsuspend `{self.container_name}`?",
            color=discord.Color.orange()
        )
        
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)


class ConfirmUnsuspendView(View):
    """Confirmation view for unsuspending"""
    
    def __init__(self, container_name: str, user_id: int, bot, vps_type: str):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Yes, Unsuspend", style=discord.ButtonStyle.success)
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        """Handle unsuspend confirmation"""
        await interaction.response.defer(ephemeral=True)
        
        entity_type = "Container" if self.vps_type == 'lxc' else "VM"
        
        try:
            # Update database
            db.unsuspend_vps(self.container_name)
            db.reset_suspicion_count(self.container_name)
            db.clear_suspicion_logs(self.container_name)

            node_info = node_manager.get_node_for_vps(self.container_name)
            if not node_info:
                await interaction.followup.send(
                    f"❌ Failed: Could not determine node for {self.container_name}.", 
                    ephemeral=True
                )
                return
            
            node_url, api_key = node_info['url'], node_info['api_key']

            # Resume/start container based on type
            if self.vps_type == 'lxc':
                await node_manager.api_request(
                    'POST', 
                    f"/lxc/container/{self.container_name}/resume", 
                    node_url, 
                    api_key
                )
            elif self.vps_type == 'kvm':
                await node_manager.api_request(
                    'POST', 
                    f"/kvm/vm/{self.container_name}/start", 
                    node_url, 
                    api_key
                )
            
            # Send success message
            success_embed = discord.Embed(
                title="✅ Unsuspended Successfully",
                description=f"{entity_type} `{self.container_name}` has been unsuspended.",
                color=discord.Color.green(),
                timestamp=discord.utils.utcnow()
            )
            
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
            # Notify user
            try:
                user = await self.bot.fetch_user(self.user_id)
                await user.send(
                    f"✅ **{entity_type} Unsuspended**\n\n"
                    f"Your {entity_type.lower()} `{self.container_name}` has been unsuspended.\n\n"
                    f"Please ensure you comply with our terms of service to avoid future suspensions."
                )
            except discord.Forbidden:
                logging.warning(f"Could not notify user {self.user_id} about unsuspension")
            except Exception as e:
                logging.error(f"Error notifying user about unsuspension: {e}")
            
            # Disable buttons
            for item in self.children:
                item.disabled = True
            
            if interaction.message:
                try:
                    await interaction.message.edit(view=self)
                except:
                    pass
        
        except Exception as e:
            logging.error(f"Failed to unsuspend {self.container_name}: {e}\n{traceback.format_exc()}")
            await interaction.followup.send(
                f"❌ Failed to unsuspend: {str(e)[:200]}", 
                ephemeral=True
            )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        """Handle cancellation"""
        for item in self.children:
            item.disabled = True
        
        embed = discord.Embed(
            title="Cancelled",
            description="Unsuspend operation cancelled.",
            color=discord.Color.grey()
        )
        
        await interaction.response.edit_message(embed=embed, view=self)


class AntiDDoSMonitor:
    """Monitor container network traffic for DDoS detection"""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        self.threshold_mbps = 40  # 40 MB/s threshold
        self.violation_count = {}
        self.suspension_threshold = 2
        
        # Traffic history: {container_name: [(timestamp, bytes_sent), ...]}
        self.traffic_history = {}
        self.max_history_age = 300  # Keep 5 minutes of history
        
    async def check_container_traffic(self, container_name: str, tx_bytes: int, previous_tx_bytes: int) -> bool:
        """
        Check if container traffic exceeds threshold
        Returns True if suspended due to violations
        """
        try:
            current_time = time.time()
            bytes_delta = tx_bytes - previous_tx_bytes
            
            if container_name not in self.traffic_history:
                self.traffic_history[container_name] = []
            
            # Add current traffic sample
            self.traffic_history[container_name].append((current_time, bytes_delta))
            
            # Clean old entries
            self.traffic_history[container_name] = [
                (ts, bytes_) for ts, bytes_ in self.traffic_history[container_name]
                if current_time - ts < self.max_history_age
            ]
            
            # Calculate average traffic over last 60 seconds
            sixty_sec_ago = current_time - 60
            recent_traffic = [bytes_ for ts, bytes_ in self.traffic_history[container_name] if ts > sixty_sec_ago]
            
            if recent_traffic:
                avg_bytes_per_sec = sum(recent_traffic) / 60
                avg_mbps = (avg_bytes_per_sec * 8) / (1024 * 1024)
                
                if avg_mbps > self.threshold_mbps:
                    if container_name not in self.violation_count:
                        self.violation_count[container_name] = 0
                    
                    self.violation_count[container_name] += 1
                    logging.warning(f"🔴 DDoS Alert {container_name}: {avg_mbps:.2f} MB/s (violation #{self.violation_count[container_name]})")
                    
                    # Notify bot founder
                    await self._notify_founder(container_name, avg_mbps, self.violation_count[container_name])
                    
                    # Auto-suspend after 2 violations
                    if self.violation_count[container_name] >= self.suspension_threshold:
                        logging.error(f"🛑 Suspending {container_name} after {self.suspension_threshold} violations")
                        await self._suspend_container(container_name)
                        return True
                else:
                    # Reset violation counter if traffic is normal
                    if container_name in self.violation_count and self.violation_count[container_name] > 0:
                        self.violation_count[container_name] = 0
                        logging.info(f"✅ {container_name} traffic normalized")
            
            return False
            
        except Exception as e:
            logging.error(f"Error checking traffic for {container_name}: {e}")
            return False
    
    async def _notify_founder(self, container_name: str, mbps: float, violation_num: int):
        """Notify founder about DDoS detection"""
        try:
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="⚠️ DDoS Detection Alert",
                description=f"Excessive traffic detected on container",
                color=discord.Color.red()
            )
            embed.add_field(name="Container", value=container_name, inline=False)
            embed.add_field(name="Traffic", value=f"{mbps:.2f} MB/s", inline=True)
            embed.add_field(name="Violation", value=f"{violation_num}/2", inline=True)
            embed.set_footer(text=f"Timestamp: {datetime.now().isoformat()}")
            
            await user.send(embed=embed)
            logging.info(f"Founder notified about {container_name} DDoS alert")
        except Exception as e:
            logging.error(f"Failed to notify founder: {e}")
    
    async def _suspend_container(self, container_name: str):
        """Suspend container due to DDoS activity"""
        try:
            # Update database
            db.update_vps_status(container_name, "suspended")
            
            # Notify founder
            user = await self.bot.fetch_user(self.admin_user_id)
            embed = discord.Embed(
                title="🛑 Container Suspended",
                description=f"Container suspended due to DDoS activity",
                color=discord.Color.dark_red()
            )
            embed.add_field(name="Container", value=container_name, inline=False)
            embed.add_field(name="Reason", value="Exceeded DDoS threshold (2+ violations)", inline=False)
            embed.set_footer(text=f"Timestamp: {datetime.now().isoformat()}")
            
            await user.send(embed=embed)
            logging.error(f"Container {container_name} suspended by anti-DDoS system")
        except Exception as e:
            logging.error(f"Failed to suspend container: {e}")


# Setup function for the cog
async def setup(bot):
    """Setup function to load the surveillance cog"""
    try:
        surveillance = SurveillanceLXC(bot)
        antiddos = AntiDDoSMonitor(bot)
        
        # Attach to surveillance instance
        surveillance.antiddos = antiddos
        
        # Start all monitoring tasks
        surveillance.check_lxc_for_mining.start()
        surveillance.monitor_lxc_network.start()
        surveillance.monitor_lxc_disk_io.start()
        surveillance.security_scan_loop.start()
        
        logging.info("✅ SurveillanceLXC initialized successfully")
        logging.info("✅ Anti-DDoS Monitor initialized successfully")
        logging.info("🔍 Mining detection: ACTIVE")
        logging.info("📊 Network monitoring: ACTIVE")
        logging.info("💾 Disk I/O monitoring: ACTIVE")
        logging.info("🛡️ Security scanning: ACTIVE (24h interval)")
        logging.info("🛡️ Anti-DDoS protection: ACTIVE (40 MB/s threshold)")
        
        return surveillance
    
    except Exception as e:
        logging.error(f"Failed to setup SurveillanceLXC: {e}\n{traceback.format_exc()}")
        raise


# Cleanup function
async def teardown(bot_instance):
    """Cleanup function to stop all tasks"""
    try:
        surveillance_instance = bot_instance.surveillance_lxc_instance
        if surveillance_instance:
            if hasattr(surveillance_instance, 'check_lxc_for_mining') and surveillance_instance.check_lxc_for_mining.is_running():
                surveillance_instance.check_lxc_for_mining.cancel()
            
            if hasattr(surveillance_instance, 'monitor_lxc_network') and surveillance_instance.monitor_lxc_network.is_running():
                surveillance_instance.monitor_lxc_network.cancel()
            
            if hasattr(surveillance_instance, 'monitor_lxc_disk_io') and surveillance_instance.monitor_lxc_disk_io.is_running():
                surveillance_instance.monitor_lxc_disk_io.cancel()
            
            if hasattr(surveillance_instance, 'security_scan_loop') and surveillance_instance.security_scan_loop.is_running():
                surveillance_instance.security_scan_loop.cancel()
            
            logging.info("SurveillanceLXC tasks stopped")
        else:
            logging.warning("SurveillanceLXC instance not found during teardown.")
    
    except Exception as e:
        logging.error(f"Error during teardown of SurveillanceLXC: {e}")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('surveillance.log'),
            logging.StreamHandler()
        ]
    )
    
    logging.info("SurveillanceLXC module loaded")
    logging.info("This module should be imported and initialized by a Discord bot")