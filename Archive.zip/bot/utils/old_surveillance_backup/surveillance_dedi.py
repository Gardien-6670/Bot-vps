import asyncio
import os
import google.generativeai as genai
from google.api_core import exceptions as google_exceptions
from discord.ext import tasks
from dotenv import load_dotenv
from bot.utils.database import db
import logging
import time
import json
import discord
from discord.ui import View, Button
import aiohttp
import re
from bot.utils import node_manager
import random
import traceback
from typing import Dict, List, Optional, Any

load_dotenv()


class PerMinuteRateLimiter:
    """Thread-safe rate limiter with semaphore"""
    def __init__(self, requests_per_minute: int):
        self.max_requests = requests_per_minute
        self.time_window = 60
        self.request_timestamps = []
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            while True:
                now = time.time()
                self.request_timestamps = [
                    ts for ts in self.request_timestamps 
                    if now - ts < self.time_window
                ]

                if len(self.request_timestamps) < self.max_requests:
                    self.request_timestamps.append(now)
                    break
                else:
                    oldest_request_time = self.request_timestamps[0]
                    time_to_wait = self.time_window - (now - oldest_request_time)
                    logging.info(f"Rate limit reached. Waiting for {time_to_wait:.2f} seconds.")
                    await asyncio.sleep(time_to_wait + 0.1)


import paramiko

class SurveillanceDedi:
    """Enhanced Dedicated Server surveillance system with improved security and performance"""
    
    def __init__(self, bot):
        self.bot = bot
        self.admin_user_id = 1047760053509312642
        
        # Initialize Gemini AI
        gemini_api_key = os.getenv("GEMINI_API_KEY")
        if not gemini_api_key:
            raise ValueError("GEMINI_API_KEY not found in .env file")
        
        genai.configure(api_key=gemini_api_key)
        self.primary_model = genai.GenerativeModel('gemini-2.5-pro')
        self.fallback_model = genai.GenerativeModel('gemini-2.5-flash-lite')
        self.primary_limiter = PerMinuteRateLimiter(20)
        self.fallback_limiter = PerMinuteRateLimiter(30)
        
        # Metrics tracking
        self.metrics = {
            'scans_completed': 0,
            'threats_detected': 0,
            'false_positives': 0,
            'api_calls': 0
        }

    async def _call_gemini_with_fallback(
        self, 
        prompt: str, 
        timeout: int = 60,
        use_primary_first: bool = True
    ) -> Optional[str]:
        """Call Gemini API with automatic fallback to flash-lite on quota errors (429)"""
        try:
            if use_primary_first:
                await self.primary_limiter.acquire()
                model = self.primary_model
                model_name = "gemini-2.5-pro"
            else:
                await self.fallback_limiter.acquire()
                model = self.fallback_model
                model_name = "gemini-2.5-flash-lite"
            
            response = await asyncio.wait_for(
                model.generate_content_async(prompt),
                timeout=timeout
            )
            
            if not response or not response.text:
                raise ValueError("Empty response from AI")
            
            return response.text.strip()
        
        except (google_exceptions.ResourceExhausted, google_exceptions.QuotaExceeded) as e:
            # Quota exceeded (429) - switch to fallback
            error_msg = str(e).lower()
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logging.warning(
                        f"[DEDI] Gemini quota exceeded on {model_name}, switching to fallback model. "
                        f"Error: {str(e)[:200]}"
                    )
                    # Retry with fallback
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logging.info("[DEDI] Successfully used fallback model (gemini-2.5-flash-lite)")
                            return response.text.strip()
                    except Exception as fallback_e:
                        logging.error(f"[DEDI] Fallback model also failed: {fallback_e}")
                        return None
                else:
                    logging.error(f"[DEDI] Fallback model also hit quota limit: {e}")
                    return None
            else:
                # Other ResourceExhausted error, try fallback anyway
                if use_primary_first:
                    logging.warning(f"[DEDI] Resource exhausted on {model_name}, trying fallback...")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            return response.text.strip()
                    except Exception:
                        pass
                return None
        
        except asyncio.TimeoutError:
            logging.error(f"[DEDI] Timeout calling Gemini API ({model_name})")
            return None
        
        except Exception as e:
            error_msg = str(e).lower()
            # Check if it's a quota/429 error in the message
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                if use_primary_first:
                    logging.warning(f"[DEDI] Quota error detected, switching to fallback: {e}")
                    try:
                        await self.fallback_limiter.acquire()
                        response = await asyncio.wait_for(
                            self.fallback_model.generate_content_async(prompt),
                            timeout=timeout
                        )
                        if response and response.text:
                            logging.info("[DEDI] Successfully used fallback model after quota error")
                            return response.text.strip()
                    except Exception:
                        pass
            logging.error(f"[DEDI] Error calling Gemini API ({model_name}): {e}")
            return None

    @tasks.loop(minutes=5)
    async def check_dedi_for_mining(self):
        logging.info("=" * 60)
        logging.info("[TASK] 🔍 check_dedi_for_mining: EXECUTING NOW")
        logging.info("=" * 60)
        logging.info("Starting mining check on all dedicated servers...")
        all_vps = db.get_all_vps()
        logging.info(f"Total VPS in database: {len(all_vps)}")
        # Filter dedicated servers - handle None/NULL values
        dedi_vps = [vps for vps in all_vps if (vps.get('vps_type') or '') == 'dedicated']
        logging.info(f"Found {len(dedi_vps)} dedicated servers to check")

        processes_to_analyze = {}
        vps_map = {}
        high_risk_servers = []
        any_suspicion_servers = []

        for vps in dedi_vps:
            server_name = vps['container_name']

            if db.is_vps_suspended(server_name):
                logging.info(f"Skipping suspended dedicated server {server_name}")
                continue

            processes_text = await asyncio.to_thread(self._get_processes_ssh, vps)

            if processes_text:
                if self._is_only_monitoring_activity(processes_text):
                    logging.info(f"Skipping dedicated server {server_name} - only monitoring SSH activity detected")
                    if vps['suspicion_count'] > 0:
                        logging.info(f"Resetting suspicion count for {server_name} (monitoring only)")
                        db.reset_suspicion_count(server_name)
                        db.clear_suspicion_logs(server_name)
                    continue

                processes_to_analyze[server_name] = processes_text
                vps_map[server_name] = vps

                if vps['suspicion_count'] >= 1:
                    any_suspicion_servers.append(server_name)
                    if vps['suspicion_count'] >= 2:
                        high_risk_servers.append(server_name)
                        logging.info(f"Dedicated server {server_name} is HIGH RISK (suspicion count: {vps['suspicion_count']})")

        if not processes_to_analyze:
            logging.info("No running dedicated servers to analyze.")
            logging.info("Dedicated server mining check finished.")
            return

        try:
            analysis_results = await self.analyze_all_servers(
                processes_to_analyze,
                use_pro_model=(len(any_suspicion_servers) > 0),
                high_risk_servers=high_risk_servers
            )

            if not analysis_results:
                logging.warning("Did not receive valid analysis from Gemini.")
                logging.info("Dedicated server mining check finished.")
                return

            for server_name, result in analysis_results.items():
                vps = vps_map.get(server_name)
                if not vps:
                    continue

                if result == 'MINING':
                    logging.warning(f"Suspicious activity detected in dedicated server {server_name}")
                    process_list = processes_to_analyze.get(server_name, "")
                    db.add_suspicion_log(server_name, process_list)
                    new_count = db.increment_suspicion_count(server_name)
                    if new_count >= 3:
                        logging.warning(f"Mining confirmed in dedicated server {server_name} after {new_count} detections. Suspending.")
                        reason = await self.get_suspension_reason(server_name)
                        await self.handle_mining_detection(vps, reason)
                        self.metrics['threats_detected'] += 1
                    else:
                        logging.info(f"Dedicated server {server_name} suspicion count is now {new_count}. Notifying admin.")
                        reason = f"Suspicion count: {new_count}. Process list:\n```\n{process_list[:900]}\n```"
                        await self.notify_admin_of_suspicion(vps, reason)
                elif result == 'CLEAN':
                    if vps['suspicion_count'] > 0:
                        logging.info(f"Dedicated server {server_name} is clean. Resetting suspicion count.")
                        db.reset_suspicion_count(server_name)
                        db.clear_suspicion_logs(server_name)
                        self.metrics['false_positives'] += 1

        except Exception as e:
            logging.error(f"An error occurred during bulk dedicated server analysis: {e}\n{traceback.format_exc()}")

        logging.info("Dedicated server mining check finished.")
        new_interval = random.randint(1, 5)
        self.check_dedi_for_mining.change_interval(minutes=new_interval)
        logging.info(f"Next dedicated server scan in {new_interval} minutes.")

    def _get_processes_ssh(self, vps: dict) -> str | None:
        """Get process list from a dedicated server via SSH."""
        ip_address = vps.get('ip_address')
        ssh_port = vps.get('ssh_port')
        ssh_password = vps.get('ssh_password')

        if not all([ip_address, ssh_port, ssh_password]):
            logging.error(f"Missing SSH credentials for dedicated server {vps['container_name']}.")
            return None

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip_address, port=ssh_port, username='root', password=ssh_password, timeout=10)
            
            # Execute commands
            ps_command = "ps -eo %cpu,%mem,pid,user,args --sort=-%cpu | head -n 20"
            ss_command = "ss -tunp | head -n 10"
            
            stdin, stdout, stderr = client.exec_command(ps_command)
            ps_output = stdout.read().decode()
            
            stdin, stdout, stderr = client.exec_command(ss_command)
            ss_output = stdout.read().decode()
            
            client.close()
            
            return f"--- Top 20 Processes ---\n{ps_output}\n\n--- Top 10 Network Connections ---\n{ss_output}"
        except Exception as e:
            logging.error(f"Error getting processes via SSH for {ip_address}:{ssh_port}: {e}")
            return None

    def _is_only_monitoring_activity(self, processes_text: str) -> bool:
        if not processes_text:
            return False
        
        processes_lower = processes_text.lower()
        sshd_count = processes_lower.count('sshd:')
        has_host_connection = '192.168.122.1' in processes_text
        max_cpu = 0.0
        cpu_intensive_count = 0
        
        for line in processes_text.split('\n'):
            parts = line.strip().split()
            if len(parts) > 0 and parts[0].replace('.', '', 1).isdigit():
                try:
                    cpu = float(parts[0])
                    max_cpu = max(max_cpu, cpu)
                    if cpu > 10.0:
                        cpu_intensive_count += 1
                except ValueError:
                    continue
        
        suspicious_keywords = ['xmrig', 'miner', 'stratum', 'cpuminer', 'nanominer', 'ethminer']
        has_suspicious = any(keyword in processes_lower for keyword in suspicious_keywords)
        suspicious_paths = ['/tmp/', '/dev/shm/', '/var/tmp/', '/.cache/']
        has_suspicious_path = any(path in processes_lower for path in suspicious_paths)
        
        if (sshd_count >= 1 and sshd_count <= 4 and 
            has_host_connection and 
            max_cpu < 12.0 and 
            cpu_intensive_count <= 3 and
            not has_suspicious and 
            not has_suspicious_path):
            
            normal_keywords = ['systemd', 'snapd', 'unattended', 'journald', 'networkd', 'init', 'kworker']
            has_normal_activity = any(keyword in processes_lower for keyword in normal_keywords)
            
            if has_normal_activity:
                logging.info(f"Detected monitoring-only activity: max_cpu={max_cpu}%, sshd_count={sshd_count}, from_host={has_host_connection}")
                return True
        
        return False

    def _prefilter_process_list(self, text: str) -> str:
        if not text:
            return ""

        lines = text.splitlines()
        filtered_lines = []
        for line in lines:
            if re.search(r'sshd:\s+\S+@notty', line, re.IGNORECASE):
                continue
            
            if re.search(r'^\s*\d+\.\d+\s+\d+\.\d+\s+\d+\s+\w+\s+sshd:', line, re.IGNORECASE):
                parts = line.strip().split()
                if len(parts) >= 5:
                    try:
                        cpu = float(parts[0])
                        if cpu < 15 and 'notty' in line.lower():
                            continue
                    except ValueError:
                        pass
            
            if line.strip() == "" or re.match(r"^===+", line.strip()):
                continue
                
            filtered_lines.append(line)
        
        max_chars = 48000
        joined = "\n".join(filtered_lines).strip()
        if len(joined) > max_chars:
            joined = joined[:max_chars] + "\n[TRUNCATED]"
        return joined

    async def analyze_all_servers(self, processes_dict, use_pro_model=False, high_risk_servers=None):
        if high_risk_servers is None:
            high_risk_servers = []

        filtered_processes = {k: self._prefilter_process_list(v) for k, v in processes_dict.items()}
        json_input = json.dumps(filtered_processes, indent=2)
        risk_note = ""
        if high_risk_servers:
            risk_note = f"\n\n**CRITICAL**: The following servers require EXTRA CAREFUL analysis: {', '.join(high_risk_servers)}"

        prompt = f"""
        You are a cybersecurity AI specialized in detecting cryptocurrency mining activity on dedicated servers.
        Analyze the following JSON object. The keys are server names, and the values are their respective Linux process and network lists.
        Each value contains the output of "ps -eo %cpu,%mem,pid,user,args --sort=-%cpu | head -n 20" and "ss -tunp | head -n 10".
        Your task: For each instance, decide whether it is **CLEAN** or **MINING**.

        ### CONTEXT
        - These are dedicated servers with no CPU limits.
        - Miners often maintain high CPU usage (e.g., >90% on a single core, or high usage across multiple cores).
        - Miners disguise as system processes or hide in temporary directories.

        ### STRONG INDICATORS OF MINING
        1. **Sustained high CPU usage** on one or more cores.
        2. **Suspicious binary paths**: `/tmp`, `/var/tmp`, `/dev/shm`, `/run/`, `/sys/fs/cgroup`, `/root/.cache/`.
        3. **Masqueraded system processes** with abnormal CPU or paths.
        4. **Known miner software or flags**: `xmrig`, `cpuminer`, `-o stratum+tcp://`.
        5. **Unusual users**: `nobody`, `systemd-coredump`, `upd`, `sys`, `svc`, `miner`.
        6. **Network connections** to known mining pool ports: `3333`, `4444`, `5555`, `7777`, `14444`.

        ### NORMAL BEHAVIOR TO IGNORE
        - **SSH and Monitoring**: `sshd: root@notty`.
        - **System Management**: `systemd`, `journald`, `cron`.
        - **Package Management**: `apt`, `dpkg`, `unattended-upgrade`, `snapd`. These can use CPU temporarily.

        ### CLASSIFICATION RULES
        - Output `"MINING"` for two or more strong indicators, or one very clear indicator.
        - Output `"CLEAN"` otherwise.
        - **BE CONSERVATIVE**. Avoid false positives.
        - Be more strict for high-risk servers.{risk_note}

        ### INPUT JSON
        {json_input}

        ### OUTPUT (JSON ONLY, NO MARKDOWN)
        """

        async def make_api_call(model, model_name):
            logging.info(f"Using {model_name} for dedicated server analysis...")
            self.metrics['api_calls'] += 1
            response = await asyncio.wait_for(model.generate_content_async(prompt), timeout=180)
            
            if not response or not response.text:
                raise ValueError("Empty response from API")
            
            text = response.text.strip()
            
            # Remove markdown formatting
            text = re.sub(r'^```(?:json)?\s*\n', '', text)
            text = re.sub(r'\n```\s*$', '', text)
            
            # Extract JSON object
            start = text.find('{')
            end = text.rfind('}') + 1
            
            if start == -1 or end == 0:
                raise ValueError(f"No JSON object found in response: {text[:200]}")
            
            json_text = text[start:end]
            result = json.loads(json_text)
            
            # Validate result format
            if not isinstance(result, dict):
                raise ValueError("Response is not a dictionary")
            
            for server, classification in result.items():
                if classification not in ['MINING', 'CLEAN']:
                    logging.warning(f"Invalid classification for {server}: {classification}")
                    result[server] = 'CLEAN'  # Default to safe
            
            return result

        # Try primary model first if high risk
        try:
            if use_pro_model and high_risk_servers:
                await self.primary_limiter.acquire()
                return await make_api_call(
                    self.primary_model, 
                    "gemini-2.5-pro (HIGH RISK DEDI SCAN)"
                )
            else:
                await self.fallback_limiter.acquire()
                return await make_api_call(
                    self.fallback_model, 
                    "gemini-2.5-flash-lite (DEDI)"
                )
        
        except (asyncio.TimeoutError, google_exceptions.ResourceExhausted, 
                google_exceptions.QuotaExceeded, json.JSONDecodeError, ValueError) as e:
            error_msg = str(e).lower()
            is_quota_error = (
                isinstance(e, (google_exceptions.ResourceExhausted, google_exceptions.QuotaExceeded)) or
                "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg
            )
            
            if is_quota_error:
                logging.warning(f"[DEDI] Quota exceeded (429) on primary model, switching to fallback: {e}")
            else:
                logging.warning(f"Primary dedicated server analysis failed: {type(e).__name__}: {e}")
            
            # Retry with alternate model (always use fallback if quota error)
            try:
                if use_pro_model or is_quota_error:
                    await self.fallback_limiter.acquire()
                    return await make_api_call(
                        self.fallback_model, 
                        "gemini-2.5-flash-lite (DEDI FALLBACK)"
                    )
                else:
                    await self.primary_limiter.acquire()
                    return await make_api_call(
                        self.primary_model, 
                        "gemini-2.5-pro (DEDI FALLBACK)"
                    )
            except Exception as fallback_e:
                logging.error(f"Both models failed for dedicated server analysis: {fallback_e}\n{traceback.format_exc()}")
                return None
        
        except Exception as e:
            # Catch any other exception and check for quota errors
            error_msg = str(e).lower()
            if "429" in error_msg or "quota" in error_msg or "exceeded" in error_msg:
                logging.warning(f"[DEDI] Quota error detected in exception, switching to fallback: {e}")
                try:
                    await self.fallback_limiter.acquire()
                    return await make_api_call(
                        self.fallback_model, 
                        "gemini-2.5-flash-lite (DEDI FALLBACK)"
                    )
                except Exception as fallback_e:
                    logging.error(f"Fallback model also failed: {fallback_e}")
                    return None
            else:
                logging.error(f"Unexpected error in dedicated server analysis: {e}\n{traceback.format_exc()}")
                return None

    async def get_suspension_reason(self, server_name):
        logs = db.get_suspicion_logs(server_name, limit=3)
        if not logs:
            return "No process logs found."
        formatted_logs = ""
        for i, log in enumerate(reversed(logs)):
            formatted_logs += f"--- Detection {i+1} ---\n{log['process_list']}\n\n"
        prompt = f"""
        You are a cybersecurity analyst.
        The following three process lists were flagged as suspicious for cryptocurrency mining from the same dedicated server, at 5-minute intervals.
        Summarize in a few bullet points why these processes are suspicious.
        Focus on the process names, CPU usage, and any patterns you observe across the detections.
        Be concise and clear.

        {formatted_logs}
        """
        result = await self._call_gemini_with_fallback(prompt, timeout=60, use_primary_first=True)
        if result:
            return result
        
        # Fallback message if both models fail
        return "Analysis unavailable. Manual review recommended."

    async def notify_admin_of_suspicion(self, vps, reason="Suspicious activity detected."):
        """Send suspicion notification to admin"""
        server_name = vps['container_name']
        user_id = vps['user_id']
        
        try:
            admin = await self.bot.fetch_user(self.admin_user_id)
            
            embed = discord.Embed(
                title="⚠️ SUSPICIOUS ACTIVITY (DEDICATED)",
                description=f"Server: `{server_name}`\nUser: `{user_id}`\n\n⚠️ Not suspended yet - requires confirmation",
                color=discord.Color.yellow(),
                timestamp=discord.utils.utcnow()
            )
            
            # Truncate reason if too long
            if len(reason) > 1024:
                reason = reason[:1020] + "..."
            
            embed.add_field(name="Analysis", value=reason, inline=False)
            embed.set_footer(text=f"Suspicion Count: {vps.get('suspicion_count', 0)}")
            
            await admin.send(embed=embed)
            
        except discord.Forbidden:
            logging.error(f"Cannot send DM to admin {self.admin_user_id}")
        except Exception as e:
            logging.error(f"Failed to notify admin: {e}")

    async def _shutdown_dedi_server(self, vps: dict):
        """Shutdown a dedicated server via SSH."""
        ip_address = vps.get('ip_address')
        ssh_port = vps.get('ssh_port')
        ssh_password = vps.get('ssh_password')

        if not all([ip_address, ssh_port, ssh_password]):
            logging.error(f"Missing SSH credentials for dedicated server {vps['container_name']}, cannot shut down.")
            return

        def ssh_shutdown():
            try:
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(ip_address, port=ssh_port, username='root', password=ssh_password, timeout=10)
                
                logging.warning(f"Executing shutdown on dedicated server {ip_address}:{ssh_port}")
                # Execute shutdown command. 'nohup' and '&' to make it run even if ssh session is terminated.
                stdin, stdout, stderr = client.exec_command("nohup shutdown -h now &")
                
                client.close()
                logging.info(f"Shutdown command sent to {ip_address}:{ssh_port}")
                return True
            except Exception as e:
                logging.error(f"Error shutting down dedicated server via SSH for {ip_address}:{ssh_port}: {e}")
                return False
        
        await asyncio.to_thread(ssh_shutdown)

    async def handle_mining_detection(self, vps, reason="No specific reason provided."):
        """Handle confirmed mining detection with improved error handling"""
        server_name = vps['container_name']
        user_id = vps['user_id']

        try:
            # Suspend in database
            db.suspend_vps(server_name)
            
            # Shutdown server
            await self._shutdown_dedi_server(vps)
            
            logging.critical(f"Dedicated server {server_name} suspended and shut down for mining")
            
            # Notify admin
            try:
                admin = await self.bot.fetch_user(self.admin_user_id)
                
                embed = discord.Embed(
                    title="🚨 MINING DETECTED & SUSPENDED (DEDICATED)",
                    description=f"**Server:** `{server_name}`\n**User:** `{user_id}`\n\n✅ Automatically suspended and **shut down**",
                    color=discord.Color.red(),
                    timestamp=discord.utils.utcnow()
                )
                
                if len(reason) > 1024:
                    reason = reason[:1020] + "..."
                
                embed.add_field(name="AI Analysis", value=reason, inline=False)
                
                view = UnsuspendView(server_name, user_id, self.bot, 'dedicated')
                await admin.send(embed=embed, view=view)
                
            except Exception as e:
                logging.error(f"Failed to notify admin: {e}")
            
            # Notify user
            try:
                user = await self.bot.fetch_user(user_id)
                await user.send(
                    f"🚨 **Dedicated Server Suspended & Shutdown**\n\n"
                    f"Your dedicated server `{server_name}` has been suspended and shut down for "
                    f"suspected cryptocurrency mining activity.\n\n"
                    f"If you believe this is an error, please contact support."
                )
            except Exception as e:
                logging.error(f"Failed to notify user {user_id}: {e}")
        
        except Exception as e:
            logging.error(f"Error handling mining detection for {server_name}: {e}\n{traceback.format_exc()}")

    @check_dedi_for_mining.before_loop
    async def before_check(self):
        print("[TASK] check_dedi_for_mining: Waiting for bot to be ready...")
        logging.info("[TASK] check_dedi_for_mining: Waiting for bot to be ready...")
        await self.bot.wait_until_ready()
        print("[TASK] ✅ check_dedi_for_mining: Bot ready, task will start in 5 minutes")
        logging.info("[TASK] ✅ check_dedi_for_mining: Bot ready, task will start in 5 minutes")


class UnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=None)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Unsuspend", style=discord.ButtonStyle.danger)
    async def unsuspend_button(self, interaction: discord.Interaction, button: Button):
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        confirm_view = ConfirmUnsuspendView(self.container_name, self.user_id, self.bot, self.vps_type)
        embed = discord.Embed(
            title=f"⚠️ Confirm Unsuspend {entity_type}",
            description=f"Are you sure you want to unsuspend `{self.container_name}`?",
            color=discord.Color.orange()
        )
        await interaction.response.send_message(embed=embed, view=confirm_view, ephemeral=True)


class ConfirmUnsuspendView(View):
    def __init__(self, container_name, user_id, bot, vps_type):
        super().__init__(timeout=60)
        self.container_name = container_name
        self.user_id = user_id
        self.bot = bot
        self.vps_type = vps_type

    @discord.ui.button(label="Yes, Unsuspend", style=discord.ButtonStyle.success)
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        entity_type = "Container" if self.vps_type == 'lxc' else "VM" if self.vps_type == 'kvm' else "Dedicated Server"
        try:
            db.unsuspend_vps(self.container_name)
            db.reset_suspicion_count(self.container_name)
            db.clear_suspicion_logs(self.container_name)

            if self.vps_type == 'dedicated':
                # For dedicated servers, we just unsuspend them in the DB.
                pass
            else:
                node_info = node_manager.get_node_for_vps(self.container_name)
                if not node_info:
                    await interaction.followup.send(f"Failed to unsuspend: Could not determine node for {self.container_name}.", ephemeral=True)
                    return
                node_url, api_key = node_info['url'], node_info['api_key']

                if self.vps_type == 'lxc':
                    await node_manager.api_request('POST', f"/lxc/container/{self.container_name}/resume", node_url, api_key)
                elif self.vps_type == 'kvm':
                    await node_manager.api_request('POST', f"/kvm/vm/{self.container_name}/start", node_url, api_key)
            success_embed = discord.Embed(title="✅ Unsuspended", description=f"{entity_type} `{self.container_name}` unsuspended.", color=discord.Color.green())
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            try:
                user = await self.bot.fetch_user(self.user_id)
                await user.send(f"✅ Your {entity_type.lower()} (`{self.container_name}`) has been unsuspended.")
            except Exception as e:
                logging.error(f"Failed to notify user about unsuspension: {e}")
            for item in self.children:
                item.disabled = True
            if interaction.message:
                await interaction.message.edit(view=self)
        except Exception as e:
            logging.error(f"Failed to unsuspend {self.container_name}: {e}")
            await interaction.followup.send(f"Failed to unsuspend: {e}", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
