"""
Ultra-advanced threat detection: zipbomb, polymorphic malware, anomalies, VirusTotal
1 suspicion = immediate suspension & data deletion
"""

import asyncio, time, hashlib, statistics, re, math, sys, os
from collections import defaultdict, deque
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path

# Ajouter le répertoire parent au path pour importer le scanner VirusTotal
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from utils.virustotal_scanner import get_virustotal_scanner
from bot.utils.database import db

logger = __import__('logging').getLogger(__name__)


class ZipbombDetector:
    """Zipbomb & compression bomb detection"""
    
    def __init__(self):
        self.entropy_threshold = 7.8
        self.ratio_threshold = 100000
    
    def calc_entropy(self, data: bytes) -> float:
        if not data: return 0.0
        counts = [0] * 256
        for b in data[:50000]: counts[b] += 1
        entropy = 0.0
        total = len(data[:50000])
        for c in counts:
            if c > 0: entropy -= (c/total) * math.log2(c/total)
        return entropy
    
    async def analyze(self, path: str, content: bytes, extracted_size: int = None) -> Dict:
        result = {"suspicious": False, "conf": 0, "reasons": [], "type": ""}
        
        # High entropy (compressed/encrypted)
        ent = self.calc_entropy(content)
        if ent > self.entropy_threshold: result["conf"] += 35
        
        # Zipbomb ratio
        if extracted_size and len(content) > 0:
            ratio = extracted_size / len(content)
            if ratio > self.ratio_threshold:
                result["conf"] += 85
                result["type"] = "ZIPBOMB"
            elif ratio > 1000:
                result["conf"] += 60
        
        # Archive format
        if any(path.lower().endswith(e) for e in ['.zip','.7z','.rar','.gz','.tar']):
            result["conf"] += 20
        
        # No extension
        if '.' not in path.split('/')[-1]: result["conf"] += 25
        
        # Large file
        if len(content) > 100*1024*1024: result["conf"] += 15
        
        result["suspicious"] = result["conf"] >= 50
        return result


class PolymorphicDetector:
    """Polymorphic malware (frequent mutations)"""
    
    def __init__(self):
        self.history = defaultdict(lambda: deque(maxlen=50))
    
    async def check(self, container: str, path: str, hash_val: str) -> Dict:
        hist = self.history[f"{container}:{path}"]
        hist.append({"time": time.time(), "hash": hash_val})
        
        if len(hist) < 3:
            return {"suspicious": False, "conf": 0}
        
        unique = len(set(h["hash"] for h in hist))
        if unique >= 5:
            return {"suspicious": True, "conf": min(unique*15, 90), "type": "POLYMORPHIC"}
        
        return {"suspicious": False, "conf": 0}


class AnomalyDetector:
    """Real-time behavioral anomalies"""
    
    def __init__(self):
        self.baseline = {}
    
    async def detect(self, container: str, metrics: Dict) -> Dict:
        if container not in self.baseline:
            self.baseline[container] = metrics.copy()
            return {"suspicious": False, "conf": 0}
        
        base = self.baseline[container]
        deviations = []
        
        for k, v in metrics.items():
            if k in base and isinstance(v, (int,float)) and isinstance(base[k], (int,float)):
                if base[k] != 0:
                    dev = abs(v - base[k]) / (base[k] + 1)
                    deviations.append(dev)
        
        if not deviations:
            return {"suspicious": False, "conf": 0}
        
        avg_dev = statistics.mean(deviations)
        conf = min(int(avg_dev * 25), 90)
        extreme = sum(1 for d in deviations if d > 5.0)
        if extreme > 1: conf = 95
        
        return {"suspicious": conf >= 60, "conf": conf, "extreme": extreme}


class FilesystemAnomalyDetector:
    """Rapid file changes, suspicious paths"""
    
    def __init__(self):
        self.rapid_changes = defaultdict(lambda: deque(maxlen=20))
    
    async def detect(self, container: str, fs_state: Dict) -> Dict:
        result = {"suspicious": False, "conf": 0}
        now = time.time()
        
        # Rapid file creation
        if "new_files_count" in fs_state:
            self.rapid_changes[container].append((now, fs_state["new_files_count"]))
            if len(self.rapid_changes[container]) >= 5:
                total_files = sum(c for _, c in list(self.rapid_changes[container])[-6:])
                if total_files > 500: result["conf"] += 70
        
        # Suspicious paths
        if fs_state.get("suspicious_path_count", 0) > 5: result["conf"] += 40
        
        # Rapid growth
        if fs_state.get("size_growth_mb", 0) > 500: result["conf"] += 35
        
        # Critical file modifications
        if fs_state.get("critical_mods", 0) > 0: result["conf"] += 85
        
        result["suspicious"] = result["conf"] >= 40
        return result


class ProcessAnalyzer:
    """Analyzes individual process behavior for suspicious activities."""

    def analyze_process_behavior(self, processes: list) -> Dict[str, any]:
        suspicious_processes = []
        
        for proc in processes:
            suspicion_score = 0
            reasons = []
            
            cmd = proc.get('command', '').lower()
            user = proc.get('user', '')
            cpu = float(proc.get('cpu_percent', 0)) # Assuming cpu_percent is available

            # 1. Processus caché dans des répertoires suspects
            if any(path in cmd for path in ['/tmp/.', '/dev/shm/.', '/var/tmp/.']):
                suspicion_score += 60
                reasons.append("hidden_suspicious_location")
            
            # 2. Arguments de mining explicites
            mining_keywords = ['xmrig', 'cpuminer', 'stratum', '--donate', '--algo', '--coin']
            if any(kw in cmd for kw in mining_keywords):
                suspicion_score += 90
                reasons.append("mining_keywords")
            
            # 3. CPU élevé + utilisateur système (mais pas les vrais processus système)
            if user in ['nobody', 'www-data'] and cpu > 50:
                # Vérifier que ce n'est pas un vrai service
                if not any(svc in cmd for svc in ['nginx', 'apache', 'php-fpm', 'node']):
                    suspicion_score += 40
                    reasons.append("system_user_high_cpu_no_service")
            
            # Add other checks here if needed, e.g., long-running processes without TTY
            
            if suspicion_score > 0:
                suspicious_processes.append({
                    "pid": proc.get('pid'), # Assuming pid is available
                    "command": proc.get('command'),
                    "user": user,
                    "cpu_percent": cpu,
                    "suspicion_score": suspicion_score,
                    "reasons": reasons
                })
        
        total_suspicion_score = sum(p['suspicion_score'] for p in suspicious_processes)
        
        return {
            "suspicious": total_suspicion_score > 0,
            "score": min(total_suspicion_score, 95), # Cap at 95, allow other detectors to add
            "threats": suspicious_processes
        }


class VirusTotalDetector:
    """VirusTotal file scanning for malware detection"""
    
    def __init__(self):
        self.scanner = get_virustotal_scanner(db)
        self.scan_cache = {}  # Cache pour éviter de scanner plusieurs fois le même fichier
        self.cache_ttl = 3600  # 1 heure de cache
    
    async def scan_file(self, file_hash: str, container: str, filepath: str) -> Dict:
        """
        Scan un fichier avec VirusTotal
        
        Args:
            file_hash: Hash SHA256 du fichier
            container: Nom du conteneur
            filepath: Chemin du fichier
            
        Returns:
            Dictionnaire avec le résultat du scan
        """
        result = {"suspicious": False, "conf": 0, "vt_result": None}
        
        # Vérifier si le scanner est disponible
        if not self.scanner.is_available():
            logger.warning("[VT] Scanner VirusTotal non disponible")
            return result
        
        # Vérifier le cache
        cache_key = f"{file_hash}:{container}"
        if cache_key in self.scan_cache:
            cached_data, cached_time = self.scan_cache[cache_key]
            if time.time() - cached_time < self.cache_ttl:
                logger.debug(f"[VT] Utilisation du cache pour {filepath}")
                return cached_data
        
        try:
            # Scanner le fichier
            vt_result = await self.scanner.scan_file_hash(
                file_hash=file_hash,
                container_name=container,
                filepath=filepath
            )
            
            if vt_result:
                result["vt_result"] = vt_result
                
                # Calculer le score de confiance basé sur le threat_level
                # threat_level: 100=sûr, 0=dangereux
                # conf: 0=sûr, 100=dangereux (inversé)
                threat_level = vt_result.get('threat_level', 50)
                malicious_percentage = vt_result.get('malicious_percentage', 0)
                
                # Convertir threat_level en score de confiance
                # Si threat_level = 20 (dangereux), conf = 80
                # Si threat_level = 80 (sûr), conf = 20
                conf = 100 - threat_level
                
                # Ajuster le score selon le pourcentage de détections
                if malicious_percentage >= 70:  # 70%+ de détections = très suspect
                    conf = max(conf, 90)
                    result["type"] = "MALWARE_HIGH_CONFIDENCE"
                elif malicious_percentage >= 50:  # 50-70% = suspect
                    conf = max(conf, 75)
                    result["type"] = "MALWARE_MEDIUM_CONFIDENCE"
                elif malicious_percentage >= 30:  # 30-50% = potentiellement suspect
                    conf = max(conf, 60)
                    result["type"] = "MALWARE_LOW_CONFIDENCE"
                elif malicious_percentage >= 10:  # 10-30% = à surveiller
                    conf = max(conf, 40)
                    result["type"] = "SUSPICIOUS"
                
                result["conf"] = int(conf)
                result["suspicious"] = conf >= 50  # Seuil à 50
                
                logger.info(
                    f"[VT] Scan de {filepath}: {vt_result['detection_ratio']} détections, "
                    f"threat_level={threat_level}, conf={conf}, suspicious={result['suspicious']}"
                )
            else:
                logger.warning(f"[VT] Aucun résultat pour {filepath}")
            
            # Mettre en cache
            self.scan_cache[cache_key] = (result, time.time())
            
            # Nettoyer le cache si trop grand
            if len(self.scan_cache) > 1000:
                self._cleanup_cache()
        
        except Exception as e:
            logger.error(f"[VT] Erreur lors du scan de {filepath}: {e}")
        
        return result
    
    def _cleanup_cache(self):
        """Nettoie les entrées expirées du cache"""
        now = time.time()
        expired_keys = [
            k for k, (_, t) in self.scan_cache.items()
            if now - t > self.cache_ttl
        ]
        for k in expired_keys:
            del self.scan_cache[k]
        logger.debug(f"[VT] Cache nettoyé: {len(expired_keys)} entrées supprimées")
    
    def get_stats(self) -> Dict:
        """Obtient les statistiques du scanner"""
        return self.scanner.get_stats()


class SecurityOrchestrator:
    """Integrated threat assessment for progressive scoring"""
    
    def __init__(self):
        self.zipbomb = ZipbombDetector()
        self.polymorphic = PolymorphicDetector()
        self.anomaly = AnomalyDetector()
        self.filesystem = FilesystemAnomalyDetector()
        self.process_analyzer = ProcessAnalyzer()
        self.virustotal = VirusTotalDetector()  # Ajout du détecteur VirusTotal
    
    async def assess(self, container: str, data: Dict) -> Dict:
        """Comprehensive threat assessment based on progressive scoring"""
        scores = []
        threats = []
        
        # Check process behavior
        if "processes" in data and isinstance(data["processes"], list):
            pa = self.process_analyzer.analyze_process_behavior(data["processes"])
            if pa["suspicious"]:
                scores.append(pa["score"])
                threats.append({"type": "process_anomaly", "details": pa["threats"]})

        # Check zipbombs
        if "files" in data:
            for path, fdata in data["files"].items():
                zb = await self.zipbomb.analyze(
                    path,
                    fdata.get("content", b""),
                    fdata.get("size")
                )
                if zb["suspicious"]:
                    scores.append(zb["conf"])
                    threats.append(f"zipbomb:{path}")
        
        # Check polymorphic malware
        if "file_hashes" in data:
            for path, hash_val in data["file_hashes"].items():
                pm = await self.polymorphic.check(container, path, hash_val)
                if pm["suspicious"]:
                    scores.append(pm["conf"])
                    threats.append(f"polymorphic:{path}")
                
                # Scan avec VirusTotal si disponible
                vt = await self.virustotal.scan_file(hash_val, container, path)
                if vt["suspicious"]:
                    scores.append(vt["conf"])
                    vt_type = vt.get("type", "MALWARE")
                    vt_result = vt.get("vt_result", {})
                    detection_ratio = vt_result.get("detection_ratio", "?/?")
                    threats.append({
                        "type": "virustotal_detection",
                        "path": path,
                        "vt_type": vt_type,
                        "detection_ratio": detection_ratio,
                        "threat_level": vt_result.get("threat_level", 0)
                    })
        
        # Check behavioral anomalies
        if "metrics" in data:
            an = await self.anomaly.detect(container, data["metrics"])
            if an["suspicious"]:
                scores.append(an["conf"])
                threats.append("behavioral_anomaly")
        
        # Check filesystem anomalies
        if "filesystem" in data:
            fs = await self.filesystem.detect(container, data["filesystem"])
            if fs["suspicious"]:
                scores.append(fs["conf"])
                threats.append("filesystem_anomaly")
        
        # Calculate score
        final_score = max(scores) if scores else 0
        
        return {
            "score": int(final_score),
            "threats": threats,
            "threat_count": len(threats),
            "threat_level": "CRITICAL" if final_score >= 85 else (
                "HIGH" if final_score >= 70 else (
                    "MEDIUM" if final_score >= 50 else (
                        "LOW" if final_score >= 30 else "NONE"
                    )
                )
            ),
            "individual_scores": scores
        }
    
    def get_virustotal_stats(self) -> Dict:
        """Obtient les statistiques du scanner VirusTotal"""
        return self.virustotal.get_stats()
