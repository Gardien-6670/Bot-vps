"""
GeoIP analysis using ipinfo.io and secure data deletion
"""

import aiohttp
import asyncio
import logging
import os
import shutil
import subprocess
from typing import Optional, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


class GeoIPAnalyzer:
    """Analyse de géolocalisation avec ipinfo.io"""
    
    SUSPICIOUS_COUNTRIES = {
        'CN', 'RU', 'KP', 'IR', 'SY', 'KZ',  # High-risk mining countries
        'MD', 'UA', 'BY', 'AM', 'GE'  # Eastern Europe mining hotspots
    }
    
    def __init__(self):
        self.ipinfo_token = os.getenv('IPINFO_TOKEN')
        self.cache = {}
        self.cache_ttl = 3600  # 1 hour
    
    async def analyze_ip(self, ip_address: str) -> Dict:
        """Analyser une IP avec ipinfo.io"""
        if not ip_address or ip_address in ['127.0.0.1', '0.0.0.0', 'N/A']:
            return {"suspicious": False, "confidence": 0}
        
        # Check cache
        if ip_address in self.cache:
            cached_time, cached_data = self.cache[ip_address]
            if datetime.now().timestamp() - cached_time < self.cache_ttl:
                return cached_data
        
        try:
            url = f"https://ipinfo.io/{ip_address}/json"
            headers = {}
            if self.ipinfo_token:
                url += f"?token={self.ipinfo_token}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        result = self._analyze_geoip_data(data)
                        self.cache[ip_address] = (datetime.now().timestamp(), result)
                        return result
        except Exception as e:
            logger.error(f"GeoIP lookup failed for {ip_address}: {e}")
        
        return {"suspicious": False, "confidence": 0, "error": True}
    
    def _analyze_geoip_data(self, data: dict) -> dict:
        """Analyse les données ipinfo pour détecter patterns suspects"""
        country = data.get('country', '')
        org = data.get('org', '').lower()
        asn = data.get('asn', {})
        
        suspicious = False
        confidence = 0
        reasons = []
        
        # 1. Pays à risque
        if country in self.SUSPICIOUS_COUNTRIES:
            suspicious = True
            confidence += 40
            reasons.append(f"high_risk_country_{country}")
        
        # 2. ISPs connus pour héberger des pools
        mining_isps = ['alibaba', 'tencent', 'huawei', 'hostinger', 'ovh', 'digitalocean']
        if any(isp in org for isp in mining_isps):
            confidence += 30
            reasons.append("known_mining_provider_isp")
        
        # 3. Data centers (généralement utilisés pour mining)
        if any(x in org for x in ['data center', 'datacenter', 'colocation', 'hosting']):
            confidence += 20
            reasons.append("hosting_provider")
        
        # 4. VPN/Proxy services (masquage)
        if any(x in org for x in ['vpn', 'proxy', 'anonymizer', 'privacy']):
            confidence += 25
            reasons.append("vpn_proxy_service")
        
        return {
            "suspicious": suspicious and confidence >= 30,
            "confidence": min(confidence, 85),
            "country": country,
            "org": data.get('org', 'Unknown'),
            "reasons": reasons,
            "full_data": {
                "ip": data.get('ip'),
                "city": data.get('city'),
                "region": data.get('region'),
                "country": country,
                "loc": data.get('loc'),
                "org": data.get('org'),
                "timezone": data.get('timezone')
            }
        }
    
    async def analyze_connection(self, ip_address: str, port: int) -> dict:
        """Analyse complète d'une connexion réseau"""
        geoip_result = await self.analyze_ip(ip_address)
        
        # Analyse du port
        suspicious_port_reasons = []
        port_confidence = 0
        
        if isinstance(port, str):
            port = int(port) if port.isdigit() else 0
        
        # Ports connus des pools de mining
        mining_pools_ports = [3333, 4444, 5555, 6666, 7777, 8888, 9999,
                              14444, 19999, 45560, 3389]
        
        if port in mining_pools_ports:
            suspicious_port_reasons.append(f"known_mining_pool_port_{port}")
            port_confidence = 80
        elif 3000 <= port <= 10000:
            suspicious_port_reasons.append("suspicious_port_range")
            port_confidence = 40
        
        # Combine results
        final_confidence = max(
            geoip_result.get('confidence', 0),
            port_confidence
        )
        
        suspicious = (geoip_result.get('suspicious', False) or 
                     port_confidence >= 40)
        
        return {
            "ip": ip_address,
            "port": port,
            "suspicious": suspicious,
            "confidence": final_confidence,
            "geoip": geoip_result,
            "port_reasons": suspicious_port_reasons
        }


class SecureDataDeletion:
    """Suppression sécurisée des données du VPS"""
    
    ALLOWED_WIPE_PATHS = {
        '/root/.cache',
        '/home',
        '/tmp',
        '/var/tmp',
        '/dev/shm',
        '/var/log',
        '/root', # Added for completeness of paths that might need wiping
        '/var/www',
        '/opt',
        '/srv',
        '/.config',
        '/.ssh', # Sensitive directory
        '/usr/local/bin'
    }

    def __init__(self):
        self.delete_passes = 3  # Nombre de passes de suppression
    
    async def wipe_container_data(self, container_name: str, node_url: str, 
                                   api_key: str) -> Dict:
        """
        Suppression sécurisée de tous les données du conteneur
        Exécute après suspension pour détruire les preuves
        """
        results = {
            "container": container_name,
            "timestamp": datetime.now().isoformat(),
            "deleted_paths": [],
            "errors": [],
            "success": True
        }
        
        # Importer le module node_manager
        try:
            from bot.utils import node_manager
        except ImportError:
            results['errors'].append("Cannot import node_manager")
            results['success'] = False
            return results
        
        for path in self.ALLOWED_WIPE_PATHS:
            # Validation stricte du chemin
            if not path.startswith('/') or '..' in path:
                error_msg = f"Invalid or unsafe path skipped: {path}"
                results['errors'].append(error_msg)
                logger.warning(f"[{container_name}] {error_msg}")
                continue
                
            try:
                # Use a safer command to find and delete files
                wipe_cmd = f"find {path} -type f -delete"
                
                # Execute the wipe command
                wipe_result = await node_manager.api_request(
                    'POST',
                    f"/lxc/container/{container_name}/exec",
                    node_url,
                    api_key,
                    data={"command": wipe_cmd, "timeout": 60}
                )
                
                if wipe_result:
                    results['deleted_paths'].append(path)
                    logger.info(f"Wiped {path} in {container_name}")
            
            except Exception as e:
                error_msg = f"Failed to wipe {path}: {str(e)}"
                results['errors'].append(error_msg)
                logger.error(f"[{container_name}] {error_msg}")
                results['success'] = False
        
        # Filesystem sync to ensure deletion
        try:
            await node_manager.api_request(
                'POST',
                f"/lxc/container/{container_name}/exec",
                node_url,
                api_key,
                data={"command": "sync"}
            )
        except:
            pass
        
        logger.critical(f"Data wiped from container {container_name}: "
                       f"{len(results['deleted_paths'])} paths deleted, "
                       f"{len(results['errors'])} errors")
        
        return results    
    async def wipe_kvm_data(self, vm_name: str, node_url: str, 
                            api_key: str) -> Dict:
        """Suppression sécurisée pour VMs KVM"""
        results = {
            "vm": vm_name,
            "timestamp": datetime.now().isoformat(),
            "deleted_paths": [],
            "errors": [],
            "success": True
        }
        
        from bot.utils import node_manager
        
        for path in self.ALLOWED_WIPE_PATHS:
            # Validation stricte du chemin
            if not path.startswith('/') or '..' in path:
                error_msg = f"Invalid or unsafe path skipped: {path}"
                results['errors'].append(error_msg)
                logger.warning(f"[{vm_name}] {error_msg}")
                continue
                
            try:
                wipe_cmd = f"find {path} -type f -delete"
                
                result = await node_manager.api_request(
                    'POST',
                    f"/kvm/vm/{vm_name}/exec",
                    node_url,
                    api_key,
                    data={"command": wipe_cmd, "timeout": 60}
                )
                
                if result:
                    results['deleted_paths'].append(path)
                    logger.info(f"Wiped {path} in KVM {vm_name}")
            
            except Exception as e:
                results['errors'].append(str(e))
                logger.error(f"[{vm_name}] Failed to wipe {path}: {e}")
                results['success'] = False
        
        return results
    
    async def wipe_dedicated_server(self, vps_dict: dict) -> Dict:
        """Suppression sécurisée pour serveurs dédiés via SSH"""
        results = {
            "server": vps_dict.get('container_name'),
            "timestamp": datetime.now().isoformat(),
            "deleted_paths": [],
            "errors": [],
            "success": True
        }
        
        ip = vps_dict.get('ip_address')
        port = vps_dict.get('ssh_port', 22)
        password = vps_dict.get('ssh_password')
        
        if not all([ip, port, password]):
            results['success'] = False
            results['errors'].append("Missing SSH credentials")
            return results
        
        import paramiko
        
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip, port=port, username='root', password=password, timeout=10)
            
            for path in self.ALLOWED_WIPE_PATHS:
                # Validation stricte du chemin
                if not path.startswith('/') or '..' in path:
                    error_msg = f"Invalid or unsafe path skipped: {path}"
                    results['errors'].append(error_msg)
                    logger.warning(f"[{ip}] {error_msg}")
                    continue
                    
                try:
                    wipe_cmd = f"find {path} -type f -delete"
                    stdin, stdout, stderr = client.exec_command(wipe_cmd)
                    stdout.read() # Read to ensure command completes and captures any output
                    results['deleted_paths'].append(path)
                    logger.info(f"Wiped {path} on dedicated server {ip}")
                except Exception as e:
                    error_msg = f"Failed to wipe {path}: {str(e)}"
                    results['errors'].append(error_msg)
            
            # Final sync
            client.exec_command("sync")
            client.close()
            
            logger.critical(f"Data wiped from dedicated server {ip}")
        
        except Exception as e:
            results['success'] = False
            results['errors'].append(str(e))
            logger.error(f"Failed to wipe dedicated server {ip}: {e}")
        
        return results
