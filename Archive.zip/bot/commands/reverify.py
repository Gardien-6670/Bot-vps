import logging
import discord
from discord.ext import commands
from discord import app_commands
from bot.utils.database import db

class Reverify(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="reverify", description="Resets your IP verification status, allowing you to re-verify.")
    @app_commands.guild_only()
    async def reverify(self, interaction: discord.Interaction):
        """Allows a user to reset their own IP verification status."""
        await interaction.response.defer(ephemeral=True)
        
        user_id = interaction.user.id
        
        try:
            db.reset_user_ip_verification(user_id)
            logging.info(f"User {user_id} has reset their IP verification status.")
            embed = discord.Embed(
                title="Status Reset",
                description="Your IP verification status has been successfully reset. You will be prompted to verify again on your next command.",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            logging.error(f"Failed to reset IP verification for user {user_id}: {e}")
            embed = discord.Embed(
                title="Error",
                description="An error occurred while resetting your status. Please contact an administrator.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(Reverify(bot))
