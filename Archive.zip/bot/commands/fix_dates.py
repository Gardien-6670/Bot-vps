import discord
from discord.ext import commands
from datetime import datetime, timedelta
import logging

from bot.utils.database import db

# Admin user ID - Make sure this is the correct ID for the admin
AUTHORIZED_USER_ID = 1047760053509312642

class FixDates(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(
        name="fix-free-vps-dates",
        description="Corrects the due dates for free-tier VPSs with incorrect 30-day expiry."
    )
    async def fix_free_vps_dates(self, interaction: discord.Interaction):
        # Check for admin permission
        if interaction.user.id != AUTHORIZED_USER_ID:
            await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        logging.info(f"Admin {interaction.user.id} initiated a fix for free VPS due dates.")
        
        corrected_vps = []
        errors = []
        
        try:
            # Get all ad-supported VPSs
            all_ad_vps = db.get_all_ad_tier_vps()

            if not all_ad_vps:
                await interaction.followup.send("No ad-supported VPSs found to check.", ephemeral=True)
                return

            now = datetime.now()
            # We assume a VPS is incorrect if its due date is more than 2 days in the future
            # because they should only have a 1-day expiry.
            two_days_from_now = now + timedelta(days=2)

            for vps in all_ad_vps:
                vps_id = vps['id']
                container_name = vps['container_name']
                current_due_date = vps['due_date']

                # Ensure current_due_date is not naive if 'now' is aware (though it is not here)
                if isinstance(current_due_date, datetime) and current_due_date > two_days_from_now:
                    # This due date is likely incorrect. Reset it to 1 day from now.
                    new_due_date = now + timedelta(days=1)
                    try:
                        db.set_vps_due_date(vps_id, new_due_date)
                        corrected_vps.append(f"`{container_name}` (Old: {current_due_date.strftime('%Y-%m-%d')}, New: {new_due_date.strftime('%Y-%m-%d')})")
                    except Exception as e:
                        logging.error(f"Failed to update due date for VPS ID {vps_id}: {e}")
                        errors.append(f"`{container_name}`: {e}")

            # Prepare report
            if not corrected_vps and not errors:
                report_message = "No incorrect due dates found on free-tier VPSs."
            else:
                report_message = ""
                if corrected_vps:
                    report_message += f"**Corrected {len(corrected_vps)} VPSs:**\n" + "\n".join(corrected_vps)
                if errors:
                    report_message += "\n\n**Errors:**\n" + "\n".join(errors)
            
            await interaction.followup.send(report_message, ephemeral=True)

        except Exception as e:
            logging.error(f"An error occurred during fix_free_vps_dates: {e}", exc_info=True)
            await interaction.followup.send(f"An unexpected error occurred: {e}", ephemeral=True)


async def setup(bot):
    await bot.add_cog(FixDates(bot))
