import discord
from discord.ext import commands, tasks
from discord import app_commands
from bot.utils.database import db
import math
import asyncio
import logging
from urllib.parse import urlparse
import aiohttp
import os
import time
import re
import random
from bot.utils import node_manager
from bot.utils.progress_poller import get_current_progress
from datetime import datetime, timedelta
import string
import pytz
import asyncssh
from bot.utils.flask_earn_server import normalize_ad_info, ensure_aware

# --- Constants ---
ADMIN_USER_ID = 1047760053509312642
EUR_TO_USD_RATE = 1.08  # Approximate rate, for OxaPay which takes USD

from bot.utils.pricing import PRICES_LXC, PRICES_KVM, usd_to_credits, eur_to_usd

# Flask server details for 'earn' command
PUBLIC_FLASK_HOST = os.getenv("PUBLIC_FLASK_HOST", "earn-jupyterhive.duckdns.org")
FLASK_PORT = 6028
FLASK_BASE_URL = f"https://{PUBLIC_FLASK_HOST}:{FLASK_PORT}"


# --- UI Components ---
class VpsConfigModal(discord.ui.Modal, title="Configure your VPS"):
    cpu = discord.ui.TextInput(label="CPU Cores", placeholder="e.g., 1, 2, 4", required=True)
    ram = discord.ui.TextInput(label="RAM (GB)", placeholder="e.g., 1, 2, 8", required=True)
    disk = discord.ui.TextInput(label="Disk (GB)", placeholder="e.g., 10, 20, 50", required=True)

    def __init__(self, bot: commands.Bot, plan_type: str):
        super().__init__()
        self.bot = bot
        self.plan_type = plan_type
        if self.plan_type == "kvm":
            self.prices = PRICES_KVM
        else:  # lxc
            self.prices = PRICES_LXC

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        # --- Admin Whitelist Check ---
        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        BOOSTER_ROLE_ID = 1436388721086693567
        is_admin = interaction.user.id in ADMIN_WHITELIST
        
        if not is_admin:
            # --- Blacklist Role Check (only for non-admins) ---
            BLACKLISTED_ROLE_ID = 1442634477963710545
            user_roles = [role.id for role in interaction.user.roles]
            if BLACKLISTED_ROLE_ID in user_roles:
                embed = discord.Embed(
                    title="Access Denied",
                    description="You are not permitted to create a VPS with your current roles.",
                    color=0x992D22
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            # --- End of Check ---
            
            # --- Payment/Booster Check for Paid Plans ---
            if self.plan_type in ["lxc", "kvm"]:  # Paid plans
                has_transaction = db.has_completed_credit_transaction(interaction.user.id)
                has_booster_role = False
                
                if interaction.guild:
                    booster_role = interaction.guild.get_role(BOOSTER_ROLE_ID)
                    if booster_role and booster_role in interaction.user.roles:
                        has_booster_role = True
                
                if not has_transaction and not has_booster_role:
                    embed = discord.Embed(
                        title="Access Denied",
                        description="You need to purchase credits first OR have the booster role to unlock paid VPS purchases.",
                        color=0x992D22
                    )
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    return
            # --- End of Payment/Booster Check ---

        try:
            cpu_cores = int(self.cpu.value)
            ram_value = self.ram.value.replace(',', '.')
            disk_value = self.disk.value.replace(',', '.')
            
            ram_gb = float(ram_value)
            disk_gb = float(disk_value)
            if cpu_cores <= 0 or ram_gb <= 0 or disk_gb <= 0:
                raise ValueError()
            if cpu_cores > 20:
                embed = discord.Embed(
                    title="Configuration Error",
                    description="You cannot request more than 20 CPU cores.",
                    color=0x992D22
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
        except ValueError:
            embed = discord.Embed(
                title="Configuration Error",
                description="Please enter valid positive numerical values.",
                color=0x992D22
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        cost_credits = math.ceil(
            (cpu_cores * usd_to_credits(self.prices["cpu"])) +
            (ram_gb * usd_to_credits(self.prices["ram"])) +
            (disk_gb * usd_to_credits(self.prices["disk"]))
        )

        description_cost = f"This VPS costs {cost_credits} credits"

        user_balance = db.get_balance(interaction.user.id)

        if user_balance < cost_credits and not is_admin:
            embed = discord.Embed(
                title="Insufficient Balance",
                description=f"{description_cost}, but you only have {user_balance} credits.",
                color=0x992D22
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
            
        # --- Node Filtering ---
        available_nodes = {}
        for name, node in node_manager.NODES.items():
            # Check if the node can support the requested plan type by capacity
            if self.plan_type == 'lxc' and node.get('max_lxc', 0) <= 0:
                continue
            if self.plan_type == 'kvm' and node.get('max_kvm', 0) <= 0:
                continue
            
            # For paid plans, ONLY use premium nodes
            if not node.get('premium', False):
                continue

            available_nodes[name] = node

        if not available_nodes:
            embed = discord.Embed(
                title="No Premium Nodes Available",
                description=f"There are currently no available premium {self.plan_type.upper()} nodes for paid VPS. Please contact an administrator.",
                color=0x992D22
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
        # --- End of filtering ---

        # Fetch node stats for display
        node_stats_tasks = [node_manager.get_node_stats(name, info) for name, info in available_nodes.items()]
        node_results = await asyncio.gather(*node_stats_tasks)
        
        node_info_list = []
        for i, (node_name, node_config) in enumerate(available_nodes.items()):
            stats = node_results[i]
            if self.plan_type == 'lxc':
                current = stats['lxc_current']
                max_cap = stats['lxc_max']
            else: # kvm
                current = stats['kvm_current']
                max_cap = stats['kvm_max']
            
            node_info_list.append({
                "name": node_name,
                "current": current,
                "max": max_cap,
                "config": node_config
            })

        embed = discord.Embed(
            title="Select a Node for your VPS",
            description=f"You are about to purchase a {cpu_cores} CPU, {ram_gb}GB RAM, {disk_gb}GB Disk {self.plan_type.upper()} VPS for {cost_credits} credits.\n\nPlease select a node below:",
            color=0xE5E6EB
        )
        
        for node_data in node_info_list:
            embed.add_field(
                name=f"Node: {node_data['name'].capitalize()}",
                value=f"Usage: {node_data['current']}/{node_data['max']} {self.plan_type.upper()}s",
                inline=True
            )

        view = NodeSelectionView(
            self.bot, cpu_cores, ram_gb, disk_gb, cost_credits,
            interaction.user.id, interaction.user.name,
            self.plan_type, interaction, node_info_list
        )
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)


class BuyCreditsModal(discord.ui.Modal, title="Buy Credits"):
    credits = discord.ui.TextInput(label="Amount of credits to buy", placeholder="e.g., 100, 500, 1000", required=True)

    def __init__(self, bot: commands.Bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        try:
            credits_to_buy = int(self.credits.value)
            if credits_to_buy < 9:
                await interaction.followup.send("The minimum amount of credits to buy is 9.", ephemeral=True)
                return
        except ValueError:
            await interaction.followup.send("Please enter a valid number.", ephemeral=True)
            return

        buy_credits_cog = self.bot.get_cog("BuyCredits")
        if not buy_credits_cog or not getattr(buy_credits_cog, "oxapay_merchant_key", None):
            await interaction.followup.send("The payment feature is currently unavailable. Please contact an administrator.", ephemeral=True)
            return

        price = round((credits_to_buy / 100) * 1.14, 2)

        async with aiohttp.ClientSession() as session:
            payload = {
                "merchant": getattr(buy_credits_cog, "oxapay_merchant_key"),
                "amount": price,
                "currency": "USD",
                "lifeTime": 90,
            }
            try:
                async with session.post("https://api.oxapay.com/merchants/request", json=payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pay_link = data.get('payLink')
                        track_id = data.get('trackId')
                        if pay_link and track_id:
                            expiration_time = datetime.now() + timedelta(minutes=90)
                            db.add_transaction(track_id, interaction.user.id, credits_to_buy, expiration_time, interaction.guild.id if interaction.guild else None)

                            embed = discord.Embed(
                                title="Payment for Credits",
                                description=f"Click the link below to pay **${price:.2f}** for **{credits_to_buy} credits**.",
                                color=0xE5E6EB
                            )
                            embed.add_field(name="Payment Link", value=f"[Click here to pay]({pay_link})", inline=False)
                            embed.add_field(name="Transaction ID", value=f"`{track_id}`", inline=False)
                            embed.add_field(name="Valid for", value="90 minutes", inline=False)
                            embed.set_footer(text="The bot will automatically detect your payment.")
                            try:
                                await interaction.user.send(embed=embed)
                                await interaction.followup.send("Payment link sent to your DMs!", ephemeral=True)
                            except discord.Forbidden:
                                await interaction.followup.send(embed=embed, ephemeral=True)
                        else:
                            await interaction.followup.send("An error occurred while creating the payment. Please try again.", ephemeral=True)
                    else:
                        await interaction.followup.send(f"OxaPay API Error: {resp.status} - {await resp.text()}", ephemeral=True)
            except Exception as e:
                await interaction.followup.send(f"An error occurred: {e}", ephemeral=True)

class NodeSelectionView(discord.ui.View):
    def __init__(self, bot: commands.Bot, cpu_cores: int, ram_gb: float, disk_gb: float, cost_credits: int, user_id: int, username: str, plan_type: str, original_interaction: discord.Interaction, node_info_list: list, plan_tier: str = None, invite_plan_tier: str = None):
        super().__init__(timeout=180)
        self.bot = bot
        self.cpu_cores = cpu_cores
        self.ram_gb = ram_gb
        self.disk_gb = disk_gb
        self.cost_credits = cost_credits
        self.user_id = user_id
        self.username = username
        self.plan_type = plan_type
        self.original_interaction = original_interaction
        self.node_info_list = node_info_list
        self.plan_tier = plan_tier
        self.invite_plan_tier = invite_plan_tier
        self.add_node_buttons()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.user_id:
            return True
        await interaction.response.defer(ephemeral=True, thinking=False)
        await interaction.followup.send("You are not authorized to interact with this.", ephemeral=True)
        return False

    def add_node_buttons(self):
        for i, node_data in enumerate(self.node_info_list):
            if i >= 5: # Discord button limit per row
                break
            
            node_name = node_data['name']
            is_full = node_data['current'] >= node_data['max']

            button = discord.ui.Button(
                label=node_name.capitalize(), 
                style=discord.ButtonStyle.secondary, 
                custom_id=f"select_node:{node_name}",
                disabled=is_full
            )
            button.callback = self.node_button_callback
            self.add_item(button)

    async def node_button_callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        selected_node_name = interaction.data['custom_id'].split(':')[1]
        selected_node_info = node_manager.NODES.get(selected_node_name)

        if not selected_node_info:
            await interaction.followup.send("Selected node not found or configured.", ephemeral=True)
            return
        
        # For paid plans (not ad-tier or invite-tier), verify it's a premium node
        if not self.plan_tier and not self.invite_plan_tier:  # This is a paid plan
            if not selected_node_info.get('premium', False):
                await interaction.followup.send(f"Node `{selected_node_name}` is not a premium node. Paid VPS can only be created on premium nodes.", ephemeral=True)
                return

        stats = await node_manager.get_node_stats(selected_node_name, selected_node_info)
        if self.plan_type == 'lxc':
            current = stats['lxc_current']
            max_cap = stats['lxc_max']
        else: # kvm
            current = stats['kvm_current']
            max_cap = stats['kvm_max']

        if current >= max_cap:
            await interaction.followup.send(f"Node `{selected_node_name}` is now full. Please try another node.", ephemeral=True)
            return

        accepted_embed = discord.Embed(
            title="Purchase Confirmed!",
            description=f"Your VPS is being created on node `{selected_node_name}`. This may take a few minutes. I will send you your credentials via private message shortly.",
            color=0xE5E6EB
        )
        accepted_embed.add_field(name="Configuration", value=f"{self.cpu_cores} CPU, {self.ram_gb}GB RAM, {self.disk_gb}GB Disk", inline=False)
        if self.cost_credits > 0:
            accepted_embed.add_field(name="Cost", value=f"{self.cost_credits} credits", inline=False)
        else:
            if self.invite_plan_tier:
                accepted_embed.add_field(name="Plan Type", value=f"Invite Plan ({self.invite_plan_tier.capitalize()})", inline=False)
            elif self.plan_tier:
                accepted_embed.add_field(name="Plan Type", value=f"Ad-Supported Plan ({self.plan_tier.capitalize()})", inline=False)
            else:
                accepted_embed.add_field(name="Cost", value="Free (Ad-supported / Invite-based)", inline=False)
        await self.original_interaction.edit_original_response(embed=accepted_embed, view=None)

        followup_message = await interaction.followup.send("Processing your VPS creation... 0%", ephemeral=True)
        
        # This task should not be awaited here
        asyncio.create_task(self.bot.get_cog("Plans")._create_vps_and_update_progress(
            followup_message, self.user_id, self.username, self.cpu_cores, self.ram_gb, self.disk_gb,
            self.cost_credits, self.plan_type, selected_node_name, selected_node_info,
            is_dedicated=False, plan_tier=self.plan_tier, invite_plan_tier=self.invite_plan_tier
        ))
        self.stop()

# --- Persistent Views ---

class MainPlansView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Buy LXC VPS", style=discord.ButtonStyle.success, custom_id="main_buy_lxc")
    async def buy_lxc_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        BOOSTER_ROLE_ID = 1436388721086693567

        is_admin = interaction.user.id in ADMIN_WHITELIST
        has_transaction = db.has_completed_credit_transaction(interaction.user.id)
        
        has_booster_role = False
        if interaction.guild:
            booster_role = interaction.guild.get_role(BOOSTER_ROLE_ID)
            if booster_role and booster_role in interaction.user.roles:
                has_booster_role = True
        
        if is_admin or has_transaction or has_booster_role:
            modal = VpsConfigModal(self.bot, "lxc")
            await interaction.response.send_modal(modal)
        else:
            await interaction.response.send_message("You need to purchase credits first OR have the booster role to unlock VPS purchases.", ephemeral=True)

    @discord.ui.button(label="Buy KVM VPS", style=discord.ButtonStyle.success, custom_id="main_buy_kvm")
    async def buy_kvm_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        kvm_enabled = db.is_feature_enabled('kvm_plans_enabled')
        if not kvm_enabled:
            await interaction.response.send_message("KVM plans are temporarily disabled.", ephemeral=True)
            return

        ADMIN_WHITELIST = [1047760053509312642, 1358004112049967206]
        BOOSTER_ROLE_ID = 1436388721086693567

        is_admin = interaction.user.id in ADMIN_WHITELIST
        has_transaction = db.has_completed_credit_transaction(interaction.user.id)

        has_booster_role = False
        if interaction.guild:
            booster_role = interaction.guild.get_role(BOOSTER_ROLE_ID)
            if booster_role and booster_role in interaction.user.roles:
                has_booster_role = True

        if is_admin or has_transaction or has_booster_role:
            modal = VpsConfigModal(self.bot, "kvm")
            await interaction.response.send_modal(modal)
        else:
            await interaction.response.send_message("You need to purchase credits first OR have the booster role to unlock VPS purchases.", ephemeral=True)
    
    @discord.ui.button(label="Balance", style=discord.ButtonStyle.secondary, custom_id="main_balance")
    async def balance_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)
        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(name="Pending Credits", value=f"**{pending_balance}**", inline=True)
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(label="Buy Credits", style=discord.ButtonStyle.primary, custom_id="main_buy_credits")
    async def buy_credits_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = BuyCreditsModal(self.bot)
        await interaction.response.send_modal(modal)

class FreePlansView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Get Free VPS", style=discord.ButtonStyle.success, custom_id="free_get_vps")
    async def get_free_vps_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = VpsConfigModal(self.bot, "free")
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Earn Free Credits", style=discord.ButtonStyle.primary, custom_id="free_earn_credits")
    async def earn_credits_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # This mirrors the logic from the 'earn' command
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        
        earn_cog = self.bot.get_cog("WatchAds")
        if not earn_cog:
            await interaction.followup.send("The earn feature is currently unavailable.", ephemeral=True)
            return

        # Simplified check from earn command
        if user_id not in [1047760053509312642, 1286418351035388006]:
            last_watch_cuty = db.get_last_watch_date(user_id, 'cuty')
            cuty_done = last_watch_cuty and (datetime.now(pytz.utc) - last_watch_cuty).days < 1
            daily_watches = db.get_linkvertise_daily_watches(user_id)
            today_utc = datetime.now(pytz.utc).date()
            today_watches = [watch for watch in daily_watches if watch.astimezone(pytz.utc).date() == today_utc]
            linkvertise_done = len(today_watches) >= 5
            if cuty_done and linkvertise_done:
                embed = discord.Embed(title="Daily Ad Limit Reached", description="You have already earned credits from all available methods today. Please try again tomorrow.", color=0x992D22)
                await interaction.followup.send(embed=embed, ephemeral=True)
                return

        ad_token, expiration_time, is_new_session = await earn_cog._get_or_create_ad_session(user_id)

        if not is_new_session:
            flask_url_for_active_link = f"{FLASK_BASE_URL}/watch-ads/{user_id}/{ad_token}"
            embed = discord.Embed(
                title="You already have an active ad link!",
                description=(
                    "You currently have an active ad session. Please use the existing link to earn credits.\n\n"
                    f"**Your active link:** [Continue Watching Ads]({flask_url_for_active_link})\n\n"
                    "This link will expire in 4 hours from when it was created."
                ),
                color=0x99AAB5
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        flask_url = f"{FLASK_BASE_URL}/watch-ads/{user_id}/{ad_token}"


        embed = discord.Embed(
            title="Watch Ads, Earn Credits!",
            description=(
                f"**[Click here to Watch Ads]({flask_url})**\n\n"
                "You will complete the entire process on the website to earn credits.\n"
                "This session will **expire in 4 hours**."
            ),
            color=0xE5E6EB
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @discord.ui.button(label="Balance", style=discord.ButtonStyle.secondary, custom_id="free_balance")
    async def balance_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)
        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(name="Pending Credits", value=f"**{pending_balance}**", inline=True)
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

class DedicatedPlanConfirmationView(discord.ui.View):
    def __init__(self, bot: commands.Bot, user_id: int):
        super().__init__(timeout=180)
        self.bot = bot
        self.user_id = user_id
        self.plan_name = "vps-dedicaced-1"
        self.specs = {"cpu": 1, "ram": 4, "disk": 200}
        self.price_eur = 5.30

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.user_id:
            return True
        await interaction.response.send_message("You are not authorized to interact with this.", ephemeral=True)
        return False

    @discord.ui.button(label="Confirm and Pay", style=discord.ButtonStyle.success)
    async def confirm_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        buy_credits_cog = self.bot.get_cog("BuyCredits")
        if not buy_credits_cog or not getattr(buy_credits_cog, "oxapay_merchant_key", None):
            await interaction.followup.send("The payment feature is currently unavailable. Please contact an administrator.", ephemeral=True)
            return

        price_usd = eur_to_usd(self.price_eur)

        async with aiohttp.ClientSession() as session:
            payload = { "merchant": getattr(buy_credits_cog, "oxapay_merchant_key"), "amount": price_usd, "currency": "USD", "lifeTime": 30}
            try:
                async with session.post("https://api.oxapay.com/merchants/request", json=payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pay_link = data.get('payLink')
                        track_id = data.get('trackId')
                        if pay_link and track_id:
                            order_id = db.add_dedicated_order(interaction.user.id, self.plan_name, self.specs, self.price_eur, track_id)
                            
                            embed = discord.Embed(title="Payment for Dedicated Server", description=f"Please use the link below to pay **€{self.price_eur:.2f}** for your dedicated server.", color=0xE5E6EB)
                            embed.add_field(name="Payment Link", value=pay_link)
                            embed.add_field(name="Order ID", value=str(order_id), inline=False)
                            embed.set_footer(text="The bot will notify an admin once the payment is confirmed.")
                            
                            await interaction.user.send(embed=embed)
                            await interaction.followup.send("Please check your private messages for the payment link.", ephemeral=True)
                            await interaction.edit_original_response(content="Payment link sent to your DMs.", view=None)
                        else:
                            await interaction.followup.send("An error occurred while creating the payment. Please try again.", ephemeral=True)
                    else:
                        await interaction.followup.send(f"OxaPay API Error: {resp.status} - {await resp.text()}", ephemeral=True)
            except Exception as e:
                logging.error(f"Dedi payment link error: {e}")
                await interaction.followup.send(f"An error occurred: {e}", ephemeral=True)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger)
    async def cancel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Purchase cancelled.", view=None)
        self.stop()


class InvitePlansView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot
        # Add buttons for each tier
        for tier_id, tier_info in INVITE_PLANS.items():
            button = discord.ui.Button(
                label=f"{tier_info['name']} ({tier_info['invites_required']} Invites)",
                style=discord.ButtonStyle.primary,
                custom_id=f"invite_tier_select:{tier_id}"
            )
            button.callback = self.tier_button_callback
            self.add_item(button)
        
        balance_button = discord.ui.Button(label="Balance", style=discord.ButtonStyle.secondary, custom_id="invite_balance")
        balance_button.callback = self.balance_button
        self.add_item(balance_button)

    async def tier_button_callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        tier_id = interaction.data['custom_id'].split(':')[1]
        tier_info = INVITE_PLANS[tier_id]
        
        valid_invites = db.get_total_valid_invite_count(interaction.user.id)
        required_invites = tier_info["invites_required"]

        if valid_invites < required_invites:
            embed = discord.Embed(
                title="Not Enough Invites",
                description=f'You need **{required_invites}** valid invites for **{tier_info["name"]}**, but you only have **{valid_invites}**.',
                color=0xED4245
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
        
        # Check if user already has an invite-plan VPS
        existing_invite_vps = db.get_user_invite_vps(interaction.user.id)
        if existing_invite_vps:
            embed = discord.Embed(
                title="Invite VPS Limit Reached",
                description="You can only have **1 invite-based VPS** at a time. Please delete or manage your current VPS before creating another.",
                color=0xED4245
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        # Proceed to node selection
        available_nodes = {}
        for name, node in node_manager.NODES.items():
            # Only allow LXC nodes for invite tiers (assuming LXC for now)
            if (node.get("type") == "lxc" or "lxc" in name.lower()) and not node.get("premium", False):
                available_nodes[name] = node

        if not available_nodes:
            embed = discord.Embed(title="No Free Nodes Available", description="There are currently no available FREE nodes for invite plans. Premium nodes are not allowed for free VPS.", color=0xED4245)
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
            
        node_stats_tasks = [node_manager.get_node_stats(name, info) for name, info in available_nodes.items()]
        node_results = await asyncio.gather(*node_stats_tasks)
        
        node_info_list = []
        for i, (node_name, node_config) in enumerate(available_nodes.items()):
            stats = node_results[i]
            current, max_cap = stats['lxc_current'], stats['lxc_max']
            node_info_list.append({"name": node_name, "current": current, "max": max_cap, "config": node_config})

        embed = discord.Embed(
            title=f"Select a Node for your {tier_info['name']} VPS",
            description=f"You have met the invite requirement for this plan. Please select a node below to create your VPS.",
            color=0x57F287
        )
        for node_data in node_info_list:
            embed.add_field(
                name=f"Node: {node_data['name'].capitalize()}",
                value=f"Usage: {node_data['current']}/{node_data['max']} LXCs",
                inline=True
            )
        
        view = NodeSelectionView(
            self.bot, tier_info['cpu'], tier_info['ram'], tier_info['disk'], 0, # Cost credits is 0 for invite plans
            interaction.user.id, interaction.user.name,
            'lxc', interaction, node_info_list, invite_plan_tier=tier_id
        )
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    async def balance_button(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)
        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(name="Pending Credits", value=f"**{pending_balance}**", inline=True)
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

class DedicatedSshModal(discord.ui.Modal, title="Setup Dedicated VPS"):
    ssh_host = discord.ui.TextInput(label="SSH Host/IP", placeholder="e.g., 123.45.67.89", required=True)
    ssh_port = discord.ui.TextInput(label="SSH Port", placeholder="e.g., 22", required=True)
    ssh_password = discord.ui.TextInput(label="SSH Password", placeholder="A strong password", style=discord.TextStyle.paragraph, required=True)

    def __init__(self, bot: commands.Bot, order_id: int, original_interaction: discord.Interaction):
        super().__init__()
        self.bot = bot
        self.order_id = order_id
        self.original_interaction = original_interaction

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        order = db.get_dedicated_order(self.order_id)
        if not order:
            await interaction.followup.send("Order not found.", ephemeral=True)
            return

        host = self.ssh_host.value
        try:
            port = int(self.ssh_port.value)
        except ValueError:
            await interaction.followup.send("Invalid port number.", ephemeral=True)
            return
        password = self.ssh_password.value

        # Test SSH connection
        try:
            # Send an initial followup, as connect can take time.
            await interaction.followup.send(f"Testing SSH connection to `{host}:{port}`...", ephemeral=True)
            async with asyncssh.connect(host, port=port, username="root", password=password, known_hosts=None, connect_timeout=10) as conn:
                await conn.run('echo "SSH connection successful!"', check=True)
        except Exception as e:
            logging.error(f"Manual SSH Check failed for order {self.order_id}: {e}")
            # Edit the followup message with the error.
            await interaction.edit_original_response(content=f"SSH connection failed: `{e}`. Please check the details and try again.")
            return
        
        # Connection successful, proceed to save and notify
        customer = await self.bot.fetch_user(order['user_id'])
        user_vps_list = db.get_user_vps(order['user_id'])
        user_vm_count = len(user_vps_list) + 1
        container_name = f"dedi-{customer.name.lower().replace(' ', '')}-{order['id']}"

        conn, cursor = db.start_transaction()
        try:
            ssh_link = f"ssh root@{host} -p {port}"
            db.add_vps(
                user_id=order['user_id'],
                username=customer.name,
                container_name=container_name,
                cpu=order['specs']['cpu'],
                ram=order['specs']['ram'],
                disk=order['specs']['disk'],
                cost_credits=0,
                ssh_link=ssh_link,
                ssh_port=port,
                ssh_password=password,
                vps_type='kvm',
                node='dedicated', # Mark as manually managed
                plan_tier=None,
                invite_plan_tier=None,
                cursor=cursor, conn=conn
            )
            db.update_dedicated_order_status(self.order_id, 'provisioned', container_name, cursor=cursor, conn=conn)
            db.commit_transaction(conn, cursor)
        except Exception as e:
            db.rollback_transaction(conn, cursor)
            logging.error(f"Database update failed for dedicated order {self.order_id}: {e}", exc_info=True)
            await interaction.edit_original_response(content=f"Database error: `{e}`. The VPS was not saved.")
            return

        # Send credentials to user
        try:
            dm_embed = discord.Embed(title="Your Dedicated Server is Ready!", description=f"Your dedicated server `{container_name}` is now online.", color=0x2ECC71)
            dm_embed.add_field(name="SSH Connection", value=f"```\n{ssh_link}\n```", inline=False)
            dm_embed.add_field(name="Password", value=f"```\n{password}\n```", inline=False)
            dm_embed.set_footer(text="Keep your SSH credentials safe!")
            await customer.send(embed=dm_embed)
        except discord.Forbidden:
            logging.warning(f"Could not send DM to user {customer.id} for order {self.order_id}")
            await interaction.edit_original_response(content=f"Successfully provisioned for {customer.mention}, but **could not send DM**. Please deliver credentials manually.")
            # Still edit the original message to show completion despite DM failure
            original_message_embed = self.original_interaction.message.embeds[0]
            original_message_embed.set_footer(text=f"VPS Provisioned by {interaction.user.name} (DM FAILED).")
            original_message_embed.color = 0xFFA500 # Orange for warning
            await self.original_interaction.edit_original_response(embed=original_message_embed, view=None)
            return

        await interaction.edit_original_response(content=f"Successfully provisioned dedicated server for {customer.mention} and sent credentials.")
        
        # Disable button on original admin message
        original_message_embed = self.original_interaction.message.embeds[0]
        original_message_embed.set_footer(text=f"VPS Provisioned by {interaction.user.name}.")
        original_message_embed.color = 0x2ECC71
        
        await self.original_interaction.edit_original_response(embed=original_message_embed, view=None)

class AdminSetupView(discord.ui.View):
    def __init__(self, bot: commands.Bot, order_id: int):
        super().__init__(timeout=None)
        self.bot = bot
        self.order_id = order_id

    @discord.ui.button(label="Setup VPS", style=discord.ButtonStyle.primary, custom_id=f"dedi_setup_vps")
    async def setup_vps_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        order = db.get_dedicated_order(self.order_id)
        if not order or order['status'] != 'paid':
            await interaction.response.send_message(f"Order {self.order_id} not found or not paid.", ephemeral=True)
            return

        # Open the modal to get SSH details from the admin
        await interaction.response.send_modal(
            DedicatedSshModal(self.bot, self.order_id, original_interaction=interaction)
        )

class DedicatedPlansView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Buy vps-dedicaced-1 (€5.30/month)", style=discord.ButtonStyle.success, custom_id="dedicaced_buy_1")
    async def buy_dedicaced_1(self, interaction: discord.Interaction, button: discord.ui.Button):
        plan_specs = {"cpu": "1 Core @ 5.6 GHz", "ram": "4 GB DDR5", "disk": "200 GB NVME Gen-5"}
        price_eur = 5.30

        embed = discord.Embed(title="Confirm Purchase: vps-dedicaced-1", color=0xE5E6EB)
        embed.description = f"Please confirm you want to buy this dedicated server for **€{price_eur:.2f}** per month."
        embed.add_field(name="CPU", value=plan_specs["cpu"])
        embed.add_field(name="RAM", value=plan_specs["ram"])
        embed.add_field(name="Disk", value=plan_specs["disk"])
        
        view = DedicatedPlanConfirmationView(self.bot, interaction.user.id)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


# --- Cog ---
class Plans(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Register persistent views
        self.bot.add_view(MainPlansView(bot))
        self.bot.add_view(AdTiersView(bot)) # Replaced FreePlansView
        self.bot.add_view(DedicatedPlansView(bot))
        self.bot.add_view(InvitePlansView(bot))
        self.bot.add_view(AdminSetupView(bot, 0)) # Register with dummy order_id
        
        # Start the automatic panel deployment task
        self.initial_panel_deployment.start()
        self.check_ad_vps_requirements.start()
        self.check_suspended_vps_for_deletion.start()
        self.check_terms_acceptance.start()
        self.check_invite_vps_requirements.start()
        self.check_paid_vps_renewals.start()
        self.check_paid_vps_for_deletion.start()
        self.check_invite_vps_for_deletion.start() # New task here

    def cog_unload(self):
        # Cancel the task when the cog is unloaded
        self.initial_panel_deployment.cancel()
        self.check_ad_vps_requirements.cancel()
        self.check_suspended_vps_for_deletion.cancel()
        self.check_terms_acceptance.cancel()
        self.check_invite_vps_requirements.cancel()
        self.check_paid_vps_renewals.cancel()
        self.check_paid_vps_for_deletion.cancel()
        self.check_invite_vps_for_deletion.cancel() # New task here

    async def _create_vps_and_update_progress(self, followup_message: discord.WebhookMessage, user_id: int, username: str, cpu_cores: int, ram_gb: float, disk_gb: float, cost_credits: int, plan_type: str, node_name: str, node_info: dict, is_dedicated: bool = False, order_id: int = None, plan_tier: str = None, invite_plan_tier: str = None):
        """Handles the VPS creation and updates the progress message."""
        user = await self.bot.fetch_user(user_id)
        
        try:
            endpoint = f"/{plan_type}/{'vm' if plan_type == 'kvm' else 'container'}"
            
            # Generate shorter VM name: username + vm_count
            user_vps_list = db.get_user_vps(user_id)
            user_vm_count = len(user_vps_list) + 1
            short_vm_name = f"{username}-{user_vm_count}"
            
            payload = { 
                "user_id": user_id, 
                "username": username, 
                "cpu": cpu_cores, 
                "ram": ram_gb, 
                "disk": disk_gb,
                "vm_name": short_vm_name  # Send shorter name to API
            }
            
            # This is the message that will be updated with progress
            progress_embed = discord.Embed(title="VPS Creation in Progress", description="Initiating...", color=0xE5E6EB)
            await followup_message.edit(embed=progress_embed)

            result = await node_manager.api_request('POST', endpoint, node_info['url'], node_info['api_key'], data=payload)
            logging.info(f"API request returned: {result}") # ADDED LOG
            operation_id = result.get("operation_id")
            logging.info(f"Extracted operation_id: {operation_id}") # ADDED LOG
            
            if not operation_id:
                await followup_message.edit(embed=discord.Embed(title="VPS Creation Failed", description=f"Could not start operation. API Response: `{result}`", color=0x992D22))
                if is_dedicated:
                    admin = await self.bot.fetch_user(ADMIN_USER_ID)
                    await admin.send(f"Failed to start VPS creation for order {order_id}.")
                return
            
            # Poll for progress
            operation_completed = False
            final_result = {}
            start_time = time.time()
            while time.time() - start_time < 1800: # 30 min timeout
                await asyncio.sleep(5)
                progress_data = await get_current_progress(operation_id, node_info['url'], node_info['api_key'])
                if progress_data:
                    percent = progress_data.get("percentage", 0)
                    message = progress_data.get("message", "Processing...")
                    is_completed = progress_data.get("completed", False)
                    
                    # ⚠️ CHANGEMENT ICI : On considère 95% comme "prêt pour finalisation"
                    if percent >= 95 and not is_completed:
                        # L'API a créé le container, on récupère les infos du result initial
                        final_result = result  # Utiliser le résultat initial de l'API
                        operation_completed = True
                        break

                    progress_embed.title = f"VPS Creation in Progress - {percent}%"
                    progress_embed.description = f"Creating your VPS on node `{node_name}`...\n\n**Status:**\n{message}"
                    await followup_message.edit(embed=progress_embed)
                    
                    if is_completed:
                        final_result = progress_data.get("result", result)
                        operation_completed = True
                        break
            
            if not operation_completed:
                raise Exception("Operation timed out.")

            # --- Finalize ---
            if final_result and (final_result.get("status") == "success" or final_result.get("container_name") or final_result.get("vm_name")):
                progress_embed.title = "VPS Creation - Verifying"
                progress_embed.description = "Finalizing setup and verifying connection..."
                await followup_message.edit(embed=progress_embed)

                container_name = final_result.get("container_name") or final_result.get("vm_name")
                # For KVM: use node domain (SSH goes through port forward). Fallback to IP or URL host.
                ssh_host = node_info.get("domain") or node_info.get("ip")
                if not ssh_host and node_info.get("url"):
                    parsed = urlparse(node_info["url"])
                    ssh_host = parsed.hostname or parsed.netloc
                ssh_port = final_result.get("ssh_port")
                ssh_user = "root"
                ssh_password = final_result.get("ssh_password")
                
                # --- Fallback: Try to get VM IP if not available (for DB storage, surveillance, etc.) ---
                vm_ip = final_result.get("vm_ip")
                if not vm_ip and plan_type == "kvm":
                    logging.info(f"Attempting IP fallback for {container_name}...")
                    try:
                        ip_endpoint = f"/kvm/vm/{container_name}/ip"
                        ip_response = await node_manager.api_request('GET', ip_endpoint, node_info['url'], node_info['api_key'])
                        vm_ip = ip_response.get("ip") if isinstance(ip_response, dict) else None
                        if vm_ip:
                            logging.info(f"Got IP via API fallback: {vm_ip}")
                    except Exception as e:
                        logging.warning(f"IP fallback API failed: {e}. Will use node domain instead.")
                
                # Verify SSH
                try:
                    async with asyncssh.connect(ssh_host, port=ssh_port, username=ssh_user, password=ssh_password, known_hosts=None) as conn:
                        await conn.run('echo "SSH connection successful!"', check=True)
                    ssh_works = True
                except Exception as e:
                    logging.error(f"SSH Check failed for {container_name}: {e}")
                    ssh_works = False

                if not ssh_works:
                    # --- Fallback: Wait more time for SSH to be ready ---
                    logging.info(f"SSH not ready yet for {container_name}, waiting before retrying...")
                    for attempt in range(5):
                        await asyncio.sleep(5)
                        try:
                            async with asyncssh.connect(ssh_host, port=ssh_port, username=ssh_user, password=ssh_password, known_hosts=None) as conn:
                                await conn.run('echo "SSH connection successful!"', check=True)
                            ssh_works = True
                            logging.info(f"SSH connected after retry {attempt + 1}")
                            break
                        except Exception as e:
                            logging.warning(f"SSH retry {attempt + 1} failed for {container_name}: {e}")
                    
                    if not ssh_works:
                        # ⚠️ Marquer comme échoué
                        await node_manager.api_request('POST', f'/progress/{operation_id}/fail', node_info['url'], node_info['api_key'], 
                                                      data={"message": "SSH verification failed after retries"})
                        raise Exception("Could not verify SSH connection to the new VPS.")

                # Save to DB
                conn, cursor = db.start_transaction()
                try:
                    ssh_link = f"ssh {ssh_user}@{ssh_host} -p {ssh_port}"
                    
                    # For ad-tier or invite-tier VPS, preserve the due date from previous VPS if exists
                    due_date = None
                    if (plan_tier and plan_tier in LXC_AD_TIERS) or invite_plan_tier:
                        # Get the old VPS to preserve its due date. For invite plans, it's always 1 month.
                        # We don't preserve old due dates for invite plans, they always get 1 month from creation.
                        if plan_tier and plan_tier in LXC_AD_TIERS:
                            old_vps_list = db.get_user_ad_tier_vps_by_tier(user_id, plan_tier)
                            if old_vps_list and len(old_vps_list) > 0:
                                old_due_date = old_vps_list[0].get('due_date')
                                if old_due_date:
                                    due_date = old_due_date
                    
                    # KVM-specific: surveillance credentials and IP for API (get_vm_processes, etc.)
                    add_vps_kwargs = dict(
                        user_id=user_id, username=username, container_name=container_name,
                        cpu=cpu_cores, ram=ram_gb, disk=disk_gb, cost_credits=cost_credits,
                        ssh_link=ssh_link, ssh_port=ssh_port, ssh_password=ssh_password,
                        vps_type=plan_type, node=node_name, cursor=cursor, conn=conn,
                        plan_tier=plan_tier, invite_plan_tier=invite_plan_tier
                    )
                    if plan_type == "kvm":
                        add_vps_kwargs["ip_address"] = vm_ip
                        add_vps_kwargs["surveillance_user"] = final_result.get("surveillance_user")
                        add_vps_kwargs["surveillance_password"] = final_result.get("surveillance_password")
                    db.add_vps(**add_vps_kwargs)
                    if is_dedicated:
                        db.update_dedicated_order_status(order_id, 'provisioned', container_name, cursor=cursor, conn=conn)
                    elif plan_tier and plan_tier in LXC_AD_TIERS:
                        required_points = LXC_AD_TIERS[plan_tier]['ads_required']
                        db.consume_vps_points(user_id, required_points, cursor=cursor, conn=conn)
                    elif invite_plan_tier and invite_plan_tier in INVITE_PLANS:
                        required_invites = INVITE_PLANS[invite_plan_tier]['invites_required']
                        try:
                            db.consume_invites(user_id, required_invites, cursor=cursor, conn=conn)
                        except AttributeError:
                            logging.error(f"db.consume_invites function not found, could not deduct {required_invites} invites from user {user_id}")
                    else:
                        db.add_credits(user_id, -cost_credits, cursor=cursor, conn=conn)
                    db.commit_transaction(conn, cursor)
                    
                    # ✅ MAINTENANT on peut marquer comme complet
                    await node_manager.api_request('POST', f'/progress/{operation_id}/complete', node_info['url'], node_info['api_key'])
                    
                except Exception as e:
                    db.rollback_transaction(conn, cursor)
                    # Marquer comme échoué
                    await node_manager.api_request('POST', f'/progress/{operation_id}/fail', node_info['url'], node_info['api_key'], 
                                                  data={"message": f"Database error: {str(e)}"})
                    raise Exception(f"Database update failed: {e}")

                # --- Send credentials to user ---
                dm_embed = discord.Embed(title="Your VPS is Ready!", description=f"Your VPS `{container_name}` on node `{node_name}` is now online.", color=0x2ECC71)
                dm_embed.add_field(name="SSH Connection", value=f"```\n{ssh_link}\n```", inline=False)
                dm_embed.add_field(name="Password", value=f"```\n{ssh_password}\n```", inline=False)
                dm_embed.set_footer(text="Keep your SSH credentials safe!")
                await user.send(embed=dm_embed)

                await followup_message.edit(embed=discord.Embed(title="VPS Creation Complete", description=f"Credentials for `{container_name}` sent to {user.mention}.", color=0x2ECC71))

            else:
                raise Exception(f"API operation failed. Result: {final_result}")

        except Exception as e:
            logging.error(f"Error in VPS creation task for user {user_id}: {e}", exc_info=True)
            error_embed = discord.Embed(title="An unexpected error occurred", description=f"Could not create the VPS. You have not been charged.\n\n`{e}`", color=0x992D22)
            try:
                if is_dedicated:
                    admin = await self.bot.fetch_user(ADMIN_USER_ID)
                    await admin.send(f"**Critical error during VPS creation for order {order_id} for user {user.mention}!**", embed=error_embed)
                else:
                    await user.send(embed=error_embed)
                await followup_message.edit(embed=error_embed)
            except:
                pass


    @tasks.loop(hours=1)
    async def check_paid_vps_renewals(self):
        await self.bot.wait_until_ready()
        logging.info("Starting hourly paid VPS renewal check.")

        try:
            all_paid_vps = db.get_all_paid_vps()
        except AttributeError:
            logging.warning("`db.get_all_paid_vps()` not found. Skipping paid VPS renewal check.")
            return

        now_utc = datetime.now(pytz.utc)

        for vps in all_paid_vps:
            user_id = vps['user_id']
            vps_id = vps['id']
            container_name = vps['container_name']
            renewal_cost = vps['cost_credits']
            vps_type = vps['vps_type']

            # First, attempt to unsuspend if they have funds
            if vps['is_suspended'] and vps.get('suspension_reason') == 'insufficient_credits':
                user_balance = db.get_balance(user_id)
                if user_balance >= renewal_cost:
                    logging.info(f"Attempting to unsuspend VPS {container_name} for user {user_id}.")
                    try:
                        node_info = node_manager.get_node_for_vps(container_name)
                        if node_info:
                            start_endpoint = f"/lxc/container/{container_name}/start" if vps_type == 'lxc' else f"/kvm/vm/{container_name}/unsuspend"
                            await node_manager.api_request('POST', start_endpoint, node_info['url'], node_info['api_key'])
                            db.unsuspend_vps(container_name)
                            # Refresh VPS data to reflect unsuspended state
                            vps = db.get_vps_by_id(vps_id) 
                            user = await self.bot.fetch_user(user_id)
                            await user.send(embed=discord.Embed(title="✅ VPS Unsuspended", description=f"Your VPS `{container_name}` has been unsuspended. Renewal will now be attempted.", color=0x2ECC71))
                    except Exception as e:
                        logging.error(f"Failed to unsuspend paid VPS {container_name}: {e}", exc_info=True)
                        continue # Skip to next VPS if unsuspension fails

            # Skip further processing if still suspended
            if vps['is_suspended']:
                continue
            
            # --- Renewal Logic ---
            vps_due_date = ensure_aware(vps['due_date'])
            if vps_due_date < now_utc:
                user_balance = db.get_balance(user_id)

                if user_balance >= renewal_cost:
                    # If expired, the new due date is now + 30 days. This avoids penalizing users for suspension time.
                    new_due_date = now_utc + timedelta(days=30)
                    
                    # --- DB Transaction Block ---
                    conn, cursor = db.start_transaction()
                    try:
                        db.add_credits(user_id, -renewal_cost, cursor=cursor, conn=conn)
                        db.set_vps_due_date(vps_id, new_due_date, cursor=cursor, conn=conn)
                        db.commit_transaction(conn, cursor)
                    except Exception as e:
                        if conn and cursor and conn.is_connected():
                            db.rollback_transaction(conn, cursor)
                        logging.error(f"Error during DB renewal for paid VPS {container_name}: {e}", exc_info=True)
                        continue # Skip to next VPS if DB fails

                    # --- Post-Transaction Actions ---
                    try:
                        logging.info(f"Renewed paid VPS {container_name}. New due date: {new_due_date.strftime('%Y-%m-%d %H:%M')}.")
                        user = await self.bot.fetch_user(user_id)
                        await user.send(embed=discord.Embed(title="🧾 VPS Auto-Renewed", description=f"Your VPS `{container_name}` has been automatically renewed. {renewal_cost} credits were deducted. New expiry: {new_due_date.strftime('%Y-%m-%d %H:%M')}.", color=0x3498DB))
                    except Exception as e:
                        logging.error(f"Error sending renewal DM for paid VPS {container_name}: {e}", exc_info=True)

                else:
                    # Not enough credits, suspend
                    logging.info(f"Insufficient credits for paid VPS {container_name} renewal. Suspending.")
                    node_info = node_manager.get_node_for_vps(container_name)
                    if node_info:
                        try:
                            await node_manager.api_request('POST', f'/{vps_type}/container/{container_name}/stop', node_info['url'], node_info['api_key'], data={"force": True})
                            db.suspend_vps(container_name, reason='insufficient_credits')
                            user = await self.bot.fetch_user(user_id)
                            await user.send(embed=discord.Embed(title="🔴 VPS Suspended", description=f"Your VPS `{container_name}` was suspended due to insufficient credits for renewal ({user_balance}/{renewal_cost} credits).", color=0x992D22))
                        except Exception as e:
                            logging.error(f"Failed to suspend paid VPS {container_name}: {e}")
    
    @tasks.loop(hours=24)
    async def check_paid_vps_for_deletion(self):
        await self.bot.wait_until_ready()
        logging.info("Starting daily suspended paid VPS deletion check.")

        try:
            vps_to_delete = db.get_suspended_paid_vps_for_deletion(days=7)
        except AttributeError:
            logging.warning("`db.get_suspended_paid_vps_for_deletion()` not found. Skipping paid VPS deletion check. This feature may not be implemented in the database.")
            return

        for vps in vps_to_delete:
            user_id = vps['user_id']
            container_name = vps['container_name']
            node_name = vps['node']
            vps_type = vps['vps_type']
            
            user = await self.bot.fetch_user(user_id)
            node_info = node_manager.NODES.get(node_name)

            if not node_info:
                logging.error(f"Node '{node_name}' not found for VPS {container_name}. Cannot delete.")
                continue

            logging.info(f"Paid VPS {container_name} by {user_id} suspended for too long. Deleting...")

            try:
                await node_manager.api_request('DELETE', f'/{vps_type}/container/{container_name}', node_info['url'], node_info['api_key'])
                db.delete_vps(vps['id'])
                
                embed = discord.Embed(
                    title="VPS Deleted",
                    description=f"Your VPS `{container_name}` has been deleted because it remained suspended for more than 7 days due to insufficient credits.",
                    color=0x992D22
                )
                await user.send(embed=embed)
                logging.info(f"Paid VPS {container_name} deleted and user {user_id} notified.")
            except Exception as e:
                logging.error(f"Failed to delete paid VPS {container_name} for user {user_id}: {e}", exc_info=True)
                await user.send(f"⚠️ Failed to delete your VPS `{container_name}`. Please contact support. Error: `{e}`")

    @tasks.loop(hours=24)
    async def check_invite_vps_for_deletion(self):
        await self.bot.wait_until_ready()
        logging.info("Starting daily suspended invite-tier VPS deletion check.")

        try:
            vps_to_delete = db.get_suspended_invite_tier_vps_for_deletion(days=2)
        except AttributeError:
            logging.warning("`db.get_suspended_invite_tier_vps_for_deletion()` not found. Skipping invite VPS deletion check.")
            return

        for vps in vps_to_delete:
            user_id = vps['user_id']
            container_name = vps['container_name']
            node_name = vps['node']
            
            user = await self.bot.fetch_user(user_id)
            node_info = node_manager.NODES.get(node_name)

            if not node_info:
                logging.error(f"Node '{node_name}' not found for VPS {container_name}. Cannot delete.")
                continue

            logging.info(f"Invite-tier VPS {container_name} by {user_id} suspended for too long. Deleting...")

            try:
                # Attempt to delete the container via API
                await node_manager.api_request('DELETE', f'/lxc/container/{container_name}', node_info['url'], node_info['api_key'])
                db.delete_vps(vps['id'])
                
                embed = discord.Embed(
                    title="VPS Deleted",
                    description=f"Your invite-based VPS `{container_name}` has been deleted because it remained suspended for more than 2 days without the invite requirements being met.",
                    color=0x992D22
                )
                await user.send(embed=embed)
                logging.info(f"Invite-tier VPS {container_name} deleted and user {user_id} notified.")

            except Exception as e:
                logging.error(f"Failed to delete invite-tier VPS {container_name} for user {user_id}: {e}", exc_info=True)
                await user.send(f"⚠️ Failed to delete your VPS `{container_name}`. Please contact support. Error: `{e}`")

    @tasks.loop(hours=24) # Run once every 24 hours
    async def check_invite_vps_requirements(self):
        await self.bot.wait_until_ready()
        logging.info("Starting daily invite-based VPS requirements check.")

        all_invite_vps = db.get_all_invite_vps()
        current_month_id = db.get_current_month_id()

        for vps in all_invite_vps:
            user_id = vps['user_id']
            vps_id = vps['id']
            container_name = vps['container_name']
            invite_plan_tier = vps['invite_plan_tier']
            is_suspended = vps['is_suspended']
            node_name = vps['node']

            renewal_info = db.get_invite_plan_renewal_info(vps_id)
            if not renewal_info:
                logging.warning(f"No renewal info found for invite VPS ID {vps_id}. Skipping.")
                continue

            # If the renewal month is the current month, check invites
            if renewal_info['renewal_month_id'] == current_month_id:
                required_invites = renewal_info['required_invites']
                valid_invites = db.get_valid_invite_count(user_id, current_month_id)
                
                user = await self.bot.fetch_user(user_id)
                node_info = node_manager.NODES.get(node_name)

                if not node_info:
                    logging.error(f"Node '{node_name}' not found for VPS {container_name}. Cannot check/control.")
                    continue

                if valid_invites < required_invites:
                    if not is_suspended:
                        logging.info(f"VPS {container_name} ({invite_plan_tier}) by {user_id} not meeting invite requirements ({valid_invites}/{required_invites}). Suspending...")
                        try:
                            await node_manager.api_request('POST', f'/lxc/container/{container_name}/stop', node_info['url'], node_info['api_key'], data={"force": True})
                            db.suspend_vps(container_name, reason='invites_not_met')
                            
                            embed = discord.Embed(
                                title="VPS Suspended",
                                description=f"Your invite-based VPS `{container_name}` has been suspended because you no longer meet the **{required_invites}** valid invites requirement for this month. You currently have **{valid_invites}**.",
                                color=0x992D22
                            )
                            embed.set_footer(text="Get more valid invites to have your VPS unsuspended.")
                            await user.send(embed=embed)
                        except Exception as e:
                            logging.error(f"Failed to suspend invite VPS {container_name} for user {user_id}: {e}", exc_info=True)
                else: # Requirements are met
                    if is_suspended and vps.get('suspension_reason') == 'invites_not_met':
                        logging.info(f"VPS {container_name} by {user_id} now meeting invite requirements ({valid_invites}/{required_invites}). Unsuspending...")
                        try:
                            await node_manager.api_request('POST', f'/lxc/container/{container_name}/start', node_info['url'], node_info['api_key'])
                            db.unsuspend_vps(container_name)

                            embed = discord.Embed(
                                title="VPS Unsuspended",
                                description=f"Your invite-based VPS `{container_name}` has been unsuspended as you now meet the invite requirement.",
                                color=0x2ECC71
                            )
                            await user.send(embed=embed)
                        except Exception as e:
                            logging.error(f"Failed to unsuspend invite VPS {container_name} for user {user_id}: {e}", exc_info=True)
            
            # If the VPS is due for renewal (due_date is in the past), update the renewal_month_id
            elif vps['due_date'] < datetime.now(pytz.utc):
                 db.update_invite_plan_renewal_info(vps_id, renewal_info['required_invites'], current_month_id)


    @tasks.loop(hours=24) # Run once every 24 hours
    async def check_ad_vps_requirements(self):
        await self.bot.wait_until_ready()
        logging.info("Starting daily ad-supported VPS renewal check.")

        all_ad_vps = db.get_all_ad_tier_vps()
        now_utc = datetime.now(pytz.utc)

        # First, handle unsuspension for those who have earned enough points
        for vps in all_ad_vps:
            if vps['is_suspended'] and vps.get('suspension_reason') == 'ads_not_met':
                user_id = vps['user_id']
                plan_tier = vps.get('plan_tier')
                if not plan_tier or plan_tier not in LXC_AD_TIERS:
                    continue

                tier_info = LXC_AD_TIERS[plan_tier]
                required_points = tier_info['ads_required']
                user_vps_points = db.get_vps_points(user_id)

                if user_vps_points >= required_points:
                    logging.info(f"Unsuspending VPS {vps['container_name']} for user {user_id} as they now have enough points.")
                    node_info = node_manager.get_node_for_vps(vps['container_name'])
                    if node_info:
                        try:
                            await node_manager.api_request('POST', f'/lxc/container/{vps["container_name"]}/start', node_info['url'], node_info['api_key'])
                            db.unsuspend_vps(vps['container_name'])
                            user = await self.bot.fetch_user(user_id)
                            await user.send(embed=discord.Embed(title="✅ VPS Unsuspended", description=f"Your VPS `{vps['container_name']}` has been unsuspended as you now have enough VPS points. Renewal will be processed shortly.", color=0x2ECC71))
                        except Exception as e:
                            logging.error(f"Failed to unsuspend ad-supported VPS {vps['container_name']}: {e}")

        # Second, process renewals and suspensions for active VPS
        all_ad_vps = db.get_all_ad_tier_vps() # Re-fetch to include newly unsuspended VPS
        for vps in all_ad_vps:
            if vps.get('is_suspended'):
                continue

            plan_tier = vps.get('plan_tier')
            if not plan_tier or plan_tier not in LXC_AD_TIERS:
                continue

            vps_due_date = ensure_aware(vps['due_date'])
            
            if vps_due_date < now_utc:
                user_id = vps['user_id']
                vps_id = vps['id']
                container_name = vps['container_name']
                tier_info = LXC_AD_TIERS[plan_tier]
                required_points = tier_info['ads_required']
                user_vps_points = db.get_vps_points(user_id)

                if user_vps_points >= required_points:
                    new_due_date = now_utc + timedelta(days=1)
                    conn, cursor = db.start_transaction()
                    try:
                        if db.consume_vps_points(user_id, required_points, cursor=cursor, conn=conn):
                            db.set_vps_due_date(vps_id, new_due_date, cursor=cursor, conn=conn)
                            db.commit_transaction(conn, cursor)
                            
                            logging.info(f"Renewed ad-supported VPS {container_name} for 1 day. New due date: {new_due_date.strftime('%Y-%m-%d %H:%M')}")
                        else:
                            db.rollback_transaction(conn, cursor)
                            logging.warning(f"Failed to consume points for VPS {container_name}, user {user_id} despite initial check.")
                    except Exception as e:
                        db.rollback_transaction(conn, cursor)
                        logging.error(f"Error renewing ad-supported VPS {container_name}: {e}")
                else:
                    # Not enough points, suspend
                    logging.info(f"VPS {container_name} for user {user_id} has insufficient points for renewal. Suspending.")
                    node_info = node_manager.get_node_for_vps(container_name)
                    if node_info:
                        try:
                            await node_manager.api_request('POST', f'/lxc/container/{container_name}/stop', node_info['url'], node_info['api_key'], data={"force": True})
                            db.suspend_vps(container_name, reason='ads_not_met')
                            user = await self.bot.fetch_user(user_id)
                            await user.send(embed=discord.Embed(title="🔴 VPS Suspended", description=f"Your ad-supported VPS `{container_name}` has been suspended because you do not have enough VPS points to cover the daily renewal cost of **{required_points} points**.", color=0x992D22))
                        except Exception as e:
                            logging.error(f"Failed to suspend ad-supported VPS {container_name}: {e}")

        logging.info("Daily ad-supported VPS renewal check complete.")

    @tasks.loop(hours=24) # Run once every 24 hours
    async def check_suspended_vps_for_deletion(self):
        await self.bot.wait_until_ready()
        logging.info("Starting daily suspended ad-supported VPS deletion check.")

        vps_to_delete = db.get_suspended_ad_tier_vps_for_deletion(days=2)

        for vps in vps_to_delete:
            user_id = vps['user_id']
            container_name = vps['container_name']
            node_name = vps['node']
            
            user = await self.bot.fetch_user(user_id)
            node_info = node_manager.NODES.get(node_name)

            if not node_info:
                logging.error(f"Node '{node_name}' not found for VPS {container_name}. Cannot delete.")
                continue

            logging.info(f"VPS {container_name} by {user_id} suspended for too long. Deleting...")

            try:
                # Attempt to delete the container via API
                await node_manager.api_request('DELETE', f'/lxc/container/{container_name}', node_info['url'], node_info['api_key'])
                db.delete_vps(vps['id'])
                
                embed = discord.Embed(
                    title="VPS Deleted",
                    description=f"Your VPS `{container_name}` has been deleted because it remained suspended for more than 2 days without the ad requirements being met.",
                    color=0x992D22
                )
                await user.send(embed=embed)
                logging.info(f"VPS {container_name} deleted and user {user_id} notified.")

            except Exception as e:
                logging.error(f"Failed to delete VPS {container_name} for user {user_id}: {e}", exc_info=True)
                await user.send(f"⚠️ Failed to delete your VPS `{container_name}`. Please contact support. Error: `{e}`")
        
        logging.info("Daily suspended ad-supported VPS deletion check complete.")

    @tasks.loop(minutes=10)  # Run every 10 minutes
    async def check_terms_acceptance(self):
        """Check if users with ad-tier VPS have accepted terms, send reminders."""
        await self.bot.wait_until_ready()
        logging.info("Starting terms acceptance verification check.")

        TERMS_ROLE_ID = 1358004304216064162
        GUILD_ID = 1337813607530102814
        
        guild = self.bot.get_guild(GUILD_ID)
        if not guild:
            logging.error(f"Could not find guild {GUILD_ID} to check terms. Task will not run.")
            return

        all_ad_vps = db.get_all_ad_tier_vps()

        for vps in all_ad_vps:
            user_id = vps['user_id']
            container_name = vps['container_name']
            
            try:
                member = None
                user_roles = []
                try:
                    member = await guild.fetch_member(user_id)
                    user_roles = [role.id for role in member.roles]
                except discord.NotFound:
                    logging.warning(f"User {user_id} for VPS {container_name} not found in guild {GUILD_ID}. Treating as not having terms role.")
                    user_roles = [] # Ensure roles list is empty if member not found

                # We need a user/member object to send DMs
                user = member or await self.bot.fetch_user(user_id)

                # Check if user has the terms role
                if TERMS_ROLE_ID not in user_roles:
                    reminder_info = db.get_terms_reminder_info(user_id)
                    reminder_count = reminder_info['terms_reminder_count'] if reminder_info else 0

                    if reminder_count < 3:
                        # Send reminder
                        db.increment_terms_reminder_count(user_id)
                        reminder_count += 1

                        embed = discord.Embed(
                            title=f"⚠️ Terms Acceptance Required - Reminder {reminder_count}/3",
                            description=f"You must accept the terms and conditions to maintain your ad-supported VPS `{container_name}`.\n\n"
                                        f"Please read and react to the terms message here:\n"
                                        f"https://discord.com/channels/1337813607530102814/1338196177782439987/1358026576385802381\n\n"
                                        f"**You have {4 - reminder_count} reminders left before suspension.**",
                            color=0xF39C12
                        )
                        try:
                            await user.send(embed=embed)
                            logging.info(f"Sent terms reminder {reminder_count} to user {user_id} for VPS {container_name}")
                        except discord.Forbidden:
                            logging.warning(f"Could not send DM to user {user_id}")

                    elif reminder_count >= 3 and not vps['is_suspended']:
                        # Suspend the VPS
                        logging.info(f"Suspending VPS {container_name} for user {user_id} due to missing terms acceptance after 3 reminders")
                        
                        try:
                            node_info = node_manager.NODES.get(vps['node'])
                            if node_info:
                                await node_manager.api_request('POST', f'/lxc/container/{container_name}/stop', node_info['url'], node_info['api_key'], data={"force": True})
                                db.suspend_vps(container_name, reason='terms_not_accepted')

                            embed = discord.Embed(
                                title="🔴 VPS Suspended",
                                description=f"Your VPS `{container_name}` has been suspended because you did not accept the terms and conditions after 3 reminders.\n\n"
                                            f"To unsuspend it, please accept the terms here:\n"
                                            f"https://discord.com/channels/1337813607530102814/1338196177782439987/1358026576385802381",
                                color=0x992D22
                            )
                            await user.send(embed=embed)
                            logging.info(f"Suspended VPS {container_name} for user {user_id} and sent notification")
                        except Exception as e:
                            logging.error(f"Failed to suspend VPS {container_name}: {e}")

                else: # User HAS the terms role
                    # User has terms role, reset reminder count if needed
                    reminder_info = db.get_terms_reminder_info(user_id)
                    if reminder_info and reminder_info['terms_reminder_count'] > 0:
                        db.reset_terms_reminder_count(user_id)
                        logging.info(f"Reset terms reminder count for user {user_id} (terms accepted)")

                    # If VPS was suspended for terms, unsuspend it
                    if vps['is_suspended'] and vps.get('suspension_reason') == 'terms_not_accepted':
                        logging.info(f"User {user_id} now has terms role, unsuspending VPS {container_name} (reason: terms_not_accepted).")
                        try:
                            node_info = node_manager.NODES.get(vps['node'])
                            if node_info:
                                await node_manager.api_request('POST', f'/lxc/container/{container_name}/start', node_info['url'], node_info['api_key'])
                                db.unsuspend_vps(container_name)

                            embed = discord.Embed(
                                title="✅ VPS Unsuspended",
                                description=f"Your VPS `{container_name}` has been unsuspended! Thank you for accepting the terms.",
                                color=0x2ECC71
                            )
                            await user.send(embed=embed)
                            logging.info(f"Auto-unsuspended VPS {container_name} for user {user_id} after they accepted terms.")
                        except Exception as e:
                            logging.error(f"Failed to auto-unsuspend VPS {container_name}: {e}", exc_info=True)

            except Exception as e:
                logging.error(f"Error checking terms for user {user_id}: {e}", exc_info=True)

        logging.info("Terms acceptance verification check complete.")

    async def notify_admin_for_setup(self, order_id: int):
        """Notifies the admin that a dedicated order is paid and ready for setup."""
        try:
            admin = await self.bot.fetch_user(ADMIN_USER_ID)
            order = db.get_dedicated_order(order_id)
            if not admin or not order:
                logging.error(f"Could not find admin ({ADMIN_USER_ID}) or order ({order_id}) for notification.")
                return

            customer = await self.bot.fetch_user(order['user_id'])
            
            embed = discord.Embed(
                title="✅ Dedicated Server Order Paid",
                description=f"A new dedicated server order has been paid and requires setup.",
                color=0x2ECC71
            )
            embed.add_field(name="Order ID", value=f"`{order['id']}`", inline=False)
            embed.add_field(name="Customer", value=f"{customer.mention} (`{customer.id}`)", inline=False)
            embed.add_field(name="Plan", value=order['plan_name'], inline=True)
            embed.add_field(name="Price Paid", value=f"€{order['price_eur']:.2f}", inline=True)
            embed.set_footer(text="Click the button below to provision the VPS.")

            view = AdminSetupView(self.bot, order_id)
            await admin.send(embed=embed, view=view)
            logging.info(f"Sent dedicated order setup notification to admin for order {order_id}")

        except Exception as e:
            logging.error(f"Failed to send admin notification for order {order_id}: {e}", exc_info=True)

    @tasks.loop(count=1) # Run once
    async def initial_panel_deployment(self):
        await self.bot.wait_until_ready()
        logging.info("Starting initial panel deployment/update...")
        reports = await self._deploy_initial_panels()
        for report in reports:
            logging.info(report)
        logging.info("Initial panel deployment/update complete.")

    async def _deploy_initial_panels(self) -> list[str]:
        """Deploys or updates the plan selection panels in their designated channels."""
        reports = []
        
        # Helper function to deploy or update a panel
        async def _deploy_panel(panel_type: str, channel_id: int, embed: discord.Embed, view: discord.ui.View):
            message = None
            channel = None
            try:
                channel = self.bot.get_channel(channel_id) or await self.bot.fetch_channel(channel_id)
                if not channel:
                    logging.error(f"Failed to find channel with ID {channel_id} for panel type '{panel_type}'.")
                    return f"❌ Failed to find channel for '{panel_type}' (ID: {channel_id}). Please check the ID and bot's access."
            except discord.Forbidden:
                logging.error(f"Bot lacks permissions to access channel {channel_id} for panel type '{panel_type}'.")
                return f"❌ Bot lacks permissions to access channel <#{channel_id}> for '{panel_type}'. Please check permissions."
            except Exception as e:
                logging.error(f"Unexpected error fetching channel {channel_id} for panel type '{panel_type}': {e}", exc_info=True)
                return f"❌ Unexpected error fetching channel for '{panel_type}' (ID: {channel_id}): {e}"

            panel_info = db.get_plan_panel_message(panel_type)
            if panel_info:
                try:
                    # Ensure the stored channel_id matches the target channel_id
                    if panel_info[0] != channel_id:
                        logging.warning(f"Stored channel ID ({panel_info[0]}) for '{panel_type}' does not match target channel ID ({channel_id}). Sending new message.")
                        # Proceed to send a new message
                    else:
                        message = await channel.fetch_message(panel_info[1])
                        await message.edit(embed=embed, view=view)
                        return f"✅ Updated panel '{panel_type}' in <#{channel.id}> (Message ID: {message.id})"
                except (discord.NotFound, discord.Forbidden):
                    logging.warning(f"Existing message {panel_info[1]} for '{panel_type}' not found or inaccessible in <#{channel.id}>. Sending new message.")
                    # Message not found or inaccessible, proceed to send a new one
                except Exception as e:
                    logging.error(f"Unexpected error editing existing message {panel_info[1]} for '{panel_type}' in <#{channel.id}>: {e}", exc_info=True)
                    return f"❌ Unexpected error editing existing panel for '{panel_type}' in <#{channel.id}>: {e}"
            
            # Send a new message if none exists or the old one was not found/edited
            try:
                message = await channel.send(embed=embed, view=view)
                db.save_plan_panel_message(panel_type, channel.id, message.id)
                return f"✅ Deployed panel '{panel_type}' to <#{channel.id}> (Message ID: {message.id})"
            except discord.Forbidden:
                logging.error(f"Bot lacks permissions to send messages to channel {channel.id} for panel type '{panel_type}'.")
                return f"❌ Bot lacks permissions to send messages to <#{channel.id}> for '{panel_type}'. Please check permissions."
            except Exception as e:
                logging.error(f"Unexpected error sending new message for '{panel_type}' to <#{channel.id}>: {e}", exc_info=True)
                return f"❌ Unexpected error sending new panel for '{panel_type}' to <#{channel.id}>: {e}"

        # 1. Main Plans
        main_embed = discord.Embed(title="VPS Hosting Plans", description="Configure and purchase your own custom server.", color=0x2B2D31)
        main_embed.add_field(name="LXC Virtualization", value=f"**CPU:** ${PRICES_LXC['cpu']:.2f}/core\n**RAM:** ${PRICES_LXC['ram']:.2f}/GB\n**Disk:** ${PRICES_LXC['disk']:.3f}/GB", inline=True)
        main_embed.add_field(name="KVM Virtualization", value=f"**CPU:** ${PRICES_KVM['cpu']:.2f}/core\n**RAM:** ${PRICES_KVM['ram']:.2f}/GB\n**Disk:** ${PRICES_KVM['disk']:.2f}/GB", inline=True)
        main_embed.set_footer(text="Click a button below to start your order.")
        reports.append(await _deploy_panel('main', 1447244265540554763, main_embed, MainPlansView(self.bot)))

        # 2. Ad-Supported Plans
        ad_tiers_embed = discord.Embed(title="Ad-Supported VPS Plans", description="Get a free LXC VPS by watching daily ads.", color=0x2B2D31)
        ad_tiers_embed.add_field(name="Tier 1", value="1 vCPU, 750 MB RAM, 5 GB Disk\n*(1 ad/day required)*", inline=False)
        ad_tiers_embed.add_field(name="Tier 2", value="1 vCPU, 1.5 GB RAM, 10 GB Disk\n*(2 ads/day required)*", inline=False)
        ad_tiers_embed.add_field(name="Tier 3", value="2 vCPU, 2 GB RAM, 20 GB Disk\n*(4 ads/day required)*", inline=False)
        ad_tiers_embed.set_footer(text="VPS will be suspended if daily ad requirements are not met and deleted after 7 days if suspended.")
        reports.append(await _deploy_panel('ad_tiers', 1447244451306012682, ad_tiers_embed, AdTiersView(self.bot)))

        # 3. Dedicated Plans
        price_eur = 5.30
        dedi_embed = discord.Embed(title="Dedicated Server Plans", description=f"High-performance dedicated servers, located in **France** and billed monthly.", color=0x2B2D31)
        dedi_embed.add_field(name="Plan: vps-dedicaced-1", value=f"**Price: €{price_eur:.2f}/month**", inline=False)
        dedi_embed.add_field(name="CPU", value="1 Core @ 5.6 GHz\n*Ryzen 9 9900X*", inline=True)
        dedi_embed.add_field(name="RAM", value="4 GB\n*DDR5 5600MHz*", inline=True)
        dedi_embed.add_field(name="Disk", value="200 GB\n*NVME Gen-5 SSD*", inline=True)
        dedi_embed.add_field(name="Network", value="1 Gbps Port\n*Unlimited Traffic*", inline=True)
        dedi_embed.add_field(name="IP Address", value="1 Dedicated IPv4\n*€2.00 / additional IP*", inline=True)
        dedi_embed.add_field(name="Backups", value="Daily Backups\n*7-Day Retention*", inline=True)
        reports.append(await _deploy_panel('dedicated', 1447244755430801521, dedi_embed, DedicatedPlansView(self.bot)))

        # 4. Invite Plans
        invite_embed = discord.Embed(title="Invite for VPS", description="Invite your friends and get a free VPS! Below are the tiers:", color=0x2B2D31)
        for tier_id, tier_info in INVITE_PLANS.items():
            invite_embed.add_field(name=tier_info['name'], value=f"{tier_info['cpu']} vCPU, {tier_info['ram']} GB RAM, {tier_info['disk']} GB Disk\n*({tier_info['invites_required']} invites/month)*", inline=False)
        invite_embed.set_footer(text="VPS will be suspended if monthly invite requirements are not met.")
        reports.append(await _deploy_panel('invite_plans', 1449707721212432385, invite_embed, InvitePlansView(self.bot)))

        return reports

# New LXC Ad Tiers (replaces PRICES_FREE)
LXC_AD_TIERS = {
    "tier1": {"cpu": 1, "ram": 0.75, "disk": 5, "ads_required": 1, "name": "Tier 1"},
    "tier2": {"cpu": 1, "ram": 1.5, "disk": 10, "ads_required": 2, "name": "Tier 2"},
    "tier3": {"cpu": 2, "ram": 2.0, "disk": 20, "ads_required": 4, "name": "Tier 3"},
}

# Invite Plans
INVITE_PLANS = {
    "tier1": {"cpu": 1, "ram": 1, "disk": 10, "invites_required": 5, "name": "Invite Tier 1"},
    "tier2": {"cpu": 1, "ram": 2, "disk": 15, "invites_required": 12, "name": "Invite Tier 2"},
    "tier3": {"cpu": 2, "ram": 3, "disk": 20, "invites_required": 25, "name": "Invite Tier 3"},
}
CUSTOM_INVITE_COST = {
    "cpu": 8,   # invites per core
    "ram": 5,   # invites per GB
    "disk": 3,  # invites per 5GB
}

# New WatchAdsForVpsView
class WatchAdsForVpsView(discord.ui.View):
    def __init__(self, bot: commands.Bot, user_id: int):
        super().__init__(timeout=180)
        self.bot = bot
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.user_id:
            return True
        await interaction.response.defer(ephemeral=True)
        await interaction.followup.send("This is not for you.", ephemeral=True)
        return False
        
    @discord.ui.button(label="Watch Ads Now", style=discord.ButtonStyle.success, custom_id="watch_ads_for_vps")
    async def watch_ads_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        user_id = self.user_id

        earn_cog = self.bot.get_cog("WatchAds")
        if not earn_cog:
            await interaction.followup.send("The earn feature is currently unavailable.", ephemeral=True)
            return

        # Cooldown check
        if user_id not in [1047760053509312642, 1286418351035388006]:  # Admin check
            last_watch_cuty = db.get_last_watch_date(user_id, 'cuty')
            cuty_done = last_watch_cuty and (datetime.now(pytz.utc) - last_watch_cuty).days < 1
            daily_watches = db.get_linkvertise_daily_watches(user_id)
            today_utc = datetime.now(pytz.utc).date()
            today_watches = [watch for watch in daily_watches if watch.astimezone(pytz.utc).date() == today_utc]
            linkvertise_done = len(today_watches) >= 5
            if cuty_done and linkvertise_done:
                embed = discord.Embed(title="Daily Ad Limit Reached", description="You have already earned credits from all available methods today. Please try again tomorrow.", color=0x992D22)
                await interaction.followup.send(embed=embed, ephemeral=True)
                return

        ad_token, _, is_new_session = await earn_cog._get_or_create_ad_session(user_id)

        if not is_new_session:
            flask_url_for_active_link = f"{FLASK_BASE_URL}/watch-ads/{user_id}/{ad_token}"
            embed = discord.Embed(
                title="You already have an active ad link!",
                description=(
                    "You currently have an active ad session. Please use the existing link to earn credits.\n\n"
                    f"**Your active link:** [Continue Watching Ads]({flask_url_for_active_link})\n\n"
                    "This link will expire in 4 hours from when it was created."
                ),
                color=0x99AAB5
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        flask_url = f"{FLASK_BASE_URL}/watch-ads/{user_id}/{ad_token}"

        embed = discord.Embed(
            title="Watch Ads, Get a VPS!",
            description=(
                f"**[Click here to Watch Ads]({flask_url})**\n\n"
                "You will complete the entire process on the website to earn VPS Points.\n"
                "After watching, come back and try to create the VPS again.\n\n"
                "This session will **expire in 4 hours**."
            ),
            color=0xE5E6EB
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

# New AdTiersView (replaces FreePlansView)
class AdTiersView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot
        # Add buttons for each tier
        for tier_id, tier_info in LXC_AD_TIERS.items():
            button = discord.ui.Button(
                label=f"{tier_info['name']} ({tier_info['cpu']}c, {tier_info['ram']}GB, {tier_info['disk']}GB)",
                style=discord.ButtonStyle.primary,
                custom_id=f"ad_tier:{tier_id}"
            )
            button.callback = self.tier_button_callback
            self.add_item(button)
        
        balance_button = discord.ui.Button(label="Balance", style=discord.ButtonStyle.secondary, custom_id="ad_tier_balance")
        balance_button.callback = self.balance_button
        self.add_item(balance_button)

    async def tier_button_callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        # Check if user has accepted terms (has the required role)
        TERMS_ROLE_ID = 1358004304216064162
        user_roles = [role.id for role in interaction.user.roles]
        if TERMS_ROLE_ID not in user_roles:
            embed = discord.Embed(
                title="Terms Not Accepted",
                description=f"You must accept the terms and conditions before creating a free VPS.\n\n"
                            f"Please read and react to the terms message here: https://discord.com/channels/1337813607530102814/1338196177782439987/1358026576385802381",
                color=0x992D22 # Red
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
        
        tier_id = interaction.data['custom_id'].split(':')[1]
        tier_info = LXC_AD_TIERS[tier_id]
        
        # Check if user already has an ad-tier VPS
        existing_ad_vps_count = db.get_user_ad_tier_vps_count(interaction.user.id)
        if existing_ad_vps_count >= 1:
            embed = discord.Embed(
                title=f"{tier_info['name']} - Limit Reached",
                description=f"You can only have **1 ad-supported VPS** at a time. Please delete or manage your current VPS before creating another.",
                color=0x992D22 # Red
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
        
        # Check VPS Points instead of ad watch count
        required_points = tier_info['ads_required']
        user_vps_points = db.get_vps_points(interaction.user.id)
        
        if user_vps_points < required_points:
            points_needed = required_points - user_vps_points
            embed = discord.Embed(
                title=f"{tier_info['name']} - VPS Points Required",
                description=f"This plan requires **{required_points}** VPS Points to create.\n\n"
                            f"You have **{user_vps_points}** VPS Points. "
                            f"You need **{points_needed} more** VPS Points to create this VPS.",
                color=0x992D22 # Red
            )
            embed.add_field(name="How to Get VPS Points", value="Watch **Linkvertise** ads on `/earn` command. Each ad watched = 1 VPS Point.", inline=False)
            view = WatchAdsForVpsView(self.bot, interaction.user.id)
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
            return

        # If they have enough ads, proceed to node selection
        cost_credits = 0 
        
        available_nodes = {}
        for name, node in node_manager.NODES.items():
            # Only allow LXC nodes for ad tiers
            if (node.get("type") == "lxc" or "lxc" in name.lower()) and not node.get("premium", False):
                available_nodes[name] = node

        if not available_nodes:
            embed = discord.Embed(title="No Free Nodes Available", description="There are currently no available FREE nodes for ad-supported plans. Premium nodes are not allowed for free VPS.", color=0x992D22)
            await interaction.followup.send(embed=embed, ephemeral=True)
            return
            
        node_stats_tasks = [node_manager.get_node_stats(name, info) for name, info in available_nodes.items()]
        node_results = await asyncio.gather(*node_stats_tasks)
        
        node_info_list = []
        for i, (node_name, node_config) in enumerate(available_nodes.items()):
            stats = node_results[i]
            current, max_cap = stats['lxc_current'], stats['lxc_max']
            node_info_list.append({"name": node_name, "current": current, "max": max_cap, "config": node_config})

        embed = discord.Embed(
            title=f"Select a Node for your {tier_info['name']} VPS",
            description=f"You have met the ad requirement for this plan. Please select a node below to create your VPS.",
            color=0xE5E6EB
        )
        for node_data in node_info_list:
            embed.add_field(
                name=f"Node: {node_data['name'].capitalize()}",
                value=f"Usage: {node_data['current']}/{node_data['max']} LXCs",
                inline=True
            )
        
        view = NodeSelectionView(
            self.bot, tier_info['cpu'], tier_info['ram'], tier_info['disk'], cost_credits,
            interaction.user.id, interaction.user.name,
            'lxc', interaction, node_info_list, plan_tier=tier_id
        )
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    async def balance_button(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)
        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(name="Pending Credits", value=f"**{pending_balance}**", inline=True)
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)



async def setup(bot: commands.Bot):
    cog = Plans(bot)
    await bot.add_cog(cog)
    # The following database calls should be moved to a single setup script or file
    # but for now, we will add them here to ensure they are created.
    # db.create_dedicated_orders_table()
    # db.create_reminders_table()