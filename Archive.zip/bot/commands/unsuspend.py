import discord
from discord.ext import commands
import logging
from bot.utils import node_manager
from bot.utils.database import db

logger = logging.getLogger(__name__)

# Specific user ID for restriction
AUTHORIZED_USER_ID = 1047760053509312642

class Unsuspend(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Change to a slash command
    @discord.app_commands.command(
        name="unsuspend",
        description="Unsuspends a VPS (LXC container or KVM VM)."
    )
    @discord.app_commands.describe(
        vps_type="The type of VPS to unsuspend (lxc or kvm).",
        container_name="The name of the container/VM to unsuspend."
    )
    async def unsuspend(self, interaction: discord.Interaction, vps_type: str, container_name: str):
        # Manual user ID check
        if interaction.user.id not in [AUTHORIZED_USER_ID, 1286418351035388006]:
            await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)
            return

        vps_type = vps_type.lower()

        if vps_type not in ['lxc', 'kvm']:
            await interaction.response.send_message("Invalid VPS type. Please use 'lxc' or 'kvm'.", ephemeral=True)
            return

        vps_info = db.get_vps_by_container_name(container_name)
        if not vps_info:
            await interaction.response.send_message(f"VPS '{container_name}' not found in the database.", ephemeral=True)
            return

        node_info = node_manager.get_node_for_vps(container_name)
        if not node_info:
            logger.error(f"Could not determine node for VPS {container_name}. Cannot unsuspend.")
            await interaction.response.send_message(f"Error: Could not determine node for VPS '{container_name}'.", ephemeral=True)
            return

        node_url, api_key = node_info['url'], node_info['api_key']

        endpoint = ""
        if vps_type == 'lxc':
            # Use 'start' for LXC containers after suspension
            endpoint = f"/lxc/container/{container_name}/start"
        elif vps_type == 'kvm':
            # Use 'start' for KVM VMs
            endpoint = f"/kvm/vm/{container_name}/start"

        try:
            await interaction.response.defer(ephemeral=True) # Defer the response as the API call might take time

            result = await node_manager.api_request('POST', endpoint, node_url, api_key)

            if result and result.get("status") == "success":
                db.unsuspend_vps(container_name)
                db.reset_suspicion_count(container_name) # Reset suspicion count on unsuspend
                db.clear_suspicion_logs(container_name) # Clear suspicion logs
                embed = discord.Embed(
                    title="VPS Unsuspended",
                    description=f"The {vps_type.upper()} '{container_name}' has been successfully unsuspended.",
                    color=discord.Color.green()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                logger.info(f"VPS {container_name} unsuspended by admin {interaction.user.name} ({interaction.user.id}).")
            else:
                error_message = result.get('error', 'Unknown error') if result else 'No response from API'
                await interaction.followup.send(f"Failed to unsuspend {vps_type.upper()} '{container_name}': {error_message}", ephemeral=True)
                logger.error(f"Failed to unsuspend VPS {container_name}: {error_message}")

        except Exception as e:
            logger.error(f"Error unsuspending VPS {container_name}: {e}")
            await interaction.followup.send(f"An unexpected error occurred while unsuspending VPS '{container_name}'.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Unsuspend(bot))