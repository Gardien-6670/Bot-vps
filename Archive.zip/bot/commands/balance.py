import discord
from discord.ext import commands
from discord import app_commands
from bot.utils.database import db

class Balance(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="balance", description="Displays your credit balance")
    @app_commands.guild_only()
    async def balance(self, ctx: commands.Context):
        user_id = ctx.author.id
        balance = db.get_balance(user_id)
        pending_balance = db.get_pending_balance(user_id)
        vps_points = db.get_vps_points(user_id)

        embed = discord.Embed(title="Your Balance", color=0xE5E6EB)
        embed.add_field(name="Available Credits", value=f"**{balance}**", inline=True)
        embed.add_field(name="Pending Credits", value=f"**{pending_balance}**", inline=True)
        embed.add_field(name="VPS Points", value=f"**{vps_points}**", inline=True)
        await ctx.send(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(Balance(bot))