import discord
from discord.ext import tasks, commands
from bot.utils.database import db
from datetime import datetime
import os
import aiohttp
import json
import asyncio
from bot.utils import node_manager

class ServerStats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.category_id = 1338194380602736721
        self.update_stats.start()

    async def cog_unload(self):
        self.update_stats.cancel()

    @tasks.loop(minutes=5)
    async def update_stats(self):
        await self.bot.wait_until_ready()
        category = self.bot.get_channel(self.category_id)
        if not category:
            return

        guild = category.guild

        # Get stats
        humans = sum(1 for member in guild.members if not member.bot)
        bots = sum(1 for member in guild.members if member.bot)
        
        active_vps_count = 0
        total_lxc_vps = 0
        total_kvm_vps = 0

        for node_name, node_info in node_manager.NODES.items():
            try:
                lxc_stats = await node_manager.api_request('GET', "/lxc/stats", node_info['url'], node_info['api_key'], timeout_seconds=5)
                if lxc_stats:
                    total_lxc_vps += lxc_stats.get('active_containers', 0)
            except Exception as e:
                print(f"LXC API Error for node {node_name}: {e}")

            try:
                kvm_stats = await node_manager.api_request('GET', "/kvm/stats", node_info['url'], node_info['api_key'], timeout_seconds=5)
                if kvm_stats:
                    total_kvm_vps += kvm_stats.get('active_vms', 0)
            except Exception as e:
                print(f"KVM API Error for node {node_name}: {e}")

        active_vps_count = total_lxc_vps + total_kvm_vps

        active_vps = active_vps_count if active_vps_count > 0 else 'N/A'

        # Get transactions count from OxaPay API
        oxapay_transactions = 0
        merchant_api_key = os.getenv("OXAPAY_MERCHANT_KEY")
        if merchant_api_key:
            now = datetime.now()
            first_day_of_month = datetime(now.year, now.month, 1)
            if now.month == 12:
                first_day_of_next_month = datetime(now.year + 1, 1, 1)
            else:
                first_day_of_next_month = datetime(now.year, now.month + 1, 1)

            start_timestamp = int(first_day_of_month.timestamp())
            end_timestamp = int(first_day_of_next_month.timestamp())

            # Headers pour l'authentification
            headers = {
                'merchant_api_key': merchant_api_key,
                'Content-Type': 'application/json'
            }
            
            # Paramètres de requête
            params = {
                'from_date': start_timestamp,
                'to_date': end_timestamp,
                'status': 'Paid',
                'size': 200  # Maximum de résultats par page
            }
            
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get('https://api.oxapay.com/v1/payment', headers=headers, params=params) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            # Vérifier si la requête a réussi
                            if data.get('status') == 200:
                                oxapay_transactions = data.get('data', {}).get('meta', {}).get('total', 0)
                except Exception as e:
                    print(f"OxaPay Exception: {e}")

        paypal_transactions = db.get_paypal_transactions_this_month()
        transactions_this_month = oxapay_transactions + paypal_transactions
        
        try:
            total_ads_watched = db.get_ads_watched_today()
        except AttributeError:
            total_ads_watched = db.get_total_ads_watched() # Fallback to total if daily function doesn't exist
        
        print(f"Transactions - OxaPay: {oxapay_transactions}, PayPal: {paypal_transactions}, Total: {transactions_this_month}")

        # Channel names and prefixes
        channel_info = {
            "humans": {"name": f"Humans: {humans}", "prefix": "Humans:"},
            "bots": {"name": f"Bots: {bots}", "prefix": "Bots:"},
            "vps": {"name": f"Active VPS: {active_vps}", "prefix": "Active VPS:"},
            "transactions": {"name": f"Transactions (month): {transactions_this_month}", "prefix": "Transactions (month):"},
            "ads": {"name": f"Ads Today: {total_ads_watched}", "prefix": "Ads Today:"},
        }

        for key, info in channel_info.items():
            name = info["name"]
            prefix = info["prefix"]
            channel_id = db.get_stats_channel_id(key)
            channel = self.bot.get_channel(channel_id) if channel_id else None

            if channel is None and channel_id is not None:
                # Channel was deleted, so remove it from DB
                db.delete_stats_channel(key)

            if not channel:
                # Search for channel by prefix
                found = False
                for ch in category.voice_channels:
                    if ch.name.startswith(prefix):
                        db.set_stats_channel_id(key, ch.id)
                        channel = ch
                        found = True
                        break
                if not found:
                    try:
                        overwrites = {
                            guild.default_role: discord.PermissionOverwrite(connect=False)
                        }
                        new_channel = await guild.create_voice_channel(name, category=category, overwrites=overwrites)
                        db.set_stats_channel_id(key, new_channel.id)
                    except discord.Forbidden:
                        print(f"Missing permissions to create channel: {name}")
                        return
                    except discord.HTTPException as e:
                        print(f"HTTP Exception creating channel: {e}")
                        return
            
            if channel and channel.name != name:
                try:
                    await channel.edit(name=name)
                except discord.Forbidden:
                    print(f"Missing permissions to edit channel: {channel.name}")
                except discord.HTTPException as e:
                    print(f"HTTP Exception editing channel: {e}")


async def setup(bot):
    await bot.add_cog(ServerStats(bot))